# Performance Fix Execution Order

## ✅ Scripts are Now Re-Runnable!

Both scripts have been updated to be **idempotent** - safe to run multiple times.

## Execution Steps

### 1. Run First: `100_performance_optimizations.sql`
```sql
-- Copy and paste this entire file into Supabase SQL Editor
-- Click "Run"
```

**What it does:**
- Drops all policies it will create (in a DO block at the top)
- Fixes 50 Auth RLS InitPlan warnings by wrapping `auth.uid()` in `(SELECT auth.uid())`
- Drops 9 duplicate indexes
- **Safe to re-run** - will drop existing policies before recreating

### 2. Run Second: `101_consolidate_policies.sql`
```sql
-- Copy and paste this entire file into Supabase SQL Editor  
-- Click "Run"
```

**What it does:**
- Drops all NEW consolidated policies first (in a DO block at the top)
- Drops all OLD policies that are being replaced
- Creates single consolidated policies for 18 tables
- Fixes 116 Multiple Permissive Policies warnings
- **Safe to re-run** - will drop policies before recreating

### 3. Run Third (Verification): `102_run_all_performance_fixes.sql`
```sql
-- Copy and paste this entire file into Supabase SQL Editor
-- Click "Run"
```

**What it does:**
- Displays summary of fixes
- Counts current policies and indexes
- Runs ANALYZE to update query planner statistics
- Shows what INFO-level warnings remain (optional fixes)

---

## What Changed?

### Before (Not Re-Runnable):
```sql
DROP POLICY IF EXISTS "some_policy" ON table;
CREATE POLICY "some_policy" ON table ...
```
**Problem:** If run twice, CREATE fails because DROP happened earlier

### After (Re-Runnable):
```sql
DO $$
BEGIN
  -- Drop ALL policies we're about to create
  DROP POLICY IF EXISTS "policy1" ON table1;
  DROP POLICY IF EXISTS "policy2" ON table2;
  -- ... all policies
END $$;

-- Then create them (no individual DROPs needed)
CREATE POLICY "policy1" ON table1 ...
CREATE POLICY "policy2" ON table2 ...
```
**Solution:** All DROPs happen first, then all CREATEs - safe to run multiple times

---

## Expected Results

After running all 3 scripts:

✅ **175 WARN-level warnings FIXED**
- 50 Auth RLS InitPlan 
- 116 Multiple Permissive Policies
- 9 Duplicate Indexes

ℹ️ **81 INFO-level warnings remain** (optional)
- See `103_optional_info_warnings.md` for details

---

## Troubleshooting

### If you get "policy already exists" errors:

The scripts are designed to prevent this, but if it happens:

**Option 1: Run the script again**
- The DO block at the top will drop the existing policy
- Then CREATE will succeed

**Option 2: Manual cleanup (not recommended)**
```sql
-- Find all policies on a table
SELECT policyname FROM pg_policies 
WHERE schemaname = 'public' AND tablename = 'your_table';

-- Drop specific policy
DROP POLICY IF EXISTS "policy_name" ON public.your_table;
```

### If you want to start fresh:

```sql
-- Drop ALL policies on a table
DO $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN (SELECT policyname FROM pg_policies WHERE schemaname = 'public' AND tablename = 'your_table')
  LOOP
    EXECUTE 'DROP POLICY IF EXISTS ' || quote_ident(r.policyname) || ' ON public.your_table';
  END LOOP;
END $$;
```

---

## Summary

1. ✅ Scripts 100 and 101 are now **idempotent** (safe to re-run)
2. ✅ Run them in order: 100 → 101 → 102
3. ✅ All WARN-level performance issues will be resolved
4. ℹ️ INFO-level warnings are optional (see 103 for guidance)

**You're ready to execute!** 🚀
