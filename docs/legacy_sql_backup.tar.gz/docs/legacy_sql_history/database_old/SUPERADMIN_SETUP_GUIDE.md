# 🎯 SuperAdmin Account Setup - Quick Guide

## ✅ What We Did

Changed your SuperAdmin account from `admin@praahis.com` to your personal email `prashanthkumareddy879@gmail.com`.

---

## 📋 Run These Scripts in Order

### **Step 1: Set Your Personal Email as SuperAdmin**

1. Open **Supabase Dashboard** → SQL Editor
2. Copy and paste: `database/SET_PERSONAL_EMAIL_AS_SUPERADMIN.sql`
3. Click **Run**
4. Verify output shows:
   - ✅ `prashanthkumareddy879@gmail.com` is now SuperAdmin (`is_owner = true`)
   - ✅ `admin@praahis.com` successfully deleted

### **Step 2: Clean Database for Testing** *(Optional)*

Only run this if you want to remove all test restaurants and staff:

1. In Supabase SQL Editor
2. Copy and paste: `database/CLEAN_DATABASE_FOR_TESTING.sql`
3. Review what will be deleted (Step 1 output)
4. Click **Run** if you want to proceed

---

## 🔐 Your SuperAdmin Credentials

```
Email: prashanthkumareddy879@gmail.com
Password: 123456
Login URL: http://localhost:5173/superadmin-login
```

⚠️ **SECURITY WARNING:** Change password `123456` immediately after first login!

---

## 🚀 How to Login

1. **Start your dev server** (if not running):
   ```bash
   npm run dev
   ```

2. **Clear browser data** (important!):
   - Chrome: Settings → Privacy → Clear browsing data
   - Or open **Incognito/Private window**

3. **Navigate to SuperAdmin login**:
   ```
   http://localhost:5173/superadmin-login
   ```

4. **Enter credentials**:
   - Email: `prashanthkumareddy879@gmail.com`
   - Password: `123456`

5. **You should see**: SuperAdmin Dashboard with "Create Restaurant" button

---

## 🔒 Change Your Password (CRITICAL!)

**Method 1: Via Forgot Password Flow**

1. Go to: `http://localhost:5173/superadmin-forgot-password`
2. Enter: `prashanthkumareddy879@gmail.com`
3. Check your email inbox
4. Click reset link
5. Set new strong password

**Method 2: Via Supabase Dashboard**

1. Supabase → Authentication → Users
2. Find `prashanthkumareddy879@gmail.com`
3. Click "..." → Reset Password
4. Use the recovery link

---

## 📝 Next Steps: Test Complete Workflow

### **As SuperAdmin:**

1. ✅ Login successful
2. ✅ Create restaurant: "The Spice Garden"
3. ✅ Add manager: `rahul@spice.com` / `Manager123!`
4. ✅ Logout

### **As Manager:**

1. ✅ Login at `/login` with `rahul@spice.com`
2. ✅ See Manager Dashboard
3. ✅ Add chef: `chef@spice.com` / `Chef123!`
4. ✅ Add waiter: `waiter@spice.com` / `Waiter123!`
5. ✅ Create menu items
6. ✅ Generate QR codes

### **As Customer:**

1. ✅ Scan QR code → Menu
2. ✅ Add items → Cart → Order
3. ✅ Make payment (test mode)
4. ✅ Track order status

### **As Chef:**

1. ✅ Login at `/login` with `chef@spice.com`
2. ✅ See orders
3. ✅ Update order status (Preparing → Ready)

### **As Waiter:**

1. ✅ Login at `/login` with `waiter@spice.com`
2. ✅ See tables and orders
3. ✅ Mark orders served

---

## 🔍 Verify Everything Works

Run this in Supabase SQL Editor:

```sql
-- Check your SuperAdmin account
SELECT 
  email,
  role,
  is_owner,
  restaurant_id,
  created_at
FROM public.users
WHERE email = 'prashanthkumareddy879@gmail.com';

-- Should show:
-- email: prashanthkumareddy879@gmail.com
-- role: admin
-- is_owner: true ✅
-- restaurant_id: NULL
```

---

## ⚠️ Troubleshooting

### Can't login?

1. Clear browser cache/localStorage
2. Try incognito window
3. Verify password is exactly: `123456` (case-sensitive)
4. Check Supabase SQL Editor that account exists

### Still see admin@praahis.com?

Run cleanup script again:
```sql
DELETE FROM public.users WHERE email = 'admin@praahis.com';
DELETE FROM auth.users WHERE email = 'admin@praahis.com';
```

### Wrong dashboard after login?

- SuperAdmin should go to: `/superadmin/dashboard`
- If you see staff dashboard, you're on wrong login page
- Use: `/superadmin-login` (NOT `/login`)

---

## 📚 Related Files

- `database/SET_PERSONAL_EMAIL_AS_SUPERADMIN.sql` - Make personal email SuperAdmin
- `database/CLEAN_DATABASE_FOR_TESTING.sql` - Remove test data
- `database/CHECK_SUPERADMIN_ACCOUNTS.sql` - Verify account status
- `src/pages/SuperAdminLogin.jsx` - SuperAdmin login page
- `src/pages/StaffLogin.jsx` - Staff login page (manager/chef/waiter)

---

## ✅ Summary

You now have:
- ✅ Personal email as SuperAdmin
- ✅ Old admin account deleted
- ✅ Clean database ready for testing
- ✅ Clear separation: SuperAdmin vs Staff logins
- ✅ Complete testing workflow documented

**Next:** Run the SQL script and login to test! 🚀
