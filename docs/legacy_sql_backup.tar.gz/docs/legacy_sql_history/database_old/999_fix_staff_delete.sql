-- ============================================================================
-- Fix Staff Delete Issue
-- Ensure deleted staff don't appear in list and delete works properly
-- ============================================================================

-- Update the list_staff function to only show non-deleted users
-- Also add better ordering
CREATE OR REPLACE FUNCTION public.list_staff_for_current_restaurant()
RETURNS SETOF public.users
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT u.*
  FROM public.users u
  WHERE u.restaurant_id = (
    SELECT restaurant_id FROM public.users WHERE id = auth.uid()
  )
  AND u.id IN (
    -- Only include users that still exist in auth.users
    SELECT id FROM auth.users
  )
  ORDER BY u.is_active DESC, u.role, u.full_name NULLS LAST;
$$;

-- Create a function to properly delete a staff member
-- This ensures both public.users and auth.users are handled
CREATE OR REPLACE FUNCTION public.admin_delete_staff_member(target_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  me public.users;
  target public.users;
BEGIN
  -- Get current user
  SELECT * INTO me FROM public.users WHERE id = auth.uid();
  IF me.id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  
  -- Only managers and admins can delete staff
  IF me.role NOT IN ('manager', 'admin') THEN
    RAISE EXCEPTION 'Insufficient permissions';
  END IF;

  -- Get target user
  SELECT * INTO target FROM public.users WHERE id = target_id;
  IF target.id IS NULL THEN
    RAISE EXCEPTION 'Target user not found';
  END IF;
  
  -- Prevent deleting yourself
  IF target.id = me.id THEN
    RAISE EXCEPTION 'Cannot delete yourself';
  END IF;
  
  -- Prevent cross-restaurant deletion
  IF target.restaurant_id IS DISTINCT FROM me.restaurant_id THEN
    RAISE EXCEPTION 'Cannot delete staff from other restaurants';
  END IF;

  -- Delete from public.users (this should cascade to related tables)
  DELETE FROM public.users WHERE id = target_id;
  
  -- Try to delete from auth.users (this requires admin privileges)
  -- Note: This might fail if not running as service role, but that's okay
  -- The auth.users entry will be orphaned but won't affect the UI
  BEGIN
    DELETE FROM auth.users WHERE id = target_id;
  EXCEPTION
    WHEN OTHERS THEN
      -- Log the error but don't fail the operation
      RAISE NOTICE 'Could not delete from auth.users: %', SQLERRM;
  END;
  
  RETURN true;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_delete_staff_member(uuid) TO authenticated;

COMMENT ON FUNCTION public.admin_delete_staff_member IS 'Permanently delete a staff member (manager/admin only)';
