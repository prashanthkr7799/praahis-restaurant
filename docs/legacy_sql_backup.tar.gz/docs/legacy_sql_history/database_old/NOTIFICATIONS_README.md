# Notifications System Setup

## Overview
Complete notifications system with realtime updates for the Manager Portal.

## Features
- ✅ Real-time notifications via Supabase subscriptions
- ✅ Notification types: Order, Payment, System, Staff, Alert
- ✅ Badge count for unread notifications
- ✅ Mark all as read functionality
- ✅ Dropdown notification center with scrolling list
- ✅ Clean manager user menu with settings & sign out
- ✅ Dark theme compatible
- ✅ RLS security policies

## Installation Steps

### 1. Run Database Migrations

In your Supabase SQL editor, run these files **in order**:

```bash
# 1. Create notifications table, RLS policies, helper functions, and enable realtime
database/20_notifications.sql

# 2. (Optional) Seed demo notifications for testing
database/21_notifications_seed.sql
```

**Note**: The migration now automatically enables realtime, so you don't need to manually configure it in the Supabase dashboard!

### 2. Verify Database Setup

After running the migrations, verify in Supabase:

1. Go to **Table Editor** → Check that `notifications` table exists
2. Go to **Authentication** → **Policies** → Verify RLS policies are enabled
3. Go to **Database** → **Functions** → Check `create_notification` function exists
4. Go to **Database** → **Replication** → Verify `notifications` table shows as enabled for realtime

### 3. Test the System

1. Start your dev server:
   ```bash
   npm run dev
   ```

2. Navigate to Manager Portal and login

3. You should see:
   - 🔔 Notifications bell icon in the header (with badge if you ran seed script)
   - 👤 User avatar dropdown with name and menu options

4. Click the bell to see notifications dropdown
   - Click "Mark all read" to clear badge
   - New notifications will appear in realtime

## Components Created

### 1. NotificationsBell.jsx
- Path: `src/Components/admin/NotificationsBell.jsx`
- Displays bell icon with unread count badge
- Opens dropdown with scrollable notification list
- Subscribes to realtime INSERT events
- Mark all read functionality
- Auto-refreshes on new notifications

### 2. ManagerUserMenu.jsx
- Path: `src/Components/admin/ManagerUserMenu.jsx`
- User avatar with initials
- Dropdown menu with:
  - Settings (navigates to `/manager/settings`)
  - Sign Out (signs out and redirects to login)

### 3. AdminHeader.jsx (Updated)
- Path: `src/Components/layouts/AdminHeader.jsx`
- Integrates both NotificationsBell and ManagerUserMenu
- Clean, tokenized dark theme styling
- Responsive layout

### 4. notificationHelpers.js
- Path: `src/utils/notificationHelpers.js`
- Utility functions:
  - `listNotifications()` - Fetch notifications for current user/restaurant
  - `markNotificationRead(id)` - Mark single notification as read
  - `markAllNotificationsRead(ids)` - Mark multiple as read
  - `subscribeToNotifications(callback)` - Subscribe to realtime updates
  - `getUnreadCount()` - Get unread notification count

## Database Schema

### notifications Table

```sql
CREATE TABLE public.notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  restaurant_id uuid REFERENCES public.restaurants(id) ON DELETE CASCADE,
  user_id uuid REFERENCES public.users(id) ON DELETE CASCADE,
  type text CHECK (type IN ('order','payment','system','staff','alert')),
  title text NOT NULL,
  body text,
  data jsonb DEFAULT '{}'::jsonb,
  is_read boolean DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
```

### Notification Types
- `order` - New orders, order updates, order completions
- `payment` - Payment confirmations, payment failures
- `system` - System messages, reports ready, maintenance alerts
- `staff` - Staff actions, shift changes, staff updates
- `alert` - Warnings, low stock, critical issues

## Creating Notifications

### Method 1: Using Helper Function (Recommended)

```sql
SELECT create_notification(
  'order',                          -- type
  'New Order Received',             -- title
  'Table 5 ordered 3 items',        -- body (optional)
  '{"order_id": "abc123"}'::jsonb,  -- data (optional)
  '550e8400-e29b-41d4-a716-446655440000', -- restaurant_id
  '660e8400-e29b-41d4-a716-446655440001'  -- user_id (optional)
);
```

### Method 2: Direct Insert

```sql
INSERT INTO public.notifications (restaurant_id, user_id, type, title, body)
VALUES (
  '550e8400-e29b-41d4-a716-446655440000',
  '660e8400-e29b-41d4-a716-446655440001',
  'payment',
  'Payment Successful',
  'Order #1234 paid ₹850'
);
```

### Method 3: From Application Code

```javascript
import { supabase } from '@/lib/supabaseClient';

await supabase.from('notifications').insert({
  restaurant_id: restaurantId,
  user_id: userId,
  type: 'alert',
  title: 'Low Stock Alert',
  body: 'Tomatoes inventory is running low',
  data: { item: 'Tomatoes', quantity: 5 }
});
```

## RLS Security

The notifications table has the following RLS policies:

- **SELECT**: Users can read notifications for their restaurant or assigned to them
- **INSERT**: Managers/admins can create notifications for their restaurant
- **UPDATE**: Users can mark their own/restaurant notifications as read
- **DELETE**: Only owners can delete notifications

## Customization

### Change Notification Badge Position
Edit `src/Components/admin/NotificationsBell.jsx`:
```jsx
<span className="absolute -top-1 -right-1 ...">
  {unreadCount}
</span>
```

### Add Toast for New Notifications
Already included! New notifications show a toast:
```jsx
toast.success(newNotification.title, {
  icon: '🔔',
  duration: 3000
});
```

### Change Dropdown Width
Edit `NotificationsBell.jsx`:
```jsx
<div className="absolute right-0 mt-2 w-[380px] ...">
```

### Add Click-to-Navigate
In `NotificationsBell.jsx`, add click handler to notification items:
```jsx
<li
  onClick={() => {
    // Navigate based on notification type/data
    if (notification.type === 'order') {
      navigate(`/manager/orders/${notification.data.order_id}`);
    }
    setOpen(false);
  }}
  ...
>
```

## Troubleshooting

### Notifications not showing?
1. Check Supabase SQL Editor for errors when running migrations
2. Verify RLS policies are enabled on `notifications` table
3. Check browser console for errors
4. Ensure user is authenticated and has proper role

### Realtime not working?
1. Verify the migration ran successfully - check for "realtime enabled successfully" message
2. If you see an error about `supabase_realtime` publication not existing, run this in Supabase SQL editor:
   ```sql
   -- Check if realtime publication exists
   SELECT * FROM pg_publication WHERE pubname = 'supabase_realtime';
   
   -- If it doesn't exist, create it
   CREATE PUBLICATION supabase_realtime;
   
   -- Then add the notifications table
   ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;
   ```
3. Restart your dev server
4. Check browser console for Supabase realtime connection errors
5. In Supabase Dashboard → Database → Replication, verify `notifications` table is listed

### Badge count incorrect?
1. Run SQL query to check unread count:
   ```sql
   SELECT COUNT(*) FROM notifications WHERE is_read = false;
   ```
2. Clear browser cache and reload
3. Check RLS policies allow SELECT on notifications

### No demo notifications after seed?
1. Ensure you have users with role 'manager' or 'admin' in the database
2. Check if seed script ran successfully (look for "seeded successfully" message)
3. Manually insert a test notification using Method 1 or 2 above

## Future Enhancements

- [ ] Notification preferences (email, SMS, push)
- [ ] Notification categories/filters
- [ ] Search notifications
- [ ] Archive old notifications
- [ ] Notification templates
- [ ] Bulk actions (delete, archive)
- [ ] Notification analytics

## Support

For issues or questions:
1. Check database/README.md for schema documentation
2. Review RLS policies in Supabase dashboard
3. Check browser console for JavaScript errors
4. Verify Supabase connection and authentication
