# 🗄️ Tabun Restaurant - Database Setup

Clean, production-ready database for your restaurant management system.

---

## 🚀 Quick Setup

Run these SQL files **in order** in your Supabase SQL Editor:

```
1. 01_schema.sql          → Tables, functions, triggers
2. 02_seed.sql            → Sample data (menu, tables)
3. 03_enable_realtime.sql → Live updates (orders, tables, menu_items, payments, ratings)
4. 04_production_rls.sql  → Security policies
5. 06_item_ratings.sql    → Per-item ratings table + RLS (optional but recommended)
6. 07_item_rating_summary.sql → Ratings summary/views (avg + count)
7. 08_verify.sql          → Post-install verification checklist
```

**Done!** Your database is ready for production.

---

## 📁 All Files

| # | File | Purpose | Required? |
|---|------|---------|-----------|
| 0 | `00_reset_database.sql` | Delete everything & start fresh | Optional |
| 1 | `01_schema.sql` | Create all 7 tables | ✅ Yes |
| 2 | `02_seed.sql` | Add sample data | ✅ Yes |
| 3 | `03_enable_realtime.sql` | Enable live updates | ✅ Yes |
| 4 | `04_production_rls.sql` | Security policies | ✅ Yes |
| 5 | `05_maintenance.sql` | Cleanup & reports | Optional |
| 6 | `06_item_ratings.sql` | Per-item ratings table + RLS | ✅ Recommended |
| 7 | `07_item_rating_summary.sql` | Ratings summary/views for menu | ✅ Recommended |
| 8 | `08_verify.sql` | Post-install verification | ✅ Recommended |

---

## 🗄️ What Gets Created

### 7 Tables:

1. **restaurants** - Your restaurant info
2. **tables** - Table 1, 2, 3... (with QR codes)
3. **menu_items** - Your menu (27 sample items included)
4. **orders** - Customer orders
5. **payments** - Razorpay transactions  
6. **feedbacks** - 1-5 star ratings
7. **users** - Staff accounts (waiter, chef, admin)

### Sample Data:

- 🏪 1 restaurant ("Tabun Restaurant")
- 🪑 10 tables (numbered 1-10)
- 🍕 27 menu items across 4 categories
- 👥 3 staff users (sample credentials)

---

## 🔒 Security (RLS)

**With RLS Enabled (`04_production_rls.sql`):**

✅ Customers can:
- View menu
- Create orders (no login!)
- Track their orders
- Leave feedback
 - Rate individual items (when 06/07 are applied)

🔐 Customers cannot:
- See other orders
- Access staff accounts
- Modify menu

---

## 🛠️ Common Issues

### "Trigger already exists"
**Solution:** Just re-run `01_schema.sql` - it's safe!

### "Row-level security policy violation"  
**Solution:** Run `04_production_rls.sql`

### "Realtime not working"
**Solution:** Run `03_enable_realtime.sql`

### Want to start over (Clean install)?
1. Run `00_reset_database.sql` (danger: deletes everything)
2. Run `01_schema.sql`
3. Run `02_seed.sql`
4. Run `03_enable_realtime.sql`
5. Run `04_production_rls.sql`
6. Run `06_item_ratings.sql` (recommended)
7. Run `07_item_rating_summary.sql` (recommended)
8. Run `08_verify.sql` to confirm everything

---

## ✅ Production Checklist

Before launching:

- [ ] All 4 core files run successfully (01, 02, 03, 04)
- [ ] Update sample data with real restaurant info
- [ ] Change staff passwords (use real hashes!)
- [ ] Test order creation
- [ ] Verify real-time updates work
- [ ] QR codes generated and tested
- [ ] Razorpay configured (production keys)

---

## 📝 Notes

- **JSONB for Order Items:** Orders table uses JSONB (not separate order_items table)
- **Order Numbers:** Auto-generated as `ORD-20251031-0001`
- **QR Code System:** Customers order without accounts
- **Safe to Re-run:** Schema file has `IF NOT EXISTS` checks

---

## 🆘 Need Help?

1. Check if files ran successfully (no red errors in Supabase)
2. Verify tables exist: `SELECT tablename FROM pg_tables WHERE schemaname = 'public';`
3. Check RLS status: `SELECT tablename, rowsecurity FROM pg_tables WHERE schemaname = 'public';`

**Remember:** Run in order: 01 → 02 → 03 → 04 ✅

---

## 🧩 Multitenancy + Supabase Auth (optional)

If you're using Supabase Auth and per-restaurant isolation, run these after the core setup:

```
10_multitenancy.sql    → Adds restaurant_id FKs + RLS across tables
11_rls_public_and_owner.sql (optional) → Owner bypass policies
12_seed_tenants.sql    → Seed sample restaurants (data-only)
13_users_rls_self.sql  → Fix users.last_login, drop recursive users policy, self-only users read/update, and upsert demo managers
```

After 13_users_rls_self.sql, try logging in with the seeded manager accounts per tenant (e.g., manager@tabun.local). If login fails, verify that a row exists in public.users matching your Auth user id and that `role=manager`, `is_active=true`, and `restaurant_id` is set.
