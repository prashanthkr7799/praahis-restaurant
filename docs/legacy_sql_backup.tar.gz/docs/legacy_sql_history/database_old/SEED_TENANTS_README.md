# Tenant Seed Summary

Run one of the following after setting environment variables (see below):

- SQL only (data): database/12_seed_tenants.sql
- Full (data + manager auth users): npm run seed:tenants

## Environment

Create a `.env.local` (or export envs) with:

```
VITE_SUPABASE_URL=https://<your-project>.supabase.co
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
APP_ORIGIN=https://your-app.example.com   # optional, defaults to http://localhost:5173
```

## Default Tenants

Below are the default manager credentials and important URLs. Replace the origin with your deployed host if needed.

- Tabun (slug: tabun)
  - Manager: manager@tabun.local / Tabun@123
  - Admin Login: ${APP_ORIGIN}/admin/login?restaurant=tabun
  - Chef Login:  ${APP_ORIGIN}/chef/login?restaurant=tabun
  - Waiter Login:${APP_ORIGIN}/waiter/login?restaurant=tabun
  - Sample Table: ${APP_ORIGIN}/table/1?restaurant=tabun

- Table 9 (slug: table9)
  - Manager: manager@table9.local / Table9@123
  - Admin Login: ${APP_ORIGIN}/admin/login?restaurant=table9
  - Chef Login:  ${APP_ORIGIN}/chef/login?restaurant=table9
  - Waiter Login:${APP_ORIGIN}/waiter/login?restaurant=table9
  - Sample Table: ${APP_ORIGIN}/table/1?restaurant=table9

- Red Chillis (slug: redchillis)
  - Manager: manager@redchillis.local / RedChillis@123
  - Admin Login: ${APP_ORIGIN}/admin/login?restaurant=redchillis
  - Chef Login:  ${APP_ORIGIN}/chef/login?restaurant=redchillis
  - Waiter Login:${APP_ORIGIN}/waiter/login?restaurant=redchillis
  - Sample Table: ${APP_ORIGIN}/table/1?restaurant=redchillis

- Demo Restaurant (slug: demo)
  - Manager: demo.manager@demo.local / Demo@123
  - Admin Login: ${APP_ORIGIN}/admin/login?restaurant=demo
  - Chef Login:  ${APP_ORIGIN}/chef/login?restaurant=demo
  - Waiter Login:${APP_ORIGIN}/waiter/login?restaurant=demo
  - Sample Table: ${APP_ORIGIN}/table/1?restaurant=demo

## Run the seed

- SQL (optional, data only)
  - Paste the contents of `database/12_seed_tenants.sql` into Supabase SQL Editor and run once.

- Node (recommended, creates manager auth users too)
  ```bash
  npm run seed:tenants
  ```

Notes:
- The Node script is idempotent: it reuses existing restaurants and users when present.
- Manager users are created via Supabase Admin API with email confirmed.
