#!/bin/bash
# ============================================================================
# Final Verification - Check SQL Files Are Ready
# ============================================================================

echo "🔍 Verifying SQL Files Status"
echo "=============================================="
echo ""

cd /Users/prashanth/Downloads/Praahis/database

# Check File 1
echo "File 1: 70_unified_login_rls_FIXED.sql"
if [ -f "70_unified_login_rls_FIXED.sql" ]; then
    LINES=$(wc -l < 70_unified_login_rls_FIXED.sql)
    AUTH_FUNCS=$(grep -c "public.auth_" 70_unified_login_rls_FIXED.sql)
    DROP_PAYMENTS=$(grep -c "DROP POLICY IF EXISTS.*payments_manager_select" 70_unified_login_rls_FIXED.sql)
    
    echo "  ✅ File exists"
    echo "  ✅ $LINES lines"
    echo "  ✅ $AUTH_FUNCS auth_* function references"
    echo "  ✅ DROP POLICY for payments_manager_select: $DROP_PAYMENTS"
else
    echo "  ❌ File not found!"
fi

echo ""

# Check File 2
echo "File 2: 71_security_audit_logging.sql"
if [ -f "71_security_audit_logging.sql" ]; then
    LINES=$(wc -l < 71_security_audit_logging.sql)
    AUTH_FUNCS=$(grep -c "public.auth_" 71_security_audit_logging.sql)
    DROP_LOGS=$(grep -c "DROP POLICY IF EXISTS.*auth_logs_manager_select" 71_security_audit_logging.sql)
    
    echo "  ✅ File exists"
    echo "  ✅ $LINES lines"
    echo "  ✅ $AUTH_FUNCS auth_* function references"
    echo "  ✅ DROP POLICY for auth_logs_manager_select: $DROP_LOGS"
else
    echo "  ❌ File not found!"
fi

echo ""
echo "=============================================="
echo "📋 Critical Checks"
echo "=============================================="
echo ""

# Verify no old function names
OLD_FUNCS_1=$(grep -c "auth\.get_user_role()\|auth\.get_user_restaurant_id()\|auth\.is_superadmin()" 70_unified_login_rls_FIXED.sql 2>/dev/null || echo "0")
OLD_FUNCS_2=$(grep -c "auth\.get_user_role()\|auth\.get_user_restaurant_id()\|auth\.is_superadmin()" 71_security_audit_logging.sql 2>/dev/null || echo "0")

if [ "$OLD_FUNCS_1" -eq "0" ] && [ "$OLD_FUNCS_2" -eq "0" ]; then
    echo "  ✅ No old 'auth.' function references found"
else
    echo "  ⚠️  Found $OLD_FUNCS_1 old references in File 1, $OLD_FUNCS_2 in File 2"
fi

# Check for new function names
NEW_FUNCS_1=$(grep "CREATE OR REPLACE FUNCTION public.auth_" 70_unified_login_rls_FIXED.sql | wc -l)
NEW_FUNCS_2=$(grep "public.auth_get_user_role\|public.auth_get_user_restaurant_id\|public.auth_is_owner_or_superadmin" 71_security_audit_logging.sql | wc -l)

echo "  ✅ File 1: $NEW_FUNCS_1 helper functions defined"
echo "  ✅ File 2: $NEW_FUNCS_2 references to auth_* functions"

echo ""
echo "=============================================="
echo "🚀 Ready to Deploy"
echo "=============================================="
echo ""
echo "Both SQL files are verified and ready!"
echo ""
echo "Deploy now:"
echo "  1. Supabase Dashboard → SQL Editor"
echo "  2. Copy/paste 70_unified_login_rls_FIXED.sql → Run"
echo "  3. Copy/paste 71_security_audit_logging.sql → Run"
echo ""
