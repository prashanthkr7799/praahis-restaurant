# Database Fix Scripts Archive

This folder contains historical debugging and fix scripts that were used during development and troubleshooting. These scripts are archived for reference purposes.

## Categories

### Authentication Fixes
- `FIX_LOGIN_COMPLETE.sql` - Login flow fixes
- `FIX_STAFF_LOGIN_CONFIRMATION.sql` - Staff login confirmation issues
- `ULTIMATE_LOGIN_FIX.sql` - Comprehensive login fixes
- `FIX_MANAGER_LOGIN_TIMING.sql` - Manager login timing issues

### RLS & Permission Fixes
- `FIX_STAFF_CREATION_RLS.sql` - Staff creation RLS policies
- `FIX_MANAGER_RESTAURANT_ID.sql` - Manager restaurant context fixes
- `QUICK_FIX_USER_RLS.sql` - User RLS quick fixes
- `QUICK_FIX_RESTAURANT_CONTEXT.sql` - Restaurant context fixes
- `SIMPLE_NO_RECURSION_FIX.sql` - RLS recursion fixes
- `DEBUG_DISABLE_RLS.sql` - RLS debugging (disable policies)

### Database Cleanup
- `CLEAN_DATABASE_FOR_TESTING.sql` - Clean database for testing
- `CLEANUP_ORPHANED_STAFF.sql` - Remove orphaned staff records
- `ONE_TIME_SETUP_FIX_ALL.sql` - One-time comprehensive setup

### Diagnostic Tools
- `CHECK_RLS_STATUS.sql` - Check RLS policy status
- `CHECK_SUPERADMIN_ACCOUNTS.sql` - Verify superadmin accounts

### Creation Scripts
- `SIMPLE_CREATE_SUPERADMIN.sql` - Create superadmin accounts
- `SIMPLE_FIX_AUTH_LOGS.sql` - Fix auth logging

### Experimental Fixes
- `TRY_THIS_FIX.sql` - Experimental fixes (trial versions)

## Usage Note

⚠️ **These scripts are for historical reference only.** Do not run them unless you understand exactly what they do and have a specific reason to use them.

Most of these fixes have been incorporated into the main numbered migration files (`01_schema.sql`, `04_production_rls.sql`, etc.).

## Current Migration Files

For the current, production-ready database schema, see the numbered migration files in the parent directory:
- `01_schema.sql` - Core schema
- `04_production_rls.sql` - RLS policies
- `70_unified_login_rls_FIXED.sql` - Current auth implementation
- `71_security_audit_logging.sql` - Audit logging
- And others...

---

**Archived:** November 16, 2025  
**Reason:** Cleanup and code organization
