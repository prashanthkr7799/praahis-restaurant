# 🔧 Manager Login Fix - "Restaurant context is missing"

## 🚨 Problem

When a manager tries to login at `/login`, they get this error:

```
Access Denied
Restaurant context is missing. Please log in again.
```

---

## 🎯 Root Cause

The manager account was created but **`restaurant_id` is NULL** in the `public.users` table.

This happens when:
1. ❌ Restaurant dropdown was not selected when creating the manager
2. ❌ Form validation was bypassed
3. ❌ Database RLS policy stripped the `restaurant_id`

---

## ✅ Quick Fix (3 Steps)

### Step 1: Run SQL Fix Script

1. Open **Supabase Dashboard** → **SQL Editor**
2. Copy and paste: **`database/FIX_MANAGER_RESTAURANT_ID.sql`**
3. Click **"Run"**
4. Verify output shows: `✅ Manager fixed - assigned to restaurant`

### Step 2: Clear Browser Cache

1. Close all browser tabs
2. Clear browser cache (Settings → Privacy → Clear browsing data)
3. **OR** use Incognito/Private window

### Step 3: Try Login Again

1. Go to: `http://localhost:5173/login` (Staff Login, NOT SuperAdmin)
2. Email: Your manager email (e.g., `rahul@spice.com`)
3. Password: Password you set when creating the manager
4. Should redirect to: `/manager/dashboard` ✅

---

## 🔍 Verify Fix Worked

After running the SQL script, verify in Supabase:

1. **Supabase Dashboard** → **Table Editor** → **users**
2. Find the manager row
3. Check columns:
   - ✅ `email`: rahul@spice.com (or your manager email)
   - ✅ `role`: manager
   - ✅ **`restaurant_id`: [UUID]** (NOT NULL!)
   - ✅ `is_active`: true

---

## 📋 Alternative Manual Fix

If the auto-fix doesn't work, manually update in Supabase SQL Editor:

```sql
-- Step 1: Find your manager and restaurant IDs
SELECT id, email, role, restaurant_id 
FROM public.users 
WHERE role = 'manager';

SELECT id, name 
FROM restaurants;

-- Step 2: Update the manager with the correct restaurant_id
UPDATE public.users
SET 
  restaurant_id = 'PASTE_RESTAURANT_ID_HERE',
  updated_at = NOW()
WHERE email = 'rahul@spice.com'  -- Replace with your manager email
AND role = 'manager';

-- Step 3: Verify
SELECT email, role, restaurant_id 
FROM public.users 
WHERE email = 'rahul@spice.com';
```

---

## 🚫 How to Prevent This in Future

When creating a new manager via SuperAdmin Dashboard:

### ✅ DO THIS:

1. **ALWAYS select a restaurant** from the "Restaurant *" dropdown
2. Wait for the dropdown to load all restaurants
3. Double-check the selection before clicking "Add Manager"
4. Verify the restaurant name appears in the manager list after creation

### ❌ DON'T DO THIS:

1. Leave "Restaurant" field empty (even though it's marked required)
2. Submit form before restaurants load
3. Assume default restaurant will be selected

---

## 🎯 Expected Form Flow

When adding a manager, the form should be filled like this:

```
┌─────────────────────────────────────────┐
│ Name: *         Rahul Kumar             │
│ Email: *        rahul@spice.com         │
│ Phone:          +91-9876543210          │
│ Restaurant: *   [The Spice Garden]  ⬅️ SELECT THIS!
│ Role:           manager                 │
│ Password: *     Manager123!             │
│                                         │
│            [Add Manager]                │
└─────────────────────────────────────────┘
```

**Required fields marked with * **

---

## 🔧 Technical Details

### Why This Error Occurs

The `ProtectedRoute.jsx` component checks for `restaurant_id`:

```javascript
// For staff roles (manager/chef/waiter)
if (['manager', 'chef', 'waiter'].includes(role)) {
  if (!restaurant_id) {
    return <ErrorState 
      message="Restaurant context is missing. Please log in again."
    />;
  }
}
```

### Database Schema

```sql
CREATE TABLE users (
  id UUID PRIMARY KEY,
  email VARCHAR(255) NOT NULL,
  role VARCHAR(50) NOT NULL,
  restaurant_id UUID REFERENCES restaurants(id),  -- MUST be set for managers!
  is_active BOOLEAN DEFAULT true,
  ...
);
```

### RLS Policy

Managers can only access data for their assigned restaurant:

```sql
-- Managers can read their restaurant's data
CREATE POLICY "managers_select_own_restaurant" ON restaurants
  FOR SELECT TO authenticated
  USING (
    id = (SELECT restaurant_id FROM users WHERE id = auth.uid())
    AND (SELECT role FROM users WHERE id = auth.uid()) = 'manager'
  );
```

---

## 🎬 Complete Testing Workflow

After fixing the manager login:

### 1. Login as Manager
- URL: `http://localhost:5173/login`
- Email: `rahul@spice.com`
- Password: `Manager123!`
- ✅ Should see Manager Dashboard

### 2. Add Chef
- Go to: Staff Management
- Click: Add Staff Member
- Fill: `chef@spice.com` / `Chef123!`
- ✅ Chef should be created with same `restaurant_id`

### 3. Add Waiter
- Click: Add Staff Member again
- Fill: `waiter@spice.com` / `Waiter123!`
- ✅ Waiter should be created with same `restaurant_id`

### 4. Create Menu Items
- Go to: Menu Management
- Add: Biryani, Paneer Tikka, Masala Dosa, etc.
- ✅ Menu items linked to restaurant

### 5. Generate QR Codes
- Go to: Table Management
- Generate QR codes for Table 1, 2, 3, etc.
- ✅ QR codes contain restaurant slug

---

## 📚 Related Files

- **Fix Script**: `database/FIX_MANAGER_RESTAURANT_ID.sql`
- **Manager Creation**: `src/pages/superadmin/managers/ManagersList.jsx`
- **Protected Routes**: `src/components/ProtectedRoute.jsx`
- **Staff Login**: `src/pages/StaffLogin.jsx`
- **Manager Dashboard**: `src/pages/manager/Dashboard.jsx`

---

## ✅ Summary

**Problem**: Manager can't login - "Restaurant context is missing"  
**Cause**: `restaurant_id` is NULL in database  
**Fix**: Run `FIX_MANAGER_RESTAURANT_ID.sql` to assign restaurant  
**Prevention**: Always select restaurant when creating managers  
**Verification**: Check `restaurant_id` column in Supabase Table Editor  

---

**Status**: ✅ Fix script created and ready to run!
