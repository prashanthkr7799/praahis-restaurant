-- ============================================================================
-- One-time linkage for Table9 manager profile
-- Ensures that the Auth user 'manager@table9.local' has a corresponding
-- row in public.users with role=manager, is_active=true, and restaurant_id
-- set to the Table9 tenant. Idempotent.
-- ============================================================================

DO $$
DECLARE
  rid uuid;
  uid uuid;
BEGIN
  -- Resolve Table9 restaurant id
  SELECT id INTO rid FROM public.restaurants WHERE lower(slug) = 'table9' LIMIT 1;
  IF rid IS NULL THEN
    RAISE NOTICE 'Restaurant with slug table9 not found; skipping manager link.';
    RETURN;
  END IF;

  -- Find Auth user for the provided email
  SELECT id INTO uid FROM auth.users WHERE lower(email) = lower('manager@table9.local') LIMIT 1;
  IF uid IS NULL THEN
    RAISE NOTICE 'Auth user manager@table9.local not found; create the account first.';
    RETURN;
  END IF;

  -- Upsert profile row into public.users
  INSERT INTO public.users (id, email, full_name, role, phone, restaurant_id, is_active, created_at, updated_at)
  VALUES (
    uid,
    'manager@table9.local',
    'Table9 Manager',
    'manager',
    NULL,
    rid,
    TRUE,
    NOW(),
    NOW()
  )
  ON CONFLICT (id) DO UPDATE
    SET email = EXCLUDED.email,
        full_name = EXCLUDED.full_name,
        role = 'manager',
        phone = EXCLUDED.phone,
        restaurant_id = EXCLUDED.restaurant_id,
        is_active = TRUE,
        updated_at = NOW();

  RAISE NOTICE 'Linked manager@table9.local to restaurant %', rid;
END $$;

-- ============================================================================