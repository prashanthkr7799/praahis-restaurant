-- ============================================================================
-- CONFIGURE RAZORPAY TEST KEYS FOR RESTAURANT
-- ============================================================================
-- This sets up Razorpay payment gateway for testing
-- Restaurant: taj
-- Mode: Test (no real money involved)
-- ============================================================================

-- Update the 'taj' restaurant with Razorpay test credentials
UPDATE restaurants
SET 
    payment_gateway_enabled = true,
    payment_settings = jsonb_build_object(
        'razorpay_key_id', 'rzp_test_Rh6FjJwAtY7xRk',
        'razorpay_key_secret', 'LiGE03TjEpHw4EetxGkiQdd3',
        'currency', 'INR',
        'accepted_methods', ARRAY['card', 'netbanking', 'wallet', 'upi'],
        'test_mode', true,
        'configured_at', NOW()
    ),
    updated_at = NOW()
WHERE name = 'taj' OR slug = 'taj';

-- Verify the update
SELECT 
    name,
    slug,
    payment_gateway_enabled,
    payment_settings->>'razorpay_key_id' as key_id,
    payment_settings->>'currency' as currency,
    payment_settings->>'test_mode' as test_mode
FROM restaurants
WHERE name = 'taj' OR slug = 'taj';

-- Success message
DO $$
DECLARE
    v_restaurant_name TEXT;
BEGIN
    SELECT name INTO v_restaurant_name FROM restaurants WHERE name = 'taj' OR slug = 'taj' LIMIT 1;
    
    RAISE NOTICE '
    ╔════════════════════════════════════════════════════════════════╗
    ║   ✅ RAZORPAY TEST MODE CONFIGURED                             ║
    ╠════════════════════════════════════════════════════════════════╣
    ║                                                                ║
    ║   Restaurant: %                                                ║
    ║   Payment Gateway: ENABLED                                     ║
    ║   Mode: TEST (No real money)                                   ║
    ║                                                                ║
    ║   Key ID: rzp_test_Rh6FjJwAtY7xRk                              ║
    ║   Currency: INR                                                ║
    ║   Methods: Card, UPI, Wallet, NetBanking                       ║
    ║                                                                ║
    ║   🧪 Test Cards:                                               ║
    ║   - Card: 4111 1111 1111 1111                                  ║
    ║   - CVV: Any 3 digits                                          ║
    ║   - Expiry: Any future date                                    ║
    ║                                                                ║
    ║   🔗 Test Now:                                                 ║
    ║   1. Add items to cart                                         ║
    ║   2. Click "Place Order & Pay"                                 ║
    ║   3. Use test card above                                       ║
    ║   4. Check Razorpay dashboard for transaction                  ║
    ║                                                                ║
    ╚════════════════════════════════════════════════════════════════╝
    ', v_restaurant_name;
END $$;
