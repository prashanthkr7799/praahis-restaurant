-- ============================================================================
-- DIAGNOSTIC QUERY - Check Current Subscription Data
-- ============================================================================
-- Run this in Supabase SQL Editor to see what data exists
-- ============================================================================

-- 1. Check all restaurants and their subscriptions
SELECT 
    r.id,
    r.name,
    r.slug,
    r.max_tables,
    s.id as sub_id,
    s.plan_name,
    s.status,
    s.current_period_end,
    s.price,
    s.billing_cycle,
    CASE 
        WHEN s.id IS NULL THEN '❌ NO SUBSCRIPTION'
        WHEN s.plan_name IS NULL THEN '⚠️ PLAN NAME IS NULL'
        ELSE '✅ HAS PLAN NAME'
    END as diagnostic
FROM restaurants r
LEFT JOIN subscriptions s ON s.restaurant_id = r.id
ORDER BY r.name;

-- 2. Check if subscriptions table has the required columns
SELECT 
    column_name,
    data_type,
    is_nullable,
    column_default
FROM information_schema.columns
WHERE table_name = 'subscriptions'
ORDER BY ordinal_position;

-- 3. Count issues
SELECT 
    'Total Restaurants' as metric,
    COUNT(*) as count
FROM restaurants

UNION ALL

SELECT 
    'Restaurants with Subscriptions',
    COUNT(*)
FROM restaurants r
INNER JOIN subscriptions s ON s.restaurant_id = r.id

UNION ALL

SELECT 
    'Restaurants WITHOUT Subscriptions',
    COUNT(*)
FROM restaurants r
LEFT JOIN subscriptions s ON s.restaurant_id = r.id
WHERE s.id IS NULL

UNION ALL

SELECT 
    'Subscriptions with NULL plan_name',
    COUNT(*)
FROM subscriptions
WHERE plan_name IS NULL

UNION ALL

SELECT 
    'Subscriptions with empty plan_name',
    COUNT(*)
FROM subscriptions
WHERE plan_name = '';

-- 4. If you have specific restaurant, check it
-- Replace 'Your Restaurant Name' with actual name
-- SELECT 
--     r.*,
--     s.*
-- FROM restaurants r
-- LEFT JOIN subscriptions s ON s.restaurant_id = r.id
-- WHERE r.name ILIKE '%pizza%'
-- LIMIT 1;
