-- ============================================================================
-- COMPLETE RESTAURANT BILLING SYSTEM WITH 3-DAY TRIAL
-- ============================================================================
-- Version: 2.0
-- Created: November 17, 2025
-- Features:
--   - 3-day free trial for all new restaurants
--   - Fixed per-table pricing: ₹100/day/table (default)
--   - Custom pricing option (override table-based pricing)
--   - Automated monthly billing on 1st of each month
--   - 3-day grace period for overdue payments
--   - Automatic suspension after grace period
--   - Receipt generation and email notifications
-- ============================================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_cron";

-- ============================================================================
-- STEP 1: UPDATE RESTAURANTS TABLE
-- ============================================================================
-- Add pricing configuration fields

DO $$ 
BEGIN
    -- Add pricing_type column if it doesn't exist
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'restaurants' AND column_name = 'pricing_type'
    ) THEN
        ALTER TABLE restaurants 
        ADD COLUMN pricing_type VARCHAR(20) DEFAULT 'per_table' 
        CHECK (pricing_type IN ('per_table', 'custom'));
    END IF;

    -- Add custom_monthly_amount column if it doesn't exist
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'restaurants' AND column_name = 'custom_monthly_amount'
    ) THEN
        ALTER TABLE restaurants 
        ADD COLUMN custom_monthly_amount DECIMAL(10, 2) DEFAULT NULL;
    END IF;

    -- Add trial_days column if it doesn't exist
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'restaurants' AND column_name = 'trial_days'
    ) THEN
        ALTER TABLE restaurants 
        ADD COLUMN trial_days INTEGER DEFAULT 3 CHECK (trial_days >= 0);
    END IF;
END $$;

COMMENT ON COLUMN restaurants.pricing_type IS 'Pricing model: per_table (₹100/day/table) or custom (flat monthly fee)';
COMMENT ON COLUMN restaurants.custom_monthly_amount IS 'Custom monthly amount if pricing_type = custom';
COMMENT ON COLUMN restaurants.trial_days IS 'Number of trial days (default 3)';

-- ============================================================================
-- STEP 2: UPDATE SUBSCRIPTIONS TABLE
-- ============================================================================
-- Ensure subscriptions table supports the new 3-day trial workflow

DO $$
BEGIN
    -- Update status check constraint to include all necessary statuses
    ALTER TABLE subscriptions DROP CONSTRAINT IF EXISTS subscriptions_status_check;
    ALTER TABLE subscriptions 
    ADD CONSTRAINT subscriptions_status_check 
    CHECK (status IN ('trial', 'active', 'grace', 'suspended', 'expired', 'cancelled', 'inactive'));

    -- Add plan_name if it doesn't exist
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'subscriptions' AND column_name = 'plan_name'
    ) THEN
        ALTER TABLE subscriptions 
        ADD COLUMN plan_name VARCHAR(100) DEFAULT 'Per-Table Plan';
    END IF;

    -- Add price column if it doesn't exist
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'subscriptions' AND column_name = 'price'
    ) THEN
        ALTER TABLE subscriptions 
        ADD COLUMN price DECIMAL(10, 2);
    END IF;

    -- Add price_per_table column if it doesn't exist
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'subscriptions' AND column_name = 'price_per_table'
    ) THEN
        ALTER TABLE subscriptions 
        ADD COLUMN price_per_table DECIMAL(10, 2) DEFAULT 100.00;
    END IF;

    -- Add current_period_start if it doesn't exist
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'subscriptions' AND column_name = 'current_period_start'
    ) THEN
        ALTER TABLE subscriptions 
        ADD COLUMN current_period_start TIMESTAMP WITH TIME ZONE DEFAULT NOW();
    END IF;

    -- Add current_period_end if it doesn't exist (dual support with end_date)
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'subscriptions' AND column_name = 'current_period_end'
    ) THEN
        ALTER TABLE subscriptions 
        ADD COLUMN current_period_end TIMESTAMP WITH TIME ZONE;
    END IF;

    -- Add grace_period_days if it doesn't exist
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'subscriptions' AND column_name = 'grace_period_days'
    ) THEN
        ALTER TABLE subscriptions 
        ADD COLUMN grace_period_days INTEGER DEFAULT 3;
    END IF;
END $$;

COMMENT ON COLUMN subscriptions.price_per_table IS 'Daily rate per table (default ₹100)';
COMMENT ON COLUMN subscriptions.current_period_start IS 'Start of current subscription period';
COMMENT ON COLUMN subscriptions.current_period_end IS 'End of current subscription period (supports dual schema)';
COMMENT ON COLUMN subscriptions.grace_period_days IS 'Number of grace days for overdue payments (default 3)';

-- ============================================================================
-- STEP 3: UPDATE BILLING TABLE
-- ============================================================================
-- Ensure billing table has all required fields

DO $$
BEGIN
    -- Add pricing_type to billing if it doesn't exist
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'billing' AND column_name = 'pricing_type'
    ) THEN
        ALTER TABLE billing 
        ADD COLUMN pricing_type VARCHAR(20) DEFAULT 'per_table' 
        CHECK (pricing_type IN ('per_table', 'custom'));
    END IF;

    -- Add custom_amount if it doesn't exist
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'billing' AND column_name = 'custom_amount'
    ) THEN
        ALTER TABLE billing 
        ADD COLUMN custom_amount DECIMAL(10, 2) DEFAULT NULL;
    END IF;

    -- Add receipt_url if it doesn't exist
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'billing' AND column_name = 'receipt_url'
    ) THEN
        ALTER TABLE billing 
        ADD COLUMN receipt_url TEXT;
    END IF;

    -- Add invoice_number if it doesn't exist
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'billing' AND column_name = 'invoice_number'
    ) THEN
        ALTER TABLE billing 
        ADD COLUMN invoice_number VARCHAR(50) UNIQUE;
    END IF;
END $$;

-- ============================================================================
-- STEP 4: HELPER FUNCTIONS
-- ============================================================================

-- Function: Calculate billing amount based on pricing type
CREATE OR REPLACE FUNCTION calculate_restaurant_billing(
    p_restaurant_id UUID,
    p_billing_month INTEGER,
    p_billing_year INTEGER
)
RETURNS DECIMAL AS $$
DECLARE
    v_pricing_type VARCHAR(20);
    v_custom_amount DECIMAL(10, 2);
    v_table_count INTEGER;
    v_rate_per_table DECIMAL(10, 2) := 100.00;
    v_days_in_month INTEGER;
    v_total_amount DECIMAL(10, 2);
BEGIN
    -- Get restaurant pricing configuration
    SELECT 
        pricing_type,
        custom_monthly_amount,
        max_tables
    INTO 
        v_pricing_type,
        v_custom_amount,
        v_table_count
    FROM restaurants
    WHERE id = p_restaurant_id;

    -- Calculate days in the billing month
    v_days_in_month := EXTRACT(DAY FROM 
        (DATE(p_billing_year || '-' || p_billing_month || '-01') + INTERVAL '1 month - 1 day')
    );

    -- Calculate amount based on pricing type
    IF v_pricing_type = 'custom' AND v_custom_amount IS NOT NULL THEN
        -- Custom pricing: use fixed monthly amount
        v_total_amount := v_custom_amount;
    ELSE
        -- Per-table pricing: table_count × ₹100 × days_in_month
        v_total_amount := v_table_count * v_rate_per_table * v_days_in_month;
    END IF;

    RETURN v_total_amount;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION calculate_restaurant_billing IS 'Calculate monthly billing amount based on pricing type (per-table or custom)';

-- ============================================================================
-- Function: Generate invoice number
CREATE OR REPLACE FUNCTION generate_invoice_number(
    p_restaurant_id UUID,
    p_billing_year INTEGER,
    p_billing_month INTEGER
)
RETURNS VARCHAR AS $$
DECLARE
    v_restaurant_slug VARCHAR;
    v_invoice_number VARCHAR;
BEGIN
    -- Get restaurant slug
    SELECT slug INTO v_restaurant_slug
    FROM restaurants
    WHERE id = p_restaurant_id;

    -- Generate invoice number: INV-{SLUG}-{YEAR}{MONTH}
    -- Example: INV-TABLE9-202511
    v_invoice_number := 'INV-' || 
                        UPPER(COALESCE(v_restaurant_slug, 'REST')) || '-' || 
                        p_billing_year || 
                        LPAD(p_billing_month::TEXT, 2, '0');

    RETURN v_invoice_number;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- STEP 5: AUTOMATED BILLING GENERATION
-- ============================================================================

-- Drop existing function if return type differs
DROP FUNCTION IF EXISTS generate_monthly_bills(INTEGER, INTEGER);

-- Function: Generate monthly bills for all active restaurants
CREATE OR REPLACE FUNCTION generate_monthly_bills(
    p_billing_month INTEGER DEFAULT EXTRACT(MONTH FROM CURRENT_DATE),
    p_billing_year INTEGER DEFAULT EXTRACT(YEAR FROM CURRENT_DATE)
)
RETURNS TABLE(
    restaurant_id UUID,
    restaurant_name VARCHAR,
    pricing_type VARCHAR,
    table_count INTEGER,
    custom_amount DECIMAL,
    total_amount DECIMAL,
    invoice_number VARCHAR,
    due_date DATE,
    status TEXT
) AS $$
DECLARE
    v_restaurant RECORD;
    v_total_amount DECIMAL(10, 2);
    v_days_in_month INTEGER;
    v_billing_period DATE;
    v_due_date DATE;
    v_grace_end_date DATE;
    v_invoice_number VARCHAR;
    v_rate_per_table DECIMAL(10, 2) := 100.00;
BEGIN
    -- Calculate billing period dates
    v_billing_period := DATE(p_billing_year || '-' || p_billing_month || '-01');
    v_due_date := v_billing_period + INTERVAL '1 month'; -- Due on 1st of next month
    v_grace_end_date := v_due_date + INTERVAL '3 days'; -- Grace period ends on 4th

    -- Calculate days in month
    v_days_in_month := EXTRACT(DAY FROM (v_billing_period + INTERVAL '1 month - 1 day'));

    -- Loop through all active restaurants with active/trial subscriptions
    FOR v_restaurant IN 
        SELECT 
            r.id,
            r.name,
            r.pricing_type,
            r.custom_monthly_amount,
            r.max_tables,
            s.status as subscription_status
        FROM restaurants r
        JOIN subscriptions s ON s.restaurant_id = r.id
        WHERE r.is_active = TRUE
        AND s.status IN ('active', 'grace') -- Don't bill suspended/trial restaurants
    LOOP
        -- Calculate billing amount
        v_total_amount := calculate_restaurant_billing(
            v_restaurant.id,
            p_billing_month,
            p_billing_year
        );

        -- Generate invoice number
        v_invoice_number := generate_invoice_number(
            v_restaurant.id,
            p_billing_year,
            p_billing_month
        );

        -- Check if bill already exists
        IF NOT EXISTS (
            SELECT 1 FROM billing b
            WHERE b.restaurant_id = v_restaurant.id
            AND b.billing_year = p_billing_year
            AND b.billing_month = p_billing_month
        ) THEN
            -- Insert billing record
            INSERT INTO billing (
                restaurant_id,
                billing_month,
                billing_year,
                billing_period,
                table_count,
                rate_per_table_per_day,
                days_in_month,
                pricing_type,
                custom_amount,
                base_amount,
                total_amount,
                status,
                due_date,
                grace_period_days,
                grace_end_date,
                invoice_number
            ) VALUES (
                v_restaurant.id,
                p_billing_month,
                p_billing_year,
                v_billing_period,
                v_restaurant.max_tables,
                v_rate_per_table,
                v_days_in_month,
                v_restaurant.pricing_type,
                v_restaurant.custom_monthly_amount,
                CASE 
                    WHEN v_restaurant.pricing_type = 'custom' THEN 0
                    ELSE v_total_amount
                END,
                v_total_amount,
                'pending',
                v_due_date,
                3,
                v_grace_end_date,
                v_invoice_number
            );

            -- Return result
            RETURN QUERY SELECT
                v_restaurant.id,
                v_restaurant.name,
                v_restaurant.pricing_type,
                v_restaurant.max_tables,
                v_restaurant.custom_monthly_amount,
                v_total_amount,
                v_invoice_number,
                v_due_date,
                'created'::TEXT;
        ELSE
            -- Bill already exists
            RETURN QUERY SELECT
                v_restaurant.id,
                v_restaurant.name,
                v_restaurant.pricing_type,
                v_restaurant.max_tables,
                v_restaurant.custom_monthly_amount,
                v_total_amount,
                v_invoice_number,
                v_due_date,
                'already_exists'::TEXT;
        END IF;
    END LOOP;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION generate_monthly_bills IS 'Automatically generate monthly bills for all active restaurants on 1st of each month';

-- ============================================================================
-- STEP 6: TRIAL MANAGEMENT
-- ============================================================================

-- Drop existing function if signature differs
DROP FUNCTION IF EXISTS create_trial_subscription(UUID, INTEGER);

-- Function: Create 3-day trial subscription for new restaurant
CREATE OR REPLACE FUNCTION create_trial_subscription(
    p_restaurant_id UUID,
    p_trial_days INTEGER DEFAULT 3
)
RETURNS UUID AS $$
DECLARE
    v_subscription_id UUID;
    v_trial_end TIMESTAMP WITH TIME ZONE;
BEGIN
    -- Calculate trial end date
    v_trial_end := NOW() + (p_trial_days || ' days')::INTERVAL;

    -- Create subscription
    INSERT INTO subscriptions (
        restaurant_id,
        status,
        start_date,
        end_date,
        current_period_start,
        current_period_end,
        trial_ends_at,
        grace_period_days,
        plan_name,
        price_per_table
    ) VALUES (
        p_restaurant_id,
        'trial',
        NOW(),
        v_trial_end,
        NOW(),
        v_trial_end,
        v_trial_end,
        3,
        '3-Day Trial',
        100.00
    )
    RETURNING id INTO v_subscription_id;

    RETURN v_subscription_id;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION create_trial_subscription IS 'Create a 3-day free trial subscription for new restaurants';

-- ============================================================================
-- Drop existing function if return type differs
DROP FUNCTION IF EXISTS expire_trial_subscriptions();

-- Function: Check and expire trials
CREATE OR REPLACE FUNCTION expire_trial_subscriptions()
RETURNS TABLE(
    restaurant_id UUID,
    restaurant_name VARCHAR,
    trial_ended_at TIMESTAMP WITH TIME ZONE,
    status TEXT
) AS $$
DECLARE
    v_record RECORD;
BEGIN
    -- Find all expired trials
    FOR v_record IN
        SELECT 
            s.id as subscription_id,
            s.restaurant_id,
            r.name as restaurant_name,
            s.trial_ends_at
        FROM subscriptions s
        JOIN restaurants r ON r.id = s.restaurant_id
        WHERE s.status = 'trial'
        AND s.trial_ends_at <= NOW()
    LOOP
        -- Update subscription to expired
        UPDATE subscriptions
        SET 
            status = 'expired',
            updated_at = NOW()
        WHERE id = v_record.subscription_id;

        -- Deactivate restaurant
        UPDATE restaurants
        SET 
            is_active = FALSE,
            updated_at = NOW()
        WHERE id = v_record.restaurant_id;

        -- Return result
        RETURN QUERY SELECT
            v_record.restaurant_id,
            v_record.restaurant_name,
            v_record.trial_ends_at,
            'expired'::TEXT;
    END LOOP;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION expire_trial_subscriptions IS 'Automatically expire trial subscriptions after 3 days and deactivate restaurants';

-- ============================================================================
-- STEP 7: PAYMENT PROCESSING
-- ============================================================================

-- Drop existing function if signature differs
DROP FUNCTION IF EXISTS process_subscription_payment(UUID, DECIMAL, VARCHAR, VARCHAR, VARCHAR, TEXT);

-- Function: Mark bill as paid and extend subscription
CREATE OR REPLACE FUNCTION process_subscription_payment(
    p_billing_id UUID,
    p_amount DECIMAL,
    p_payment_method VARCHAR DEFAULT 'razorpay',
    p_transaction_id VARCHAR DEFAULT NULL,
    p_payment_gateway_order_id VARCHAR DEFAULT NULL,
    p_receipt_url TEXT DEFAULT NULL
)
RETURNS JSONB AS $$
DECLARE
    v_restaurant_id UUID;
    v_billing_amount DECIMAL;
    v_subscription_id UUID;
    v_current_end TIMESTAMP WITH TIME ZONE;
    v_new_end TIMESTAMP WITH TIME ZONE;
    v_payment_id UUID;
    v_result JSONB;
BEGIN
    -- Get billing details
    SELECT restaurant_id, total_amount
    INTO v_restaurant_id, v_billing_amount
    FROM billing
    WHERE id = p_billing_id;

    IF v_restaurant_id IS NULL THEN
        RETURN jsonb_build_object(
            'success', false,
            'error', 'Billing record not found'
        );
    END IF;

    -- Verify amount matches
    IF p_amount < v_billing_amount THEN
        RETURN jsonb_build_object(
            'success', false,
            'error', 'Payment amount insufficient'
        );
    END IF;

    -- Get subscription
    SELECT id, current_period_end, end_date
    INTO v_subscription_id, v_current_end, v_new_end
    FROM subscriptions
    WHERE restaurant_id = v_restaurant_id;

    -- Use whichever end date exists (dual schema support)
    v_current_end := COALESCE(v_current_end, v_new_end, NOW());

    -- Calculate new subscription end (extend by 30 days)
    v_new_end := GREATEST(v_current_end, NOW()) + INTERVAL '30 days';

    -- Record payment
    INSERT INTO payments (
        billing_id,
        restaurant_id,
        subscription_id,
        amount,
        payment_type,
        payment_method,
        payment_gateway_id,
        payment_gateway_order_id,
        status,
        payment_date,
        completed_at,
        receipt_url
    ) VALUES (
        p_billing_id,
        v_restaurant_id,
        v_subscription_id,
        p_amount,
        'monthly_subscription',
        p_payment_method,
        p_transaction_id,
        p_payment_gateway_order_id,
        'completed',
        NOW(),
        NOW(),
        p_receipt_url
    )
    RETURNING id INTO v_payment_id;

    -- Update billing status
    UPDATE billing
    SET 
        status = 'paid',
        paid_at = NOW(),
        receipt_url = p_receipt_url,
        updated_at = NOW()
    WHERE id = p_billing_id;

    -- Extend subscription
    UPDATE subscriptions
    SET 
        status = 'active',
        current_period_end = v_new_end,
        end_date = v_new_end,
        last_payment_date = NOW(),
        next_billing_date = v_new_end,
        suspended_at = NULL,
        suspended_reason = NULL,
        updated_at = NOW()
    WHERE restaurant_id = v_restaurant_id;

    -- Reactivate restaurant if suspended
    UPDATE restaurants
    SET 
        is_active = TRUE,
        updated_at = NOW()
    WHERE id = v_restaurant_id;

    -- Build success response
    v_result := jsonb_build_object(
        'success', true,
        'payment_id', v_payment_id,
        'restaurant_id', v_restaurant_id,
        'subscription_extended_to', v_new_end,
        'restaurant_reactivated', true
    );

    RETURN v_result;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION process_subscription_payment IS 'Process subscription payment, mark bill as paid, extend subscription by 30 days, and reactivate restaurant';

-- ============================================================================
-- STEP 8: SUSPENSION & REACTIVATION
-- ============================================================================

-- Drop existing function if return type differs
DROP FUNCTION IF EXISTS suspend_overdue_subscriptions();

-- Function: Suspend overdue restaurants
CREATE OR REPLACE FUNCTION suspend_overdue_subscriptions()
RETURNS TABLE(
    restaurant_id UUID,
    restaurant_name VARCHAR,
    billing_amount DECIMAL,
    days_overdue INTEGER,
    status TEXT
) AS $$
DECLARE
    v_record RECORD;
    v_days_overdue INTEGER;
BEGIN
    -- Find all overdue bills past grace period
    FOR v_record IN
        SELECT 
            b.id as billing_id,
            b.restaurant_id,
            r.name as restaurant_name,
            b.total_amount,
            b.grace_end_date,
            s.id as subscription_id
        FROM billing b
        JOIN restaurants r ON r.id = b.restaurant_id
        JOIN subscriptions s ON s.restaurant_id = b.restaurant_id
        WHERE b.status IN ('pending', 'overdue')
        AND b.grace_end_date < CURRENT_DATE
        AND s.status NOT IN ('suspended', 'cancelled')
    LOOP
        -- Calculate days overdue
        v_days_overdue := CURRENT_DATE - v_record.grace_end_date;

        -- Update billing status
        UPDATE billing
        SET 
            status = 'overdue',
            suspended_at = NOW(),
            updated_at = NOW()
        WHERE id = v_record.billing_id;

        -- Suspend subscription
        UPDATE subscriptions
        SET 
            status = 'suspended',
            suspended_at = NOW(),
            suspended_reason = 'Payment overdue',
            updated_at = NOW()
        WHERE id = v_record.subscription_id;

        -- Deactivate restaurant
        UPDATE restaurants
        SET 
            is_active = FALSE,
            updated_at = NOW()
        WHERE id = v_record.restaurant_id;

        -- Return result
        RETURN QUERY SELECT
            v_record.restaurant_id,
            v_record.restaurant_name,
            v_record.total_amount,
            v_days_overdue,
            'suspended'::TEXT;
    END LOOP;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION suspend_overdue_subscriptions IS 'Automatically suspend restaurants with overdue bills past grace period';

-- ============================================================================
-- STEP 9: REPORTING FUNCTIONS
-- ============================================================================

-- Drop existing function if signature differs
DROP FUNCTION IF EXISTS get_restaurant_billing_summary(UUID);

-- Function: Get restaurant billing summary
CREATE OR REPLACE FUNCTION get_restaurant_billing_summary(
    p_restaurant_id UUID
)
RETURNS JSONB AS $$
DECLARE
    v_summary JSONB;
    v_current_bill RECORD;
    v_subscription RECORD;
    v_total_paid DECIMAL;
    v_outstanding DECIMAL;
BEGIN
    -- Get current month bill
    SELECT *
    INTO v_current_bill
    FROM billing
    WHERE restaurant_id = p_restaurant_id
    AND billing_year = EXTRACT(YEAR FROM CURRENT_DATE)
    AND billing_month = EXTRACT(MONTH FROM CURRENT_DATE)
    ORDER BY created_at DESC
    LIMIT 1;

    -- Get subscription
    SELECT *
    INTO v_subscription
    FROM subscriptions
    WHERE restaurant_id = p_restaurant_id
    LIMIT 1;

    -- Calculate total paid this year
    SELECT COALESCE(SUM(b.total_amount), 0)
    INTO v_total_paid
    FROM billing b
    WHERE b.restaurant_id = p_restaurant_id
    AND b.status = 'paid'
    AND b.billing_year = EXTRACT(YEAR FROM CURRENT_DATE);

    -- Calculate outstanding amount
    SELECT COALESCE(SUM(b.total_amount), 0)
    INTO v_outstanding
    FROM billing b
    WHERE b.restaurant_id = p_restaurant_id
    AND b.status IN ('pending', 'overdue');

    -- Build summary
    v_summary := jsonb_build_object(
        'restaurant_id', p_restaurant_id,
        'current_bill', row_to_json(v_current_bill),
        'subscription', row_to_json(v_subscription),
        'total_paid_this_year', v_total_paid,
        'outstanding_amount', v_outstanding,
        'subscription_status', v_subscription.status,
        'subscription_end_date', COALESCE(v_subscription.current_period_end, v_subscription.end_date)
    );

    RETURN v_summary;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION get_restaurant_billing_summary IS 'Get comprehensive billing summary for a restaurant';

-- ============================================================================
-- STEP 10: TRIGGERS
-- ============================================================================

-- Trigger: Auto-update updated_at timestamp
CREATE OR REPLACE FUNCTION update_billing_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS billing_updated_at_trigger ON billing;
CREATE TRIGGER billing_updated_at_trigger
    BEFORE UPDATE ON billing
    FOR EACH ROW
    EXECUTE FUNCTION update_billing_timestamp();

DROP TRIGGER IF EXISTS subscriptions_updated_at_trigger ON subscriptions;
CREATE TRIGGER subscriptions_updated_at_trigger
    BEFORE UPDATE ON subscriptions
    FOR EACH ROW
    EXECUTE FUNCTION update_billing_timestamp();

-- ============================================================================
-- STEP 11: GRANT PERMISSIONS
-- ============================================================================

-- Grant necessary permissions
GRANT EXECUTE ON FUNCTION calculate_restaurant_billing TO authenticated;
GRANT EXECUTE ON FUNCTION generate_invoice_number TO authenticated;
GRANT EXECUTE ON FUNCTION generate_monthly_bills TO authenticated;
GRANT EXECUTE ON FUNCTION create_trial_subscription TO authenticated;
GRANT EXECUTE ON FUNCTION expire_trial_subscriptions TO authenticated;
GRANT EXECUTE ON FUNCTION process_subscription_payment TO authenticated;
GRANT EXECUTE ON FUNCTION suspend_overdue_subscriptions TO authenticated;
GRANT EXECUTE ON FUNCTION get_restaurant_billing_summary TO authenticated;

-- ============================================================================
-- SUCCESS MESSAGE
-- ============================================================================

DO $$
BEGIN
    RAISE NOTICE '
    ╔════════════════════════════════════════════════════════════════╗
    ║   ✅ COMPLETE BILLING SYSTEM INSTALLED SUCCESSFULLY           ║
    ╠════════════════════════════════════════════════════════════════╣
    ║                                                                ║
    ║   Features Enabled:                                            ║
    ║   ✓ 3-day free trial for all new restaurants                  ║
    ║   ✓ Fixed per-table pricing (₹100/day/table)                  ║
    ║   ✓ Custom pricing option                                      ║
    ║   ✓ Automated monthly billing                                  ║
    ║   ✓ 3-day grace period for payments                            ║
    ║   ✓ Automatic suspension after grace period                    ║
    ║   ✓ Payment processing and reactivation                        ║
    ║                                                                ║
    ║   Next Steps:                                                  ║
    ║   1. Set up cron jobs for automation                           ║
    ║   2. Implement frontend billing dashboards                     ║
    ║   3. Configure email notifications                             ║
    ║   4. Set up Razorpay integration for payments                  ║
    ║                                                                ║
    ╚════════════════════════════════════════════════════════════════╝
    ';
END $$;
