-- ============================================================================
-- SIMPLE FIX: Create auth_activity_logs table (fixes 401 errors)
-- ============================================================================
-- This is a simplified version that won't fail if policies already exist
-- ============================================================================

-- Step 1: Verify manager has restaurant_id
SELECT 
  email,
  role,
  restaurant_id,
  CASE 
    WHEN restaurant_id IS NOT NULL THEN '✅ HAS restaurant_id'
    ELSE '❌ MISSING restaurant_id'
  END as status
FROM public.users
WHERE role = 'manager'
ORDER BY created_at DESC;

-- Step 2: Create table if missing
CREATE TABLE IF NOT EXISTS public.auth_activity_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  action VARCHAR(100) NOT NULL,
  ip_address VARCHAR(45),
  user_agent TEXT,
  metadata JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Step 3: Create indexes if missing
CREATE INDEX IF NOT EXISTS idx_auth_activity_logs_user_id 
ON public.auth_activity_logs(user_id);

CREATE INDEX IF NOT EXISTS idx_auth_activity_logs_created_at 
ON public.auth_activity_logs(created_at DESC);

-- Step 4: Enable RLS
ALTER TABLE public.auth_activity_logs ENABLE ROW LEVEL SECURITY;

-- Step 5: Drop and recreate policies (idempotent)
DROP POLICY IF EXISTS "users_select_own_logs" ON public.auth_activity_logs;
DROP POLICY IF EXISTS "system_insert_logs" ON public.auth_activity_logs;
DROP POLICY IF EXISTS "owners_select_all_logs" ON public.auth_activity_logs;

CREATE POLICY "users_select_own_logs" ON public.auth_activity_logs
  FOR SELECT TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "system_insert_logs" ON public.auth_activity_logs
  FOR INSERT TO authenticated
  WITH CHECK (true);

CREATE POLICY "owners_select_all_logs" ON public.auth_activity_logs
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.users
      WHERE id = auth.uid()
      AND is_owner = true
    )
  );

-- Step 6: Verification
SELECT '✅ auth_activity_logs setup complete!' as status;

SELECT 
  u.email,
  u.role,
  u.restaurant_id,
  r.name as restaurant_name,
  CASE 
    WHEN u.restaurant_id IS NULL THEN '❌ No restaurant_id'
    WHEN r.id IS NULL THEN '❌ Restaurant not found'
    ELSE '✅ ALL OK'
  END as final_status
FROM public.users u
LEFT JOIN restaurants r ON u.restaurant_id = r.id
WHERE u.role = 'manager'
ORDER BY u.created_at DESC;
