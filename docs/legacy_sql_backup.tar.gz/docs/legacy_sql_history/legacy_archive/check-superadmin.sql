-- Check if your superadmin user is in platform_admins table
SELECT 
    pa.user_id,
    pa.role,
    pa.is_active,
    u.email,
    u.full_name
FROM platform_admins pa
LEFT JOIN users u ON u.id = pa.user_id
WHERE pa.role = 'superadmin'
ORDER BY pa.created_at DESC;

-- If no superadmin found, get the list of all platform admins
SELECT COUNT(*) as total_admins FROM platform_admins;

-- Check your current user's ID (if logged in)
-- You would need to know your UUID from auth.users table
SELECT id, email FROM auth.users WHERE email LIKE '%prashanthkumarreddy%';
