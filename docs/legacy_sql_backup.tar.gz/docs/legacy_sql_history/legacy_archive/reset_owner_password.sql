-- Reset password for prashanthkumarreddy879@gmail.com

-- This will send a password reset email to the account
-- You need to run this through Supabase's admin API or use the dashboard

-- Option 1: Check if you can login with a specific password
-- First, let's verify the account is active and email is confirmed

SELECT 
  id,
  email,
  email_confirmed_at,
  last_sign_in_at,
  created_at,
  CASE 
    WHEN email_confirmed_at IS NOT NULL THEN '✅ Email confirmed'
    ELSE '❌ Email NOT confirmed - need to confirm'
  END as email_status
FROM auth.users
WHERE email = 'prashanthkumarreddy879@gmail.com';

-- Option 2: If email is not confirmed, confirm it manually
UPDATE auth.users
SET 
  email_confirmed_at = NOW(),
  confirmed_at = NOW()
WHERE email = 'prashanthkumarreddy879@gmail.com'
  AND email_confirmed_at IS NULL;

-- Option 3: Verify it's updated
SELECT 
  id,
  email,
  email_confirmed_at,
  confirmed_at,
  '✅ Email confirmed - you can now login' as status
FROM auth.users
WHERE email = 'prashanthkumarreddy879@gmail.com';

-- Note: To reset the password, you have 2 options:
-- 1. Use the "Forgot Password" link on the login page
-- 2. Go to Supabase Dashboard > Authentication > Users > Find your user > Send Reset Password Email
-- 3. Or set a new password directly (not recommended but works for testing):
--    Go to Supabase Dashboard > Authentication > Users > Click on user > Set new password
