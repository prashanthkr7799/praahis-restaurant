-- ============================================================================
-- ADD ORDER PAYMENTS TABLE
-- ============================================================================
-- Purpose: Separate table for customer order payments
-- Reason: The main 'payments' table is used for restaurant billing/subscriptions
-- This table specifically handles Razorpay payments from customers
-- ============================================================================

-- Create order_payments table for customer checkout
CREATE TABLE IF NOT EXISTS order_payments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
    
    -- Razorpay Details
    razorpay_order_id VARCHAR(100),
    razorpay_payment_id VARCHAR(100),
    razorpay_signature VARCHAR(255),
    
    -- Payment Details
    amount DECIMAL(10, 2) NOT NULL CHECK (amount >= 0),
    currency VARCHAR(10) DEFAULT 'INR',
    status VARCHAR(50) DEFAULT 'created' CHECK (status IN ('created', 'authorized', 'captured', 'failed', 'refunded')),
    payment_method VARCHAR(50) DEFAULT 'razorpay',
    
    -- Metadata
    payment_details JSONB DEFAULT '{}',
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Constraints
    UNIQUE(razorpay_payment_id)
);

COMMENT ON TABLE order_payments IS 'Customer payment records via Razorpay for orders';
COMMENT ON COLUMN order_payments.status IS 'created, authorized, captured, failed, refunded';

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_order_payments_order_id ON order_payments(order_id);
CREATE INDEX IF NOT EXISTS idx_order_payments_restaurant_id ON order_payments(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_order_payments_razorpay_payment_id ON order_payments(razorpay_payment_id);

-- Enable RLS
ALTER TABLE order_payments ENABLE ROW LEVEL SECURITY;

-- RLS Policies
-- Policy 1: Anyone can insert order payments (for customer checkout)
DROP POLICY IF EXISTS "Anyone can create order payments" ON order_payments;
CREATE POLICY "Anyone can create order payments"
ON order_payments
FOR INSERT
WITH CHECK (true);

-- Policy 2: Anyone can view order payments (for order status checks)
DROP POLICY IF EXISTS "Anyone can view order payments" ON order_payments;
CREATE POLICY "Anyone can view order payments"
ON order_payments
FOR SELECT
USING (true);

-- Policy 3: Restaurants can view their order payments
DROP POLICY IF EXISTS "Restaurants can view their order payments" ON order_payments;
CREATE POLICY "Restaurants can view their order payments"
ON order_payments
FOR SELECT
USING (
  restaurant_id IN (
    SELECT restaurant_id 
    FROM users 
    WHERE id = auth.uid() 
    AND role IN ('owner', 'manager', 'admin')
  )
);

-- Policy 4: Superadmins can manage all order payments
DROP POLICY IF EXISTS "Superadmins can manage all order payments" ON order_payments;
CREATE POLICY "Superadmins can manage all order payments"
ON order_payments
FOR ALL
USING (
  is_superadmin(auth.uid())
);

-- ============================================================================
-- VERIFICATION
-- ============================================================================
DO $$ 
BEGIN
  -- Check if table exists
  IF EXISTS (
    SELECT 1 
    FROM pg_tables 
    WHERE tablename = 'order_payments'
  ) THEN
    RAISE NOTICE '✓ order_payments table created';
  ELSE
    RAISE EXCEPTION '✗ Failed to create order_payments table';
  END IF;

  -- Check if RLS is enabled
  IF EXISTS (
    SELECT 1 
    FROM pg_tables 
    WHERE tablename = 'order_payments' 
    AND rowsecurity = true
  ) THEN
    RAISE NOTICE '✓ RLS is enabled on order_payments table';
  ELSE
    RAISE WARNING '⚠ RLS might not be enabled on order_payments table';
  END IF;

  RAISE NOTICE '✓ Order payments table setup complete';
END $$;

-- ============================================================================
-- NOTES
-- ============================================================================
-- This table is specifically for customer order payments via Razorpay
-- The main 'payments' table is reserved for restaurant billing/subscriptions
-- This separation keeps the data models clean and prevents conflicts
-- ============================================================================
