-- ============================================================================
-- TABUN RESTAURANT MANAGEMENT SYSTEM - ENABLE REALTIME
-- ============================================================================
-- Version: 1.0
-- Created: October 2025
-- Description: Enable Supabase Realtime for instant data updates
-- ============================================================================

-- ============================================================================
-- ENABLE REALTIME SUBSCRIPTIONS
-- ============================================================================
-- This allows the frontend to receive real-time updates when data changes
-- Required for: Chef Dashboard, Waiter Dashboard, Order Status Page

DO $$
BEGIN
    -- Enable realtime for orders table (most critical)
    BEGIN
        ALTER PUBLICATION supabase_realtime ADD TABLE orders;
        RAISE NOTICE 'Realtime enabled for orders table';
    EXCEPTION
        WHEN duplicate_object THEN
            RAISE NOTICE 'Realtime already enabled for orders table';
    END;

    -- Enable realtime for tables (for table status updates)
    BEGIN
        ALTER PUBLICATION supabase_realtime ADD TABLE tables;
        RAISE NOTICE 'Realtime enabled for tables table';
    EXCEPTION
        WHEN duplicate_object THEN
            RAISE NOTICE 'Realtime already enabled for tables table';
    END;

    -- Enable realtime for menu_items (for availability updates)
    BEGIN
        ALTER PUBLICATION supabase_realtime ADD TABLE menu_items;
        RAISE NOTICE 'Realtime enabled for menu_items table';
    EXCEPTION
        WHEN duplicate_object THEN
            RAISE NOTICE 'Realtime already enabled for menu_items table';
    END;

    -- Enable realtime for payments (optional - for payment status)
    BEGIN
        ALTER PUBLICATION supabase_realtime ADD TABLE payments;
        RAISE NOTICE 'Realtime enabled for payments table';
    EXCEPTION
        WHEN duplicate_object THEN
            RAISE NOTICE 'Realtime already enabled for payments table';
    END;

    -- Enable realtime for item ratings (optional - for live rating updates)
    BEGIN
        ALTER PUBLICATION supabase_realtime ADD TABLE menu_item_ratings;
        RAISE NOTICE 'Realtime enabled for menu_item_ratings table';
    EXCEPTION
        WHEN undefined_table THEN
            RAISE NOTICE 'menu_item_ratings not found (run 06_item_ratings.sql first)';
        WHEN duplicate_object THEN
            RAISE NOTICE 'Realtime already enabled for menu_item_ratings table';
    END;
END $$;

-- ============================================================================
-- VERIFY REALTIME IS ENABLED
-- ============================================================================
-- Run this query to verify which tables have realtime enabled:
-- SELECT schemaname, tablename 
-- FROM pg_publication_tables 
-- WHERE pubname = 'supabase_realtime';

-- ============================================================================
-- REALTIME SETUP COMPLETE
-- ============================================================================
-- ============================================================================
