-- Fix Staff Delete Permissions
-- Allow managers to delete staff from their restaurant

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "managers_can_delete_staff" ON public.users;

-- Create policy to allow managers to delete staff from their restaurant
CREATE POLICY "managers_can_delete_staff"
ON public.users
FOR DELETE
USING (
  -- Allow deletion if:
  -- 1. The current user is a manager/admin
  -- 2. The target user belongs to the same restaurant
  -- 3. The target user is not an owner
  EXISTS (
    SELECT 1 FROM public.users manager
    WHERE manager.id = auth.uid()
    AND manager.role IN ('manager', 'admin')
    AND manager.restaurant_id = users.restaurant_id
    AND manager.is_active = true
  )
  AND users.is_owner = false
);

-- Verify the policy
SELECT 
  schemaname,
  tablename,
  policyname,
  permissive,
  roles,
  cmd,
  qual
FROM pg_policies 
WHERE tablename = 'users' AND cmd = 'DELETE';

-- Test query (replace with actual IDs to test)
-- SELECT id, email, role FROM users WHERE restaurant_id = 'YOUR_RESTAURANT_ID';
