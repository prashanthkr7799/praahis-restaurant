-- Check prashanthkumarreddy879@gmail.com account details

-- Step 1: Check public.users profile
SELECT 
  id,
  email,
  full_name,
  role,
  restaurant_id,
  is_owner,
  is_active,
  created_at,
  updated_at
FROM public.users
WHERE email = 'prashanthkumarreddy879@gmail.com';

-- Step 2: Check auth.users entry
SELECT 
  id,
  email,
  email_confirmed_at,
  created_at,
  last_sign_in_at
FROM auth.users
WHERE email = 'prashanthkumarreddy879@gmail.com';

-- Step 3: Check if IDs match
SELECT 
  au.id as auth_id,
  pu.id as public_id,
  au.email,
  pu.full_name,
  pu.role,
  pu.is_owner,
  pu.restaurant_id,
  CASE 
    WHEN au.id = pu.id THEN '✅ IDs match - account is valid'
    WHEN au.id != pu.id THEN '❌ ID MISMATCH - this is a problem'
    WHEN pu.id IS NULL THEN '❌ No public.users profile'
    WHEN au.id IS NULL THEN '❌ No auth.users entry'
  END as status
FROM auth.users au
FULL OUTER JOIN public.users pu ON au.email = pu.email
WHERE au.email = 'prashanthkumarreddy879@gmail.com' 
   OR pu.email = 'prashanthkumarreddy879@gmail.com';

-- Step 4: If this should be a superadmin/owner, update it:
-- Uncomment the following lines AFTER verifying the account exists above

-- UPDATE public.users 
-- SET 
--   is_owner = true,
--   role = 'owner',
--   restaurant_id = NULL
-- WHERE email = 'prashanthkumarreddy879@gmail.com';

-- Step 5: Verify the update
-- SELECT 
--   email,
--   full_name,
--   role,
--   is_owner,
--   restaurant_id,
--   '✅ Updated to owner/superadmin' as status
-- FROM public.users
-- WHERE email = 'prashanthkumarreddy879@gmail.com';
