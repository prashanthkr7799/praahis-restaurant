-- Complete Fix for Orphaned Users and ID Mismatches
-- Run this to fix all authentication issues

-- Step 1: Check for orphaned users (auth.users without public.users)
SELECT 
  au.id,
  au.email,
  CASE WHEN pu.id IS NULL THEN '❌ ORPHANED' ELSE '✅ VALID' END as status
FROM auth.users au
LEFT JOIN public.users pu ON au.id = pu.id
ORDER BY status DESC;

-- Step 2: Check for ID mismatches (same email, different ID)
SELECT 
  au.id as auth_id,
  au.email,
  pu.id as profile_id,
  pu.role,
  CASE 
    WHEN au.id = pu.id THEN '✅ MATCHED'
    WHEN pu.id IS NULL THEN '❌ NO PROFILE'
    ELSE '❌ MISMATCH'
  END as status
FROM auth.users au
LEFT JOIN public.users pu ON au.email = pu.email
ORDER BY status DESC;

-- Step 3: Fix the specific ID mismatch for prashanthkr7799@gmail.com
-- ONLY run this if the user exists with mismatched ID
UPDATE public.users
SET id = '1098a8d1-67bc-4e3f-8a36-88bb6597a9ad'
WHERE email = 'prashanthkr7799@gmail.com'
AND id != '1098a8d1-67bc-4e3f-8a36-88bb6597a9ad';

-- Step 4: Delete any duplicate profiles with the old ID (if needed)
DELETE FROM public.users
WHERE id = '0cd26e56-bb49-4286-8d28-c0b99fba9c4c'
AND email = 'prashanthkr7799@gmail.com';

-- Step 5: Verify all users are now correctly linked
SELECT 
  au.id,
  au.email,
  pu.role,
  pu.restaurant_id,
  CASE 
    WHEN au.id = pu.id THEN '✅ OK'
    ELSE '❌ STILL BROKEN'
  END as status
FROM auth.users au
LEFT JOIN public.users pu ON au.id = pu.id
ORDER BY status DESC, au.email;

-- Step 6: Check for users without restaurant_id (will cause "login first" errors)
SELECT 
  id,
  email,
  role,
  restaurant_id,
  CASE 
    WHEN restaurant_id IS NULL AND role IN ('chef', 'waiter', 'manager') THEN '❌ MISSING RESTAURANT'
    ELSE '✅ OK'
  END as status
FROM public.users
WHERE role != 'owner'
ORDER BY status DESC;
