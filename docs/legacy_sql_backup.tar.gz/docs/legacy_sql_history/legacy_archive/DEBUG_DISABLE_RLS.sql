-- =========================================================================
-- SIMPLIFIED FIX: Disable RLS temporarily to debug
-- =========================================================================

-- Step 1: Temporarily disable RLS on users table (for debugging)
ALTER TABLE public.users DISABLE ROW LEVEL SECURITY;

-- Step 2: Verify you can now read users
SELECT id, email, role, is_owner, is_active 
FROM public.users 
WHERE id = '9446f5ca-6b1b-43f5-aded-23e7fc452f4a';  -- Your user ID

-- Step 3: Check for any triggers or functions that might be causing issues
SELECT 
    trigger_name,
    event_manipulation,
    event_object_table,
    action_statement
FROM information_schema.triggers
WHERE event_object_table = 'users';

-- =========================================================================
-- After running this, try logging in again.
-- If it works, we know RLS is the issue and we'll create a simpler policy.
-- =========================================================================
