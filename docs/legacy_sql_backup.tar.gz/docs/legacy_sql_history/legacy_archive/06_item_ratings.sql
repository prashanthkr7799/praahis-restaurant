-- ============================================================================
-- ITEM RATINGS SCHEMA
-- ============================================================================
-- Creates per-item ratings table and basic RLS so customers can submit ratings
-- Run after 01_schema.sql and before 07_item_rating_summary.sql
-- ==========================================================================

-- Enable UUID extension (if not already enabled via 01_schema.sql)
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create table: menu_item_ratings
CREATE TABLE IF NOT EXISTS menu_item_ratings (
		id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
		order_id UUID REFERENCES orders(id) ON DELETE CASCADE,
	restaurant_id UUID REFERENCES restaurants(id) ON DELETE CASCADE,
		menu_item_id UUID REFERENCES menu_items(id) ON DELETE CASCADE,
		rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
		created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE menu_item_ratings IS 'Per-item customer ratings (1-5 stars)';
COMMENT ON COLUMN menu_item_ratings.rating IS 'Rating from 1 to 5';

-- Ensure required columns exist for legacy deployments (idempotent)
ALTER TABLE menu_item_ratings
	ADD COLUMN IF NOT EXISTS restaurant_id UUID;

-- Ensure FK constraint exists for restaurant_id (idempotent)
DO $$
BEGIN
	IF NOT EXISTS (
		SELECT 1 FROM information_schema.table_constraints 
		WHERE table_schema = 'public' 
			AND table_name = 'menu_item_ratings' 
			AND constraint_type = 'FOREIGN KEY' 
			AND constraint_name = 'menu_item_ratings_restaurant_id_fkey'
	) THEN
		ALTER TABLE menu_item_ratings
			ADD CONSTRAINT menu_item_ratings_restaurant_id_fkey
			FOREIGN KEY (restaurant_id) REFERENCES restaurants(id) ON DELETE CASCADE;
	END IF;
END $$;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_item_ratings_item ON menu_item_ratings(menu_item_id);
CREATE INDEX IF NOT EXISTS idx_item_ratings_restaurant ON menu_item_ratings(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_item_ratings_order ON menu_item_ratings(order_id);
CREATE INDEX IF NOT EXISTS idx_item_ratings_created_at ON menu_item_ratings(created_at DESC);

-- Enable RLS
ALTER TABLE menu_item_ratings ENABLE ROW LEVEL SECURITY;

-- Clean slate: drop existing policies if re-running
DO $$ 
BEGIN
	IF EXISTS (
		SELECT 1 FROM pg_policies WHERE schemaname = 'public' AND tablename = 'menu_item_ratings'
	) THEN
		EXECUTE 'DROP POLICY IF EXISTS menu_item_ratings_select ON menu_item_ratings';
		EXECUTE 'DROP POLICY IF EXISTS menu_item_ratings_insert ON menu_item_ratings';
		EXECUTE 'DROP POLICY IF EXISTS menu_item_ratings_update ON menu_item_ratings';
		EXECUTE 'DROP POLICY IF EXISTS menu_item_ratings_delete ON menu_item_ratings';
	END IF;
END $$;

-- Policies: mirror feedbacks (allow anon + authenticated to insert/select)
CREATE POLICY menu_item_ratings_select
	ON menu_item_ratings FOR SELECT
	TO anon, authenticated
	USING (true);

CREATE POLICY menu_item_ratings_insert
	ON menu_item_ratings FOR INSERT
	TO anon, authenticated
	WITH CHECK (rating BETWEEN 1 AND 5);

-- (Optional) allow updates/deletes only to authenticated roles (staff)
CREATE POLICY menu_item_ratings_update
	ON menu_item_ratings FOR UPDATE
	TO authenticated
	USING (true)
	WITH CHECK (rating BETWEEN 1 AND 5);

CREATE POLICY menu_item_ratings_delete
	ON menu_item_ratings FOR DELETE
	TO authenticated
	USING (true);

-- Grants (in addition to global grants in 04_production_rls.sql)
GRANT SELECT ON menu_item_ratings TO anon, authenticated;
GRANT INSERT ON menu_item_ratings TO anon, authenticated;
GRANT UPDATE, DELETE ON menu_item_ratings TO authenticated;

-- Verify
SELECT tablename, rowsecurity FROM pg_tables WHERE tablename = 'menu_item_ratings';
SELECT policyname, cmd, roles FROM pg_policies WHERE tablename = 'menu_item_ratings' ORDER BY policyname;

-- Optional: Backfill restaurant_id from orders if missing
UPDATE menu_item_ratings mir
SET restaurant_id = o.restaurant_id
FROM orders o
WHERE mir.order_id = o.id AND mir.restaurant_id IS NULL;

