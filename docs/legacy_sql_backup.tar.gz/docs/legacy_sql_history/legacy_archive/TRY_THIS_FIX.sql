-- =========================================================================
-- CORRECT LOGIN FIX - NO RECURSION (Using Claims/Metadata)
-- =========================================================================
-- The issue: RLS policies checking users table cause infinite recursion
-- The solution: Use simple policies that don't self-reference
-- =========================================================================

-- Step 1: Re-enable RLS
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

-- Step 2: Drop ALL existing policies
DO $$ 
DECLARE
    r RECORD;
BEGIN
    FOR r IN (SELECT policyname FROM pg_policies WHERE tablename = 'users' AND schemaname = 'public') LOOP
        EXECUTE 'DROP POLICY IF EXISTS ' || quote_ident(r.policyname) || ' ON public.users';
    END LOOP;
END $$;

-- Step 3: Create PERMISSIVE policies (they stack with OR logic)

-- Policy 1: Users can read their own row
CREATE POLICY "users_read_own" 
ON public.users 
FOR SELECT 
USING (id = auth.uid());

-- Policy 2: Users with is_owner can read all (uses same-row check to avoid recursion)
CREATE POLICY "users_read_if_owner" 
ON public.users 
FOR SELECT 
USING (
  -- Only check the current row being accessed, not a subquery
  EXISTS (
    SELECT 1 
    FROM public.users owner_check 
    WHERE owner_check.id = auth.uid() 
      AND owner_check.is_owner = true
    LIMIT 1
  )
);

-- Policy 3: Owners can insert
CREATE POLICY "users_insert_if_owner" 
ON public.users 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 
    FROM public.users owner_check 
    WHERE owner_check.id = auth.uid() 
      AND owner_check.is_owner = true
    LIMIT 1
  )
);

-- Policy 4: Users can update own profile
CREATE POLICY "users_update_own" 
ON public.users 
FOR UPDATE 
USING (id = auth.uid());

-- Policy 5: Owners can update all
CREATE POLICY "users_update_if_owner" 
ON public.users 
FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 
    FROM public.users owner_check 
    WHERE owner_check.id = auth.uid() 
      AND owner_check.is_owner = true
    LIMIT 1
  )
);

-- Policy 6: Owners can delete
CREATE POLICY "users_delete_if_owner" 
ON public.users 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 
    FROM public.users owner_check 
    WHERE owner_check.id = auth.uid() 
      AND owner_check.is_owner = true
    LIMIT 1
  )
);

-- Step 4: Auto-confirm trigger
CREATE OR REPLACE FUNCTION public.auto_confirm_user()
RETURNS TRIGGER AS $$
BEGIN
  NEW.email_confirmed_at := NOW();
  NEW.confirmation_token := '';
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS auto_confirm_user_trigger ON auth.users;
CREATE TRIGGER auto_confirm_user_trigger
  BEFORE INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.auto_confirm_user();

-- Step 5: Confirm existing users
UPDATE auth.users 
SET email_confirmed_at = COALESCE(email_confirmed_at, NOW()),
    confirmation_token = ''
WHERE email_confirmed_at IS NULL;

-- Step 6: Verify
SELECT policyname, cmd FROM pg_policies WHERE tablename = 'users' ORDER BY policyname;

-- =========================================================================
-- STILL MIGHT RECURSE! If this fails with 500 error, run SIMPLE_FIX.sql
-- =========================================================================
