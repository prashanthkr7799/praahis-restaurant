-- ============================================================================
-- users: add phone column if missing (idempotent)
-- Purpose: Align users table with app/UI and admin RPCs that read/write phone
-- Run this before 14_staff_admin.sql and any profile upserts that include phone
-- ============================================================================

ALTER TABLE IF EXISTS public.users
  ADD COLUMN IF NOT EXISTS phone TEXT;

-- Optional: basic length check (commented out to avoid breaking existing data)
-- ALTER TABLE public.users
--   ADD CONSTRAINT users_phone_length CHECK (phone IS NULL OR length(phone) <= 32);

-- ============================================================================