-- =========================================================================
-- CLEANUP: Delete orphaned auth users
-- =========================================================================
-- This removes users from auth.users that don't exist in public.users
-- =========================================================================

-- Find orphaned auth users (exist in auth.users but not in public.users)
SELECT 
    'Orphaned Auth Users' as type,
    au.id,
    au.email,
    au.created_at
FROM auth.users au
LEFT JOIN public.users u ON au.id = u.id
WHERE u.id IS NULL
ORDER BY au.created_at DESC;

-- Delete orphaned auth users (UNCOMMENT TO RUN)
-- DELETE FROM auth.users
-- WHERE id IN (
--     SELECT au.id
--     FROM auth.users au
--     LEFT JOIN public.users u ON au.id = u.id
--     WHERE u.id IS NULL
-- );

-- =========================================================================
-- Instructions:
-- 1. First run the SELECT query to see orphaned users
-- 2. If you want to delete them, uncomment the DELETE section
-- 3. Run again
-- =========================================================================
