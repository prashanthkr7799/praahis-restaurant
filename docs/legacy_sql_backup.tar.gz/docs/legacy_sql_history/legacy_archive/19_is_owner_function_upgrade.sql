-- =========================================================================
-- Upgrade is_owner() to use users.is_owner boolean when available
-- Run after 18_users_is_owner.sql
-- =========================================================================

CREATE OR REPLACE FUNCTION public.is_owner()
RETURNS BOOLEAN AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.users u
    WHERE u.id = auth.uid() AND (
      COALESCE(u.is_owner, FALSE) = TRUE OR lower(u.role) = 'owner'
    )
  );
$$ LANGUAGE sql STABLE SECURITY DEFINER;

COMMENT ON FUNCTION public.is_owner() IS 'True when current auth.uid() is platform owner (users.is_owner=true or role=owner)';

-- =========================================================================
