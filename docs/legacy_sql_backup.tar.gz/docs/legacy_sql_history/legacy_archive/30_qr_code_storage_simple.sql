-- Simplified QR Code Storage Setup
-- Run this in Supabase SQL Editor if the full version has permission issues

-- Create bucket only (do policies via Dashboard UI)
INSERT INTO storage.buckets (id, name, public)
VALUES ('qr-codes', 'qr-codes', true)
ON CONFLICT (id) DO NOTHING;

-- Note: Add policies via Supabase Dashboard → Storage → qr-codes → Policies
-- See CLEANUP_AND_QR_IMPLEMENTATION_SUMMARY.md for policy details
