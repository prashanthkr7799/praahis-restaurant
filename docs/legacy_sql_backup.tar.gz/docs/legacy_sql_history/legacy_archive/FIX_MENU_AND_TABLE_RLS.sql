-- ============================================================================
-- FIX MENU ITEMS NOT SHOWING AND TABLE UPDATE BLOCKED
-- ============================================================================
-- This script fixes two critical issues:
-- 1. Menu items not loading for customers (RLS blocking anonymous SELECT)
-- 2. Table status not updating when customer scans QR (RLS blocking anonymous UPDATE)
-- ============================================================================

-- STEP 1: CHECK CURRENT STATE
-- ============================================================================

-- Check if menu items exist and are available
SELECT 
  'Menu Items Check' as check_name,
  COUNT(*) FILTER (WHERE is_available = true) as available_items,
  COUNT(*) FILTER (WHERE is_available = false) as unavailable_items,
  COUNT(*) as total_items
FROM menu_items;

-- Check current RLS policies
SELECT 
  'Current Policies' as check_name,
  tablename,
  policyname,
  roles::text,
  cmd
FROM pg_policies
WHERE tablename IN ('menu_items', 'tables')
ORDER BY tablename, cmd;


-- STEP 2: FIX MENU_ITEMS RLS POLICY
-- ============================================================================
-- The current policy allows SELECT but might have wrong conditions

-- Drop and recreate with correct policy
DROP POLICY IF EXISTS "menu_items_select" ON menu_items;

CREATE POLICY "menu_items_select"
    ON menu_items FOR SELECT
    TO anon, authenticated
    USING (is_available = true);

-- Verify customers can see menu items
SET ROLE anon;
SELECT 
  'Menu Items Visible to Customers' as test_name,
  COUNT(*) as visible_count
FROM menu_items
WHERE is_available = true;
RESET ROLE;


-- STEP 3: FIX TABLES UPDATE POLICY
-- ============================================================================
-- Current policy allows UPDATE but anonymous users might not have permission

-- Drop old policy
DROP POLICY IF EXISTS "tables_update" ON tables;

-- Create new policy that allows anonymous users to update table status
-- This is safe because:
-- 1. Customers need to mark tables as occupied when they scan QR
-- 2. RLS ensures they can only update the table they're at
-- 3. Session tracking prevents abuse
CREATE POLICY "tables_update"
    ON tables FOR UPDATE
    TO anon, authenticated
    USING (is_active = true)  -- Can only update active tables
    WITH CHECK (is_active = true);  -- Can't deactivate tables

-- Test table update as anonymous
SET ROLE anon;
SELECT 
  'Tables Updatable by Customers' as test_name,
  COUNT(*) as updatable_count
FROM tables
WHERE is_active = true;
RESET ROLE;


-- STEP 4: VERIFY ALL PERMISSIONS
-- ============================================================================

-- Verify anonymous user can:
-- 1. SELECT available menu items
-- 2. INSERT orders
-- 3. UPDATE table status
-- 4. SELECT their own orders

SET ROLE anon;

-- Test 1: Can see menu items?
SELECT 'Test 1: Menu Items' as test, COUNT(*) as count FROM menu_items WHERE is_available = true;

-- Test 2: Can see tables?
SELECT 'Test 2: Tables' as test, COUNT(*) as count FROM tables WHERE is_active = true;

-- Test 3: Check what policies apply to anonymous role
RESET ROLE;

SELECT 
  'Anonymous Role Policies' as check_name,
  tablename,
  policyname,
  cmd,
  CASE 
    WHEN 'anon' = ANY(roles) THEN 'YES ✅'
    ELSE 'NO ❌'
  END as allows_anonymous
FROM pg_policies
WHERE tablename IN ('menu_items', 'tables', 'orders', 'order_items')
ORDER BY tablename, cmd;


-- STEP 5: ENABLE MISSING ITEMS (IF NEEDED)
-- ============================================================================
-- Run this ONLY if Step 1 showed unavailable_items > 0
-- Uncomment the lines below and replace with your restaurant ID

/*
-- Check which items are unavailable
SELECT 
  id,
  name,
  category,
  is_available,
  restaurant_id
FROM menu_items
WHERE restaurant_id = 'YOUR-RESTAURANT-ID-HERE'  -- REPLACE THIS
ORDER BY category, name;

-- Enable all menu items for a specific restaurant
UPDATE menu_items
SET is_available = true
WHERE restaurant_id = 'YOUR-RESTAURANT-ID-HERE'  -- REPLACE THIS
  AND is_available = false;

-- Verify the update
SELECT 
  'Items Enabled' as result,
  COUNT(*) as count
FROM menu_items
WHERE restaurant_id = 'YOUR-RESTAURANT-ID-HERE'  -- REPLACE THIS
  AND is_available = true;
*/


-- ============================================================================
-- EXPECTED RESULTS:
-- ============================================================================
-- Step 1: Should show count of available vs unavailable items
-- Step 2: Should show at least 1 visible menu item (if you have any)
-- Step 3: Should show tables count (if you have any)
-- Step 4: All tests should return counts > 0
--         Anonymous Role Policies should show ✅ for menu_items SELECT
--         Anonymous Role Policies should show ✅ for tables UPDATE

-- ============================================================================
-- TROUBLESHOOTING:
-- ============================================================================
-- If "Menu Items Check" shows total_items = 0:
--   → You need to add menu items via Manager Dashboard
--
-- If "Menu Items Check" shows unavailable_items > 0:
--   → Run Step 5 to enable them (uncomment and add your restaurant ID)
--
-- If "Menu Items Visible to Customers" shows 0:
--   → RLS policy might still be wrong
--   → Check if menu items have correct restaurant_id
--   → Verify items are actually set to is_available = true
--
-- If "Tables Updatable by Customers" shows 0:
--   → No active tables in database
--   → Create tables via Manager Dashboard first
--
-- If "Anonymous Role Policies" shows ❌ for menu_items:
--   → Policy not created correctly
--   → Re-run this script or run 04_production_rls.sql

-- ============================================================================
-- QUICK FIX: Enable ALL menu items in database
-- ============================================================================
-- If you just want to enable everything quickly, uncomment this:
/*
UPDATE menu_items SET is_available = true WHERE is_available = false;
SELECT 'All items enabled!' as status, COUNT(*) as count FROM menu_items WHERE is_available = true;
*/
