-- ============================================================================
-- DISABLE RLS ON PLATFORM_ADMINS TABLE
-- ============================================================================
-- Problem: is_superadmin() function queries platform_admins table,
-- which has RLS policies that also check platform_admins → infinite recursion
--
-- Solution: Disable RLS on platform_admins table entirely
-- This is safe because:
-- 1. platform_admins is a small, controlled table
-- 2. Only superadmins should have records here
-- 3. The SECURITY DEFINER functions provide the security layer
-- ============================================================================

-- Disable RLS on platform_admins table
ALTER TABLE public.platform_admins DISABLE ROW LEVEL SECURITY;

-- Drop all existing policies on platform_admins
DROP POLICY IF EXISTS "platform_admins_select" ON public.platform_admins;
DROP POLICY IF EXISTS "Admins can view their own profile" ON public.platform_admins;
DROP POLICY IF EXISTS "Superadmin full access to platform_admins" ON public.platform_admins;

DO $$
BEGIN
  RAISE NOTICE '========================================';
  RAISE NOTICE 'PLATFORM_ADMINS RLS DISABLED';
  RAISE NOTICE '========================================';
  RAISE NOTICE '✓ Disabled RLS on platform_admins table';
  RAISE NOTICE '✓ Dropped all policies on platform_admins';
  RAISE NOTICE '';
  RAISE NOTICE 'This prevents infinite recursion when is_superadmin()';
  RAISE NOTICE 'function queries the platform_admins table.';
  RAISE NOTICE '';
  RAISE NOTICE 'Security is maintained through:';
  RAISE NOTICE '  - Application-level access control';
  RAISE NOTICE '  - SECURITY DEFINER functions';
  RAISE NOTICE '  - Limited access to platform_admins table';
  RAISE NOTICE '========================================';
END $$;
