-- ============================================================================
-- COMPREHENSIVE RLS CLEANUP AND FIX
-- ============================================================================
-- This removes ALL existing policies and creates clean, correct ones
-- Safe to run multiple times
-- ============================================================================

-- ============================================================================
-- STEP 1: DROP ALL EXISTING POLICIES (Complete cleanup)
-- ============================================================================

-- Drop all policies on USERS table
DROP POLICY IF EXISTS "owner_users_all_operations" ON public.users;
DROP POLICY IF EXISTS "owner_users_select_all" ON public.users;
DROP POLICY IF EXISTS "users_allow_insert" ON public.users;
DROP POLICY IF EXISTS "users_allow_update" ON public.users;
DROP POLICY IF EXISTS "users_delete" ON public.users;
DROP POLICY IF EXISTS "users_select" ON public.users;
DROP POLICY IF EXISTS "users_select_own" ON public.users;
DROP POLICY IF EXISTS "users_update_own" ON public.users;
DROP POLICY IF EXISTS "owners_read_all_users" ON public.users;
DROP POLICY IF EXISTS "Platform owners can view all users" ON public.users;
DROP POLICY IF EXISTS "Platform owners can manage all users" ON public.users;
DROP POLICY IF EXISTS "Users can view their own profile" ON public.users;
DROP POLICY IF EXISTS "Users can update their own profile" ON public.users;
DROP POLICY IF EXISTS "users_read_own_profile" ON public.users;
DROP POLICY IF EXISTS "users_update_own_profile" ON public.users;

-- Drop all policies on SUBSCRIPTIONS table
DROP POLICY IF EXISTS "owner_subscriptions_all_operations" ON public.subscriptions;
DROP POLICY IF EXISTS "owner_subscriptions_select_all" ON public.subscriptions;
DROP POLICY IF EXISTS "manager_subscriptions_select_own_restaurant" ON public.subscriptions;
DROP POLICY IF EXISTS "subscriptions_delete" ON public.subscriptions;
DROP POLICY IF EXISTS "subscriptions_insert" ON public.subscriptions;
DROP POLICY IF EXISTS "subscriptions_select" ON public.subscriptions;
DROP POLICY IF EXISTS "subscriptions_update" ON public.subscriptions;
DROP POLICY IF EXISTS "owners_read_all_subscriptions" ON public.subscriptions;
DROP POLICY IF EXISTS "Platform owners can view all subscriptions" ON public.subscriptions;
DROP POLICY IF EXISTS "Platform owners can manage all subscriptions" ON public.subscriptions;
DROP POLICY IF EXISTS "Managers can view own restaurant subscriptions" ON public.subscriptions;
DROP POLICY IF EXISTS "authenticated_read_subscriptions" ON public.subscriptions;

-- Drop all policies on RESTAURANTS table
DROP POLICY IF EXISTS "owner_restaurants_all_operations" ON public.restaurants;
DROP POLICY IF EXISTS "owner_restaurants_select_all" ON public.restaurants;
DROP POLICY IF EXISTS "manager_restaurants_select_own" ON public.restaurants;
DROP POLICY IF EXISTS "restaurants_select" ON public.restaurants;
DROP POLICY IF EXISTS "owners_delete_restaurants" ON public.restaurants;
DROP POLICY IF EXISTS "owners_insert_restaurants" ON public.restaurants;
DROP POLICY IF EXISTS "owners_update_restaurants" ON public.restaurants;
DROP POLICY IF EXISTS "owners_read_all_restaurants" ON public.restaurants;
DROP POLICY IF EXISTS "Platform owners can view all restaurants" ON public.restaurants;
DROP POLICY IF EXISTS "Platform owners can manage all restaurants" ON public.restaurants;
DROP POLICY IF EXISTS "authenticated_read_restaurants" ON public.restaurants;

-- ============================================================================
-- STEP 2: Ensure RLS is enabled
-- ============================================================================
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.restaurants ENABLE ROW LEVEL SECURITY;

-- ============================================================================
-- STEP 3: Create USERS table policies (Simple and Clean)
-- ============================================================================

-- Everyone can read their own profile
CREATE POLICY "users_select_own"
ON public.users
FOR SELECT
TO authenticated
USING (id = auth.uid());

-- Everyone can update their own profile
CREATE POLICY "users_update_own"
ON public.users
FOR UPDATE
TO authenticated
USING (id = auth.uid())
WITH CHECK (id = auth.uid());

-- Owners can read ALL users
CREATE POLICY "owner_users_select_all"
ON public.users
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users 
    WHERE id = auth.uid() 
    AND is_owner = true 
    LIMIT 1
  )
);

-- Owners can insert new users
CREATE POLICY "owner_users_insert"
ON public.users
FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.users 
    WHERE id = auth.uid() 
    AND is_owner = true 
    LIMIT 1
  )
);

-- Owners can update all users
CREATE POLICY "owner_users_update_all"
ON public.users
FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users 
    WHERE id = auth.uid() 
    AND is_owner = true 
    LIMIT 1
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.users 
    WHERE id = auth.uid() 
    AND is_owner = true 
    LIMIT 1
  )
);

-- Owners can delete users
CREATE POLICY "owner_users_delete"
ON public.users
FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users 
    WHERE id = auth.uid() 
    AND is_owner = true 
    LIMIT 1
  )
);

-- ============================================================================
-- STEP 4: Create SUBSCRIPTIONS table policies
-- ============================================================================

-- Owners can read all subscriptions
CREATE POLICY "owner_subscriptions_select_all"
ON public.subscriptions
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users 
    WHERE id = auth.uid() 
    AND is_owner = true 
    LIMIT 1
  )
);

-- Owners can insert subscriptions
CREATE POLICY "owner_subscriptions_insert"
ON public.subscriptions
FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.users 
    WHERE id = auth.uid() 
    AND is_owner = true 
    LIMIT 1
  )
);

-- Owners can update subscriptions
CREATE POLICY "owner_subscriptions_update"
ON public.subscriptions
FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users 
    WHERE id = auth.uid() 
    AND is_owner = true 
    LIMIT 1
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.users 
    WHERE id = auth.uid() 
    AND is_owner = true 
    LIMIT 1
  )
);

-- Owners can delete subscriptions
CREATE POLICY "owner_subscriptions_delete"
ON public.subscriptions
FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users 
    WHERE id = auth.uid() 
    AND is_owner = true 
    LIMIT 1
  )
);

-- Managers can view their restaurant's subscription
CREATE POLICY "manager_subscriptions_select_own_restaurant"
ON public.subscriptions
FOR SELECT
TO authenticated
USING (
  restaurant_id IN (
    SELECT restaurant_id 
    FROM public.users 
    WHERE id = auth.uid()
  )
);

-- ============================================================================
-- STEP 5: Create RESTAURANTS table policies
-- ============================================================================

-- Owners can read all restaurants
CREATE POLICY "owner_restaurants_select_all"
ON public.restaurants
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users 
    WHERE id = auth.uid() 
    AND is_owner = true 
    LIMIT 1
  )
);

-- Owners can insert restaurants
CREATE POLICY "owner_restaurants_insert"
ON public.restaurants
FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.users 
    WHERE id = auth.uid() 
    AND is_owner = true 
    LIMIT 1
  )
);

-- Owners can update restaurants
CREATE POLICY "owner_restaurants_update"
ON public.restaurants
FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users 
    WHERE id = auth.uid() 
    AND is_owner = true 
    LIMIT 1
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.users 
    WHERE id = auth.uid() 
    AND is_owner = true 
    LIMIT 1
  )
);

-- Owners can delete restaurants
CREATE POLICY "owner_restaurants_delete"
ON public.restaurants
FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users 
    WHERE id = auth.uid() 
    AND is_owner = true 
    LIMIT 1
  )
);

-- Managers can view their own restaurant
CREATE POLICY "manager_restaurants_select_own"
ON public.restaurants
FOR SELECT
TO authenticated
USING (
  id IN (
    SELECT restaurant_id 
    FROM public.users 
    WHERE id = auth.uid()
  )
);

-- ============================================================================
-- STEP 6: Ensure superadmin user exists and is marked as owner
-- ============================================================================
DO $$
DECLARE
  v_user_id UUID;
BEGIN
  -- Find the superadmin user in auth.users
  SELECT id INTO v_user_id
  FROM auth.users
  WHERE email = 'prashanthkumarreddy879@gmail.com'
  LIMIT 1;

  IF v_user_id IS NOT NULL THEN
    -- Ensure they exist in public.users with is_owner = true
    INSERT INTO public.users (
      id,
      email,
      name,
      full_name,
      role,
      is_owner,
      is_active,
      restaurant_id
    )
    VALUES (
      v_user_id,
      'prashanthkumarreddy879@gmail.com',
      'Super Admin',
      'Super Admin',
      'owner',
      true,
      true,
      NULL
    )
    ON CONFLICT (id) DO UPDATE
    SET is_owner = true,
        role = 'owner',
        is_active = true,
        restaurant_id = NULL;

    RAISE NOTICE '✅ Superadmin user configured: %', v_user_id;
  ELSE
    RAISE WARNING '⚠️  Superadmin user not found in auth.users';
  END IF;
END $$;

-- ============================================================================
-- STEP 7: Grant permissions
-- ============================================================================
GRANT SELECT, INSERT, UPDATE, DELETE ON public.users TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.subscriptions TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.restaurants TO authenticated;

-- ============================================================================
-- STEP 8: Verify the setup
-- ============================================================================

-- Show owner user
SELECT 
  '👤 OWNER USER' as section,
  id,
  email,
  role,
  is_owner,
  is_active,
  restaurant_id
FROM public.users
WHERE email = 'prashanthkumarreddy879@gmail.com';

-- Count policies per table
SELECT 
  '📊 POLICY COUNTS' as section,
  tablename,
  COUNT(*) as policy_count
FROM pg_policies
WHERE schemaname = 'public'
  AND tablename IN ('users', 'subscriptions', 'restaurants')
GROUP BY tablename
ORDER BY tablename;

-- List all policies
SELECT 
  '📋 ALL POLICIES' as section,
  tablename,
  policyname,
  cmd as operation
FROM pg_policies
WHERE schemaname = 'public'
  AND tablename IN ('users', 'subscriptions', 'restaurants')
ORDER BY tablename, cmd, policyname;

-- ============================================================================
-- DONE!
-- ============================================================================
DO $$
BEGIN
  RAISE NOTICE '';
  RAISE NOTICE '════════════════════════════════════════════════════════';
  RAISE NOTICE '✅ RLS POLICIES COMPLETELY REBUILT!';
  RAISE NOTICE '════════════════════════════════════════════════════════';
  RAISE NOTICE '';
  RAISE NOTICE '✓ Removed ALL old conflicting policies';
  RAISE NOTICE '✓ Created clean owner policies (6 per table)';
  RAISE NOTICE '✓ Created manager policies for restaurant access';
  RAISE NOTICE '✓ Verified superadmin user is marked as owner';
  RAISE NOTICE '';
  RAISE NOTICE '📊 Expected Policy Counts:';
  RAISE NOTICE '   • users table: 6 policies';
  RAISE NOTICE '   • subscriptions table: 5 policies';
  RAISE NOTICE '   • restaurants table: 6 policies';
  RAISE NOTICE '';
  RAISE NOTICE '📝 NEXT STEPS:';
  RAISE NOTICE '   1. Logout from superadmin portal';
  RAISE NOTICE '   2. Clear browser cache (Cmd+Shift+R)';
  RAISE NOTICE '   3. Login again at /superadmin-login';
  RAISE NOTICE '   4. Verify you see managers and subscriptions!';
  RAISE NOTICE '';
  RAISE NOTICE '════════════════════════════════════════════════════════';
END $$;
