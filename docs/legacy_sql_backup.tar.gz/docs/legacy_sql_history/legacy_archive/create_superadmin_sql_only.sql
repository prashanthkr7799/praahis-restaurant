-- =========================================================================
-- CREATE SUPERADMIN USER - Completely via SQL
-- =========================================================================
-- This script creates BOTH the Auth user AND the database record
-- No need to use the Supabase Dashboard!
-- =========================================================================

-- Step 1: Create the Auth user using Supabase Admin API
-- Note: This uses the auth.users table (managed by Supabase Auth)
DO $$
DECLARE
    new_user_id UUID;
    user_email TEXT := 'admin@praahis.com';  -- ⚠️ CHANGE THIS!
    user_password TEXT := 'YourSecurePassword123!';  -- ⚠️ CHANGE THIS!
    user_name TEXT := 'Super Admin';  -- ⚠️ CHANGE THIS!
BEGIN
    -- Insert into auth.users (Supabase Auth table)
    INSERT INTO auth.users (
        instance_id,
        id,
        aud,
        role,
        email,
        encrypted_password,
        email_confirmed_at,
        raw_app_meta_data,
        raw_user_meta_data,
        created_at,
        updated_at,
        confirmation_token,
        email_change,
        email_change_token_new,
        recovery_token
    ) VALUES (
        '00000000-0000-0000-0000-000000000000',
        gen_random_uuid(),
        'authenticated',
        'authenticated',
        user_email,
        crypt(user_password, gen_salt('bf')),  -- Encrypt the password
        NOW(),
        '{"provider":"email","providers":["email"]}',
        jsonb_build_object('full_name', user_name),
        NOW(),
        NOW(),
        '',
        '',
        '',
        ''
    )
    RETURNING id INTO new_user_id;

    -- Insert into public.users (your application table)
    INSERT INTO public.users (
        id,
        email,
        full_name,
        name,
        role,
        is_owner,
        is_active,
        restaurant_id,
        created_at,
        updated_at
    ) VALUES (
        new_user_id,
        user_email,
        user_name,
        user_name,
        'owner',
        TRUE,
        TRUE,
        NULL,
        NOW(),
        NOW()
    );

    RAISE NOTICE 'SuperAdmin user created successfully!';
    RAISE NOTICE 'Email: %', user_email;
    RAISE NOTICE 'User ID: %', new_user_id;
    RAISE NOTICE 'You can now login with this email and password.';
END $$;

-- Step 2: Verify the user was created
SELECT 
    u.id,
    u.email,
    u.full_name,
    u.role,
    u.is_owner,
    u.is_active,
    au.email_confirmed_at,
    au.created_at
FROM public.users u
LEFT JOIN auth.users au ON u.id = au.id
WHERE u.is_owner = TRUE
ORDER BY u.created_at DESC;

-- =========================================================================
-- Instructions:
-- 1. Update the variables at the top:
--    - user_email: Your email address
--    - user_password: Your secure password (min 6 characters)
--    - user_name: Your display name
-- 2. Run this entire script in Supabase SQL Editor
-- 3. Login immediately with the email and password you set!
-- =========================================================================

-- OPTIONAL: If user already exists and you just want to update permissions:
-- UPDATE public.users 
-- SET is_owner = TRUE, 
--     role = 'owner',
--     is_active = TRUE
-- WHERE email = 'admin@praahis.com';  -- Change to your email
