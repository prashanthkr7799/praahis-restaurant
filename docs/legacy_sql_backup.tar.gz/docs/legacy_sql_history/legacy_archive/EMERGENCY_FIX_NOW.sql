-- ============================================================================
-- EMERGENCY FIX: Enable Menu Items and Fix Table Updates
-- ============================================================================
-- This script will:
-- 1. Show you exactly what's in your database
-- 2. Enable all menu items that are disabled
-- 3. Fix RLS policies if needed
-- 4. Verify everything works
-- ============================================================================

-- ============================================================================
-- STEP 1: CURRENT STATE - What do we have?
-- ============================================================================

-- Check menu items status
SELECT 
  '1a. Menu Items Count' as check_name,
  COUNT(*) as total_items,
  COUNT(*) FILTER (WHERE is_available = true) as available,
  COUNT(*) FILTER (WHERE is_available = false) as unavailable
FROM menu_items;

-- Check menu items by restaurant
SELECT 
  '1b. Menu Items by Restaurant' as check_name,
  r.name as restaurant_name,
  r.slug as restaurant_slug,
  COUNT(m.id) as total_items,
  COUNT(m.id) FILTER (WHERE m.is_available = true) as available_items,
  COUNT(m.id) FILTER (WHERE m.is_available = false) as unavailable_items
FROM restaurants r
LEFT JOIN menu_items m ON m.restaurant_id = r.id
GROUP BY r.id, r.name, r.slug
ORDER BY r.name;

-- Show actual menu items
SELECT 
  '1c. All Menu Items Details' as check_name,
  m.id,
  m.name,
  m.category,
  m.price,
  m.is_available,
  r.name as restaurant_name
FROM menu_items m
JOIN restaurants r ON r.id = m.restaurant_id
ORDER BY r.name, m.category, m.name;


-- ============================================================================
-- STEP 2: FIX - Enable ALL menu items
-- ============================================================================

-- Enable all menu items
UPDATE menu_items 
SET is_available = true 
WHERE is_available = false;

-- Show what changed
SELECT 
  '2a. Items Enabled' as result,
  COUNT(*) as newly_enabled_count
FROM menu_items
WHERE is_available = true;


-- ============================================================================
-- STEP 3: FIX - Update RLS Policies
-- ============================================================================

-- Drop existing menu_items SELECT policies
DROP POLICY IF EXISTS "menu_items_select" ON menu_items;
DROP POLICY IF EXISTS "menu_items_chef_select" ON menu_items;
DROP POLICY IF EXISTS "menu_items_waiter_select" ON menu_items;
DROP POLICY IF EXISTS "menu_items_read_own" ON menu_items;

-- Create simple, permissive policy for menu items
CREATE POLICY "menu_items_select" ON menu_items
FOR SELECT TO authenticated, anon
USING (
  is_available = true -- Anyone can see available items
  OR
  -- Staff can see all items for their restaurant
  EXISTS (
    SELECT 1 FROM users u
    WHERE u.id = auth.uid()
    AND u.restaurant_id = menu_items.restaurant_id
  )
);

-- Drop existing tables UPDATE policies
DROP POLICY IF EXISTS "tables_update" ON tables;
DROP POLICY IF EXISTS "tables_waiter_update" ON tables;

-- Create simple, permissive policy for tables
CREATE POLICY "tables_update" ON tables
FOR UPDATE TO authenticated, anon
USING (is_active = true)  -- Can update active tables
WITH CHECK (is_active = true);  -- Can't deactivate

SELECT '3a. Policies Updated' as result, 'Success' as status;


-- ============================================================================
-- STEP 4: VERIFY - Test as anonymous user (customer)
-- ============================================================================

-- Test as anonymous user
SET ROLE anon;

-- Can see menu items?
SELECT 
  '4a. Menu Items Visible to Customers' as test_name,
  COUNT(*) as visible_count
FROM menu_items
WHERE is_available = true;

-- Can see tables?
SELECT 
  '4b. Tables Visible to Customers' as test_name,
  COUNT(*) as visible_count
FROM tables
WHERE is_active = true;

RESET ROLE;


-- ============================================================================
-- STEP 5: FINAL CHECK - Everything should work now
-- ============================================================================

-- Show final state
SELECT 
  '5a. FINAL STATE' as check_name,
  COUNT(*) as total_items,
  COUNT(*) FILTER (WHERE is_available = true) as available_for_customers,
  COUNT(*) FILTER (WHERE is_available = false) as hidden
FROM menu_items;

-- Show active policies
SELECT 
  '5b. Active Policies' as check_name,
  tablename,
  policyname,
  cmd as operation,
  CASE 
    WHEN 'anon' = ANY(roles) THEN 'YES - Customers can use'
    ELSE 'NO - Requires login'
  END as allows_customers
FROM pg_policies
WHERE tablename IN ('menu_items', 'tables')
ORDER BY tablename, cmd;


-- ============================================================================
-- SUCCESS! If you see counts > 0 above, menu items should now appear
--
-- Next steps:
-- 1. Clear your browser cache (Ctrl+Shift+Delete or Cmd+Shift+Delete)
-- 2. Reload the ordering page
-- 3. Menu items should appear
-- 4. QR code scanning should work (no RLS error)
-- ============================================================================
