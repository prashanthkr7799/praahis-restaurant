-- ============================================================================
-- FIX: Add end_date as alias/view for current_period_end
-- ============================================================================
-- The subscriptions table uses current_period_end, but frontend expects end_date
-- Solution: Add end_date column and sync it with current_period_end

-- Add end_date column if missing
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name='subscriptions' AND column_name='end_date'
  ) THEN
    -- Add the column
    ALTER TABLE subscriptions ADD COLUMN end_date TIMESTAMPTZ;
    
    -- Copy existing values from current_period_end
    UPDATE subscriptions 
    SET end_date = current_period_end;
    
    -- Make it NOT NULL
    ALTER TABLE subscriptions ALTER COLUMN end_date SET NOT NULL;
  END IF;
END $$;

-- Create trigger to keep end_date synced with current_period_end
CREATE OR REPLACE FUNCTION sync_subscription_end_date()
RETURNS TRIGGER AS $$
BEGIN
  NEW.end_date = NEW.current_period_end;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS sync_end_date_trigger ON subscriptions;
CREATE TRIGGER sync_end_date_trigger
  BEFORE INSERT OR UPDATE ON subscriptions
  FOR EACH ROW
  EXECUTE FUNCTION sync_subscription_end_date();

-- Verify the columns
SELECT 
  'Subscriptions Columns' as check_name,
  column_name,
  data_type,
  is_nullable
FROM information_schema.columns
WHERE table_name = 'subscriptions'
AND column_name IN ('current_period_start', 'current_period_end', 'end_date', 'status', 'trial_ends_at')
ORDER BY ordinal_position;
