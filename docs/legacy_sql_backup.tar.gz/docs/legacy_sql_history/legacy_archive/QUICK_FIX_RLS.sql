-- QUICK FIX: Run this in Supabase SQL Editor
-- This will allow your owner account to see all data

-- 1. Make sure your user is marked as owner
UPDATE public.users
SET is_owner = true,
    role = 'owner'
WHERE email = 'prashanthkumarreddy879@gmail.com';

-- 2. Allow owners to see subscriptions
DROP POLICY IF EXISTS "owners_read_all_subscriptions" ON public.subscriptions;
CREATE POLICY "owners_read_all_subscriptions"
ON public.subscriptions FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users
    WHERE users.id = auth.uid()
    AND users.is_owner = true
  )
);

-- 3. Allow owners to see all users (managers)
DROP POLICY IF EXISTS "owners_read_all_users" ON public.users;
CREATE POLICY "owners_read_all_users"
ON public.users FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users u2
    WHERE u2.id = auth.uid()
    AND u2.is_owner = true
  )
  OR id = auth.uid()
);

-- Verify
SELECT 'Owner user updated:' as status, COUNT(*) as count
FROM public.users WHERE is_owner = true;
