-- ============================================================================
-- TEMPORARILY DISABLE RLS ON BILLING TABLE FOR TESTING
-- ============================================================================
-- This helps us verify the data exists and is being stored correctly
-- We'll re-enable proper RLS after confirming the billing data is visible

-- Check current RLS status
SELECT tablename, rowsecurity FROM pg_tables 
WHERE tablename IN ('billing', 'payments') 
ORDER BY tablename;

-- Disable RLS on billing table temporarily
ALTER TABLE billing DISABLE ROW LEVEL SECURITY;

-- Disable RLS on payments table temporarily
ALTER TABLE payments DISABLE ROW LEVEL SECURITY;

-- Verify RLS is disabled
SELECT tablename, rowsecurity FROM pg_tables 
WHERE tablename IN ('billing', 'payments') 
ORDER BY tablename;

-- Test query to see if billing data is accessible
SELECT 
    b.id,
    b.restaurant_id,
    b.invoice_number,
    b.billing_month,
    b.billing_year,
    b.total_amount,
    b.status,
    r.name as restaurant_name
FROM billing b
LEFT JOIN restaurants r ON r.id = b.restaurant_id
ORDER BY b.billing_year DESC, b.billing_month DESC
LIMIT 10;
