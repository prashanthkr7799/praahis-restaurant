-- ============================================================================
-- RESTAURANTS TABLE - OWNER RLS POLICIES
-- ============================================================================
-- Version: 1.0
-- Created: November 6, 2025
-- Description: Add RLS policies for super admin (owner) to manage restaurants
-- Run after: 23_superadmin_schema.sql
-- ============================================================================

-- Ensure RLS is enabled on restaurants table
ALTER TABLE restaurants ENABLE ROW LEVEL SECURITY;

-- ============================================================================
-- OWNER POLICIES FOR RESTAURANTS
-- ============================================================================

-- Owners can view all restaurants
DROP POLICY IF EXISTS "Owners can view all restaurants" ON restaurants;
CREATE POLICY "Owners can view all restaurants" ON restaurants
    FOR SELECT
    USING (public.is_owner());

-- Owners can insert new restaurants
DROP POLICY IF EXISTS "Owners can insert restaurants" ON restaurants;
CREATE POLICY "Owners can insert restaurants" ON restaurants
    FOR INSERT
    WITH CHECK (public.is_owner());

-- Owners can update any restaurant
DROP POLICY IF EXISTS "Owners can update restaurants" ON restaurants;
CREATE POLICY "Owners can update restaurants" ON restaurants
    FOR UPDATE
    USING (public.is_owner())
    WITH CHECK (public.is_owner());

-- Owners can delete any restaurant
DROP POLICY IF EXISTS "Owners can delete restaurants" ON restaurants;
CREATE POLICY "Owners can delete restaurants" ON restaurants
    FOR DELETE
    USING (public.is_owner());

-- ============================================================================
-- VERIFICATION
-- ============================================================================

DO $$
BEGIN
    RAISE NOTICE 'Owner RLS policies for restaurants table created successfully!';
END $$;

-- ============================================================================
-- END OF OWNER POLICIES
-- ============================================================================
