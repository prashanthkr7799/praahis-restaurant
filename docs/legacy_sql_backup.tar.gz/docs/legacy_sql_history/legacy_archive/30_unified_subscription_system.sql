-- ============================================================================
-- PRAAHIS UNIFIED SUBSCRIPTION SYSTEM
-- ============================================================================
-- Single Plan Model: ₹35,000/month + ₹5,000 one-time setup
-- 3-day free trial → 3-day grace period → Auto-suspension
-- Netflix-style: Simple, automatic, instant reactivation
-- ============================================================================

-- ============================================================================
-- 1. DROP EXISTING TABLES (IF MIGRATING FROM OLD SYSTEM)
-- ============================================================================
-- Uncomment these if you want to start fresh
-- DROP TABLE IF EXISTS payments CASCADE;
-- DROP TABLE IF EXISTS subscriptions CASCADE;

-- ============================================================================
-- 2. SUBSCRIPTIONS TABLE (Unified Single Plan)
-- ============================================================================
CREATE TABLE IF NOT EXISTS subscriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
    
    -- Subscription Period
    start_date TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    end_date TIMESTAMPTZ NOT NULL, -- Trial: NOW() + 3 days, Paid: NOW() + 30 days
    
    -- Status: 'trial', 'active', 'grace', 'suspended', 'cancelled'
    status TEXT NOT NULL DEFAULT 'trial' CHECK (status IN ('trial', 'active', 'grace', 'suspended', 'cancelled')),
    
    -- Payment Info
    last_payment_date TIMESTAMPTZ,
    next_billing_date TIMESTAMPTZ,
    setup_fee_paid BOOLEAN DEFAULT FALSE, -- ₹5,000 one-time setup fee
    
    -- Trial & Grace
    trial_ends_at TIMESTAMPTZ, -- Set for trial plans (3 days from start)
    grace_period_days INTEGER DEFAULT 3, -- Days after expiry before suspension
    grace_period_start TIMESTAMPTZ, -- When grace period started (on expiry)
    
    -- Metadata
    suspended_at TIMESTAMPTZ, -- When subscription was suspended
    suspended_reason TEXT,
    cancelled_at TIMESTAMPTZ,
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    
    -- Ensure one subscription per restaurant
    UNIQUE(restaurant_id)
);

-- Index for performance
CREATE INDEX IF NOT EXISTS idx_subscriptions_restaurant ON subscriptions(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_status ON subscriptions(status);
CREATE INDEX IF NOT EXISTS idx_subscriptions_end_date ON subscriptions(end_date);
CREATE INDEX IF NOT EXISTS idx_subscriptions_next_billing ON subscriptions(next_billing_date);

-- ============================================================================
-- 3. PAYMENTS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS payments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
    subscription_id UUID REFERENCES subscriptions(id) ON DELETE SET NULL,
    
    -- Payment Details
    amount DECIMAL(10, 2) NOT NULL, -- ₹35,000 or ₹5,000
    payment_type TEXT NOT NULL CHECK (payment_type IN ('setup_fee', 'monthly_subscription', 'renewal')),
    
    -- Payment Gateway
    payment_method TEXT, -- 'razorpay', 'stripe', 'manual', 'bank_transfer'
    payment_gateway_id TEXT, -- Razorpay/Stripe payment ID
    payment_gateway_order_id TEXT, -- Razorpay/Stripe order ID
    
    -- Status
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed', 'refunded')),
    
    -- Dates
    payment_date TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    failed_at TIMESTAMPTZ,
    
    -- Metadata
    receipt_url TEXT,
    invoice_number TEXT,
    notes TEXT,
    metadata JSONB, -- Store gateway response
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_payments_restaurant ON payments(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_payments_subscription ON payments(subscription_id);
CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);
CREATE INDEX IF NOT EXISTS idx_payments_date ON payments(payment_date);
CREATE INDEX IF NOT EXISTS idx_payments_gateway_id ON payments(payment_gateway_id);

-- ============================================================================
-- 4. PLATFORM SETTINGS FOR SUBSCRIPTION CONFIG
-- ============================================================================
INSERT INTO platform_settings (key, value, category, description) VALUES
    ('subscription_monthly_price', '35000', 'pricing', 'Monthly subscription price in rupees'),
    ('subscription_setup_fee', '5000', 'pricing', 'One-time setup fee in rupees'),
    ('subscription_trial_days', '3', 'subscription', 'Free trial period in days'),
    ('subscription_grace_days', '3', 'subscription', 'Grace period after expiry in days'),
    ('subscription_auto_suspend', 'true', 'subscription', 'Automatically suspend expired subscriptions'),
    ('subscription_warning_days', '[3, 1, 0]', 'subscription', 'Days before expiry to send warnings'),
    ('subscription_currency', 'INR', 'pricing', 'Currency for payments'),
    ('payment_gateway', 'razorpay', 'payment', 'Default payment gateway')
ON CONFLICT (key) DO UPDATE SET
    value = EXCLUDED.value,
    description = EXCLUDED.description,
    updated_at = NOW();

-- ============================================================================
-- 5. FUNCTION: Check Subscription Status
-- ============================================================================
CREATE OR REPLACE FUNCTION check_subscription_status(p_restaurant_id UUID)
RETURNS TABLE(
    status TEXT,
    is_active BOOLEAN,
    days_remaining INTEGER,
    in_grace_period BOOLEAN,
    message TEXT
) 
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_subscription RECORD;
    v_now TIMESTAMPTZ := NOW();
    v_days_left INTEGER;
    v_grace_days INTEGER;
BEGIN
    -- Get subscription
    SELECT * INTO v_subscription
    FROM subscriptions
    WHERE restaurant_id = p_restaurant_id;
    
    -- No subscription found
    IF v_subscription IS NULL THEN
        RETURN QUERY SELECT 
            'none'::TEXT,
            FALSE,
            0,
            FALSE,
            'No subscription found. Please contact support.'::TEXT;
        RETURN;
    END IF;
    
    -- Calculate days remaining
    v_days_left := EXTRACT(DAY FROM (v_subscription.end_date - v_now))::INTEGER;
    v_grace_days := COALESCE(v_subscription.grace_period_days, 3);
    
    -- Status: Suspended
    IF v_subscription.status = 'suspended' THEN
        RETURN QUERY SELECT 
            'suspended'::TEXT,
            FALSE,
            0,
            FALSE,
            'Your subscription has been suspended. Please renew to continue.'::TEXT;
        RETURN;
    END IF;
    
    -- Status: Cancelled
    IF v_subscription.status = 'cancelled' THEN
        RETURN QUERY SELECT 
            'cancelled'::TEXT,
            FALSE,
            0,
            FALSE,
            'Subscription cancelled. Please contact support to reactivate.'::TEXT;
        RETURN;
    END IF;
    
    -- Status: Trial (Active)
    IF v_subscription.status = 'trial' AND v_now < v_subscription.trial_ends_at THEN
        RETURN QUERY SELECT 
            'trial'::TEXT,
            TRUE,
            v_days_left,
            FALSE,
            format('Trial ends in %s days. Upgrade to continue.', v_days_left)::TEXT;
        RETURN;
    END IF;
    
    -- Status: Active (Paid)
    IF v_subscription.status = 'active' AND v_now < v_subscription.end_date THEN
        RETURN QUERY SELECT 
            'active'::TEXT,
            TRUE,
            v_days_left,
            FALSE,
            format('Subscription active. Renews in %s days.', v_days_left)::TEXT;
        RETURN;
    END IF;
    
    -- Status: Grace Period
    IF v_subscription.status = 'grace' OR 
       (v_now >= v_subscription.end_date AND v_now < (v_subscription.end_date + (v_grace_days || ' days')::INTERVAL)) THEN
        
        -- Calculate remaining grace days
        v_days_left := v_grace_days - EXTRACT(DAY FROM (v_now - v_subscription.end_date))::INTEGER;
        
        RETURN QUERY SELECT 
            'grace'::TEXT,
            TRUE, -- Still accessible during grace
            v_days_left,
            TRUE,
            format('Payment overdue! %s days left before suspension.', GREATEST(v_days_left, 0))::TEXT;
        RETURN;
    END IF;
    
    -- Status: Expired (Should be suspended)
    RETURN QUERY SELECT 
        'expired'::TEXT,
        FALSE,
        0,
        FALSE,
        'Subscription expired. Please renew to continue.'::TEXT;
END;
$$;

-- ============================================================================
-- 6. FUNCTION: Auto-Suspend Expired Subscriptions
-- ============================================================================
CREATE OR REPLACE FUNCTION auto_suspend_expired_subscriptions()
RETURNS TABLE(suspended_count INTEGER, suspended_restaurants TEXT[])
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_grace_days INTEGER;
    v_auto_suspend BOOLEAN;
    v_suspended_ids UUID[];
    v_suspended_names TEXT[];
BEGIN
    -- Get settings
    SELECT value::INTEGER INTO v_grace_days 
    FROM platform_settings WHERE key = 'subscription_grace_days';
    
    SELECT value::BOOLEAN INTO v_auto_suspend 
    FROM platform_settings WHERE key = 'subscription_auto_suspend';
    
    v_grace_days := COALESCE(v_grace_days, 3);
    v_auto_suspend := COALESCE(v_auto_suspend, TRUE);
    
    IF NOT v_auto_suspend THEN
        RETURN QUERY SELECT 0, ARRAY[]::TEXT[];
        RETURN;
    END IF;
    
    -- Update subscriptions to grace period first
    UPDATE subscriptions
    SET 
        status = 'grace',
        grace_period_start = NOW(),
        updated_at = NOW()
    WHERE status IN ('trial', 'active')
    AND end_date < NOW()
    AND (grace_period_start IS NULL OR status != 'grace');
    
    -- Suspend subscriptions past grace period
    WITH suspended AS (
        UPDATE subscriptions s
        SET 
            status = 'suspended',
            suspended_at = NOW(),
            suspended_reason = 'Payment not received after grace period',
            updated_at = NOW()
        WHERE s.status = 'grace'
        AND s.end_date + (v_grace_days || ' days')::INTERVAL < NOW()
        RETURNING s.restaurant_id
    )
    SELECT ARRAY_AGG(suspended.restaurant_id) INTO v_suspended_ids FROM suspended;
    
    -- Get restaurant names
    SELECT ARRAY_AGG(r.name) INTO v_suspended_names
    FROM restaurants r
    WHERE r.id = ANY(COALESCE(v_suspended_ids, ARRAY[]::UUID[]));
    
    RETURN QUERY SELECT 
        COALESCE(array_length(v_suspended_ids, 1), 0),
        COALESCE(v_suspended_names, ARRAY[]::TEXT[]);
END;
$$;

-- ============================================================================
-- 7. FUNCTION: Process Payment and Reactivate
-- ============================================================================
CREATE OR REPLACE FUNCTION process_payment_and_reactivate(
    p_restaurant_id UUID,
    p_amount DECIMAL,
    p_payment_type TEXT,
    p_payment_method TEXT DEFAULT 'razorpay',
    p_gateway_id TEXT DEFAULT NULL,
    p_gateway_order_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    success BOOLEAN,
    message TEXT,
    subscription_id UUID,
    payment_id UUID,
    new_end_date TIMESTAMPTZ
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_subscription RECORD;
    v_payment_id UUID;
    v_new_end_date TIMESTAMPTZ;
    v_monthly_price DECIMAL;
    v_setup_fee DECIMAL;
BEGIN
    -- Get pricing
    SELECT value::DECIMAL INTO v_monthly_price FROM platform_settings WHERE key = 'subscription_monthly_price';
    SELECT value::DECIMAL INTO v_setup_fee FROM platform_settings WHERE key = 'subscription_setup_fee';
    
    v_monthly_price := COALESCE(v_monthly_price, 35000);
    v_setup_fee := COALESCE(v_setup_fee, 5000);
    
    -- Get subscription
    SELECT * INTO v_subscription FROM subscriptions WHERE restaurant_id = p_restaurant_id;
    
    IF v_subscription IS NULL THEN
        RETURN QUERY SELECT FALSE, 'Subscription not found'::TEXT, NULL::UUID, NULL::UUID, NULL::TIMESTAMPTZ;
        RETURN;
    END IF;
    
    -- Validate payment amount
    IF p_payment_type = 'setup_fee' AND p_amount != v_setup_fee THEN
        RETURN QUERY SELECT FALSE, format('Invalid setup fee amount. Expected ₹%s', v_setup_fee)::TEXT, NULL::UUID, NULL::UUID, NULL::TIMESTAMPTZ;
        RETURN;
    END IF;
    
    IF p_payment_type IN ('monthly_subscription', 'renewal') AND p_amount != v_monthly_price THEN
        RETURN QUERY SELECT FALSE, format('Invalid subscription amount. Expected ₹%s', v_monthly_price)::TEXT, NULL::UUID, NULL::UUID, NULL::TIMESTAMPTZ;
        RETURN;
    END IF;
    
    -- Create payment record
    INSERT INTO payments (
        restaurant_id,
        subscription_id,
        amount,
        payment_type,
        payment_method,
        payment_gateway_id,
        payment_gateway_order_id,
        status,
        payment_date,
        completed_at
    ) VALUES (
        p_restaurant_id,
        v_subscription.id,
        p_amount,
        p_payment_type,
        p_payment_method,
        p_gateway_id,
        p_gateway_order_id,
        'completed',
        NOW(),
        NOW()
    )
    RETURNING id INTO v_payment_id;
    
    -- Calculate new end date
    IF v_subscription.status IN ('suspended', 'grace', 'cancelled') OR v_subscription.end_date < NOW() THEN
        -- Expired/Suspended: Start fresh 30-day period from now
        v_new_end_date := NOW() + INTERVAL '30 days';
    ELSE
        -- Active: Extend from current end date
        v_new_end_date := v_subscription.end_date + INTERVAL '30 days';
    END IF;
    
    -- Update subscription
    UPDATE subscriptions
    SET
        status = 'active',
        end_date = v_new_end_date,
        next_billing_date = v_new_end_date,
        last_payment_date = NOW(),
        setup_fee_paid = CASE WHEN p_payment_type = 'setup_fee' THEN TRUE ELSE setup_fee_paid END,
        trial_ends_at = NULL, -- Remove trial status
        grace_period_start = NULL,
        suspended_at = NULL,
        suspended_reason = NULL,
        updated_at = NOW()
    WHERE id = v_subscription.id;
    
    -- Reactivate restaurant if suspended
    UPDATE restaurants
    SET 
        is_active = TRUE,
        updated_at = NOW()
    WHERE id = p_restaurant_id;
    
    RETURN QUERY SELECT 
        TRUE,
        format('Payment successful! Subscription active until %s', v_new_end_date::DATE)::TEXT,
        v_subscription.id,
        v_payment_id,
        v_new_end_date;
END;
$$;

-- ============================================================================
-- 8. FUNCTION: Create Trial Subscription
-- ============================================================================
CREATE OR REPLACE FUNCTION create_trial_subscription(p_restaurant_id UUID)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_subscription_id UUID;
    v_trial_days INTEGER;
    v_grace_days INTEGER;
BEGIN
    -- Get settings
    SELECT value::INTEGER INTO v_trial_days FROM platform_settings WHERE key = 'subscription_trial_days';
    SELECT value::INTEGER INTO v_grace_days FROM platform_settings WHERE key = 'subscription_grace_days';
    
    v_trial_days := COALESCE(v_trial_days, 3);
    v_grace_days := COALESCE(v_grace_days, 3);
    
    -- Create subscription
    INSERT INTO subscriptions (
        restaurant_id,
        start_date,
        end_date,
        trial_ends_at,
        next_billing_date,
        status,
        grace_period_days
    ) VALUES (
        p_restaurant_id,
        NOW(),
        NOW() + (v_trial_days || ' days')::INTERVAL,
        NOW() + (v_trial_days || ' days')::INTERVAL,
        NOW() + (v_trial_days || ' days')::INTERVAL,
        'trial',
        v_grace_days
    )
    ON CONFLICT (restaurant_id) DO NOTHING
    RETURNING id INTO v_subscription_id;
    
    RETURN v_subscription_id;
END;
$$;

-- ============================================================================
-- 9. FUNCTION: Get Expiring Subscriptions (For Notifications)
-- ============================================================================
CREATE OR REPLACE FUNCTION get_expiring_subscriptions(p_days_before INTEGER DEFAULT 3)
RETURNS TABLE(
    restaurant_id UUID,
    restaurant_name TEXT,
    restaurant_email TEXT,
    subscription_status TEXT,
    end_date TIMESTAMPTZ,
    days_remaining INTEGER,
    phone TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        s.restaurant_id,
        r.name,
        r.email,
        s.status,
        s.end_date,
        EXTRACT(DAY FROM (s.end_date - NOW()))::INTEGER,
        r.phone
    FROM subscriptions s
    JOIN restaurants r ON r.id = s.restaurant_id
    WHERE s.status IN ('trial', 'active')
    AND s.end_date BETWEEN NOW() AND NOW() + (p_days_before || ' days')::INTERVAL
    AND s.end_date > NOW()
    ORDER BY s.end_date ASC;
END;
$$;

-- ============================================================================
-- 10. FUNCTION: Manual Suspend/Reactivate (Super Admin)
-- ============================================================================
CREATE OR REPLACE FUNCTION toggle_subscription_status(
    p_restaurant_id UUID,
    p_action TEXT, -- 'suspend' or 'reactivate'
    p_reason TEXT DEFAULT NULL
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    IF p_action = 'suspend' THEN
        UPDATE subscriptions
        SET 
            status = 'suspended',
            suspended_at = NOW(),
            suspended_reason = COALESCE(p_reason, 'Manually suspended by admin'),
            updated_at = NOW()
        WHERE restaurant_id = p_restaurant_id
        AND status NOT IN ('suspended', 'cancelled');
        
        UPDATE restaurants SET is_active = FALSE WHERE id = p_restaurant_id;
        
    ELSIF p_action = 'reactivate' THEN
        UPDATE subscriptions
        SET 
            status = 'active',
            suspended_at = NULL,
            suspended_reason = NULL,
            grace_period_start = NULL,
            updated_at = NOW()
        WHERE restaurant_id = p_restaurant_id;
        
        UPDATE restaurants SET is_active = TRUE WHERE id = p_restaurant_id;
    ELSE
        RETURN FALSE;
    END IF;
    
    RETURN TRUE;
END;
$$;

-- ============================================================================
-- 11. VIEW: Subscription Overview (For Super Admin Dashboard)
-- ============================================================================
CREATE OR REPLACE VIEW subscription_overview AS
SELECT 
    r.id as restaurant_id,
    r.name as restaurant_name,
    r.email,
    r.phone,
    r.is_active,
    s.status as subscription_status,
    s.start_date,
    s.end_date,
    s.trial_ends_at,
    s.last_payment_date,
    s.next_billing_date,
    s.setup_fee_paid,
    s.grace_period_start,
    s.suspended_at,
    s.suspended_reason,
    EXTRACT(DAY FROM (s.end_date - NOW()))::INTEGER as days_remaining,
    CASE 
        WHEN s.status = 'trial' AND NOW() < s.trial_ends_at THEN TRUE
        WHEN s.status = 'active' AND NOW() < s.end_date THEN TRUE
        WHEN s.status = 'grace' THEN TRUE
        ELSE FALSE
    END as has_access,
    (SELECT COUNT(*) FROM payments p WHERE p.restaurant_id = r.id AND p.status = 'completed') as total_payments,
    (SELECT SUM(amount) FROM payments p WHERE p.restaurant_id = r.id AND p.status = 'completed') as total_revenue
FROM restaurants r
LEFT JOIN subscriptions s ON s.restaurant_id = r.id
ORDER BY s.end_date ASC;

-- ============================================================================
-- 12. RLS POLICIES
-- ============================================================================

-- Enable RLS
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

-- Subscriptions: Restaurants see only their own
DROP POLICY IF EXISTS subscriptions_restaurant_select ON subscriptions;
CREATE POLICY subscriptions_restaurant_select ON subscriptions
    FOR SELECT
    USING (
        restaurant_id IN (
            SELECT restaurant_id FROM users WHERE id = auth.uid()
        )
    );

-- Subscriptions: Super Admin sees all
DROP POLICY IF EXISTS subscriptions_superadmin_all ON subscriptions;
CREATE POLICY subscriptions_superadmin_all ON subscriptions
    FOR ALL
    USING (
        EXISTS (
            SELECT 1 FROM users 
            WHERE id = auth.uid() 
            AND role = 'super_admin'
        )
    );

-- Payments: Restaurants see only their own
DROP POLICY IF EXISTS payments_restaurant_select ON payments;
CREATE POLICY payments_restaurant_select ON payments
    FOR SELECT
    USING (
        restaurant_id IN (
            SELECT restaurant_id FROM users WHERE id = auth.uid()
        )
    );

-- Payments: Super Admin sees all
DROP POLICY IF EXISTS payments_superadmin_all ON payments;
CREATE POLICY payments_superadmin_all ON payments
    FOR ALL
    USING (
        EXISTS (
            SELECT 1 FROM users 
            WHERE id = auth.uid() 
            AND role = 'super_admin'
        )
    );

-- ============================================================================
-- 13. TRIGGERS
-- ============================================================================

-- Auto-update updated_at timestamp
CREATE OR REPLACE FUNCTION update_subscription_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS subscriptions_updated_at ON subscriptions;
CREATE TRIGGER subscriptions_updated_at
    BEFORE UPDATE ON subscriptions
    FOR EACH ROW
    EXECUTE FUNCTION update_subscription_updated_at();

DROP TRIGGER IF EXISTS payments_updated_at ON payments;
CREATE TRIGGER payments_updated_at
    BEFORE UPDATE ON payments
    FOR EACH ROW
    EXECUTE FUNCTION update_subscription_updated_at();

-- ============================================================================
-- 14. GRANT PERMISSIONS
-- ============================================================================
GRANT SELECT ON subscription_overview TO authenticated;
GRANT EXECUTE ON FUNCTION check_subscription_status TO authenticated;
GRANT EXECUTE ON FUNCTION get_expiring_subscriptions TO authenticated;
GRANT EXECUTE ON FUNCTION auto_suspend_expired_subscriptions TO service_role;
GRANT EXECUTE ON FUNCTION process_payment_and_reactivate TO authenticated;
GRANT EXECUTE ON FUNCTION create_trial_subscription TO authenticated;
GRANT EXECUTE ON FUNCTION toggle_subscription_status TO authenticated;

-- ============================================================================
-- MIGRATION COMPLETE
-- ============================================================================
-- Next Steps:
-- 1. Run this SQL in Supabase SQL Editor
-- 2. Set up Supabase Edge Function or pg_cron for daily auto-suspension
-- 3. Integrate Razorpay payment gateway in React frontend
-- 4. Add subscription check to login flow
-- 5. Build Super Admin subscription management UI
-- ============================================================================
