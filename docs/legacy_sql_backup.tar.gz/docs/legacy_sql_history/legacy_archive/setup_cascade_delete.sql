-- Setup CASCADE DELETE for restaurant deletion
-- When a restaurant is deleted, all related data should be deleted

-- Step 1: Check current foreign key constraint on users.restaurant_id
SELECT
  tc.constraint_name,
  tc.table_name,
  kcu.column_name,
  ccu.table_name AS foreign_table_name,
  ccu.column_name AS foreign_column_name,
  rc.delete_rule,
  CASE 
    WHEN rc.delete_rule = 'CASCADE' THEN '✅ Already has CASCADE'
    WHEN rc.delete_rule = 'NO ACTION' THEN '⚠️ NO ACTION - needs to be changed to CASCADE'
    WHEN rc.delete_rule = 'SET NULL' THEN '⚠️ SET NULL - needs to be changed to CASCADE'
    ELSE '❓ ' || rc.delete_rule
  END as status
FROM information_schema.table_constraints AS tc 
JOIN information_schema.key_column_usage AS kcu
  ON tc.constraint_name = kcu.constraint_name
  AND tc.table_schema = kcu.table_schema
JOIN information_schema.constraint_column_usage AS ccu
  ON ccu.constraint_name = tc.constraint_name
  AND ccu.table_schema = tc.table_schema
JOIN information_schema.referential_constraints AS rc
  ON rc.constraint_name = tc.constraint_name
WHERE tc.constraint_type = 'FOREIGN KEY'
  AND tc.table_name = 'users'
  AND kcu.column_name = 'restaurant_id';

-- Step 2: Drop the old foreign key constraint (if it exists)
-- Replace 'constraint_name' with the actual name from Step 1
-- Common names: users_restaurant_id_fkey, fk_users_restaurant, etc.

DO $$
DECLARE
  constraint_name_var TEXT;
BEGIN
  -- Find the constraint name
  SELECT tc.constraint_name INTO constraint_name_var
  FROM information_schema.table_constraints AS tc 
  JOIN information_schema.key_column_usage AS kcu
    ON tc.constraint_name = kcu.constraint_name
  WHERE tc.constraint_type = 'FOREIGN KEY'
    AND tc.table_name = 'users'
    AND kcu.column_name = 'restaurant_id';
  
  -- Drop it if found
  IF constraint_name_var IS NOT NULL THEN
    EXECUTE format('ALTER TABLE public.users DROP CONSTRAINT IF EXISTS %I', constraint_name_var);
    RAISE NOTICE 'Dropped constraint: %', constraint_name_var;
  END IF;
END $$;

-- Step 3: Add new foreign key constraint WITH CASCADE DELETE
ALTER TABLE public.users
ADD CONSTRAINT users_restaurant_id_fkey 
FOREIGN KEY (restaurant_id) 
REFERENCES restaurants(id) 
ON DELETE CASCADE;

-- Step 4: Verify the new constraint
SELECT
  tc.constraint_name,
  tc.table_name,
  kcu.column_name,
  ccu.table_name AS foreign_table_name,
  rc.delete_rule,
  CASE 
    WHEN rc.delete_rule = 'CASCADE' THEN '✅ CASCADE DELETE enabled - deleting restaurant will delete all staff'
    ELSE '❌ Not configured correctly'
  END as status
FROM information_schema.table_constraints AS tc 
JOIN information_schema.key_column_usage AS kcu
  ON tc.constraint_name = kcu.constraint_name
JOIN information_schema.constraint_column_usage AS ccu
  ON ccu.constraint_name = tc.constraint_name
JOIN information_schema.referential_constraints AS rc
  ON rc.constraint_name = tc.constraint_name
WHERE tc.constraint_type = 'FOREIGN KEY'
  AND tc.table_name = 'users'
  AND kcu.column_name = 'restaurant_id';

-- Step 5: Check other tables that might need CASCADE DELETE
-- These are common tables that might reference restaurants:

SELECT 
  tc.table_name,
  kcu.column_name,
  rc.delete_rule,
  CASE 
    WHEN rc.delete_rule = 'CASCADE' THEN '✅ Has CASCADE'
    ELSE '⚠️ No CASCADE - might need to add'
  END as status
FROM information_schema.table_constraints AS tc 
JOIN information_schema.key_column_usage AS kcu
  ON tc.constraint_name = kcu.constraint_name
JOIN information_schema.constraint_column_usage AS ccu
  ON ccu.constraint_name = tc.constraint_name
JOIN information_schema.referential_constraints AS rc
  ON rc.constraint_name = tc.constraint_name
WHERE tc.constraint_type = 'FOREIGN KEY'
  AND ccu.table_name = 'restaurants'
ORDER BY tc.table_name;
