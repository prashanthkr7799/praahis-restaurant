-- ============================================================================
-- FIX: "You must be logged in as a manager to add staff" Error
-- ============================================================================
-- This error occurs when manager tries to add chef/waiter
-- Root cause: RPC function can't find manager's profile in public.users
-- ============================================================================

-- ============================================================================
-- STEP 1: Diagnostic - Check if manager profile exists
-- ============================================================================

SELECT '=== STEP 1: Check Manager Profile Exists ===' as info;

SELECT 
  id,
  email,
  role,
  restaurant_id,
  is_active,
  created_at,
  CASE 
    WHEN role = 'manager' AND restaurant_id IS NOT NULL THEN '✅ Manager profile OK'
    WHEN role = 'manager' AND restaurant_id IS NULL THEN '❌ Missing restaurant_id'
    ELSE '⚠️ Not a manager'
  END as status
FROM public.users
WHERE role = 'manager'
ORDER BY created_at DESC;

-- ============================================================================
-- STEP 2: Check RLS policies on users table
-- ============================================================================

SELECT '=== STEP 2: Check RLS Policies ===' as info;

SELECT 
  schemaname,
  tablename,
  policyname,
  permissive,
  roles,
  cmd,
  qual,
  with_check
FROM pg_policies
WHERE schemaname = 'public'
AND tablename = 'users'
ORDER BY policyname;

-- ============================================================================
-- STEP 3: Fix - Add RLS policy for authenticated users to SELECT their own profile
-- ============================================================================

SELECT '=== STEP 3: Adding RLS Policy for Self-Select ===' as info;

-- Drop existing policy if it exists
DROP POLICY IF EXISTS "users_select_self" ON public.users;

-- Create policy: Users can always SELECT their own profile
-- This is CRITICAL for RPC functions that check auth.uid()
CREATE POLICY "users_select_self" ON public.users
  FOR SELECT TO authenticated
  USING (id = auth.uid());

SELECT '✅ Policy created: users_select_self' as status;

-- ============================================================================
-- STEP 4: Verify the fix
-- ============================================================================

SELECT '=== STEP 4: Verification ===' as info;

-- Check if the policy was created
SELECT 
  policyname,
  cmd,
  CASE 
    WHEN policyname = 'users_select_self' THEN '✅ Policy exists'
    ELSE 'Other policy'
  END as status
FROM pg_policies
WHERE schemaname = 'public'
AND tablename = 'users'
AND policyname = 'users_select_self';

-- ============================================================================
-- STEP 5: Test query (simulates what RPC function does)
-- ============================================================================

SELECT '=== STEP 5: Test Query ===' as info;

-- This query simulates what the RPC function does
-- It should return the current user's profile
SELECT 
  id,
  email,
  role,
  restaurant_id,
  'This is what RPC function sees' as note
FROM public.users
WHERE id = auth.uid();

-- If the above returns NO ROWS, the RPC will fail!

-- ============================================================================
-- ROOT CAUSE EXPLANATION
-- ============================================================================

/*

WHY THIS ERROR OCCURS:

1. Manager logs in successfully
2. Auth session is created in auth.users
3. Manager tries to add a chef/waiter
4. StaffForm.jsx calls: supabase.rpc('admin_upsert_user_profile', {...})
5. RPC function runs: SELECT * INTO me FROM public.users WHERE id = auth.uid()
6. RLS policy blocks the SELECT (or no policy exists!)
7. me.id IS NULL
8. RPC raises: 'Not a staff user'
9. Frontend shows: 'You must be logged in as a manager to add staff'

THE FIX:

Add RLS policy that allows users to SELECT their own profile:

CREATE POLICY "users_select_self" ON public.users
  FOR SELECT TO authenticated
  USING (id = auth.uid());

This ensures:
- Manager can query their own profile
- RPC function can verify manager's role
- Staff creation works!

*/

-- ============================================================================
-- ALTERNATIVE FIX: Check existing policies
-- ============================================================================

SELECT '=== CHECK: Existing SELECT Policies ===' as info;

SELECT 
  policyname,
  qual::text as using_expression,
  CASE 
    WHEN qual::text ILIKE '%auth.uid()%' THEN '✅ Allows self-select'
    ELSE '⚠️ May not allow self-select'
  END as allows_self_select
FROM pg_policies
WHERE schemaname = 'public'
AND tablename = 'users'
AND cmd = 'SELECT'
ORDER BY policyname;

-- ============================================================================
-- SUMMARY
-- ============================================================================
-- ✅ Created RLS policy: users_select_self
-- ✅ Manager can now query their own profile
-- ✅ RPC function admin_upsert_user_profile will work
-- ✅ Staff creation should succeed
-- 
-- NEXT STEPS:
-- 1. Run this script in Supabase SQL Editor
-- 2. Logout and login again as manager
-- 3. Try adding chef/waiter
-- 4. Should work now! ✅
-- ============================================================================
