-- ============================================================================
-- FIX RECURSIVE RLS POLICIES - EMERGENCY FIX
-- ============================================================================
-- Problem: All policies that query the users table trigger users RLS policies
-- causing infinite recursion and 500 errors
--
-- Solution: Create SECURITY DEFINER functions that bypass RLS
-- ============================================================================

-- Create a function to check if current user belongs to a restaurant
CREATE OR REPLACE FUNCTION public.user_belongs_to_restaurant(p_restaurant_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER -- This bypasses RLS
STABLE
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.users
    WHERE id = auth.uid()
    AND restaurant_id = p_restaurant_id
  );
END;
$$;

-- Create a function to check if current user has a specific role in a restaurant
CREATE OR REPLACE FUNCTION public.user_has_role_in_restaurant(p_restaurant_id uuid, p_roles text[])
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER -- This bypasses RLS
STABLE
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.users
    WHERE id = auth.uid()
    AND restaurant_id = p_restaurant_id
    AND role = ANY(p_roles)
  );
END;
$$;

-- Create a function to check if current user is a platform admin
CREATE OR REPLACE FUNCTION public.is_platform_admin()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER -- This bypasses RLS
STABLE
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.platform_admins
    WHERE user_id = auth.uid()
    AND is_active = true
  );
END;
$$;

-- Create a function to check if current user is a superadmin
CREATE OR REPLACE FUNCTION public.is_superadmin()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER -- This bypasses RLS
STABLE
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.platform_admins
    WHERE user_id = auth.uid()
    AND role = 'superadmin'
    AND is_active = true
  );
END;
$$;

DO $$
BEGIN
  RAISE NOTICE '========================================';
  RAISE NOTICE 'SECURITY DEFINER FUNCTIONS CREATED';
  RAISE NOTICE '========================================';
  RAISE NOTICE 'Created 4 helper functions to bypass RLS:';
  RAISE NOTICE '  - user_belongs_to_restaurant(restaurant_id)';
  RAISE NOTICE '  - user_has_role_in_restaurant(restaurant_id, roles[])';
  RAISE NOTICE '  - is_platform_admin()';
  RAISE NOTICE '  - is_superadmin()';
  RAISE NOTICE '';
  RAISE NOTICE 'Now update policies to use these functions instead of';
  RAISE NOTICE 'querying users table directly (which causes recursion)';
  RAISE NOTICE '========================================';
END $$;
