-- ============================================================================
-- TABUN RESTAURANT MANAGEMENT SYSTEM - MAINTENANCE SCRIPTS
-- ============================================================================
-- Version: 1.0
-- Created: October 2025
-- Description: Useful maintenance and cleanup queries
-- ============================================================================

-- ============================================================================
-- 1. CLEAN ALL ORDERS AND RESET TABLES
-- ============================================================================
-- Use this to reset the system (delete all orders and free all tables)

-- Delete all feedbacks first (foreign key constraint)
DELETE FROM feedbacks;

-- Delete all payments
DELETE FROM payments;

-- Delete all orders
DELETE FROM orders;

-- Reset all tables to available status
UPDATE tables 
SET status = 'available', 
    booked_at = NULL, 
    updated_at = NOW();

-- Reset sequence (not needed for UUIDs, but good to know)
-- For order numbers, the function auto-generates based on date

SELECT 'All orders cleaned and tables reset' AS status;

-- ============================================================================
-- 2. CLEAN OLD ORDERS (Archive Strategy)
-- ============================================================================
-- Keep only orders from last 30 days

-- First, check how many orders will be deleted
SELECT 
    COUNT(*) as orders_to_delete,
    MIN(created_at) as oldest_order,
    MAX(created_at) as newest_order
FROM orders 
WHERE created_at < NOW() - INTERVAL '30 days';

-- Uncomment to actually delete
-- DELETE FROM feedbacks 
-- WHERE order_id IN (
--     SELECT id FROM orders 
--     WHERE created_at < NOW() - INTERVAL '30 days'
-- );

-- DELETE FROM payments 
-- WHERE order_id IN (
--     SELECT id FROM orders 
--     WHERE created_at < NOW() - INTERVAL '30 days'
-- );

-- DELETE FROM orders 
-- WHERE created_at < NOW() - INTERVAL '30 days';

-- ============================================================================
-- 3. VIEW DATABASE STATISTICS
-- ============================================================================

-- Count records in each table
SELECT 
    'restaurants' as table_name, COUNT(*) as record_count FROM restaurants
UNION ALL
SELECT 'tables', COUNT(*) FROM tables
UNION ALL
SELECT 'menu_items', COUNT(*) FROM menu_items
UNION ALL
SELECT 'orders', COUNT(*) FROM orders
UNION ALL
SELECT 'payments', COUNT(*) FROM payments
UNION ALL
SELECT 'feedbacks', COUNT(*) FROM feedbacks
UNION ALL
SELECT 'users', COUNT(*) FROM users
ORDER BY table_name;

-- ============================================================================
-- 4. VIEW DATABASE SIZE
-- ============================================================================

-- Check table sizes
SELECT 
    schemaname,
    tablename,
    pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) AS size,
    pg_total_relation_size(schemaname||'.'||tablename) AS size_bytes
FROM pg_tables
WHERE schemaname = 'public'
ORDER BY size_bytes DESC;

-- ============================================================================
-- 5. TODAY'S STATISTICS
-- ============================================================================

-- Today's orders summary
SELECT 
    COUNT(*) as total_orders_today,
    COUNT(CASE WHEN payment_status = 'paid' THEN 1 END) as paid_orders,
    COUNT(CASE WHEN payment_status = 'pending' THEN 1 END) as pending_orders,
    SUM(CASE WHEN payment_status = 'paid' THEN total ELSE 0 END) as total_revenue_today
FROM orders 
WHERE DATE(created_at) = CURRENT_DATE;

-- ============================================================================
-- 6. RESET SPECIFIC TABLE STATUS
-- ============================================================================

-- Reset a specific table (replace '1' with table number)
-- UPDATE tables 
-- SET status = 'available', 
--     booked_at = NULL, 
--     updated_at = NOW()
-- WHERE table_number = '1';

-- ============================================================================
-- 7. CHECK REALTIME STATUS
-- ============================================================================

-- Verify which tables have realtime enabled
SELECT schemaname, tablename 
FROM pg_publication_tables 
WHERE pubname = 'supabase_realtime'
ORDER BY tablename;

-- ============================================================================
-- 8. CANCEL PENDING ORDERS (Cleanup stuck orders)
-- ============================================================================

-- Find orders pending for more than 2 hours
SELECT 
    id, 
    order_number, 
    table_number, 
    order_status,
    payment_status,
    created_at
FROM orders 
WHERE payment_status = 'pending' 
  AND created_at < NOW() - INTERVAL '2 hours';

-- Uncomment to cancel them
-- UPDATE orders 
-- SET order_status = 'cancelled', 
--     updated_at = NOW()
-- WHERE payment_status = 'pending' 
--   AND created_at < NOW() - INTERVAL '2 hours';

-- ============================================================================
-- 9. POPULAR MENU ITEMS REPORT
-- ============================================================================

-- Most ordered items (from JSONB items column)
WITH order_items AS (
    SELECT 
        jsonb_array_elements(items) as item
    FROM orders
    WHERE payment_status = 'paid'
      AND created_at >= NOW() - INTERVAL '30 days'
)
SELECT 
    item->>'name' as item_name,
    COUNT(*) as times_ordered,
    SUM((item->>'quantity')::int) as total_quantity
FROM order_items
GROUP BY item->>'name'
ORDER BY times_ordered DESC
LIMIT 10;

-- ============================================================================
-- 10. VACUUM AND ANALYZE (Performance Maintenance)
-- ============================================================================

-- Reclaim space and update statistics
-- Run periodically for better performance
-- VACUUM ANALYZE;

-- ============================================================================
-- MAINTENANCE SCRIPTS COMPLETE
-- ============================================================================
-- Available operations:
-- 1. Clean all orders and reset tables
-- 2. Archive old orders (>30 days)
-- 3. View database statistics
-- 4. Check table sizes
-- 5. Today's statistics
-- 6. Reset specific table
-- 7. Check realtime status
-- 8. Cancel stuck orders
-- 9. Popular items report
-- 10. Performance maintenance
-- ============================================================================
