-- ============================================================================
-- CLEANUP: Delete Failed Staff Users (No Profile Created)
-- ============================================================================
-- Use this when staff user exists in auth.users but NOT in public.users
-- This happens when RPC function failed during staff creation
-- ============================================================================

-- ============================================================================
-- STEP 1: Check current state - Find orphaned auth users
-- ============================================================================

SELECT '=== STEP 1: Check Orphaned Auth Users ===' as info;

-- Find auth users WITHOUT profiles in public.users
SELECT 
    au.id,
    au.email,
    au.email_confirmed_at,
    au.created_at,
    CASE 
        WHEN pu.id IS NULL THEN '❌ NO PROFILE (orphaned)'
        ELSE '✅ Has profile'
    END as status
FROM auth.users au
LEFT JOIN public.users pu ON au.id = pu.id
WHERE au.created_at > NOW() - INTERVAL '24 hours'  -- Recent users
ORDER BY au.created_at DESC;

-- ============================================================================
-- STEP 2: Find specific user by email (UPDATE THIS!)
-- ============================================================================

SELECT '=== STEP 2: Find Specific User ===' as info;

-- REPLACE 'rahul@chef.com' with the actual chef/waiter email!
SELECT 
    au.id,
    au.email,
    au.email_confirmed_at,
    au.created_at,
    pu.id as profile_id,
    pu.role,
    pu.restaurant_id,
    CASE 
        WHEN pu.id IS NULL THEN '❌ Delete this user (no profile)'
        ELSE '✅ Keep (has profile)'
    END as action
FROM auth.users au
LEFT JOIN public.users pu ON au.id = pu.id
WHERE au.email = 'rahul@chef.com';  -- ⚠️ Your chef email

-- ============================================================================
-- STEP 3: Delete orphaned user from auth.users
-- ============================================================================

SELECT '=== STEP 3: Deleting Orphaned User ===' as info;

-- This will delete the user from auth.users
-- IMPORTANT: Update the email address first!
DELETE FROM auth.users 
WHERE email = 'rahul@chef.com'  -- ⚠️ Your chef email
AND id NOT IN (SELECT id FROM public.users);  -- Safety check: only delete if no profile

-- Check result
SELECT 'Deleted user: rahul@chef.com' as result;

-- ============================================================================
-- STEP 4: Verify deletion
-- ============================================================================

SELECT '=== STEP 4: Verify Deletion ===' as info;

-- Should return NO ROWS
SELECT id, email 
FROM auth.users 
WHERE email = 'rahul@chef.com';  -- ⚠️ Your chef email

-- ============================================================================
-- STEP 5: Check remaining users are valid
-- ============================================================================

SELECT '=== STEP 5: Remaining Users ===' as info;

SELECT 
    au.id,
    au.email,
    pu.role,
    pu.restaurant_id,
    pu.is_active,
    '✅ Valid user' as status
FROM auth.users au
INNER JOIN public.users pu ON au.id = pu.id
WHERE au.created_at > NOW() - INTERVAL '24 hours'
ORDER BY au.created_at DESC;

-- ============================================================================
-- HOW TO USE THIS SCRIPT
-- ============================================================================

/*

1. UPDATE THE EMAIL ADDRESS:
   - Find lines with: WHERE email = 'kumar@spice.com'
   - Replace 'kumar@spice.com' with your chef/waiter email
   - There are 3 places to update!

2. RUN THE SCRIPT:
   - Copy to Supabase SQL Editor
   - Click "Run"
   - Check output for deleted user

3. RECREATE THE USER:
   - Go back to Manager Dashboard
   - Add Staff → Fill in chef/waiter details
   - Submit
   - This time it should work! (after running all 3 fix scripts)

*/

-- ============================================================================
-- ALTERNATIVE: Delete ALL orphaned users
-- ============================================================================

/*
If you have multiple failed staff creations, use this instead:

DELETE FROM auth.users 
WHERE id NOT IN (SELECT id FROM public.users)
AND created_at > NOW() - INTERVAL '24 hours';

This will delete ALL auth users without profiles created in the last 24 hours.
*/

-- ============================================================================
-- SUMMARY
-- ============================================================================
-- ✅ Found orphaned auth.users (no public.users profile)
-- ✅ Deleted specific user by email
-- ✅ Ready to recreate staff member
-- 
-- NEXT STEPS:
-- 1. Update email address in this script (3 places!)
-- 2. Run this script in Supabase SQL Editor
-- 3. Go to Manager Dashboard
-- 4. Add the staff member again
-- 5. Should work now! ✅
-- ============================================================================
