-- =============================================
-- Table Sessions System
-- =============================================
-- Purpose: Track customer dining sessions from QR scan to feedback
-- A session starts when QR is scanned and ends after feedback submission
-- =============================================

-- Create table_sessions table
CREATE TABLE IF NOT EXISTS public.table_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  table_id UUID REFERENCES public.tables(id) ON DELETE CASCADE,
  restaurant_id UUID REFERENCES public.restaurants(id) ON DELETE CASCADE,
  started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ended_at TIMESTAMPTZ,
  status TEXT CHECK (status IN ('active', 'completed', 'cancelled')) DEFAULT 'active',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Add session_id to orders table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'orders' 
    AND column_name = 'session_id'
  ) THEN
    ALTER TABLE public.orders 
    ADD COLUMN session_id UUID REFERENCES public.table_sessions(id) ON DELETE SET NULL;
  END IF;
END $$;

-- Add session_id to feedbacks table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'feedbacks' 
    AND column_name = 'session_id'
  ) THEN
    ALTER TABLE public.feedbacks 
    ADD COLUMN session_id UUID REFERENCES public.table_sessions(id) ON DELETE SET NULL;
  END IF;
END $$;

-- Add session_id to menu_item_ratings table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'menu_item_ratings' 
    AND column_name = 'session_id'
  ) THEN
    ALTER TABLE public.menu_item_ratings 
    ADD COLUMN session_id UUID REFERENCES public.table_sessions(id) ON DELETE SET NULL;
  END IF;
  
  -- Make order_id nullable since we now use session_id as primary reference
  -- This allows rating items across entire session, not just per order
  ALTER TABLE public.menu_item_ratings 
  ALTER COLUMN order_id DROP NOT NULL;
END $$;

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_table_sessions_table 
  ON public.table_sessions (table_id, status, started_at DESC);

CREATE INDEX IF NOT EXISTS idx_table_sessions_restaurant 
  ON public.table_sessions (restaurant_id, status, started_at DESC);

CREATE INDEX IF NOT EXISTS idx_orders_session 
  ON public.orders (session_id);

CREATE INDEX IF NOT EXISTS idx_feedbacks_session 
  ON public.feedbacks (session_id);

CREATE INDEX IF NOT EXISTS idx_menu_item_ratings_session 
  ON public.menu_item_ratings (session_id);

-- Constraint: Only one active session per table
CREATE UNIQUE INDEX IF NOT EXISTS idx_table_sessions_active_unique 
  ON public.table_sessions (table_id) 
  WHERE status = 'active';

-- Enable RLS
ALTER TABLE public.table_sessions ENABLE ROW LEVEL SECURITY;

-- =============================================
-- RLS Policies for table_sessions
-- =============================================

-- Anyone can read sessions (customers need to fetch their session)
DROP POLICY IF EXISTS "Anyone can read table sessions" ON public.table_sessions;
CREATE POLICY "Anyone can read table sessions"
  ON public.table_sessions FOR SELECT
  USING (true);

-- Anyone can create a session (when QR is scanned)
DROP POLICY IF EXISTS "Anyone can create table sessions" ON public.table_sessions;
CREATE POLICY "Anyone can create table sessions"
  ON public.table_sessions FOR INSERT
  WITH CHECK (true);

-- Only authenticated users can update sessions
DROP POLICY IF EXISTS "Authenticated users can update sessions" ON public.table_sessions;
CREATE POLICY "Authenticated users can update sessions"
  ON public.table_sessions FOR UPDATE
  USING (
    auth.role() = 'authenticated'
    OR
    -- Allow customers to complete their own session via feedback
    true
  );

-- Only authenticated users can delete sessions
DROP POLICY IF EXISTS "Only staff can delete sessions" ON public.table_sessions;
CREATE POLICY "Only staff can delete sessions"
  ON public.table_sessions FOR DELETE
  USING (auth.role() = 'authenticated');

-- =============================================
-- Helper Functions
-- =============================================

-- Get or create active session for a table
CREATE OR REPLACE FUNCTION public.get_or_create_table_session(
  p_table_id UUID,
  p_restaurant_id UUID
)
RETURNS UUID AS $$
DECLARE
  v_session_id UUID;
BEGIN
  -- Try to get existing active session
  SELECT id INTO v_session_id
  FROM public.table_sessions
  WHERE table_id = p_table_id
    AND status = 'active'
  LIMIT 1;

  -- If no active session, create new one
  IF v_session_id IS NULL THEN
    INSERT INTO public.table_sessions (table_id, restaurant_id, status)
    VALUES (p_table_id, p_restaurant_id, 'active')
    RETURNING id INTO v_session_id;
  END IF;

  RETURN v_session_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- End a table session
CREATE OR REPLACE FUNCTION public.end_table_session(
  p_session_id UUID
)
RETURNS BOOLEAN AS $$
DECLARE
  v_table_id UUID;
BEGIN
  -- Update session
  UPDATE public.table_sessions
  SET 
    status = 'completed',
    ended_at = NOW(),
    updated_at = NOW()
  WHERE id = p_session_id
    AND status = 'active'
  RETURNING table_id INTO v_table_id;

  -- If session was ended, also free the table
  IF v_table_id IS NOT NULL THEN
    UPDATE public.tables
    SET 
      status = 'available',
      active_session_id = NULL,
      updated_at = NOW()
    WHERE id = v_table_id;
    
    RETURN TRUE;
  END IF;

  RETURN FALSE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant execute permissions
GRANT EXECUTE ON FUNCTION public.get_or_create_table_session TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.end_table_session TO anon, authenticated;

-- =============================================
-- Trigger: Update updated_at timestamp
-- =============================================
CREATE OR REPLACE FUNCTION public.update_table_sessions_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_table_sessions_updated_at ON public.table_sessions;
CREATE TRIGGER trigger_table_sessions_updated_at
  BEFORE UPDATE ON public.table_sessions
  FOR EACH ROW
  EXECUTE FUNCTION public.update_table_sessions_updated_at();

-- Success message
DO $$
BEGIN
  RAISE NOTICE 'Table sessions system created successfully!';
  RAISE NOTICE 'Created: table_sessions table, session_id columns (orders, feedbacks, menu_item_ratings), helper functions, RLS policies';
END $$;
