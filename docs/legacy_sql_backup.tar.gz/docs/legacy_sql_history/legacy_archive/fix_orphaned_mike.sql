-- Fix the orphaned user bf61d54a-59f4-4dcc-9817-ef8c543a42a9 (mike@gmail.com)
-- This user exists in auth.users but not in public.users

-- Step 1: Check if user exists in auth.users
SELECT 
  id,
  email,
  created_at,
  '❌ Orphaned in auth.users only' as status
FROM auth.users
WHERE id = 'bf61d54a-59f4-4dcc-9817-ef8c543a42a9';

-- Step 2: Check if user exists in public.users
SELECT 
  id,
  email,
  full_name,
  role,
  restaurant_id,
  '✅ Exists in public.users' as status
FROM public.users
WHERE id = 'bf61d54a-59f4-4dcc-9817-ef8c543a42a9';

-- Step 3: Get user details from auth.users to create profile
SELECT 
  au.id,
  au.email,
  au.created_at,
  'Will insert into public.users' as action
FROM auth.users au
WHERE au.id = 'bf61d54a-59f4-4dcc-9817-ef8c543a42a9'
  AND NOT EXISTS (
    SELECT 1 FROM public.users pu WHERE pu.id = au.id
  );

-- Step 4: Insert the missing profile into public.users
-- Replace 'YOUR_RESTAURANT_ID' with your actual restaurant ID: 3c98c081-a93e-44a6-95bf-9534edf4c41d
INSERT INTO public.users (
  id,
  email,
  full_name,
  role,
  restaurant_id,
  is_active,
  is_owner,
  created_at
)
SELECT
  au.id,
  au.email,
  'Mike',  -- Default name, can be updated later
  'waiter', -- Default role based on your previous context
  '3c98c081-a93e-44a6-95bf-9534edf4c41d', -- Your restaurant ID
  true,
  false,
  au.created_at
FROM auth.users au
WHERE au.id = 'bf61d54a-59f4-4dcc-9817-ef8c543a42a9'
  AND NOT EXISTS (
    SELECT 1 FROM public.users pu WHERE pu.id = au.id
  );

-- Step 5: Verify the fix
SELECT 
  au.id,
  au.email as auth_email,
  pu.email as public_email,
  pu.full_name,
  pu.role,
  pu.restaurant_id,
  CASE 
    WHEN pu.id IS NOT NULL THEN '✅ Fixed - user now in both tables'
    ELSE '❌ Still orphaned'
  END as status
FROM auth.users au
LEFT JOIN public.users pu ON au.id = pu.id
WHERE au.id = 'bf61d54a-59f4-4dcc-9817-ef8c543a42a9';
