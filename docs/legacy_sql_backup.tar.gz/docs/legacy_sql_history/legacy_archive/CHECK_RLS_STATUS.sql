-- =========================================================================
-- CHECK CURRENT RLS STATUS
-- =========================================================================
-- Run this first to see what's wrong
-- =========================================================================

-- Check if RLS is enabled on users table
SELECT 
    schemaname,
    tablename,
    rowsecurity as rls_enabled
FROM pg_tables
WHERE tablename = 'users' AND schemaname = 'public';

-- Check existing policies
SELECT 
    schemaname,
    tablename,
    policyname,
    permissive,
    roles,
    cmd,
    qual,
    with_check
FROM pg_policies 
WHERE tablename = 'users' AND schemaname = 'public'
ORDER BY policyname;

-- Check if there are ANY policies
SELECT COUNT(*) as policy_count
FROM pg_policies 
WHERE tablename = 'users' AND schemaname = 'public';

-- =========================================================================
-- RESULTS:
-- - If rls_enabled = false, then RLS is DISABLED (causes 406 error)
-- - If policy_count = 0, then NO policies exist (causes 403/406 errors)
-- =========================================================================
