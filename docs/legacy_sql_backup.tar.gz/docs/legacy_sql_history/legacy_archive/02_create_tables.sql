-- ============================================================================
-- CLEAN DATABASE SETUP - TABLE CREATION
-- ============================================================================
-- Generated: 2025-11-18 13:08:10
-- Description: All table definitions in correct dependency order
-- ============================================================================

-- ============================================================================
-- CORE TABLES
-- ============================================================================

-- TABLE: restaurants (Foundation table - no dependencies)
CREATE TABLE IF NOT EXISTS restaurants (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    address TEXT,
    phone VARCHAR(20),
    email VARCHAR(255),
    logo_url TEXT,
    slug TEXT,
    is_active BOOLEAN DEFAULT true,
    
    -- Subscription & Billing Info
    subscription_status VARCHAR(50) DEFAULT 'trial',
    max_users INTEGER DEFAULT 10,
    max_tables INTEGER DEFAULT 20,
    max_menu_items INTEGER DEFAULT 100,
    
    -- Payment Gateway
    payment_gateway_enabled BOOLEAN DEFAULT false,
    razorpay_key_id VARCHAR(255),
    razorpay_key_secret VARCHAR(255),
    razorpay_webhook_secret VARCHAR(255),
    
    -- Features & Metadata
    features JSONB DEFAULT '{}',
    metadata JSONB DEFAULT '{}',
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE restaurants IS 'Restaurant master table - multi-tenant foundation';
COMMENT ON COLUMN restaurants.slug IS 'URL-safe unique identifier for restaurant routing';
COMMENT ON COLUMN restaurants.subscription_status IS 'Current subscription status: trial, active, suspended, cancelled';

-- TABLE: users (Staff and Admin accounts)
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    restaurant_id UUID REFERENCES restaurants(id) ON DELETE SET NULL,
    
    -- Authentication
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    
    -- Profile
    full_name VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL, -- 'owner', 'manager', 'admin', 'chef', 'waiter'
    
    -- Flags
    is_active BOOLEAN DEFAULT true,
    is_owner BOOLEAN DEFAULT false,
    is_superadmin BOOLEAN DEFAULT false,
    
    -- Login Tracking
    last_login TIMESTAMP WITH TIME ZONE,
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE users IS 'User accounts for staff, managers, and platform admins';
COMMENT ON COLUMN users.role IS 'User role: owner, manager, admin, chef, waiter';
COMMENT ON COLUMN users.is_owner IS 'Platform owner/super admin flag';

-- TABLE: tables (Physical restaurant tables)
CREATE TABLE IF NOT EXISTS tables (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
    
    -- Table Details
    table_number VARCHAR(10) NOT NULL,
    table_name VARCHAR(100),
    capacity INTEGER DEFAULT 4,
    
    -- Status
    status VARCHAR(20) DEFAULT 'available', -- 'available', 'occupied', 'reserved', 'cleaning'
    booked_at TIMESTAMP WITH TIME ZONE,
    is_active BOOLEAN DEFAULT true,
    
    -- QR Code
    qr_code_url TEXT,
    price_per_day DECIMAL(10, 2) DEFAULT 100.00,
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(restaurant_id, table_number)
);

COMMENT ON TABLE tables IS 'Physical tables in restaurants with QR codes for customer ordering';
COMMENT ON COLUMN tables.price_per_day IS 'Daily billing rate for this table';

-- TABLE: menu_items (Restaurant menu)
CREATE TABLE IF NOT EXISTS menu_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
    
    -- Menu Item Details
    name VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(100) NOT NULL, -- 'Starters', 'Main Course', 'Desserts', 'Beverages'
    price DECIMAL(10, 2) NOT NULL CHECK (price >= 0),
    
    -- Media
    image_url TEXT,
    
    -- Attributes
    is_vegetarian BOOLEAN DEFAULT false,
    is_available BOOLEAN DEFAULT true,
    preparation_time INTEGER DEFAULT 15, -- in minutes
    tags TEXT[],
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE menu_items IS 'Restaurant menu items with pricing and availability';
COMMENT ON COLUMN menu_items.preparation_time IS 'Estimated preparation time in minutes';

-- TABLE: table_sessions (Track customer dining sessions)
CREATE TABLE IF NOT EXISTS table_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
    table_id UUID NOT NULL REFERENCES tables(id) ON DELETE CASCADE,
    
    -- Session Details
    session_token TEXT UNIQUE,
    status TEXT CHECK (status IN ('active', 'completed', 'cancelled')) DEFAULT 'active',
    
    -- Timing
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    ended_at TIMESTAMPTZ,
    
    -- Timestamps
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE table_sessions IS 'Customer dining sessions at tables - one active session per table';

-- TABLE: orders (Customer orders)
CREATE TABLE IF NOT EXISTS orders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
    table_id UUID REFERENCES tables(id) ON DELETE SET NULL,
    session_id UUID REFERENCES table_sessions(id) ON DELETE SET NULL,
    
    -- Order Identification
    order_number VARCHAR(20) UNIQUE NOT NULL,
    order_token VARCHAR(100),
    table_number VARCHAR(10),
    
    -- Customer Info
    customer_name VARCHAR(255),
    customer_phone VARCHAR(20),
    
    -- Order Details
    items JSONB NOT NULL, -- Array of menu items with details
    special_instructions TEXT,
    
    -- Pricing
    subtotal DECIMAL(10, 2) NOT NULL CHECK (subtotal >= 0),
    tax DECIMAL(10, 2) DEFAULT 0 CHECK (tax >= 0),
    discount DECIMAL(10, 2) DEFAULT 0 CHECK (discount >= 0),
    total DECIMAL(10, 2) NOT NULL CHECK (total >= 0),
    
    -- Status
    order_status VARCHAR(50) DEFAULT 'received', -- 'received', 'preparing', 'ready', 'served', 'cancelled'
    payment_status VARCHAR(50) DEFAULT 'pending', -- 'pending', 'paid', 'failed'
    
    -- Feedback
    feedback_submitted BOOLEAN DEFAULT false,
    feedback_submitted_at TIMESTAMP WITH TIME ZONE,
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE orders IS 'Customer orders with items, pricing, and status tracking';
COMMENT ON COLUMN orders.order_number IS 'Unique order number: ORD-YYYYMMDD-0001';

-- ============================================================================
-- PAYMENT & BILLING TABLES
-- ============================================================================

-- TABLE: order_payments (Per-order payment transactions - Razorpay)
CREATE TABLE IF NOT EXISTS order_payments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
    order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    
    -- Razorpay Details
    razorpay_order_id VARCHAR(100),
    razorpay_payment_id VARCHAR(100),
    razorpay_signature VARCHAR(255),
    
    -- Payment Details
    amount DECIMAL(10, 2) NOT NULL CHECK (amount >= 0),
    currency VARCHAR(10) DEFAULT 'INR',
    status VARCHAR(50) DEFAULT 'created' CHECK (status IN ('created', 'authorized', 'captured', 'failed', 'refunded')),
    payment_method VARCHAR(50) DEFAULT 'razorpay',
    payment_details JSONB DEFAULT '{}',
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(razorpay_payment_id)
);

COMMENT ON TABLE order_payments IS 'Payment transactions for customer orders via Razorpay';

-- TABLE: payments (Generic payments table - kept for compatibility)
CREATE TABLE IF NOT EXISTS payments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    restaurant_id UUID REFERENCES restaurants(id) ON DELETE CASCADE,
    order_id UUID REFERENCES orders(id) ON DELETE CASCADE,
    billing_id UUID REFERENCES billing(id) ON DELETE CASCADE,
    subscription_id UUID REFERENCES subscriptions(id) ON DELETE CASCADE,
    
    -- Payment Details
    amount DECIMAL(10, 2) NOT NULL CHECK (amount >= 0),
    currency VARCHAR(10) DEFAULT 'INR',
    status VARCHAR(50) DEFAULT 'created',
    payment_method VARCHAR(50),
    payment_status VARCHAR(50) DEFAULT 'completed',
    
    -- Gateway Details
    razorpay_order_id VARCHAR(100),
    razorpay_payment_id VARCHAR(100),
    razorpay_signature VARCHAR(255),
    payment_gateway_id VARCHAR(255),
    transaction_id VARCHAR(255),
    transaction_reference VARCHAR(255),
    payment_gateway VARCHAR(50),
    
    -- Metadata
    payment_details JSONB,
    payment_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    verified_at TIMESTAMP WITH TIME ZONE,
    verified_by UUID REFERENCES auth.users(id),
    receipt_url TEXT,
    invoice_url TEXT,
    notes TEXT,
    metadata JSONB DEFAULT '{}',
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE payments IS 'Generic payments table for orders, subscriptions, and billing';

-- TABLE: subscriptions (Restaurant subscription plans)
CREATE TABLE IF NOT EXISTS subscriptions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
    
    -- Plan Details
    plan_name VARCHAR(100) NOT NULL, -- 'trial', 'basic', 'pro', 'enterprise'
    status VARCHAR(50) DEFAULT 'active', -- 'active', 'inactive', 'trial', 'cancelled', 'expired'
    billing_cycle VARCHAR(20) DEFAULT 'monthly', -- 'monthly', 'yearly'
    
    -- Pricing
    price DECIMAL(10, 2) NOT NULL CHECK (price >= 0),
    price_per_table DECIMAL(10, 2) DEFAULT 100.00,
    currency VARCHAR(10) DEFAULT 'INR',
    
    -- Period
    trial_ends_at TIMESTAMP WITH TIME ZONE,
    current_period_start TIMESTAMP WITH TIME ZONE NOT NULL,
    current_period_end TIMESTAMP WITH TIME ZONE NOT NULL,
    end_date TIMESTAMPTZ,
    next_billing_date DATE,
    
    -- Cancellation
    cancelled_at TIMESTAMP WITH TIME ZONE,
    
    -- Metadata
    metadata JSONB DEFAULT '{}',
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE subscriptions IS 'Restaurant subscription plans and billing cycles';
COMMENT ON COLUMN subscriptions.price_per_table IS 'Daily rate per table (₹100/table/day default)';

-- TABLE: billing (Monthly billing records)
CREATE TABLE IF NOT EXISTS billing (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
    
    -- Billing Period
    billing_month INTEGER NOT NULL CHECK (billing_month BETWEEN 1 AND 12),
    billing_year INTEGER NOT NULL CHECK (billing_year >= 2024),
    billing_period DATE NOT NULL,
    
    -- Billing Calculation
    table_count INTEGER NOT NULL CHECK (table_count >= 0),
    rate_per_table_per_day DECIMAL(10, 2) NOT NULL DEFAULT 100.00,
    days_in_month INTEGER NOT NULL CHECK (days_in_month BETWEEN 28 AND 31),
    
    -- Amounts
    base_amount DECIMAL(10, 2) NOT NULL CHECK (base_amount >= 0),
    discount_amount DECIMAL(10, 2) DEFAULT 0 CHECK (discount_amount >= 0),
    tax_amount DECIMAL(10, 2) DEFAULT 0 CHECK (tax_amount >= 0),
    total_amount DECIMAL(10, 2) NOT NULL CHECK (total_amount >= 0),
    
    -- Status
    status VARCHAR(50) DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'overdue', 'cancelled')),
    
    -- Dates
    due_date DATE NOT NULL,
    grace_period_days INTEGER DEFAULT 3,
    grace_end_date DATE NOT NULL,
    paid_at TIMESTAMP WITH TIME ZONE,
    suspended_at TIMESTAMP WITH TIME ZONE,
    reactivated_at TIMESTAMP WITH TIME ZONE,
    
    -- Metadata
    notes TEXT,
    metadata JSONB DEFAULT '{}',
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(restaurant_id, billing_year, billing_month)
);

COMMENT ON TABLE billing IS 'Monthly billing records: table_count × ₹100 × days_in_month';

-- ============================================================================
-- FEEDBACK & RATINGS
-- ============================================================================

-- TABLE: feedbacks (Order feedback)
CREATE TABLE IF NOT EXISTS feedbacks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    restaurant_id UUID REFERENCES restaurants(id) ON DELETE CASCADE,
    order_id UUID REFERENCES orders(id) ON DELETE CASCADE,
    session_id UUID REFERENCES table_sessions(id) ON DELETE CASCADE,
    
    rating INTEGER CHECK (rating >= 1 AND rating <= 5),
    comment TEXT,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE feedbacks IS 'Customer ratings and feedback for orders';

-- TABLE: menu_item_ratings (Individual item ratings)
CREATE TABLE IF NOT EXISTS menu_item_ratings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
    menu_item_id UUID NOT NULL REFERENCES menu_items(id) ON DELETE CASCADE,
    order_id UUID REFERENCES orders(id) ON DELETE CASCADE,
    session_id UUID REFERENCES table_sessions(id) ON DELETE CASCADE,
    
    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE menu_item_ratings IS 'Customer ratings for individual menu items';

-- ============================================================================
-- NOTIFICATIONS & ACTIVITY
-- ============================================================================

-- TABLE: notifications
CREATE TABLE IF NOT EXISTS notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    restaurant_id UUID REFERENCES restaurants(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    
    type TEXT CHECK (type IN ('order','payment','system','staff','alert')) DEFAULT 'system',
    title TEXT NOT NULL,
    body TEXT,
    data JSONB DEFAULT '{}',
    is_read BOOLEAN DEFAULT false,
    
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE notifications IS 'In-app notifications for managers and staff';

-- TABLE: offers (Promotions and discounts)
CREATE TABLE IF NOT EXISTS offers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    restaurant_id UUID REFERENCES restaurants(id) ON DELETE CASCADE,
    
    title TEXT NOT NULL,
    description TEXT,
    discount_percent NUMERIC(5,2) CHECK (discount_percent >= 0 AND discount_percent <= 100),
    is_active BOOLEAN DEFAULT true,
    starts_at TIMESTAMPTZ,
    ends_at TIMESTAMPTZ,
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

COMMENT ON TABLE offers IS 'Restaurant promotions and discount offers';

-- TABLE: activity_logs (User activity tracking)
CREATE TABLE IF NOT EXISTS activity_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    restaurant_id UUID REFERENCES restaurants(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    
    action TEXT NOT NULL,
    entity_type TEXT,
    entity_id UUID,
    details JSONB,
    ip_address INET,
    user_agent TEXT,
    
    created_at TIMESTAMPTZ DEFAULT NOW()
);

COMMENT ON TABLE activity_logs IS 'User activity and action tracking within restaurants';

-- ============================================================================
-- PLATFORM ADMIN TABLES
-- ============================================================================

-- TABLE: platform_settings (Global configuration)
CREATE TABLE IF NOT EXISTS platform_settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    key VARCHAR(255) UNIQUE NOT NULL,
    value JSONB,
    category VARCHAR(100), -- 'payment', 'email', 'storage', 'api', 'platform'
    is_encrypted BOOLEAN DEFAULT false,
    description TEXT,
    updated_by UUID REFERENCES auth.users(id),
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE platform_settings IS 'Platform-wide configuration settings';

-- TABLE: platform_admins (Super admin users)
CREATE TABLE IF NOT EXISTS platform_admins (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
    
    email TEXT NOT NULL UNIQUE,
    full_name TEXT NOT NULL,
    role admin_role NOT NULL DEFAULT 'subadmin',
    permissions JSONB DEFAULT '{}',
    
    is_active BOOLEAN DEFAULT true,
    two_factor_enabled BOOLEAN DEFAULT false,
    two_factor_secret TEXT,
    
    last_login TIMESTAMP WITH TIME ZONE,
    login_count INTEGER DEFAULT 0,
    last_ip INET,
    
    notes TEXT,
    created_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE platform_admins IS 'Platform administrator accounts with role-based permissions';

-- TABLE: system_logs (Platform-wide logging)
CREATE TABLE IF NOT EXISTS system_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    level VARCHAR(20) NOT NULL, -- 'info', 'warning', 'error', 'critical'
    source VARCHAR(100), -- 'api', 'database', 'payment', 'auth', 'storage'
    message TEXT NOT NULL,
    details JSONB,
    restaurant_id UUID REFERENCES restaurants(id),
    user_id UUID,
    ip_address INET,
    user_agent TEXT,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE system_logs IS 'System-wide logging and monitoring';

-- TABLE: audit_trail (Action audit log)
CREATE TABLE IF NOT EXISTS audit_trail (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    actor_id UUID REFERENCES auth.users(id),
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50),
    entity_id UUID,
    old_values JSONB,
    new_values JSONB,
    ip_address INET,
    user_agent TEXT,
    severity VARCHAR(20) DEFAULT 'info',
    metadata JSONB DEFAULT '{}',
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE audit_trail IS 'Comprehensive audit trail for all platform actions';

-- TABLE: backups (Backup tracking)
CREATE TABLE IF NOT EXISTS backups (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    backup_type VARCHAR(50) NOT NULL, -- 'full', 'incremental', 'restaurant'
    restaurant_id UUID REFERENCES restaurants(id),
    file_path TEXT,
    file_size BIGINT,
    status VARCHAR(50) DEFAULT 'in_progress', -- 'in_progress', 'completed', 'failed'
    initiated_by UUID REFERENCES auth.users(id),
    completed_at TIMESTAMP WITH TIME ZONE,
    expires_at TIMESTAMP WITH TIME ZONE,
    error_message TEXT,
    metadata JSONB DEFAULT '{}',
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE backups IS 'Database backup operations tracking';

-- TABLE: backup_schedules (Automated backup configuration)
CREATE TABLE IF NOT EXISTS backup_schedules (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    name TEXT NOT NULL,
    backup_type VARCHAR(50) NOT NULL CHECK (backup_type IN ('full', 'incremental', 'restaurant')),
    frequency VARCHAR(50) NOT NULL CHECK (frequency IN ('hourly', 'daily', 'weekly', 'monthly')),
    schedule_time TIME,
    schedule_day INTEGER,
    restaurant_id UUID REFERENCES restaurants(id) ON DELETE CASCADE,
    include_all_restaurants BOOLEAN DEFAULT false,
    retention_days INTEGER DEFAULT 30,
    compression_enabled BOOLEAN DEFAULT true,
    encryption_enabled BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    last_run TIMESTAMP WITH TIME ZONE,
    next_run TIMESTAMP WITH TIME ZONE,
    last_backup_id UUID REFERENCES backups(id),
    created_by UUID REFERENCES auth.users(id),
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE backup_schedules IS 'Automated backup scheduling and configuration';

-- TABLE: maintenance_mode (Platform maintenance control)
CREATE TABLE IF NOT EXISTS maintenance_mode (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    is_active BOOLEAN DEFAULT false,
    scheduled BOOLEAN DEFAULT false,
    start_time TIMESTAMP WITH TIME ZONE,
    end_time TIMESTAMP WITH TIME ZONE,
    title TEXT DEFAULT 'System Maintenance',
    message TEXT DEFAULT 'We are currently performing scheduled maintenance.',
    estimated_duration INTEGER,
    allow_admin_access BOOLEAN DEFAULT true,
    activated_by UUID REFERENCES auth.users(id),
    activated_by_email TEXT,
    activated_at TIMESTAMP WITH TIME ZONE,
    deactivated_at TIMESTAMP WITH TIME ZONE,
    reason TEXT,
    metadata JSONB DEFAULT '{}',
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE maintenance_mode IS 'Platform maintenance mode control and scheduling';

-- TABLE: payment_credential_audit (Payment gateway credential changes)
CREATE TABLE IF NOT EXISTS payment_credential_audit (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    restaurant_id UUID REFERENCES restaurants(id) ON DELETE CASCADE,
    changed_by UUID REFERENCES auth.users(id),
    
    action VARCHAR(50) NOT NULL, -- 'added', 'updated', 'removed', 'verified'
    old_key_id VARCHAR(255),
    new_key_id VARCHAR(255),
    ip_address INET,
    user_agent TEXT,
    notes TEXT,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE payment_credential_audit IS 'Audit log for Razorpay credential changes';

-- TABLE: auth_activity_logs (Authentication activity tracking)
CREATE TABLE IF NOT EXISTS auth_activity_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    
    action VARCHAR(100) NOT NULL, -- 'login', 'logout', 'failed_login', 'password_change'
    ip_address INET,
    user_agent TEXT,
    metadata JSONB DEFAULT '{}',
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE auth_activity_logs IS 'Authentication and security activity logging';

-- ============================================================================
-- TABLE CREATION COMPLETE
-- ============================================================================

SELECT 'All tables created successfully!' AS status;
