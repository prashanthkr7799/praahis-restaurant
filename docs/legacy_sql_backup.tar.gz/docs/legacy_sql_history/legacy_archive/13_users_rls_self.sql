-- ============================================================================
-- USERS schema + RLS fixes (idempotent)
-- Purpose: fix 400 on PATCH /rest/v1/users (missing last_login) and
--          remove recursive users policy causing 500 recursion error.
-- Run this after 10_multitenancy.sql in the same Supabase database.
-- ============================================================================

-- 1) Schema fixes -------------------------------------------------------------
-- Make legacy password_hash optional (Supabase Auth doesn't use it)
ALTER TABLE IF EXISTS public.users
  ALTER COLUMN password_hash DROP NOT NULL;

-- Ensure columns used by app exist
ALTER TABLE IF EXISTS public.users
  ADD COLUMN IF NOT EXISTS restaurant_id UUID,
  ADD COLUMN IF NOT EXISTS last_login TIMESTAMPTZ;

-- Ensure FK to restaurants (safe if already exists)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'fk_users_restaurant'
      AND conrelid = 'public.users'::regclass
  ) THEN
    ALTER TABLE public.users
      ADD CONSTRAINT fk_users_restaurant
      FOREIGN KEY (restaurant_id) REFERENCES public.restaurants(id)
      ON DELETE SET NULL;
  END IF;
END$$;

-- 2) Clean users RLS to avoid recursion --------------------------------------
ALTER TABLE IF EXISTS public.users ENABLE ROW LEVEL SECURITY;

-- Drop any old users policies if present (safe no-ops if missing)
DO $$
BEGIN
  -- Policies introduced earlier in this repo
  IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='users' AND policyname='users_select') THEN
    DROP POLICY users_select ON public.users;
  END IF;
  IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='users' AND policyname='users_update') THEN
    DROP POLICY users_update ON public.users;
  END IF;

  -- Policies from multitenancy migration (recursive via helper)
  IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='users' AND policyname='users_read_own_restaurant') THEN
    DROP POLICY users_read_own_restaurant ON public.users;
  END IF;
  IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='users' AND policyname='users_rw_own_restaurant') THEN
    DROP POLICY users_rw_own_restaurant ON public.users;
  END IF;

  -- If self policies were created previously, drop to recreate cleanly
  IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='users' AND policyname='users_self_select') THEN
    DROP POLICY users_self_select ON public.users;
  END IF;
  IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='users' AND policyname='users_self_update') THEN
    DROP POLICY users_self_update ON public.users;
  END IF;
END$$;

-- Minimal, non-recursive policies needed for login:
-- Allow every authenticated user to read/update ONLY their own row
CREATE POLICY users_self_select ON public.users
  FOR SELECT TO authenticated
  USING (id = auth.uid());

CREATE POLICY users_self_update ON public.users
  FOR UPDATE TO authenticated
  USING (id = auth.uid())
  WITH CHECK (id = auth.uid());

-- 3) Upsert manager profiles so login can load role/is_active/restaurant_id ----
WITH tenants AS (
  SELECT id, lower(slug) AS slug
  FROM public.restaurants
  WHERE lower(slug) IN ('tabun','table9','redchillis','demo')
),
-- expected auth users (seeded via scripts/seed-tenants.js or manual)
-- emails must match your Supabase Auth users
pairs AS (
  SELECT 'tabun'::text AS slug, 'manager@tabun.local'::text AS email, 'Tabun Manager'::text AS full_name
  UNION ALL SELECT 'table9', 'manager@table9.local', 'Table9 Manager'
  UNION ALL SELECT 'redchillis', 'manager@redchillis.local', 'Red Chillis Manager'
  UNION ALL SELECT 'demo', 'demo.manager@demo.local', 'Demo Manager'
),
-- join auth.users to the expected manager emails
to_upsert AS (
  SELECT
    au.id AS auth_id,
    au.email,
    COALESCE(au.raw_user_meta_data->>'full_name', p.full_name) AS full_name,
    lower(p.slug) AS slug
  FROM auth.users au
  JOIN pairs p ON lower(au.email) = lower(p.email)
)
INSERT INTO public.users (id, email, full_name, role, restaurant_id, is_active, created_at, updated_at)
SELECT u.auth_id, u.email, u.full_name, 'manager', t.id, true, NOW(), NOW()
FROM to_upsert u
JOIN tenants t ON t.slug = u.slug
ON CONFLICT (id) DO UPDATE
SET email = EXCLUDED.email,
    full_name = EXCLUDED.full_name,
    role = EXCLUDED.role,
    restaurant_id = EXCLUDED.restaurant_id,
    is_active = true,
    updated_at = NOW();

-- End of migration ------------------------------------------------------------
