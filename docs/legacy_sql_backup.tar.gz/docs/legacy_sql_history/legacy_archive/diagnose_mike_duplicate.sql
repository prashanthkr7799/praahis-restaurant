-- Diagnose the mike@gmail.com duplicate issue

-- Step 1: Find all users with email mike@gmail.com in auth.users
SELECT 
  id,
  email,
  created_at,
  'auth.users' as source
FROM auth.users
WHERE email = 'mike@gmail.com'
ORDER BY created_at;

-- Step 2: Find all users with email mike@gmail.com in public.users
SELECT 
  id,
  email,
  full_name,
  role,
  restaurant_id,
  is_active,
  created_at,
  'public.users' as source
FROM public.users
WHERE email = 'mike@gmail.com'
ORDER BY created_at;

-- Step 3: Show the mismatch
SELECT 
  au.id as auth_id,
  au.email as auth_email,
  au.created_at as auth_created,
  pu.id as public_id,
  pu.email as public_email,
  pu.created_at as public_created,
  CASE 
    WHEN au.id = pu.id THEN '✅ IDs match'
    WHEN au.id != pu.id THEN '❌ ID MISMATCH - This is the problem!'
    WHEN pu.id IS NULL THEN '❌ No public.users entry'
    ELSE 'Unknown'
  END as status
FROM auth.users au
FULL OUTER JOIN public.users pu ON au.email = pu.email
WHERE au.email = 'mike@gmail.com' OR pu.email = 'mike@gmail.com'
ORDER BY au.created_at, pu.created_at;

-- Step 4: Solution - Delete the orphaned auth.users entry
-- (Keep the public.users entry and delete the mismatched auth user)
-- Uncomment the line below ONLY after confirming the ID mismatch above:

-- DELETE FROM auth.users WHERE id = 'bf61d54a-59f4-4dcc-9817-ef8c543a42a9' AND email = 'mike@gmail.com';
