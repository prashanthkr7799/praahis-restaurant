-- =========================================================================
-- FIX: Owner Login RLS Policies
-- =========================================================================
-- Allows owners to read their own user record during login
-- =========================================================================

-- Step 1: Confirm the email for your user
UPDATE auth.users 
SET email_confirmed_at = NOW(),
    confirmation_token = ''
WHERE email = 'your-email@example.com';  -- ⚠️ CHANGE THIS!

-- Step 2: Add RLS policy for owners to read their own user record
DROP POLICY IF EXISTS "owners_can_read_own_profile" ON public.users;
CREATE POLICY "owners_can_read_own_profile" ON public.users
    FOR SELECT
    USING (
        id = auth.uid() AND (is_owner = TRUE OR role = 'owner')
    );

-- Step 3: Add RLS policy for owners to read all users (for management)
DROP POLICY IF EXISTS "owners_can_read_all_users" ON public.users;
CREATE POLICY "owners_can_read_all_users" ON public.users
    FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM public.users 
            WHERE id = auth.uid() 
            AND (is_owner = TRUE OR role = 'owner')
        )
    );

-- Step 4: Ensure the user exists in public.users
INSERT INTO public.users (
    id,
    email,
    full_name,
    name,
    role,
    is_owner,
    is_active,
    restaurant_id
)
SELECT 
    au.id,
    au.email,
    'Super Admin',
    'Super Admin',
    'owner',
    TRUE,
    TRUE,
    NULL
FROM auth.users au
WHERE au.email = 'your-email@example.com'  -- ⚠️ CHANGE THIS!
ON CONFLICT (id) DO UPDATE SET
    is_owner = TRUE,
    role = 'owner',
    is_active = TRUE,
    email = EXCLUDED.email;

-- Step 5: Verify everything
SELECT 
    u.id,
    u.email,
    u.role,
    u.is_owner,
    u.is_active,
    au.email_confirmed_at
FROM public.users u
JOIN auth.users au ON u.id = au.id
WHERE u.email = 'your-email@example.com';  -- ⚠️ CHANGE THIS!

-- =========================================================================
-- After running this:
-- 1. The email should be confirmed (email_confirmed_at will have a timestamp)
-- 2. The user should exist in public.users with is_owner = TRUE
-- 3. RLS policies allow the owner to read their profile during login
-- 4. Try logging in again!
-- =========================================================================
