-- ============================================================================
-- MAINTENANCE MODE SYSTEM
-- ============================================================================
-- Version: 1.0
-- Created: November 7, 2025
-- Description: System-wide maintenance mode with scheduling
-- ============================================================================

-- Drop existing objects
DO $$
BEGIN
    DROP POLICY IF EXISTS "Superadmin full access to maintenance_mode" ON maintenance_mode;
EXCEPTION
    WHEN undefined_table THEN NULL;
END $$;

DROP TABLE IF EXISTS maintenance_mode CASCADE;

-- ============================================================================
-- TABLE: MAINTENANCE_MODE
-- ============================================================================

CREATE TABLE maintenance_mode (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Status
    is_active BOOLEAN DEFAULT false,
    
    -- Schedule
    scheduled BOOLEAN DEFAULT false,
    start_time TIMESTAMP WITH TIME ZONE,
    end_time TIMESTAMP WITH TIME ZONE,
    
    -- Messages
    title TEXT DEFAULT 'System Maintenance',
    message TEXT DEFAULT 'We are currently performing scheduled maintenance. The system will be back online shortly.',
    estimated_duration INTEGER, -- minutes
    
    -- Admin Bypass
    allow_admin_access BOOLEAN DEFAULT true,
    
    -- Tracking
    activated_by UUID REFERENCES auth.users(id),
    activated_by_email TEXT,
    activated_at TIMESTAMP WITH TIME ZONE,
    deactivated_at TIMESTAMP WITH TIME ZONE,
    
    -- Metadata
    reason TEXT,
    metadata JSONB DEFAULT '{}',
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE maintenance_mode IS 'System-wide maintenance mode configuration';
COMMENT ON COLUMN maintenance_mode.is_active IS 'Whether maintenance mode is currently active';
COMMENT ON COLUMN maintenance_mode.scheduled IS 'Whether this is a scheduled maintenance';
COMMENT ON COLUMN maintenance_mode.allow_admin_access IS 'Whether superadmins can bypass maintenance mode';

-- Indexes
CREATE INDEX idx_maintenance_mode_active ON maintenance_mode(is_active);
CREATE INDEX idx_maintenance_mode_start_time ON maintenance_mode(start_time);

-- ============================================================================
-- FUNCTION: Toggle Maintenance Mode
-- ============================================================================

CREATE OR REPLACE FUNCTION toggle_maintenance_mode(
    p_is_active BOOLEAN,
    p_title TEXT DEFAULT NULL,
    p_message TEXT DEFAULT NULL,
    p_reason TEXT DEFAULT NULL,
    p_user_id UUID DEFAULT NULL
)
RETURNS UUID AS $$
DECLARE
    v_mode_id UUID;
    v_user_email TEXT;
BEGIN
    -- Get user email
    IF p_user_id IS NOT NULL THEN
        SELECT email INTO v_user_email FROM auth.users WHERE id = p_user_id;
    END IF;
    
    -- Insert or update maintenance mode
    INSERT INTO maintenance_mode (
        is_active,
        title,
        message,
        reason,
        activated_by,
        activated_by_email,
        activated_at
    ) VALUES (
        p_is_active,
        COALESCE(p_title, 'System Maintenance'),
        COALESCE(p_message, 'We are currently performing scheduled maintenance.'),
        p_reason,
        p_user_id,
        v_user_email,
        CASE WHEN p_is_active THEN NOW() ELSE NULL END
    )
    RETURNING id INTO v_mode_id;
    
    -- Log to audit trail
    PERFORM log_audit_trail(
        CASE WHEN p_is_active THEN 'maintenance_enabled' ELSE 'maintenance_disabled' END,
        'system',
        v_mode_id,
        'Maintenance Mode',
        NULL,
        jsonb_build_object('reason', p_reason),
        CASE WHEN p_is_active THEN 'Maintenance mode activated' ELSE 'Maintenance mode deactivated' END,
        'warning'
    );
    
    RETURN v_mode_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION toggle_maintenance_mode IS 'Activate or deactivate maintenance mode';

-- ============================================================================
-- FUNCTION: Schedule Maintenance
-- ============================================================================

CREATE OR REPLACE FUNCTION schedule_maintenance(
    p_start_time TIMESTAMP WITH TIME ZONE,
    p_end_time TIMESTAMP WITH TIME ZONE,
    p_title TEXT,
    p_message TEXT,
    p_estimated_duration INTEGER,
    p_user_id UUID DEFAULT NULL
)
RETURNS UUID AS $$
DECLARE
    v_mode_id UUID;
    v_user_email TEXT;
BEGIN
    -- Get user email
    IF p_user_id IS NOT NULL THEN
        SELECT email INTO v_user_email FROM auth.users WHERE id = p_user_id;
    END IF;
    
    -- Create scheduled maintenance
    INSERT INTO maintenance_mode (
        is_active,
        scheduled,
        start_time,
        end_time,
        title,
        message,
        estimated_duration,
        activated_by,
        activated_by_email
    ) VALUES (
        false, -- Not active yet
        true,
        p_start_time,
        p_end_time,
        p_title,
        p_message,
        p_estimated_duration,
        p_user_id,
        v_user_email
    )
    RETURNING id INTO v_mode_id;
    
    -- Log to audit trail
    PERFORM log_audit_trail(
        'maintenance_scheduled',
        'system',
        v_mode_id,
        'Scheduled Maintenance',
        NULL,
        jsonb_build_object(
            'start_time', p_start_time,
            'end_time', p_end_time,
            'duration', p_estimated_duration
        ),
        'Maintenance scheduled for ' || p_start_time::TEXT,
        'info'
    );
    
    RETURN v_mode_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION schedule_maintenance IS 'Schedule a future maintenance window';

-- ============================================================================
-- FUNCTION: Get Current Maintenance Status
-- ============================================================================

CREATE OR REPLACE FUNCTION get_maintenance_status()
RETURNS JSONB AS $$
DECLARE
    v_status JSONB;
    v_current maintenance_mode%ROWTYPE;
BEGIN
    -- Get the most recent maintenance mode entry
    SELECT * INTO v_current
    FROM maintenance_mode
    ORDER BY created_at DESC
    LIMIT 1;
    
    IF NOT FOUND THEN
        RETURN jsonb_build_object(
            'is_active', false,
            'message', null,
            'allow_admin_access', true
        );
    END IF;
    
    v_status := jsonb_build_object(
        'is_active', v_current.is_active,
        'scheduled', v_current.scheduled,
        'title', v_current.title,
        'message', v_current.message,
        'start_time', v_current.start_time,
        'end_time', v_current.end_time,
        'estimated_duration', v_current.estimated_duration,
        'allow_admin_access', v_current.allow_admin_access,
        'activated_at', v_current.activated_at
    );
    
    RETURN v_status;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION get_maintenance_status IS 'Get current maintenance mode status';

-- ============================================================================
-- ROW LEVEL SECURITY
-- ============================================================================

ALTER TABLE maintenance_mode ENABLE ROW LEVEL SECURITY;

-- Only superadmins can manage maintenance mode
DROP POLICY IF EXISTS "Superadmin full access to maintenance_mode" ON maintenance_mode;
CREATE POLICY "Superadmin full access to maintenance_mode" ON maintenance_mode
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM platform_admins
            WHERE user_id = auth.uid()
            AND role = 'superadmin'
            AND is_active = true
        )
    );

-- ============================================================================
-- TRIGGER: Update timestamp
-- ============================================================================

CREATE OR REPLACE FUNCTION update_maintenance_mode_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS update_maintenance_mode_timestamp_trigger ON maintenance_mode;
CREATE TRIGGER update_maintenance_mode_timestamp_trigger
    BEFORE UPDATE ON maintenance_mode
    FOR EACH ROW
    EXECUTE FUNCTION update_maintenance_mode_timestamp();

-- ============================================================================
-- USAGE EXAMPLES
-- ============================================================================

/*
-- 1. Enable maintenance mode immediately
SELECT toggle_maintenance_mode(
    true,
    'Emergency Maintenance',
    'We are fixing a critical issue. Service will resume shortly.',
    'Database migration',
    '<admin_user_id>'::UUID
);

-- 2. Disable maintenance mode
SELECT toggle_maintenance_mode(
    false,
    NULL,
    NULL,
    'Maintenance completed',
    '<admin_user_id>'::UUID
);

-- 3. Schedule future maintenance
SELECT schedule_maintenance(
    '2025-11-10 02:00:00+00'::TIMESTAMP WITH TIME ZONE,
    '2025-11-10 04:00:00+00'::TIMESTAMP WITH TIME ZONE,
    'Scheduled Database Upgrade',
    'We will be upgrading our database servers. Expected downtime: 2 hours.',
    120, -- 2 hours in minutes
    '<admin_user_id>'::UUID
);

-- 4. Check maintenance status
SELECT get_maintenance_status();

-- 5. Get maintenance history
SELECT * FROM maintenance_mode
ORDER BY created_at DESC
LIMIT 10;
*/
