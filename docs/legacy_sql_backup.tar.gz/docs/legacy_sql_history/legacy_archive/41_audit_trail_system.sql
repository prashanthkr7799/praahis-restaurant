-- ============================================================================
-- AUDIT TRAIL & COMPREHENSIVE LOGGING SYSTEM
-- ============================================================================
-- Version: 1.0
-- Created: November 7, 2025
-- Description: Complete audit trail for all super admin actions
-- ============================================================================

-- Enable UUID extension if not exists
DO $$ 
BEGIN
    CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
EXCEPTION
    WHEN duplicate_object THEN NULL;
END $$;

-- Drop existing objects if they exist (for clean reinstall)
DROP TRIGGER IF EXISTS audit_restaurants_trigger ON restaurants CASCADE;
DROP TRIGGER IF EXISTS audit_billing_trigger ON billing CASCADE;
DROP TRIGGER IF EXISTS audit_payments_trigger ON payments CASCADE;
DROP TRIGGER IF EXISTS audit_users_trigger ON users CASCADE;
DROP TRIGGER IF EXISTS audit_platform_settings_trigger ON platform_settings CASCADE;

DROP FUNCTION IF EXISTS audit_restaurants() CASCADE;
DROP FUNCTION IF EXISTS audit_billing() CASCADE;
DROP FUNCTION IF EXISTS audit_payments() CASCADE;
DROP FUNCTION IF EXISTS audit_users() CASCADE;
DROP FUNCTION IF EXISTS audit_platform_settings() CASCADE;
DROP FUNCTION IF EXISTS log_audit_trail CASCADE;
DROP FUNCTION IF EXISTS get_recent_audit_logs CASCADE;
DROP FUNCTION IF EXISTS get_entity_audit_history CASCADE;

DROP TABLE IF EXISTS audit_trail CASCADE;

-- ============================================================================
-- TABLE: AUDIT_TRAIL
-- ============================================================================
-- Comprehensive logging of all CRUD operations and system actions

CREATE TABLE audit_trail (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Actor Information
    actor_id UUID REFERENCES auth.users(id),
    actor_email TEXT,
    actor_role TEXT,
    
    -- Action Details
    action VARCHAR(100) NOT NULL CHECK (action IN (
        'created', 'updated', 'deleted', 'restored',
        'activated', 'deactivated', 'suspended', 'reactivated',
        'payment_made', 'payment_verified', 'billing_generated',
        'backup_created', 'backup_restored',
        'settings_updated', 'login', 'logout',
        'password_reset', 'role_changed',
        'bulk_action'
    )),
    
    -- Entity Information
    entity_type VARCHAR(50) NOT NULL CHECK (entity_type IN (
        'restaurant', 'user', 'manager', 'subscription', 
        'billing', 'payment', 'menu_item', 'table', 'order',
        'platform_settings', 'backup', 'system'
    )),
    entity_id UUID,
    entity_name TEXT,
    
    -- Change Tracking
    old_values JSONB,
    new_values JSONB,
    changed_fields TEXT[],
    
    -- Request Metadata
    ip_address INET,
    user_agent TEXT,
    request_method VARCHAR(10),
    request_path TEXT,
    
    -- Additional Context
    description TEXT,
    severity VARCHAR(20) DEFAULT 'info' CHECK (severity IN ('info', 'warning', 'error', 'critical')),
    metadata JSONB DEFAULT '{}',
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE audit_trail IS 'Complete audit log of all system actions';
COMMENT ON COLUMN audit_trail.action IS 'Type of action performed';
COMMENT ON COLUMN audit_trail.entity_type IS 'Type of entity affected';
COMMENT ON COLUMN audit_trail.old_values IS 'Previous state (for updates/deletes)';
COMMENT ON COLUMN audit_trail.new_values IS 'New state (for creates/updates)';
COMMENT ON COLUMN audit_trail.changed_fields IS 'Array of field names that changed';

-- Indexes for fast queries
CREATE INDEX idx_audit_trail_actor ON audit_trail(actor_id);
CREATE INDEX idx_audit_trail_entity ON audit_trail(entity_type, entity_id);
CREATE INDEX idx_audit_trail_action ON audit_trail(action);
CREATE INDEX idx_audit_trail_created ON audit_trail(created_at DESC);
CREATE INDEX idx_audit_trail_entity_type ON audit_trail(entity_type);
CREATE INDEX idx_audit_trail_severity ON audit_trail(severity);

-- ============================================================================
-- FUNCTION: Log Audit Trail Entry
-- ============================================================================

CREATE OR REPLACE FUNCTION log_audit_trail(
    p_action VARCHAR,
    p_entity_type VARCHAR,
    p_entity_id UUID DEFAULT NULL,
    p_entity_name TEXT DEFAULT NULL,
    p_old_values JSONB DEFAULT NULL,
    p_new_values JSONB DEFAULT NULL,
    p_description TEXT DEFAULT NULL,
    p_severity VARCHAR DEFAULT 'info',
    p_metadata JSONB DEFAULT '{}'
)
RETURNS UUID AS $$
DECLARE
    v_audit_id UUID;
    v_actor_id UUID;
    v_actor_email TEXT;
    v_actor_role TEXT;
    v_changed_fields TEXT[];
BEGIN
    -- Get actor information from current session
    v_actor_id := auth.uid();
    
    SELECT email INTO v_actor_email
    FROM auth.users
    WHERE id = v_actor_id;
    
    SELECT role INTO v_actor_role
    FROM users
    WHERE id = v_actor_id;
    
    -- Extract changed fields if both old and new values exist
    IF p_old_values IS NOT NULL AND p_new_values IS NOT NULL THEN
        SELECT array_agg(key)
        INTO v_changed_fields
        FROM jsonb_each(p_new_values)
        WHERE value != COALESCE(p_old_values->key, 'null'::jsonb);
    END IF;
    
    -- Insert audit record
    INSERT INTO audit_trail (
        actor_id,
        actor_email,
        actor_role,
        action,
        entity_type,
        entity_id,
        entity_name,
        old_values,
        new_values,
        changed_fields,
        description,
        severity,
        metadata
    ) VALUES (
        v_actor_id,
        v_actor_email,
        v_actor_role,
        p_action,
        p_entity_type,
        p_entity_id,
        p_entity_name,
        p_old_values,
        p_new_values,
        v_changed_fields,
        p_description,
        p_severity,
        p_metadata
    ) RETURNING id INTO v_audit_id;
    
    RETURN v_audit_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION log_audit_trail IS 'Log an audit trail entry with automatic change detection';

-- ============================================================================
-- TRIGGER FUNCTIONS: Auto-audit for key tables
-- ============================================================================

-- Restaurant audit trigger
CREATE OR REPLACE FUNCTION audit_restaurants()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        PERFORM log_audit_trail(
            'created',
            'restaurant',
            NEW.id,
            NEW.name,
            NULL,
            row_to_json(NEW)::jsonb,
            'Restaurant created: ' || NEW.name
        );
    ELSIF TG_OP = 'UPDATE' THEN
        PERFORM log_audit_trail(
            'updated',
            'restaurant',
            NEW.id,
            NEW.name,
            row_to_json(OLD)::jsonb,
            row_to_json(NEW)::jsonb,
            'Restaurant updated: ' || NEW.name
        );
    ELSIF TG_OP = 'DELETE' THEN
        PERFORM log_audit_trail(
            'deleted',
            'restaurant',
            OLD.id,
            OLD.name,
            row_to_json(OLD)::jsonb,
            NULL,
            'Restaurant deleted: ' || OLD.name,
            'warning'
        );
    END IF;
    RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Billing audit trigger
CREATE OR REPLACE FUNCTION audit_billing()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        PERFORM log_audit_trail(
            'billing_generated',
            'billing',
            NEW.id,
            'Billing for ' || NEW.billing_period::TEXT,
            NULL,
            row_to_json(NEW)::jsonb,
            'Bill generated: ₹' || NEW.total_amount::TEXT
        );
    ELSIF TG_OP = 'UPDATE' AND OLD.status != NEW.status THEN
        PERFORM log_audit_trail(
            CASE 
                WHEN NEW.status = 'paid' THEN 'payment_verified'
                WHEN NEW.status = 'overdue' THEN 'suspended'
                ELSE 'updated'
            END,
            'billing',
            NEW.id,
            'Billing for ' || NEW.billing_period::TEXT,
            row_to_json(OLD)::jsonb,
            row_to_json(NEW)::jsonb,
            'Billing status changed: ' || OLD.status || ' → ' || NEW.status
        );
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Payment audit trigger
CREATE OR REPLACE FUNCTION audit_payments()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        PERFORM log_audit_trail(
            'payment_made',
            'payment',
            NEW.id,
            'Payment #' || NEW.id::TEXT,
            NULL,
            row_to_json(NEW)::jsonb,
            'Payment recorded: ₹' || NEW.amount::TEXT || ' via ' || NEW.payment_method
        );
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Users audit trigger
CREATE OR REPLACE FUNCTION audit_users()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        PERFORM log_audit_trail(
            'created',
            'user',
            NEW.id,
            COALESCE(NEW.full_name, NEW.name, NEW.email),
            NULL,
            row_to_json(NEW)::jsonb,
            'User created: ' || COALESCE(NEW.full_name, NEW.name, NEW.email)
        );
    ELSIF TG_OP = 'UPDATE' THEN
        PERFORM log_audit_trail(
            CASE 
                WHEN OLD.is_active != NEW.is_active THEN 
                    CASE WHEN NEW.is_active THEN 'activated' ELSE 'deactivated' END
                WHEN OLD.role != NEW.role THEN 'role_changed'
                ELSE 'updated'
            END,
            'user',
            NEW.id,
            COALESCE(NEW.full_name, NEW.name, NEW.email),
            row_to_json(OLD)::jsonb,
            row_to_json(NEW)::jsonb,
            'User updated: ' || COALESCE(NEW.full_name, NEW.name, NEW.email)
        );
    ELSIF TG_OP = 'DELETE' THEN
        PERFORM log_audit_trail(
            'deleted',
            'user',
            OLD.id,
            COALESCE(OLD.full_name, OLD.name, OLD.email),
            row_to_json(OLD)::jsonb,
            NULL,
            'User deleted: ' || COALESCE(OLD.full_name, OLD.name, OLD.email),
            'warning'
        );
    END IF;
    RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Settings audit trigger
CREATE OR REPLACE FUNCTION audit_platform_settings()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'UPDATE' THEN
        PERFORM log_audit_trail(
            'settings_updated',
            'platform_settings',
            NEW.id,
            NEW.key,
            row_to_json(OLD)::jsonb,
            row_to_json(NEW)::jsonb,
            'Setting updated: ' || NEW.key
        );
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================================
-- ATTACH TRIGGERS
-- ============================================================================

DROP TRIGGER IF EXISTS audit_restaurants_trigger ON restaurants;
CREATE TRIGGER audit_restaurants_trigger
    AFTER INSERT OR UPDATE OR DELETE ON restaurants
    FOR EACH ROW EXECUTE FUNCTION audit_restaurants();

DROP TRIGGER IF EXISTS audit_billing_trigger ON billing;
CREATE TRIGGER audit_billing_trigger
    AFTER INSERT OR UPDATE ON billing
    FOR EACH ROW EXECUTE FUNCTION audit_billing();

DROP TRIGGER IF EXISTS audit_payments_trigger ON payments;
CREATE TRIGGER audit_payments_trigger
    AFTER INSERT ON payments
    FOR EACH ROW EXECUTE FUNCTION audit_payments();

DROP TRIGGER IF EXISTS audit_users_trigger ON users;
CREATE TRIGGER audit_users_trigger
    AFTER INSERT OR UPDATE OR DELETE ON users
    FOR EACH ROW EXECUTE FUNCTION audit_users();

DROP TRIGGER IF EXISTS audit_platform_settings_trigger ON platform_settings;
CREATE TRIGGER audit_platform_settings_trigger
    AFTER UPDATE ON platform_settings
    FOR EACH ROW EXECUTE FUNCTION audit_platform_settings();

-- ============================================================================
-- ROW LEVEL SECURITY
-- ============================================================================

ALTER TABLE audit_trail ENABLE ROW LEVEL SECURITY;

-- Super Admin: Full access
DROP POLICY IF EXISTS "Superadmin full access to audit trail" ON audit_trail;
CREATE POLICY "Superadmin full access to audit trail" ON audit_trail
    FOR ALL USING (
        (auth.jwt() ->> 'is_owner')::boolean = true
    );

-- Managers: View logs related to their restaurant only
DROP POLICY IF EXISTS "Managers view own restaurant audits" ON audit_trail;
CREATE POLICY "Managers view own restaurant audits" ON audit_trail
    FOR SELECT USING (
        entity_type = 'restaurant' AND entity_id IN (
            SELECT restaurant_id FROM users 
            WHERE id = auth.uid() 
            AND role IN ('manager', 'admin')
        )
    );

-- ============================================================================
-- HELPER FUNCTIONS
-- ============================================================================

-- Get recent audit logs
CREATE OR REPLACE FUNCTION get_recent_audit_logs(
    p_limit INTEGER DEFAULT 50,
    p_entity_type VARCHAR DEFAULT NULL,
    p_action VARCHAR DEFAULT NULL
)
RETURNS TABLE(
    id UUID,
    action VARCHAR,
    entity_type VARCHAR,
    entity_name TEXT,
    actor_email TEXT,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        a.id,
        a.action,
        a.entity_type,
        a.entity_name,
        a.actor_email,
        a.description,
        a.created_at
    FROM audit_trail a
    WHERE (p_entity_type IS NULL OR a.entity_type = p_entity_type)
      AND (p_action IS NULL OR a.action = p_action)
    ORDER BY a.created_at DESC
    LIMIT p_limit;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Get audit logs for specific entity
CREATE OR REPLACE FUNCTION get_entity_audit_history(
    p_entity_type VARCHAR,
    p_entity_id UUID
)
RETURNS TABLE(
    id UUID,
    action VARCHAR,
    actor_email TEXT,
    description TEXT,
    old_values JSONB,
    new_values JSONB,
    changed_fields TEXT[],
    created_at TIMESTAMP WITH TIME ZONE
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        a.id,
        a.action,
        a.actor_email,
        a.description,
        a.old_values,
        a.new_values,
        a.changed_fields,
        a.created_at
    FROM audit_trail a
    WHERE a.entity_type = p_entity_type
      AND a.entity_id = p_entity_id
    ORDER BY a.created_at DESC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION get_recent_audit_logs IS 'Get recent audit logs with optional filters';
COMMENT ON FUNCTION get_entity_audit_history IS 'Get complete audit history for a specific entity';

-- ============================================================================
-- USAGE EXAMPLES
-- ============================================================================

/*
-- 1. Manual audit log entry
SELECT log_audit_trail(
    'updated',
    'restaurant',
    '<restaurant_id>'::UUID,
    'The Golden Fork',
    '{"is_active": false}'::jsonb,
    '{"is_active": true}'::jsonb,
    'Restaurant reactivated after payment',
    'info'
);

-- 2. Get recent audit logs
SELECT * FROM get_recent_audit_logs(100);

-- 3. Get audit history for specific restaurant
SELECT * FROM get_entity_audit_history('restaurant', '<restaurant_id>'::UUID);

-- 4. Find all suspension actions
SELECT * FROM audit_trail 
WHERE action = 'suspended' 
ORDER BY created_at DESC;

-- 5. Get audit summary by action type
SELECT 
    action,
    entity_type,
    COUNT(*) as count,
    MAX(created_at) as last_occurred
FROM audit_trail
WHERE created_at > CURRENT_DATE - INTERVAL '30 days'
GROUP BY action, entity_type
ORDER BY count DESC;
*/
