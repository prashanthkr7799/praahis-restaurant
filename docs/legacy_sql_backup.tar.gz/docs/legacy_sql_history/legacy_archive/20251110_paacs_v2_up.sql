-- ============================================================================
-- PAACS v2.0 (Fusion Edition) — DATABASE MIGRATION (UP)
-- ============================================================================
-- Version: 1.0
-- Date: 2025-11-10
-- Description: Adds authentication and security tables/columns for PAACS v2.0
-- Compatibility: PostgreSQL 12+, Supabase
-- Risk Level: LOW (additive only, no data loss, reversible)
-- Estimated Runtime: <10 seconds on typical database
-- ============================================================================

BEGIN;

-- ----------------------------------------------------------------------------
-- 1) ALTER users table — add security and i18n columns
-- ----------------------------------------------------------------------------
-- These columns enable account lockout, password policies, and localization

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS failed_login_attempts INTEGER DEFAULT 0,
  ADD COLUMN IF NOT EXISTS last_failed_attempt TIMESTAMP NULL,
  ADD COLUMN IF NOT EXISTS account_locked_until TIMESTAMP NULL,
  ADD COLUMN IF NOT EXISTS last_password_change TIMESTAMP DEFAULT NOW(),
  ADD COLUMN IF NOT EXISTS must_change_password BOOLEAN DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS preferred_language VARCHAR(2) DEFAULT 'en';

-- Add constraint to ensure preferred_language is valid
ALTER TABLE users
  ADD CONSTRAINT users_preferred_language_check
  CHECK (preferred_language IN ('en', 'hi', 'te', 'ta'));

-- Add index for lockout queries (frequently checked during login)
CREATE INDEX IF NOT EXISTS users_account_locked_until_idx
  ON users (account_locked_until) WHERE account_locked_until IS NOT NULL;

-- Add index for failed login attempts (security monitoring)
CREATE INDEX IF NOT EXISTS users_failed_login_attempts_idx
  ON users (failed_login_attempts) WHERE failed_login_attempts > 0;

COMMENT ON COLUMN users.failed_login_attempts IS 'Counter for consecutive failed login attempts (resets on success)';
COMMENT ON COLUMN users.last_failed_attempt IS 'Timestamp of most recent failed login (for rate limiting)';
COMMENT ON COLUMN users.account_locked_until IS 'Account locked until this timestamp (NULL = not locked)';
COMMENT ON COLUMN users.last_password_change IS 'Timestamp of last password change (for password expiry policies)';
COMMENT ON COLUMN users.must_change_password IS 'Forces password change on next login (for first-time users or admin resets)';
COMMENT ON COLUMN users.preferred_language IS 'User interface language preference (en/hi/te/ta)';

-- ----------------------------------------------------------------------------
-- 2) CREATE user_sessions table — multi-device session tracking
-- ----------------------------------------------------------------------------
-- Enables tracking all active user sessions across devices with revocation

CREATE TABLE IF NOT EXISTS user_sessions (
  -- Primary key and session identifier
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(),
  
  -- User and restaurant context
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  restaurant_id UUID REFERENCES restaurants(id) ON DELETE CASCADE,
  
  -- Token identifiers for revocation
  access_jti VARCHAR(255),
  refresh_jti VARCHAR(255) NOT NULL UNIQUE,
  
  -- Device and network fingerprinting
  device_name VARCHAR(255),
  ip_address VARCHAR(50),
  user_agent TEXT,
  
  -- Session lifecycle timestamps
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  last_active TIMESTAMP NOT NULL DEFAULT NOW(),
  expires_at TIMESTAMP NOT NULL,
  logged_out_at TIMESTAMP NULL,
  
  -- Session state
  is_active BOOLEAN NOT NULL DEFAULT TRUE
);

-- Indexes for performance (critical for every API request)
CREATE INDEX IF NOT EXISTS user_sessions_user_id_idx ON user_sessions (user_id);
CREATE INDEX IF NOT EXISTS user_sessions_session_id_idx ON user_sessions (session_id);
CREATE INDEX IF NOT EXISTS user_sessions_is_active_idx ON user_sessions (is_active) WHERE is_active = TRUE;
CREATE INDEX IF NOT EXISTS user_sessions_expires_at_idx ON user_sessions (expires_at) WHERE is_active = TRUE;
CREATE INDEX IF NOT EXISTS user_sessions_refresh_jti_idx ON user_sessions (refresh_jti) WHERE is_active = TRUE;

-- Table comments
COMMENT ON TABLE user_sessions IS 'Tracks all active user authentication sessions across devices';
COMMENT ON COLUMN user_sessions.session_id IS 'Unique session identifier (embedded in JWT tokens)';
COMMENT ON COLUMN user_sessions.access_jti IS 'JWT ID of current access token (for single-use validation)';
COMMENT ON COLUMN user_sessions.refresh_jti IS 'JWT ID of current refresh token (rotates on each refresh)';
COMMENT ON COLUMN user_sessions.device_name IS 'User-friendly device name (e.g., "iPhone 13" or "Chrome on Windows")';
COMMENT ON COLUMN user_sessions.last_active IS 'Updated on each API request with valid token';
COMMENT ON COLUMN user_sessions.expires_at IS 'Session hard expiry (respects Remember Me duration)';
COMMENT ON COLUMN user_sessions.is_active IS 'FALSE when user logs out or session is revoked';

-- ----------------------------------------------------------------------------
-- 3) CREATE auth_activity_logs table — comprehensive audit trail
-- ----------------------------------------------------------------------------
-- Records all authentication events for security monitoring and compliance

CREATE TABLE IF NOT EXISTS auth_activity_logs (
  -- Primary key
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- User context (user_id may be NULL for failed logins)
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  restaurant_id UUID REFERENCES restaurants(id) ON DELETE SET NULL,
  email VARCHAR(254),
  
  -- Event details
  action VARCHAR(50) NOT NULL,
  success BOOLEAN NOT NULL,
  failure_reason VARCHAR(255),
  
  -- Network and device info
  ip_address VARCHAR(50),
  device_info TEXT,
  
  -- Timestamp
  timestamp TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Indexes for security dashboards and queries
CREATE INDEX IF NOT EXISTS auth_activity_logs_user_id_idx ON auth_activity_logs (user_id);
CREATE INDEX IF NOT EXISTS auth_activity_logs_timestamp_idx ON auth_activity_logs (timestamp DESC);
CREATE INDEX IF NOT EXISTS auth_activity_logs_success_idx ON auth_activity_logs (success);
CREATE INDEX IF NOT EXISTS auth_activity_logs_action_idx ON auth_activity_logs (action);
CREATE INDEX IF NOT EXISTS auth_activity_logs_email_idx ON auth_activity_logs (email);

-- Composite index for failed login monitoring
CREATE INDEX IF NOT EXISTS auth_activity_logs_failed_logins_idx 
  ON auth_activity_logs (email, timestamp DESC) 
  WHERE action = 'login_failed' AND success = FALSE;

-- Table comments
COMMENT ON TABLE auth_activity_logs IS 'Immutable audit log of all authentication events';
COMMENT ON COLUMN auth_activity_logs.action IS 'Event type: login_success, login_failed, logout, password_reset, etc.';
COMMENT ON COLUMN auth_activity_logs.success IS 'TRUE for successful operations, FALSE for failures';
COMMENT ON COLUMN auth_activity_logs.failure_reason IS 'Reason code: invalid_password, account_locked, user_not_found, etc.';

-- ----------------------------------------------------------------------------
-- 4) CREATE password_reset_tokens table — secure password recovery
-- ----------------------------------------------------------------------------
-- One-time use tokens with expiry for forgot-password flow

CREATE TABLE IF NOT EXISTS password_reset_tokens (
  -- Primary key
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- User reference
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  
  -- Token details
  token UUID NOT NULL UNIQUE DEFAULT gen_random_uuid(),
  expires_at TIMESTAMP NOT NULL,
  used BOOLEAN NOT NULL DEFAULT FALSE,
  used_at TIMESTAMP NULL,
  
  -- Timestamps
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Indexes for token lookup and cleanup
CREATE INDEX IF NOT EXISTS password_reset_tokens_token_idx ON password_reset_tokens (token) WHERE used = FALSE;
CREATE INDEX IF NOT EXISTS password_reset_tokens_user_id_idx ON password_reset_tokens (user_id);
CREATE INDEX IF NOT EXISTS password_reset_tokens_expires_at_idx ON password_reset_tokens (expires_at) WHERE used = FALSE;

-- Table comments
COMMENT ON TABLE password_reset_tokens IS 'Secure one-time tokens for password reset flow';
COMMENT ON COLUMN password_reset_tokens.token IS 'Random UUID sent via email (not the hashed password)';
COMMENT ON COLUMN password_reset_tokens.expires_at IS 'Token valid for 15 minutes from creation';
COMMENT ON COLUMN password_reset_tokens.used IS 'Prevents token reuse (set TRUE after successful reset)';

-- ----------------------------------------------------------------------------
-- 5) CREATE helper functions — session and auth utilities
-- ----------------------------------------------------------------------------

-- Function: Clean up expired sessions
CREATE OR REPLACE FUNCTION cleanup_expired_sessions()
RETURNS INTEGER AS $$
DECLARE
  deleted_count INTEGER;
BEGIN
  -- Mark expired sessions as inactive
  UPDATE user_sessions
  SET is_active = FALSE
  WHERE is_active = TRUE
    AND expires_at < NOW();
  
  GET DIAGNOSTICS deleted_count = ROW_COUNT;
  RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION cleanup_expired_sessions IS 'Marks expired sessions as inactive (run via cron job)';

-- Function: Clean up old auth logs (retention policy)
CREATE OR REPLACE FUNCTION cleanup_old_auth_logs(retention_days INTEGER DEFAULT 90)
RETURNS INTEGER AS $$
DECLARE
  deleted_count INTEGER;
BEGIN
  DELETE FROM auth_activity_logs
  WHERE timestamp < NOW() - (retention_days || ' days')::INTERVAL;
  
  GET DIAGNOSTICS deleted_count = ROW_COUNT;
  RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION cleanup_old_auth_logs IS 'Deletes auth logs older than retention period (default 90 days)';

-- Function: Clean up expired password reset tokens
CREATE OR REPLACE FUNCTION cleanup_expired_password_tokens()
RETURNS INTEGER AS $$
DECLARE
  deleted_count INTEGER;
BEGIN
  DELETE FROM password_reset_tokens
  WHERE expires_at < NOW() AND used = FALSE;
  
  GET DIAGNOSTICS deleted_count = ROW_COUNT;
  RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION cleanup_expired_password_tokens IS 'Deletes expired unused password reset tokens';

-- Function: Get active session count for user
CREATE OR REPLACE FUNCTION get_user_active_session_count(p_user_id UUID)
RETURNS INTEGER AS $$
BEGIN
  RETURN (
    SELECT COUNT(*)
    FROM user_sessions
    WHERE user_id = p_user_id
      AND is_active = TRUE
      AND expires_at > NOW()
  );
END;
$$ LANGUAGE plpgsql STABLE;

COMMENT ON FUNCTION get_user_active_session_count IS 'Returns count of active sessions for a user';

-- Function: Revoke all user sessions (used on password change, role change, etc.)
CREATE OR REPLACE FUNCTION revoke_all_user_sessions(p_user_id UUID)
RETURNS INTEGER AS $$
DECLARE
  revoked_count INTEGER;
BEGIN
  UPDATE user_sessions
  SET is_active = FALSE,
      logged_out_at = NOW()
  WHERE user_id = p_user_id
    AND is_active = TRUE;
  
  GET DIAGNOSTICS revoked_count = ROW_COUNT;
  RETURN revoked_count;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION revoke_all_user_sessions IS 'Revokes all active sessions for a user (security action)';

-- ----------------------------------------------------------------------------
-- 6) CREATE triggers — automatic session invalidation
-- ----------------------------------------------------------------------------

-- Trigger function: Revoke sessions on password change
CREATE OR REPLACE FUNCTION trigger_revoke_sessions_on_password_change()
RETURNS TRIGGER AS $$
BEGIN
  -- Only trigger if password_hash actually changed
  IF NEW.password_hash IS DISTINCT FROM OLD.password_hash THEN
    PERFORM revoke_all_user_sessions(NEW.id);
    NEW.last_password_change := NOW();
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger function: Revoke sessions on role change
CREATE OR REPLACE FUNCTION trigger_revoke_sessions_on_role_change()
RETURNS TRIGGER AS $$
BEGIN
  -- Only trigger if role actually changed
  IF NEW.role IS DISTINCT FROM OLD.role THEN
    PERFORM revoke_all_user_sessions(NEW.id);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger function: Revoke sessions on account deactivation
CREATE OR REPLACE FUNCTION trigger_revoke_sessions_on_deactivation()
RETURNS TRIGGER AS $$
BEGIN
  -- Only trigger if is_active changed from TRUE to FALSE
  IF OLD.is_active = TRUE AND NEW.is_active = FALSE THEN
    PERFORM revoke_all_user_sessions(NEW.id);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Attach triggers to users table
DROP TRIGGER IF EXISTS revoke_sessions_on_password_change ON users;
CREATE TRIGGER revoke_sessions_on_password_change
  BEFORE UPDATE ON users
  FOR EACH ROW
  EXECUTE FUNCTION trigger_revoke_sessions_on_password_change();

DROP TRIGGER IF EXISTS revoke_sessions_on_role_change ON users;
CREATE TRIGGER revoke_sessions_on_role_change
  BEFORE UPDATE ON users
  FOR EACH ROW
  EXECUTE FUNCTION trigger_revoke_sessions_on_role_change();

DROP TRIGGER IF EXISTS revoke_sessions_on_deactivation ON users;
CREATE TRIGGER revoke_sessions_on_deactivation
  BEFORE UPDATE ON users
  FOR EACH ROW
  EXECUTE FUNCTION trigger_revoke_sessions_on_deactivation();

-- ----------------------------------------------------------------------------
-- 7) Row-Level Security (RLS) Policies
-- ----------------------------------------------------------------------------
-- Note: Adjust based on your existing RLS setup. These are baseline policies.

-- Enable RLS on new tables
ALTER TABLE user_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE auth_activity_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE password_reset_tokens ENABLE ROW LEVEL SECURITY;

-- user_sessions policies
-- Users can view their own sessions
CREATE POLICY user_sessions_select_own
  ON user_sessions FOR SELECT
  USING (auth.uid() = user_id);

-- Users can update (revoke) their own sessions
CREATE POLICY user_sessions_update_own
  ON user_sessions FOR UPDATE
  USING (auth.uid() = user_id);

-- Service role (backend) can do everything
CREATE POLICY user_sessions_service_role
  ON user_sessions FOR ALL
  USING (auth.role() = 'service_role');

-- Managers can view sessions for their restaurant
CREATE POLICY user_sessions_manager_view
  ON user_sessions FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
        AND users.role IN ('manager', 'owner', 'superadmin')
        AND users.restaurant_id = user_sessions.restaurant_id
    )
  );

-- auth_activity_logs policies
-- Users can view their own activity logs
CREATE POLICY auth_activity_logs_select_own
  ON auth_activity_logs FOR SELECT
  USING (auth.uid() = user_id);

-- Service role can insert logs
CREATE POLICY auth_activity_logs_insert_service
  ON auth_activity_logs FOR INSERT
  WITH CHECK (auth.role() = 'service_role');

-- Managers/SuperAdmins can view logs for their restaurant
CREATE POLICY auth_activity_logs_manager_view
  ON auth_activity_logs FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
        AND users.role IN ('manager', 'owner', 'superadmin')
        AND users.restaurant_id = auth_activity_logs.restaurant_id
    )
  );

-- password_reset_tokens policies
-- Service role only (no direct user access)
CREATE POLICY password_reset_tokens_service_role
  ON password_reset_tokens FOR ALL
  USING (auth.role() = 'service_role');

-- ----------------------------------------------------------------------------
-- 8) Create maintenance jobs (PostgreSQL cron if available)
-- ----------------------------------------------------------------------------
-- Note: Requires pg_cron extension. If not available, run via external cron.

-- Clean expired sessions daily at 2 AM
-- Uncomment if pg_cron is installed:
/*
SELECT cron.schedule(
  'cleanup-expired-sessions',
  '0 2 * * *', -- Daily at 2:00 AM
  $$ SELECT cleanup_expired_sessions(); $$
);

-- Clean old auth logs monthly
SELECT cron.schedule(
  'cleanup-old-auth-logs',
  '0 3 1 * *', -- 1st of month at 3:00 AM
  $$ SELECT cleanup_old_auth_logs(90); $$
);

-- Clean expired password reset tokens hourly
SELECT cron.schedule(
  'cleanup-expired-password-tokens',
  '0 * * * *', -- Every hour
  $$ SELECT cleanup_expired_password_tokens(); $$
);
*/

-- ----------------------------------------------------------------------------
-- 9) Insert initial data / migrations
-- ----------------------------------------------------------------------------

-- Update existing users to have default values
UPDATE users
SET 
  failed_login_attempts = 0,
  last_password_change = COALESCE(last_password_change, created_at, NOW()),
  must_change_password = FALSE,
  preferred_language = 'en'
WHERE failed_login_attempts IS NULL;

-- ----------------------------------------------------------------------------
-- 10) Verification queries
-- ----------------------------------------------------------------------------

-- Verify all columns added
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'failed_login_attempts'
  ) THEN
    RAISE EXCEPTION 'Migration failed: users.failed_login_attempts not created';
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_name = 'user_sessions'
  ) THEN
    RAISE EXCEPTION 'Migration failed: user_sessions table not created';
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_name = 'auth_activity_logs'
  ) THEN
    RAISE EXCEPTION 'Migration failed: auth_activity_logs table not created';
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_name = 'password_reset_tokens'
  ) THEN
    RAISE EXCEPTION 'Migration failed: password_reset_tokens table not created';
  END IF;
  
  RAISE NOTICE 'Migration verification passed: all objects created successfully';
END $$;

COMMIT;

-- ============================================================================
-- Migration complete! Run verification query:
-- SELECT * FROM information_schema.columns WHERE table_name IN ('users', 'user_sessions', 'auth_activity_logs', 'password_reset_tokens');
-- ============================================================================
