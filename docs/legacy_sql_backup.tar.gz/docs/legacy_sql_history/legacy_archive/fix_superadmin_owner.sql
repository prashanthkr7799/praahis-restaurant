-- =========================================================================
-- FIX: Set SuperAdmin User as Owner
-- =========================================================================
-- This script marks your superadmin user as owner so they can create restaurants
-- Replace 'your-superadmin-email@example.com' with your actual superadmin email
-- =========================================================================

-- Option 1: Set by email (recommended)
UPDATE public.users 
SET is_owner = TRUE, 
    role = 'owner'
WHERE email = 'your-superadmin-email@example.com';

-- Option 2: Set by user ID (if you know the UUID)
-- UPDATE public.users 
-- SET is_owner = TRUE, 
--     role = 'owner'
-- WHERE id = 'your-user-uuid-here';

-- Option 3: Set the first user as owner (use with caution)
-- UPDATE public.users 
-- SET is_owner = TRUE, 
--     role = 'owner'
-- WHERE id = (SELECT id FROM public.users ORDER BY created_at LIMIT 1);

-- Verify the change
SELECT id, email, role, is_owner, is_active 
FROM public.users 
WHERE is_owner = TRUE OR role = 'owner';

-- =========================================================================
