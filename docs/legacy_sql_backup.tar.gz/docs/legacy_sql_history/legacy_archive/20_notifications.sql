-- =============================================
-- Notifications Table & RLS
-- =============================================
-- Purpose: Store app notifications for managers, staff, and owners
-- Events: order updates, payment confirmations, system alerts, staff actions
-- =============================================

-- Drop existing if rerunning
drop table if exists public.notifications cascade;

-- Create notifications table
create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  restaurant_id uuid references public.restaurants(id) on delete cascade,
  user_id uuid references public.users(id) on delete cascade,
  type text check (type in ('order','payment','system','staff','alert')) default 'system',
  title text not null,
  body text,
  data jsonb default '{}'::jsonb, -- extra metadata for links/actions
  is_read boolean default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Enable RLS
alter table public.notifications enable row level security;

-- Indexes for performance
create index if not exists idx_notifications_restaurant_created 
  on public.notifications (restaurant_id, created_at desc);
create index if not exists idx_notifications_user_created 
  on public.notifications (user_id, created_at desc);
create index if not exists idx_notifications_unread 
  on public.notifications (restaurant_id, is_read, created_at desc);

-- =============================================
-- RLS Policies
-- =============================================

-- SELECT: Read notifications for own restaurant or user
create policy notifications_select on public.notifications
  for select using (
    -- Owner can read all
    public.is_owner()
    or
    -- Manager/staff can read their restaurant's or their own notifications
    exists (
      select 1 from public.users u
      where u.id = auth.uid()
        and (
          notifications.user_id = u.id
          or notifications.restaurant_id = u.restaurant_id
        )
    )
  );

-- INSERT: Only managers/admins can create notifications for their restaurant
create policy notifications_insert on public.notifications
  for insert with check (
    public.is_owner()
    or
    exists (
      select 1 from public.users u
      where u.id = auth.uid()
        and lower(u.role) in ('admin','manager')
        and notifications.restaurant_id = u.restaurant_id
    )
  );

-- UPDATE: Can mark own/restaurant notifications as read
create policy notifications_update on public.notifications
  for update using (
    public.is_owner()
    or
    exists (
      select 1 from public.users u
      where u.id = auth.uid()
        and (
          notifications.user_id = u.id
          or (
            lower(u.role) in ('admin','manager')
            and notifications.restaurant_id = u.restaurant_id
          )
        )
    )
  );

-- DELETE: Only owner or the notification creator can delete
create policy notifications_delete on public.notifications
  for delete using (
    public.is_owner()
  );

-- =============================================
-- Trigger: Update updated_at timestamp
-- =============================================
create or replace function public.update_notifications_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trigger_notifications_updated_at on public.notifications;
create trigger trigger_notifications_updated_at
  before update on public.notifications
  for each row
  execute function public.update_notifications_updated_at();

-- =============================================
-- Helper function: Create notification
-- =============================================
-- Usage: select create_notification('order', 'New Order', 'Table 3 ordered 2 items', '{"order_id": "123"}', restaurant_id, user_id);
create or replace function public.create_notification(
  p_type text,
  p_title text,
  p_body text default null,
  p_data jsonb default '{}'::jsonb,
  p_restaurant_id uuid default null,
  p_user_id uuid default null
) returns uuid as $$
declare
  v_notification_id uuid;
begin
  insert into public.notifications (type, title, body, data, restaurant_id, user_id)
  values (p_type, p_title, p_body, p_data, p_restaurant_id, p_user_id)
  returning id into v_notification_id;
  
  return v_notification_id;
end;
$$ language plpgsql security definer;

-- Grant execute to authenticated users
grant execute on function public.create_notification to authenticated;

-- =============================================
-- Enable Realtime for Notifications
-- =============================================
-- This allows frontend to subscribe to INSERT events in realtime

-- Enable realtime for the notifications table
alter publication supabase_realtime add table public.notifications;

-- Success
do $$
begin
  raise notice 'Notifications table, RLS policies, helper functions, and realtime enabled successfully.';
end $$;
