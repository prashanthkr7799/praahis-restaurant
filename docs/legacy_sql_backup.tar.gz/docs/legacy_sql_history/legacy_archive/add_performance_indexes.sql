-- Performance optimization: Add missing indexes for faster queries

-- Step 1: Check existing indexes on users table
SELECT 
  indexname,
  indexdef
FROM pg_indexes
WHERE tablename = 'users'
  AND schemaname = 'public'
ORDER BY indexname;

-- Step 2: Check existing indexes on restaurants table
SELECT 
  indexname,
  indexdef
FROM pg_indexes
WHERE tablename = 'restaurants'
  AND schemaname = 'public'
ORDER BY indexname;

-- Step 3: Add missing indexes for common queries
-- Index on users.restaurant_id (for filtering staff by restaurant)
CREATE INDEX IF NOT EXISTS idx_users_restaurant_id 
ON public.users(restaurant_id) 
WHERE restaurant_id IS NOT NULL;

-- Index on users.email (for login lookups)
CREATE INDEX IF NOT EXISTS idx_users_email_lower 
ON public.users(LOWER(email));

-- Index on users.role (for filtering by role)
CREATE INDEX IF NOT EXISTS idx_users_role 
ON public.users(role) 
WHERE role IS NOT NULL;

-- Index on users.is_active (for filtering active users)
CREATE INDEX IF NOT EXISTS idx_users_is_active 
ON public.users(is_active) 
WHERE is_active = true;

-- Composite index for common query: active users in a restaurant
CREATE INDEX IF NOT EXISTS idx_users_restaurant_active 
ON public.users(restaurant_id, is_active, role) 
WHERE restaurant_id IS NOT NULL AND is_active = true;

-- Index on restaurants.slug (for slug lookups)
CREATE INDEX IF NOT EXISTS idx_restaurants_slug_lower 
ON public.restaurants(LOWER(slug));

-- Index on restaurants.is_active
CREATE INDEX IF NOT EXISTS idx_restaurants_is_active 
ON public.restaurants(is_active) 
WHERE is_active = true;

-- Step 4: Verify all indexes were created
SELECT 
  schemaname,
  tablename,
  indexname,
  indexdef,
  '✅ Index created' as status
FROM pg_indexes
WHERE tablename IN ('users', 'restaurants')
  AND schemaname = 'public'
  AND indexname LIKE 'idx_%'
ORDER BY tablename, indexname;

-- Step 5: Analyze tables to update statistics for query planner
ANALYZE public.users;
ANALYZE public.restaurants;

SELECT '✅ Tables analyzed - query planner statistics updated' as status;
