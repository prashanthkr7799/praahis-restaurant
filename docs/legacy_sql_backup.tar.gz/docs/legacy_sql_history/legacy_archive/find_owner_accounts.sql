-- Find all owner/superadmin accounts (checking actual columns)

-- Step 1: Check users table structure
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'users' 
  AND table_schema = 'public'
ORDER BY ordinal_position;

-- Step 2: Check for owner accounts (is_owner = true)
SELECT 
  id,
  email,
  full_name,
  role,
  restaurant_id,
  is_owner,
  is_active,
  created_at,
  '✅ Owner user' as type
FROM public.users
WHERE is_owner = true
ORDER BY created_at;

-- Step 3: Check all users with no restaurant_id (potential platform owners)
SELECT 
  id,
  email,
  full_name,
  role,
  restaurant_id,
  is_owner,
  is_active,
  '⚠️ No restaurant (potential platform admin)' as type
FROM public.users
WHERE restaurant_id IS NULL
ORDER BY created_at;

-- Step 4: Show ALL users to help identify accounts
SELECT 
  id,
  email,
  full_name,
  role,
  restaurant_id,
  is_owner,
  is_active,
  created_at
FROM public.users
ORDER BY created_at;

-- Step 5: Check if there are any auth.users that don't have public.users profiles
SELECT 
  au.id,
  au.email,
  au.created_at as auth_created,
  CASE 
    WHEN pu.id IS NOT NULL THEN '✅ Has profile'
    ELSE '❌ Orphaned - no profile'
  END as status
FROM auth.users au
LEFT JOIN public.users pu ON au.id = pu.id
ORDER BY au.created_at;
