-- Debug restaurant context mismatch for manager login

-- Step 1: Check restaurants table structure first
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'restaurants' 
  AND table_schema = 'public'
ORDER BY ordinal_position;

-- Step 1b: Show all restaurants
SELECT 
  id,
  name,
  slug,
  is_active,
  created_at,
  '🏪 Restaurant' as type
FROM restaurants
ORDER BY created_at DESC;

-- Step 2: Show the newly created manager
SELECT 
  u.id,
  u.email,
  u.full_name,
  u.role,
  u.restaurant_id,
  r.name as restaurant_name,
  r.slug as restaurant_slug,
  u.is_active,
  u.created_at,
  '👤 Manager Account' as type
FROM public.users u
LEFT JOIN restaurants r ON u.restaurant_id = r.id
WHERE u.role = 'manager'
ORDER BY u.created_at DESC
LIMIT 5;

-- Step 3: Check if restaurant_id matches a valid restaurant
SELECT 
  u.email,
  u.full_name,
  u.role,
  u.restaurant_id as user_restaurant_id,
  r.id as actual_restaurant_id,
  r.name as restaurant_name,
  r.slug as restaurant_slug,
  CASE 
    WHEN u.restaurant_id = r.id THEN '✅ Restaurant ID matches'
    WHEN r.id IS NULL THEN '❌ Restaurant does not exist!'
    ELSE '❌ Mismatch'
  END as status
FROM public.users u
LEFT JOIN restaurants r ON u.restaurant_id = r.id
WHERE u.role = 'manager'
ORDER BY u.created_at DESC
LIMIT 5;

-- Step 4: Show what's stored in localStorage (you'll need to check this in browser console)
-- Run this in your browser console after logging in:
-- console.log('Restaurant Context:', localStorage.getItem('praahis_restaurant_ctx'));
-- console.log('Manager Session:', localStorage.getItem('sb-manager-session'));
