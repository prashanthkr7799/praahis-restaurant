-- ============================================================================
-- FIX: "Invalid Refresh Token" Error When Staff Tries to Login
-- ============================================================================
-- After creating staff (chef/waiter), they get 400/406 errors when logging in
-- Root cause: Email not confirmed in auth.users table
-- ============================================================================

-- ============================================================================
-- STEP 1: Check if auto-confirm trigger exists
-- ============================================================================

SELECT '=== STEP 1: Check Auto-Confirm Trigger ===' as info;

SELECT 
    trigger_name,
    event_object_table,
    action_timing,
    event_manipulation,
    CASE 
        WHEN trigger_name = 'auto_confirm_user_trigger' THEN '✅ Trigger exists'
        ELSE '⚠️ Other trigger'
    END as status
FROM information_schema.triggers
WHERE trigger_name = 'auto_confirm_user_trigger';

-- If NO ROWS returned, trigger is missing!

-- ============================================================================
-- STEP 2: Check unconfirmed users in auth.users
-- ============================================================================

SELECT '=== STEP 2: Check Unconfirmed Users ===' as info;

SELECT 
    id,
    email,
    email_confirmed_at,
    created_at,
    CASE 
        WHEN email_confirmed_at IS NULL THEN '❌ NOT CONFIRMED'
        ELSE '✅ CONFIRMED'
    END as status
FROM auth.users
WHERE email_confirmed_at IS NULL
OR created_at > NOW() - INTERVAL '1 hour';  -- Recent users

-- ============================================================================
-- STEP 3: Create/Recreate auto-confirm trigger (if missing)
-- ============================================================================

SELECT '=== STEP 3: Creating Auto-Confirm Trigger ===' as info;

-- Create the function
CREATE OR REPLACE FUNCTION public.auto_confirm_user()
RETURNS TRIGGER AS $$
BEGIN
  -- Auto-confirm email for new users
  NEW.email_confirmed_at := NOW();
  NEW.confirmation_token := '';
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create the trigger (runs BEFORE insert on auth.users)
DROP TRIGGER IF EXISTS auto_confirm_user_trigger ON auth.users;
CREATE TRIGGER auto_confirm_user_trigger
  BEFORE INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.auto_confirm_user();

SELECT '✅ Auto-confirm trigger created' as status;

-- ============================================================================
-- STEP 4: CONFIRM ALL EXISTING UNCONFIRMED USERS
-- ============================================================================

SELECT '=== STEP 4: Confirming Existing Users ===' as info;

-- This will fix any users created before the trigger was active
UPDATE auth.users 
SET 
    email_confirmed_at = COALESCE(email_confirmed_at, NOW()),
    confirmation_token = '',
    confirmation_sent_at = NULL
WHERE email_confirmed_at IS NULL;

-- Show how many were updated
SELECT '✅ Confirmed ' || COUNT(*) || ' unconfirmed users' as result
FROM auth.users
WHERE email_confirmed_at IS NOT NULL;

-- ============================================================================
-- STEP 5: Verify the fix
-- ============================================================================

SELECT '=== STEP 5: Verification ===' as info;

-- Check all recent users are confirmed
SELECT 
    id,
    email,
    email_confirmed_at,
    created_at,
    CASE 
        WHEN email_confirmed_at IS NOT NULL THEN '✅ Can login'
        ELSE '❌ Cannot login'
    END as login_status
FROM auth.users
WHERE created_at > NOW() - INTERVAL '1 hour'
ORDER BY created_at DESC;

-- ============================================================================
-- STEP 6: Check public.users profiles match
-- ============================================================================

SELECT '=== STEP 6: Check Profile Sync ===' as info;

-- Verify all auth users have profiles in public.users
SELECT 
    au.id,
    au.email,
    au.email_confirmed_at,
    pu.role,
    pu.restaurant_id,
    pu.is_active,
    CASE 
        WHEN pu.id IS NULL THEN '❌ Profile missing'
        WHEN au.email_confirmed_at IS NULL THEN '❌ Email not confirmed'
        WHEN pu.is_active = false THEN '⚠️ Inactive'
        ELSE '✅ Ready'
    END as status
FROM auth.users au
LEFT JOIN public.users pu ON au.id = pu.id
WHERE au.created_at > NOW() - INTERVAL '1 hour'
ORDER BY au.created_at DESC;

-- ============================================================================
-- ROOT CAUSE EXPLANATION
-- ============================================================================

/*

WHY "Invalid Refresh Token" ERROR OCCURS:

1. Manager creates new chef/waiter via StaffForm
2. supabase.auth.admin.createUser() creates user in auth.users
3. BUT: email_confirmed_at is NULL by default
4. User is created in public.users with role, restaurant_id
5. Chef/Waiter tries to login with email/password
6. Supabase Auth checks: email_confirmed_at IS NULL
7. Auth rejects login → 400 error "Invalid Refresh Token"
8. Frontend shows: "Failed to load resource: the server responded with a status of 400"

THE FIX:

1. Create auto-confirm trigger on auth.users (BEFORE INSERT)
2. Trigger sets: email_confirmed_at = NOW(), confirmation_token = ''
3. Confirm all existing unconfirmed users
4. Future staff users will auto-confirm on creation

RESULT:
- New staff can login immediately after creation
- No email confirmation required
- No refresh token errors

*/

-- ============================================================================
-- ADDITIONAL CHECK: Supabase Auth Settings
-- ============================================================================

SELECT '=== CHECK: Auth Settings ===' as info;

-- Note: These settings are in Supabase Dashboard > Authentication > Settings
-- For reference only (can't query directly from SQL)

/*
RECOMMENDED SETTINGS:

1. Email Confirmation Required: DISABLE
   (Or keep the auto-confirm trigger active)

2. Secure Email Change: ENABLE
   (Security feature for existing users changing email)

3. Email Template: Can stay default
   (Not used when auto-confirm is active)

To check in Dashboard:
1. Go to: https://supabase.com/dashboard/project/YOUR_PROJECT/auth/users
2. Settings > Auth Settings
3. Verify: Enable email confirmations = UNCHECKED
   OR: Auto-confirm trigger is active (this script)
*/

-- ============================================================================
-- SUMMARY
-- ============================================================================
-- ✅ Created/verified auto-confirm trigger
-- ✅ Confirmed all existing unconfirmed users
-- ✅ Future staff will auto-confirm on creation
-- ✅ Staff can now login immediately
-- 
-- NEXT STEPS:
-- 1. Run this script in Supabase SQL Editor
-- 2. Check output: All users should show "✅ Can login"
-- 3. Try logging in as the chef/waiter you just created
-- 4. Should work without refresh token errors! ✅
-- ============================================================================
