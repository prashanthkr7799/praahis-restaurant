-- ============================================================================
-- CLEAN DATABASE SETUP - FUNCTIONS & PROCEDURES
-- ============================================================================
-- Generated: 2025-11-18 13:10:11
-- Description: Database functions, stored procedures, and business logic
-- ============================================================================

-- ============================================================================
-- UTILITY FUNCTIONS
-- ============================================================================

-- Function: Update updated_at timestamp automatically
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION update_updated_at_column() IS 'Auto-update updated_at timestamp on row update';

-- Function: Generate unique order number
CREATE OR REPLACE FUNCTION generate_order_number()
RETURNS VARCHAR AS $$
DECLARE
    today_date TEXT;
    order_count INTEGER;
    new_order_number VARCHAR;
BEGIN
    today_date := TO_CHAR(NOW(), 'YYYYMMDD');
    
    SELECT COUNT(*) INTO order_count
    FROM orders
    WHERE order_number LIKE 'ORD-' || today_date || '-%';
    
    new_order_number := 'ORD-' || today_date || '-' || LPAD((order_count + 1)::TEXT, 4, '0');
    
    RETURN new_order_number;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION generate_order_number() IS 'Generate unique order number: ORD-YYYYMMDD-0001';

-- ============================================================================
-- USER & AUTHENTICATION FUNCTIONS
-- ============================================================================

-- Function: Check if user is owner/superadmin
CREATE OR REPLACE FUNCTION is_owner()
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM users
        WHERE id = auth.uid()
        AND (is_owner = true OR is_superadmin = true)
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

COMMENT ON FUNCTION is_owner() IS 'Check if authenticated user is platform owner/superadmin';

-- Function: Get user's restaurant ID
CREATE OR REPLACE FUNCTION get_user_restaurant_id()
RETURNS UUID AS $$
DECLARE
    restaurant_id UUID;
BEGIN
    SELECT u.restaurant_id INTO restaurant_id
    FROM users u
    WHERE u.id = auth.uid();
    
    RETURN restaurant_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

COMMENT ON FUNCTION get_user_restaurant_id() IS 'Get authenticated user restaurant ID';

-- ============================================================================
-- NOTIFICATION FUNCTIONS
-- ============================================================================

-- Function: Create notification
CREATE OR REPLACE FUNCTION create_notification(
    p_type TEXT,
    p_title TEXT,
    p_body TEXT DEFAULT NULL,
    p_data JSONB DEFAULT '{}',
    p_restaurant_id UUID DEFAULT NULL,
    p_user_id UUID DEFAULT NULL
) RETURNS UUID AS $$
DECLARE
    v_notification_id UUID;
BEGIN
    INSERT INTO notifications (type, title, body, data, restaurant_id, user_id)
    VALUES (p_type, p_title, p_body, p_data, p_restaurant_id, p_user_id)
    RETURNING id INTO v_notification_id;
    
    RETURN v_notification_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION create_notification IS 'Create a new notification';

-- ============================================================================
-- BILLING FUNCTIONS
-- ============================================================================

-- Function: Calculate monthly billing amount
CREATE OR REPLACE FUNCTION calculate_billing_amount(
    p_table_count INTEGER,
    p_rate_per_table DECIMAL DEFAULT 100.00,
    p_days_in_month INTEGER DEFAULT 30
)
RETURNS DECIMAL AS $$
BEGIN
    RETURN p_table_count * p_rate_per_table * p_days_in_month;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

COMMENT ON FUNCTION calculate_billing_amount IS 'Calculate billing: table_count × rate × days';

-- Function: Generate monthly bills for all restaurants
CREATE OR REPLACE FUNCTION generate_monthly_bills(
    p_billing_month INTEGER DEFAULT EXTRACT(MONTH FROM CURRENT_DATE)::INTEGER,
    p_billing_year INTEGER DEFAULT EXTRACT(YEAR FROM CURRENT_DATE)::INTEGER
)
RETURNS TABLE(
    restaurant_id UUID,
    restaurant_name TEXT,
    table_count BIGINT,
    amount DECIMAL,
    status TEXT
) AS $$
DECLARE
    v_billing_period DATE;
    v_days_in_month INTEGER;
    v_due_date DATE;
    v_grace_end_date DATE;
    v_rate DECIMAL := 100.00;
    v_grace_days INTEGER := 3;
BEGIN
    v_billing_period := make_date(p_billing_year, p_billing_month, 1);
    v_days_in_month := EXTRACT(DAY FROM (v_billing_period + INTERVAL '1 month' - INTERVAL '1 day'))::INTEGER;
    v_due_date := v_billing_period + INTERVAL '1 month';
    v_grace_end_date := v_due_date + (v_grace_days || ' days')::INTERVAL;
    
    RETURN QUERY
    INSERT INTO billing (
        restaurant_id, billing_month, billing_year, billing_period,
        table_count, rate_per_table_per_day, days_in_month,
        base_amount, total_amount, status,
        due_date, grace_period_days, grace_end_date
    )
    SELECT 
        r.id, p_billing_month, p_billing_year, v_billing_period,
        COUNT(t.id)::INTEGER AS tables, v_rate, v_days_in_month,
        calculate_billing_amount(COUNT(t.id)::INTEGER, v_rate, v_days_in_month),
        calculate_billing_amount(COUNT(t.id)::INTEGER, v_rate, v_days_in_month),
        'pending', v_due_date, v_grace_days, v_grace_end_date
    FROM restaurants r
    LEFT JOIN tables t ON t.restaurant_id = r.id AND t.is_active = true
    WHERE r.is_active = true
    GROUP BY r.id
    ON CONFLICT (restaurant_id, billing_year, billing_month) DO NOTHING
    RETURNING 
        billing.restaurant_id,
        (SELECT name FROM restaurants WHERE id = billing.restaurant_id),
        billing.table_count,
        billing.total_amount,
        'Bill generated'::TEXT;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION generate_monthly_bills IS 'Auto-generate monthly bills for all active restaurants';

-- Function: Mark bill as paid
CREATE OR REPLACE FUNCTION mark_bill_as_paid(
    p_billing_id UUID,
    p_payment_method VARCHAR DEFAULT 'manual',
    p_transaction_id VARCHAR DEFAULT NULL,
    p_verified_by UUID DEFAULT NULL
)
RETURNS JSONB AS $$
DECLARE
    v_billing RECORD;
    v_payment_id UUID;
    v_result JSONB;
BEGIN
    SELECT * INTO v_billing FROM billing WHERE id = p_billing_id;
    
    IF NOT FOUND THEN
        RETURN jsonb_build_object('success', false, 'error', 'Billing record not found');
    END IF;
    
    INSERT INTO payments (
        billing_id, restaurant_id, amount, payment_method,
        payment_status, transaction_id, payment_date, verified_by
    ) VALUES (
        p_billing_id, v_billing.restaurant_id, v_billing.total_amount,
        p_payment_method, 'completed', p_transaction_id, NOW(), p_verified_by
    ) RETURNING id INTO v_payment_id;
    
    UPDATE billing 
    SET status = 'paid', paid_at = NOW(), reactivated_at = NOW(), updated_at = NOW()
    WHERE id = p_billing_id;
    
    UPDATE restaurants 
    SET is_active = true, updated_at = NOW()
    WHERE id = v_billing.restaurant_id AND is_active = false;
    
    RETURN jsonb_build_object(
        'success', true,
        'billing_id', p_billing_id,
        'payment_id', v_payment_id,
        'restaurant_id', v_billing.restaurant_id,
        'amount', v_billing.total_amount
    );
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION mark_bill_as_paid IS 'Mark bill as paid and reactivate restaurant';

-- ============================================================================
-- PLATFORM STATS FUNCTIONS
-- ============================================================================

-- Function: Get platform statistics
CREATE OR REPLACE FUNCTION get_platform_stats()
RETURNS JSONB AS $$
DECLARE
    stats JSONB;
BEGIN
    SELECT jsonb_build_object(
        'total_restaurants', (SELECT COUNT(*) FROM restaurants),
        'active_restaurants', (SELECT COUNT(*) FROM restaurants WHERE is_active = true),
        'total_users', (SELECT COUNT(*) FROM users),
        'total_orders', (SELECT COUNT(*) FROM orders),
        'total_revenue', (SELECT COALESCE(SUM(total), 0) FROM orders WHERE payment_status = 'paid'),
        'active_subscriptions', (SELECT COUNT(*) FROM subscriptions WHERE status = 'active')
    ) INTO stats;
    
    RETURN stats;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION get_platform_stats() IS 'Get platform-wide statistics (owner only)';

-- Function: Calculate MRR (Monthly Recurring Revenue)
CREATE OR REPLACE FUNCTION calculate_mrr()
RETURNS DECIMAL AS $$
DECLARE
    mrr DECIMAL;
BEGIN
    SELECT COALESCE(SUM(
        CASE 
            WHEN billing_cycle = 'monthly' THEN price
            WHEN billing_cycle = 'yearly' THEN price / 12
            ELSE 0
        END
    ), 0)
    INTO mrr
    FROM subscriptions
    WHERE status = 'active';
    
    RETURN mrr;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION calculate_mrr() IS 'Calculate Monthly Recurring Revenue';

-- ============================================================================
-- FUNCTIONS CREATED
-- ============================================================================

SELECT 'All functions created successfully!' AS status;
