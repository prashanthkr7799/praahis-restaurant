-- ============================================================================
-- FIX BILLING & PAYMENTS RLS POLICIES - AVOID INFINITE RECURSION
-- ============================================================================
-- This fixes both "permission denied" AND "infinite recursion" errors
-- Solution: Create helper functions with SECURITY DEFINER to safely check admin status
-- ============================================================================

-- ============================================================================
-- HELPER FUNCTION: Check if user is superadmin (with SECURITY DEFINER)
-- ============================================================================

CREATE OR REPLACE FUNCTION is_superadmin(user_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM platform_admins
        WHERE platform_admins.user_id = is_superadmin.user_id
        AND role = 'superadmin'
        AND is_active = true
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

COMMENT ON FUNCTION is_superadmin IS 'Check if user is an active superadmin (bypasses RLS with SECURITY DEFINER)';

-- ============================================================================
-- BILLING TABLE - UPDATE SUPERADMIN POLICY
-- ============================================================================

DROP POLICY IF EXISTS "Superadmin full access to billing" ON billing;

CREATE POLICY "Superadmin full access to billing" ON billing
    FOR ALL 
    USING (
        -- Use helper function that bypasses RLS recursion
        is_superadmin(auth.uid())
    );

-- ============================================================================
-- PAYMENTS TABLE - UPDATE SUPERADMIN POLICY  
-- ============================================================================

DROP POLICY IF EXISTS "Superadmin full access to payments" ON payments;

CREATE POLICY "Superadmin full access to payments" ON payments
    FOR ALL 
    USING (
        -- Use helper function that bypasses RLS recursion
        is_superadmin(auth.uid())
    );

-- ============================================================================
-- VERIFICATION
-- ============================================================================

/*
-- 1. Test the helper function
SELECT is_superadmin(auth.uid());
-- Should return true if you're logged in as superadmin

-- 2. Verify policies exist
SELECT schemaname, tablename, policyname 
FROM pg_policies 
WHERE tablename IN ('billing', 'payments')
AND policyname LIKE '%Superadmin%'
ORDER BY tablename, policyname;

-- 3. Test as superadmin (should work without recursion errors)
SELECT COUNT(*) FROM billing;
SELECT COUNT(*) FROM payments;

-- 4. Export queries that should now work:
SELECT * FROM billing LIMIT 10;
SELECT * FROM payments LIMIT 10;

-- 5. Test with join (should work)
SELECT r.name, b.* 
FROM billing b 
JOIN restaurants r ON b.restaurant_id = r.id 
LIMIT 10;
*/
