-- =========================================================================
-- AUTO-CONFIRM NEW USERS TRIGGER
-- =========================================================================
-- This trigger automatically confirms emails for new auth users
-- So managers can login immediately after being created
-- =========================================================================

-- Create the function
CREATE OR REPLACE FUNCTION public.auto_confirm_user()
RETURNS TRIGGER AS $$
BEGIN
  -- Auto-confirm email for new users
  NEW.email_confirmed_at := NOW();
  NEW.confirmation_token := '';
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create the trigger (runs BEFORE insert on auth.users)
DROP TRIGGER IF EXISTS auto_confirm_user_trigger ON auth.users;
CREATE TRIGGER auto_confirm_user_trigger
  BEFORE INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.auto_confirm_user();

-- Verify the trigger was created
SELECT 
    trigger_name,
    event_object_table,
    action_statement,
    action_timing
FROM information_schema.triggers
WHERE trigger_name = 'auto_confirm_user_trigger';

-- Also confirm any existing unconfirmed users
UPDATE auth.users 
SET email_confirmed_at = COALESCE(email_confirmed_at, NOW()),
    confirmation_token = ''
WHERE email_confirmed_at IS NULL;

-- =========================================================================
-- SUCCESS! New users will be automatically confirmed.
-- You can now create managers and they can login immediately!
-- =========================================================================
