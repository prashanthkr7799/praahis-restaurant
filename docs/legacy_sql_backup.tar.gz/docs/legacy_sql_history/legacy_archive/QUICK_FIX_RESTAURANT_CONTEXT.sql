-- Quick Fix: Restaurant Context Issues
-- Run this if you're getting "Restaurant context is missing" errors

-- 1. Check which users don't have restaurant_id assigned
SELECT 
  id,
  email,
  full_name,
  role,
  restaurant_id,
  is_active
FROM users
WHERE restaurant_id IS NULL
  AND role IN ('manager', 'chef', 'waiter', 'admin')
ORDER BY created_at DESC;

-- 2. Assign restaurant_id to users who need it
-- OPTION A: If you have one test restaurant, assign all staff to it
-- UPDATE users
-- SET restaurant_id = (SELECT id FROM restaurants LIMIT 1)
-- WHERE restaurant_id IS NULL
--   AND role IN ('manager', 'chef', 'waiter', 'admin');

-- OPTION B: Assign specific user to specific restaurant
-- UPDATE users
-- SET restaurant_id = 'YOUR_RESTAURANT_UUID_HERE'
-- WHERE email = 'manager@example.com';

-- 3. Verify the fix
SELECT 
  u.email,
  u.role,
  u.restaurant_id,
  r.name as restaurant_name
FROM users u
LEFT JOIN restaurants r ON u.restaurant_id = r.id
WHERE u.role IN ('manager', 'chef', 'waiter', 'admin')
ORDER BY u.created_at DESC;

-- 4. Check if auth_activity_logs table exists (for SuperAdmin login)
SELECT EXISTS (
  SELECT FROM information_schema.tables 
  WHERE table_schema = 'public' 
  AND table_name = 'auth_activity_logs'
) as table_exists;

-- 5. If auth_activity_logs doesn't exist, check which SQL file creates it
-- It should be in: database/71_security_audit_logging.sql
-- Run that migration if the table doesn't exist
