-- ============================================================================
-- COMPLETE DATABASE RESET - START FROM SCRATCH
-- ============================================================================
-- WARNING: This will DELETE ALL DATA and TABLES!
-- Use this if you want to start completely fresh with the new SQL files
-- ============================================================================

-- 1. Drop all existing tables (in correct order to handle foreign keys)
DROP TABLE IF EXISTS feedbacks CASCADE;
DROP TABLE IF EXISTS payments CASCADE;
DROP TABLE IF EXISTS orders CASCADE;
DROP TABLE IF EXISTS menu_items CASCADE;
DROP TABLE IF EXISTS tables CASCADE;
DROP TABLE IF EXISTS users CASCADE;
DROP TABLE IF EXISTS restaurants CASCADE;

-- 2. Drop all functions
DROP FUNCTION IF EXISTS update_updated_at_column() CASCADE;
DROP FUNCTION IF EXISTS generate_order_number() CASCADE;

-- 3. Remove from realtime publication (if exists)
DO $$
BEGIN
    ALTER PUBLICATION supabase_realtime DROP TABLE orders;
EXCEPTION
    WHEN OTHERS THEN NULL;
END $$;

DO $$
BEGIN
    ALTER PUBLICATION supabase_realtime DROP TABLE tables;
EXCEPTION
    WHEN OTHERS THEN NULL;
END $$;

DO $$
BEGIN
    ALTER PUBLICATION supabase_realtime DROP TABLE menu_items;
EXCEPTION
    WHEN OTHERS THEN NULL;
END $$;

DO $$
BEGIN
    ALTER PUBLICATION supabase_realtime DROP TABLE payments;
EXCEPTION
    WHEN OTHERS THEN NULL;
END $$;

-- ============================================================================
-- DATABASE COMPLETELY CLEARED
-- ============================================================================
-- Now run the clean scripts in order:
-- 1. 01_schema.sql
-- 2. 02_seed.sql
-- 3. 03_enable_realtime.sql
-- 4. 04_production_rls.sql
-- ============================================================================

SELECT '✅ Database reset complete! Run 01, 02, 03, 04 now.' AS status;
