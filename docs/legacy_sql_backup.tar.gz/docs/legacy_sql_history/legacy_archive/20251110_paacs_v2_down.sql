-- ============================================================================
-- PAACS v2.0 (Fusion Edition) — DATABASE ROLLBACK (DOWN)
-- ============================================================================
-- Version: 1.0
-- Date: 2025-11-10
-- Description: Rolls back PAACS v2.0 migration (removes tables/columns)
-- ⚠️  WARNING: This will delete session and audit log data!
-- ⚠️  Use only for rollback during testing/staging
-- ⚠️  DO NOT run on production without backup!
-- ============================================================================

BEGIN;

-- ----------------------------------------------------------------------------
-- 1) DROP triggers first (to avoid errors when dropping functions)
-- ----------------------------------------------------------------------------

DROP TRIGGER IF EXISTS revoke_sessions_on_password_change ON users;
DROP TRIGGER IF EXISTS revoke_sessions_on_role_change ON users;
DROP TRIGGER IF EXISTS revoke_sessions_on_deactivation ON users;

-- ----------------------------------------------------------------------------
-- 2) DROP functions
-- ----------------------------------------------------------------------------

DROP FUNCTION IF EXISTS trigger_revoke_sessions_on_password_change() CASCADE;
DROP FUNCTION IF EXISTS trigger_revoke_sessions_on_role_change() CASCADE;
DROP FUNCTION IF EXISTS trigger_revoke_sessions_on_deactivation() CASCADE;
DROP FUNCTION IF EXISTS cleanup_expired_sessions() CASCADE;
DROP FUNCTION IF EXISTS cleanup_old_auth_logs(INTEGER) CASCADE;
DROP FUNCTION IF EXISTS cleanup_expired_password_tokens() CASCADE;
DROP FUNCTION IF EXISTS get_user_active_session_count(UUID) CASCADE;
DROP FUNCTION IF EXISTS revoke_all_user_sessions(UUID) CASCADE;

-- ----------------------------------------------------------------------------
-- 3) DROP cron jobs (if pg_cron was used)
-- ----------------------------------------------------------------------------
-- Uncomment if pg_cron was set up:
/*
SELECT cron.unschedule('cleanup-expired-sessions');
SELECT cron.unschedule('cleanup-old-auth-logs');
SELECT cron.unschedule('cleanup-expired-password-tokens');
*/

-- ----------------------------------------------------------------------------
-- 4) DROP tables (cascades will remove policies and indexes)
-- ----------------------------------------------------------------------------

DROP TABLE IF EXISTS password_reset_tokens CASCADE;
DROP TABLE IF EXISTS auth_activity_logs CASCADE;
DROP TABLE IF EXISTS user_sessions CASCADE;

-- ----------------------------------------------------------------------------
-- 5) REMOVE columns from users table
-- ----------------------------------------------------------------------------
-- ⚠️  WARNING: This will delete user lockout and preference data!

ALTER TABLE users DROP COLUMN IF EXISTS preferred_language;
ALTER TABLE users DROP COLUMN IF EXISTS must_change_password;
ALTER TABLE users DROP COLUMN IF EXISTS last_password_change;
ALTER TABLE users DROP COLUMN IF EXISTS account_locked_until;
ALTER TABLE users DROP COLUMN IF EXISTS last_failed_attempt;
ALTER TABLE users DROP COLUMN IF EXISTS failed_login_attempts;

-- Drop indexes that were added
DROP INDEX IF EXISTS users_account_locked_until_idx;
DROP INDEX IF EXISTS users_failed_login_attempts_idx;

-- ----------------------------------------------------------------------------
-- 6) Verification
-- ----------------------------------------------------------------------------

DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_name = 'user_sessions'
  ) THEN
    RAISE EXCEPTION 'Rollback failed: user_sessions table still exists';
  END IF;
  
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'failed_login_attempts'
  ) THEN
    RAISE EXCEPTION 'Rollback failed: users.failed_login_attempts column still exists';
  END IF;
  
  RAISE NOTICE 'Rollback verification passed: PAACS v2.0 migration reverted successfully';
END $$;

COMMIT;

-- ============================================================================
-- Rollback complete! Verify with:
-- SELECT table_name FROM information_schema.tables 
-- WHERE table_name IN ('user_sessions', 'auth_activity_logs', 'password_reset_tokens');
-- (Should return 0 rows)
-- ============================================================================
