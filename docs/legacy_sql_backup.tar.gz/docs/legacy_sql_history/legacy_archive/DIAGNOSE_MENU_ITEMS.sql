-- ============================================================================
-- MENU ITEMS DIAGNOSTIC SCRIPT
-- Run this in Supabase SQL Editor to diagnose why menu items aren't showing
-- ============================================================================

-- Step 1: Check if menu items exist
SELECT 
  '1. Total menu items in database' as check_name,
  COUNT(*) as count
FROM menu_items;

-- Step 2: Check available vs unavailable
SELECT 
  '2. Menu items by availability' as check_name,
  is_available,
  COUNT(*) as count
FROM menu_items
GROUP BY is_available;

-- Step 3: Check menu items by restaurant
SELECT 
  '3. Menu items per restaurant' as check_name,
  r.name as restaurant_name,
  r.id as restaurant_id,
  COUNT(m.id) as menu_item_count,
  COUNT(m.id) FILTER (WHERE m.is_available = true) as available_count
FROM restaurants r
LEFT JOIN menu_items m ON m.restaurant_id = r.id
GROUP BY r.id, r.name
ORDER BY r.name;

-- Step 4: Sample of menu items (first 10)
SELECT 
  '4. Sample menu items' as check_name,
  id,
  name,
  category,
  price,
  is_available,
  restaurant_id
FROM menu_items
ORDER BY created_at DESC
LIMIT 10;

-- Step 5: Check RLS policies on menu_items
SELECT 
  '5. RLS Policies on menu_items' as check_name,
  policyname,
  roles,
  cmd,
  qual,
  with_check
FROM pg_policies
WHERE tablename = 'menu_items';

-- Step 6: Check if RLS is enabled
SELECT 
  '6. RLS Status' as check_name,
  tablename,
  rowsecurity as rls_enabled
FROM pg_tables
WHERE tablename = 'menu_items';

-- Step 7: Test SELECT as anonymous user (simulates customer)
SET ROLE anon;
SELECT 
  '7. Menu items visible to anonymous users' as check_name,
  COUNT(*) as count
FROM menu_items
WHERE is_available = true;
RESET ROLE;

-- Step 8: Check for specific restaurant (REPLACE WITH YOUR RESTAURANT ID)
-- Uncomment and replace the UUID below with your actual restaurant ID
/*
SELECT 
  '8. Menu items for specific restaurant' as check_name,
  id,
  name,
  category,
  price,
  is_available
FROM menu_items
WHERE restaurant_id = '00000000-0000-0000-0000-000000000000'  -- REPLACE THIS
  AND is_available = true
ORDER BY category, name;
*/

-- ============================================================================
-- EXPECTED RESULTS:
-- ============================================================================
-- 1. Should show total number of menu items
-- 2. Should show breakdown of available vs unavailable
-- 3. Should list all restaurants with their menu item counts
-- 4. Should show sample menu items with all details
-- 5. Should show RLS policies (should include "menu_items_select" for anon)
-- 6. Should show rls_enabled = true
-- 7. Should show count > 0 if you have available menu items
-- 8. Should show menu items for your specific restaurant

-- ============================================================================
-- TROUBLESHOOTING:
-- ============================================================================
-- If Step 1 returns 0: No menu items in database - add them in Manager dashboard
-- If Step 2 shows all is_available = false: Menu items are disabled - enable them
-- If Step 3 shows 0 for your restaurant: Menu items linked to wrong restaurant_id
-- If Step 5 doesn't show policy for 'anon': RLS policy missing - run 04_production_rls.sql
-- If Step 7 returns 0: RLS is blocking access OR all items unavailable
