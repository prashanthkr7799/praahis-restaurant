-- ============================================================================
-- CLEAN DATABASE FOR COMPLETE WORKFLOW TESTING
-- ============================================================================
-- This script removes all test data (restaurants, staff) while keeping
-- the superadmin owner account. Use this to test the complete hierarchy:
-- SuperAdmin → Create Restaurant → Add Manager → Manager adds Chef/Waiter
-- ============================================================================

-- ⚠️ WARNING: This will delete ALL restaurants and staff accounts!
-- ⚠️ Only the platform owner (superadmin) accounts will remain.
-- ⚠️ Review carefully before running!

BEGIN;

-- ============================================================================
-- STEP 1: Show what will be deleted (REVIEW THIS FIRST!)
-- ============================================================================

SELECT 'RESTAURANTS TO BE DELETED:' as info;
SELECT id, name, slug, created_at FROM restaurants;

SELECT 'STAFF TO BE DELETED:' as info;
SELECT 
  id, 
  email, 
  role, 
  full_name,
  restaurant_id
FROM public.users 
WHERE role IN ('chef', 'waiter', 'manager')
ORDER BY role, created_at;

-- ============================================================================
-- STEP 2: Delete audit trail records (must go first due to foreign keys)
-- ============================================================================

-- Delete ALL audit trail records to avoid foreign key conflicts
-- (This is test data cleanup - safe to remove all audit logs)
DELETE FROM audit_trail;

-- ============================================================================
-- STEP 3: Delete all staff (chef, waiter, manager)
-- ============================================================================

-- First, delete from public.users
DELETE FROM public.users 
WHERE role IN ('chef', 'waiter', 'manager');

-- Then, delete corresponding auth.users
-- (These are staff accounts that were created via UI)
DELETE FROM auth.users 
WHERE id NOT IN (
  SELECT id FROM public.users WHERE is_owner = true
)
AND id NOT IN (
  SELECT id FROM public.users WHERE role = 'admin'
);

-- ============================================================================
-- STEP 4: Delete all restaurants and related data
-- ============================================================================

-- Delete orders (must go before restaurants due to FK)
DELETE FROM orders WHERE restaurant_id IN (SELECT id FROM restaurants);

-- Delete menu items (must go before restaurants due to FK)
DELETE FROM menu_items WHERE restaurant_id IN (SELECT id FROM restaurants);

-- Delete any other restaurant-related data
DELETE FROM table_sessions WHERE restaurant_id IN (SELECT id FROM restaurants);

-- Finally, delete restaurants
DELETE FROM restaurants;

-- ============================================================================
-- STEP 5: Verify cleanup - Show what remains
-- ============================================================================

SELECT 'REMAINING ACCOUNTS (Should be only superadmin):' as info;

SELECT 
  au.email as auth_email,
  au.id as auth_id,
  u.email as profile_email,
  u.role,
  u.is_owner,
  u.created_at
FROM auth.users au
LEFT JOIN public.users u ON au.id = u.id
ORDER BY u.created_at DESC;

SELECT 'REMAINING RESTAURANTS (Should be ZERO):' as info;
SELECT COUNT(*) as restaurant_count FROM restaurants;

SELECT 'REMAINING STAFF (Should be ZERO):' as info;
SELECT COUNT(*) as staff_count FROM public.users 
WHERE role IN ('chef', 'waiter', 'manager');

-- ============================================================================
-- STEP 6: Find your SuperAdmin credentials
-- ============================================================================

SELECT 'YOUR SUPERADMIN EMAIL (Use this to login):' as info;
SELECT email, is_owner, created_at 
FROM public.users 
WHERE is_owner = true 
LIMIT 1;

COMMIT;

-- ============================================================================
-- CLEANUP COMPLETE! ✅
-- ============================================================================
-- Next Steps:
-- 1. Login at: http://localhost:5173/superadmin-login
-- 2. Email: prashanthkumareddy879@gmail.com
-- 3. Password: 123456 (⚠️ CHANGE THIS AFTER LOGIN!)
-- 4. Create a new restaurant: "The Spice Garden"
-- 5. Add manager: rahul@spice.com / Manager123!
-- 6. Logout and login as manager at /login (staff login)
-- 7. Add chef: chef@spice.com / Chef123!
-- 8. Add waiter: waiter@spice.com / Waiter123!
-- 9. Test complete workflow!
-- ============================================================================
