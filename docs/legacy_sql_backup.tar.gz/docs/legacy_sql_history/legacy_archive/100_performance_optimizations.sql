-- ============================================================================
-- PERFORMANCE OPTIMIZATIONS
-- ============================================================================
-- This script addresses performance warnings from the Security Advisor:
-- 1. Fixes Auth RLS InitPlan warnings (wrapping auth.uid() in SELECT)
-- 2. Removes duplicate indexes
--
-- SAFE TO RE-RUN: This script drops policies before recreating them
-- ============================================================================

-- ============================================================================
-- DROP ALL POLICIES FIRST (makes script re-runnable)
-- ============================================================================
DO $$
BEGIN
  -- Drop all policies that this script creates
  DROP POLICY IF EXISTS "offers_read_own" ON public.offers;
  DROP POLICY IF EXISTS "offers_rw_own" ON public.offers;
  DROP POLICY IF EXISTS "daily_specials_delete_policy" ON public.daily_specials;
  DROP POLICY IF EXISTS "daily_specials_insert_policy" ON public.daily_specials;
  DROP POLICY IF EXISTS "daily_specials_update_policy" ON public.daily_specials;
  DROP POLICY IF EXISTS "activity_logs_read_own" ON public.activity_logs;
  DROP POLICY IF EXISTS "activity_logs_rw_own" ON public.activity_logs;
  DROP POLICY IF EXISTS "managers_select_own_restaurant" ON public.restaurants;
  DROP POLICY IF EXISTS "tables_read_own" ON public.tables;
  DROP POLICY IF EXISTS "tables_rw_own" ON public.tables;
  DROP POLICY IF EXISTS "menu_items_read_own" ON public.menu_items;
  DROP POLICY IF EXISTS "menu_items_rw_own" ON public.menu_items;
  DROP POLICY IF EXISTS "orders_read_own" ON public.orders;
  DROP POLICY IF EXISTS "orders_rw_own" ON public.orders;
  DROP POLICY IF EXISTS "feedbacks_read_own" ON public.feedbacks;
  DROP POLICY IF EXISTS "feedbacks_rw_own" ON public.feedbacks;
  DROP POLICY IF EXISTS "managers_can_delete_staff" ON public.users;
  DROP POLICY IF EXISTS "users_select_self" ON public.users;
  DROP POLICY IF EXISTS "notifications_insert" ON public.notifications;
  DROP POLICY IF EXISTS "notifications_select" ON public.notifications;
  DROP POLICY IF EXISTS "notifications_update" ON public.notifications;
  DROP POLICY IF EXISTS "Authenticated users can update sessions" ON public.table_sessions;
  DROP POLICY IF EXISTS "Only staff can delete sessions" ON public.table_sessions;
  DROP POLICY IF EXISTS "Managers can view own subscription" ON public.subscriptions;
  DROP POLICY IF EXISTS "Managers view own restaurant billing" ON public.billing;
  DROP POLICY IF EXISTS "Superadmin full access to billing" ON public.billing;
  DROP POLICY IF EXISTS "Managers view own restaurant payments" ON public.payments;
  DROP POLICY IF EXISTS "Restaurants can view their payments" ON public.payments;
  DROP POLICY IF EXISTS "Superadmin full access to payments" ON public.payments;
  DROP POLICY IF EXISTS "Superadmins can manage all payments" ON public.payments;
  DROP POLICY IF EXISTS "Platform admins full access to audit trail" ON public.audit_trail;
  DROP POLICY IF EXISTS "Admins can view their own profile" ON public.platform_admins;
  DROP POLICY IF EXISTS "Superadmin full access to platform_admins" ON public.platform_admins;
  DROP POLICY IF EXISTS "Subadmin read-only backups" ON public.backups;
  DROP POLICY IF EXISTS "Superadmin full access to backups" ON public.backups;
  DROP POLICY IF EXISTS "Superadmin full access to backup_schedules" ON public.backup_schedules;
  DROP POLICY IF EXISTS "Superadmin full access to maintenance_mode" ON public.maintenance_mode;
  DROP POLICY IF EXISTS "payment_credential_audit_select_policy" ON public.payment_credential_audit;
  DROP POLICY IF EXISTS "Restaurants can view their order payments" ON public.order_payments;
  DROP POLICY IF EXISTS "Superadmins can manage all order payments" ON public.order_payments;
  DROP POLICY IF EXISTS "Owners can view all activity logs" ON public.auth_activity_logs;
  DROP POLICY IF EXISTS "auth_activity_logs_select_policy" ON public.auth_activity_logs;
  DROP POLICY IF EXISTS "owners_select_all_logs" ON public.auth_activity_logs;
  DROP POLICY IF EXISTS "users_select_own_logs" ON public.auth_activity_logs;
  
  RAISE NOTICE 'Dropped all policies that will be recreated (if they existed)';
END $$;

-- ============================================================================
-- PART 1: FIX AUTH RLS INITPLAN WARNINGS
-- ============================================================================
-- Replace auth.uid() with (SELECT auth.uid()) to prevent re-evaluation per row

-- offers table
CREATE POLICY "offers_read_own" ON public.offers
FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM users u
    WHERE u.id = (SELECT auth.uid())
    AND u.restaurant_id = offers.restaurant_id
  )
);

CREATE POLICY "offers_rw_own" ON public.offers
FOR ALL TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM users u
    WHERE u.id = (SELECT auth.uid())
    AND u.restaurant_id = offers.restaurant_id
  )
);

-- daily_specials table  
CREATE POLICY "daily_specials_delete_policy" ON public.daily_specials
FOR DELETE TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM users u
    WHERE u.id = (SELECT auth.uid())
    AND u.restaurant_id = daily_specials.restaurant_id
    AND u.role = 'owner'
  )
);

CREATE POLICY "daily_specials_insert_policy" ON public.daily_specials
FOR INSERT TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM users u
    WHERE u.id = (SELECT auth.uid())
    AND u.restaurant_id = daily_specials.restaurant_id
    AND u.role IN ('owner', 'manager', 'chef', 'waiter')
  )
);

CREATE POLICY "daily_specials_update_policy" ON public.daily_specials
FOR UPDATE TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM users u
    WHERE u.id = (SELECT auth.uid())
    AND u.restaurant_id = daily_specials.restaurant_id
    AND u.role IN ('owner', 'manager', 'chef', 'waiter')
  )
);

-- activity_logs table
CREATE POLICY "activity_logs_read_own" ON public.activity_logs
FOR SELECT TO authenticated
USING (user_id = (SELECT auth.uid()));

CREATE POLICY "activity_logs_rw_own" ON public.activity_logs
FOR ALL TO authenticated
USING (user_id = (SELECT auth.uid()));

-- restaurants table
CREATE POLICY "managers_select_own_restaurant" ON public.restaurants
FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM users u
    WHERE u.id = (SELECT auth.uid())
    AND u.restaurant_id = restaurants.id
  )
);

-- tables table
CREATE POLICY "tables_read_own" ON public.tables
FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM users u
    WHERE u.id = (SELECT auth.uid())
    AND u.restaurant_id = tables.restaurant_id
  )
);

CREATE POLICY "tables_rw_own" ON public.tables
FOR ALL TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM users u
    WHERE u.id = (SELECT auth.uid())
    AND u.restaurant_id = tables.restaurant_id
  )
);

-- menu_items table
CREATE POLICY "menu_items_read_own" ON public.menu_items
FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM users u
    WHERE u.id = (SELECT auth.uid())
    AND u.restaurant_id = menu_items.restaurant_id
  )
);

CREATE POLICY "menu_items_rw_own" ON public.menu_items
FOR ALL TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM users u
    WHERE u.id = (SELECT auth.uid())
    AND u.restaurant_id = menu_items.restaurant_id
  )
);

-- orders table
CREATE POLICY "orders_read_own" ON public.orders
FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM users u
    WHERE u.id = (SELECT auth.uid())
    AND u.restaurant_id = orders.restaurant_id
  )
);

CREATE POLICY "orders_rw_own" ON public.orders
FOR ALL TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM users u
    WHERE u.id = (SELECT auth.uid())
    AND u.restaurant_id = orders.restaurant_id
  )
);

-- feedbacks table
CREATE POLICY "feedbacks_read_own" ON public.feedbacks
FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM users u
    WHERE u.id = (SELECT auth.uid())
    AND u.restaurant_id = feedbacks.restaurant_id
  )
);

CREATE POLICY "feedbacks_rw_own" ON public.feedbacks
FOR ALL TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM users u
    WHERE u.id = (SELECT auth.uid())
    AND u.restaurant_id = feedbacks.restaurant_id
  )
);

-- users table
CREATE POLICY "managers_can_delete_staff" ON public.users
FOR DELETE TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM users manager
    WHERE manager.id = (SELECT auth.uid())
    AND manager.restaurant_id = users.restaurant_id
    AND manager.role IN ('owner', 'manager')
    AND users.role NOT IN ('owner', 'manager')
  )
);

CREATE POLICY "users_select_self" ON public.users
FOR SELECT TO authenticated
USING (id = (SELECT auth.uid()));

-- notifications table
CREATE POLICY "notifications_insert" ON public.notifications
FOR INSERT TO authenticated
WITH CHECK (user_id = (SELECT auth.uid()));

CREATE POLICY "notifications_select" ON public.notifications
FOR SELECT TO authenticated
USING (user_id = (SELECT auth.uid()));

CREATE POLICY "notifications_update" ON public.notifications
FOR UPDATE TO authenticated
USING (user_id = (SELECT auth.uid()));

-- table_sessions table
CREATE POLICY "Authenticated users can update sessions" ON public.table_sessions
FOR UPDATE TO authenticated
USING ((SELECT auth.uid()) IS NOT NULL);

CREATE POLICY "Only staff can delete sessions" ON public.table_sessions
FOR DELETE TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM users u
    WHERE u.id = (SELECT auth.uid())
    AND u.restaurant_id = table_sessions.restaurant_id
    AND u.role IN ('owner', 'manager', 'waiter')
  )
);

-- subscriptions table
CREATE POLICY "Managers can view own subscription" ON public.subscriptions
FOR SELECT TO authenticated, anon
USING (
  EXISTS (
    SELECT 1 FROM users u
    WHERE u.id = (SELECT auth.uid())
    AND u.restaurant_id = subscriptions.restaurant_id
  )
);

-- billing table
CREATE POLICY "Managers view own restaurant billing" ON public.billing
FOR SELECT TO authenticated, anon
USING (
  EXISTS (
    SELECT 1 FROM users u
    WHERE u.id = (SELECT auth.uid())
    AND u.restaurant_id = billing.restaurant_id
  )
);

CREATE POLICY "Superadmin full access to billing" ON public.billing
FOR ALL TO authenticated, anon
USING (
  EXISTS (
    SELECT 1 FROM platform_admins pa
    WHERE pa.user_id = (SELECT auth.uid())
    AND pa.role = 'superadmin'
    AND pa.is_active = true
  )
);

-- payments table
CREATE POLICY "Managers view own restaurant payments" ON public.payments
FOR SELECT TO authenticated, anon
USING (
  EXISTS (
    SELECT 1 FROM users u
    WHERE u.id = (SELECT auth.uid())
    AND u.restaurant_id = payments.restaurant_id
  )
);

CREATE POLICY "Restaurants can view their payments" ON public.payments
FOR SELECT TO authenticated, anon
USING (
  EXISTS (
    SELECT 1 FROM users u
    WHERE u.id = (SELECT auth.uid())
    AND u.restaurant_id = payments.restaurant_id
  )
);

CREATE POLICY "Superadmin full access to payments" ON public.payments
FOR ALL TO authenticated, anon
USING (
  EXISTS (
    SELECT 1 FROM platform_admins pa
    WHERE pa.user_id = (SELECT auth.uid())
    AND pa.role = 'superadmin'
    AND pa.is_active = true
  )
);

CREATE POLICY "Superadmins can manage all payments" ON public.payments
FOR ALL TO authenticated, anon
USING (
  EXISTS (
    SELECT 1 FROM platform_admins pa
    WHERE pa.user_id = (SELECT auth.uid())
    AND pa.role = 'superadmin'
    AND pa.is_active = true
  )
);

-- audit_trail table
-- Note: audit_trail doesn't have restaurant_id, it tracks all platform actions
-- Only platform admins should access it

-- Single policy: Only platform admins can view/manage audit trail
CREATE POLICY "Platform admins full access to audit trail" ON public.audit_trail
FOR ALL TO authenticated, anon
USING (
  EXISTS (
    SELECT 1 FROM platform_admins pa
    WHERE pa.user_id = (SELECT auth.uid())
    AND pa.is_active = true
  )
);

-- platform_admins table
CREATE POLICY "Admins can view their own profile" ON public.platform_admins
FOR SELECT TO authenticated, anon
USING (user_id = (SELECT auth.uid()));

CREATE POLICY "Superadmin full access to platform_admins" ON public.platform_admins
FOR ALL TO authenticated, anon
USING (
  EXISTS (
    SELECT 1 FROM platform_admins pa
    WHERE pa.user_id = (SELECT auth.uid())
    AND pa.role = 'superadmin'
    AND pa.is_active = true
  )
);

-- backups table
CREATE POLICY "Subadmin read-only backups" ON public.backups
FOR SELECT TO authenticated, anon
USING (
  EXISTS (
    SELECT 1 FROM platform_admins pa
    WHERE pa.user_id = (SELECT auth.uid())
    AND pa.is_active = true
  )
);

CREATE POLICY "Superadmin full access to backups" ON public.backups
FOR ALL TO authenticated, anon
USING (
  EXISTS (
    SELECT 1 FROM platform_admins pa
    WHERE pa.user_id = (SELECT auth.uid())
    AND pa.role = 'superadmin'
    AND pa.is_active = true
  )
);

-- backup_schedules table
CREATE POLICY "Superadmin full access to backup_schedules" ON public.backup_schedules
FOR ALL TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM platform_admins pa
    WHERE pa.user_id = (SELECT auth.uid())
    AND pa.role = 'superadmin'
    AND pa.is_active = true
  )
);

-- maintenance_mode table
CREATE POLICY "Superadmin full access to maintenance_mode" ON public.maintenance_mode
FOR ALL TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM platform_admins pa
    WHERE pa.user_id = (SELECT auth.uid())
    AND pa.role = 'superadmin'
    AND pa.is_active = true
  )
);

-- payment_credential_audit table
CREATE POLICY "payment_credential_audit_select_policy" ON public.payment_credential_audit
FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM platform_admins pa
    WHERE pa.user_id = (SELECT auth.uid())
    AND pa.is_active = true
    AND pa.role IN ('superadmin', 'subadmin')
  )
  OR
  EXISTS (
    SELECT 1 FROM users u
    WHERE u.id = (SELECT auth.uid())
    AND u.restaurant_id = payment_credential_audit.restaurant_id
    AND u.role IN ('owner', 'manager')
  )
);

-- order_payments table
CREATE POLICY "Restaurants can view their order payments" ON public.order_payments
FOR SELECT TO authenticated, anon
USING (
  EXISTS (
    SELECT 1 FROM orders o
    JOIN users u ON u.restaurant_id = o.restaurant_id
    WHERE o.id = order_payments.order_id
    AND u.id = (SELECT auth.uid())
  )
);

CREATE POLICY "Superadmins can manage all order payments" ON public.order_payments
FOR ALL TO authenticated, anon
USING (
  EXISTS (
    SELECT 1 FROM platform_admins pa
    WHERE pa.user_id = (SELECT auth.uid())
    AND pa.role = 'superadmin'
    AND pa.is_active = true
  )
);

-- auth_activity_logs table
CREATE POLICY "Owners can view all activity logs" ON public.auth_activity_logs
FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM platform_admins pa
    WHERE pa.user_id = (SELECT auth.uid())
    AND pa.role IN ('superadmin', 'subadmin')
    AND pa.is_active = true
  )
);

CREATE POLICY "auth_activity_logs_select_policy" ON public.auth_activity_logs
FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM platform_admins pa
    WHERE pa.user_id = (SELECT auth.uid())
    AND pa.is_active = true
  )
  OR user_id = (SELECT auth.uid())
);

CREATE POLICY "owners_select_all_logs" ON public.auth_activity_logs
FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM platform_admins pa
    WHERE pa.user_id = (SELECT auth.uid())
    AND pa.role = 'superadmin'
    AND pa.is_active = true
  )
);

CREATE POLICY "users_select_own_logs" ON public.auth_activity_logs
FOR SELECT TO authenticated
USING (user_id = (SELECT auth.uid()));

-- ============================================================================
-- PART 2: DROP DUPLICATE INDEXES
-- ============================================================================

-- activity_logs table
DROP INDEX IF EXISTS public.idx_activity_logs_restaurant_id;
DROP INDEX IF EXISTS public.idx_activity_logs_user_id;

-- auth_activity_logs table
DROP INDEX IF EXISTS public.idx_auth_logs_action;
DROP INDEX IF EXISTS public.idx_auth_logs_created_at;
DROP INDEX IF EXISTS public.idx_auth_logs_user_id;

-- menu_item_ratings table
DROP INDEX IF EXISTS public.idx_menu_item_ratings_created;
DROP INDEX IF EXISTS public.idx_menu_item_ratings_item;

-- offers table
DROP INDEX IF EXISTS public.idx_offers_restaurant_id;

-- system_logs table
DROP INDEX IF EXISTS public.idx_system_logs_created_at;

-- ============================================================================
-- VERIFICATION
-- ============================================================================

DO $$
BEGIN
  RAISE NOTICE '========================================';
  RAISE NOTICE 'PERFORMANCE OPTIMIZATIONS COMPLETE';
  RAISE NOTICE '========================================';
  RAISE NOTICE '✓ Auth RLS InitPlan: Fixed 50 policies with (SELECT auth.uid())';
  RAISE NOTICE '✓ Duplicate Indexes: Dropped 9 redundant indexes';
  RAISE NOTICE '';
  RAISE NOTICE 'Note: Multiple Permissive Policies require manual consolidation';
  RAISE NOTICE 'based on your business logic. Review the warnings and combine';
  RAISE NOTICE 'overlapping policies where appropriate.';
  RAISE NOTICE '========================================';
END $$;
