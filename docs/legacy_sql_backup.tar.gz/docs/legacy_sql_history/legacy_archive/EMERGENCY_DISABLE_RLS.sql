-- EMERGENCY FIX: Remove ALL RLS policies temporarily to get things working
-- Run this in Supabase SQL Editor

-- 1. Disable RLS on critical tables (TEMPORARY - for debugging only)
ALTER TABLE public.users DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscriptions DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.restaurants DISABLE ROW LEVEL SECURITY;

-- 2. Make sure your owner user exists
INSERT INTO public.users (
  id,
  email,
  name,
  full_name,
  role,
  is_owner,
  is_active
)
SELECT 
  id,
  email,
  COALESCE(raw_user_meta_data->>'full_name', 'Super Admin'),
  COALESCE(raw_user_meta_data->>'full_name', 'Super Admin'),
  'owner',
  true,
  true
FROM auth.users
WHERE email = 'prashanthkumarreddy879@gmail.com'
ON CONFLICT (id) DO UPDATE
SET is_owner = true,
    role = 'owner',
    is_active = true;

-- 3. Verify
SELECT 'Users in public.users:' as info, COUNT(*) FROM public.users;
SELECT 'Subscriptions:' as info, COUNT(*) FROM public.subscriptions;
SELECT 'Restaurants:' as info, COUNT(*) FROM public.restaurants;

SELECT * FROM public.users WHERE email = 'prashanthkumarreddy879@gmail.com';
