-- ============================================================================
-- FIX MANAGER MISSING RESTAURANT_ID
-- ============================================================================
-- This script fixes the "Restaurant context is missing" error when managers
-- try to login. This happens when a manager is created but restaurant_id
-- is NULL in the public.users table.
-- ============================================================================

-- ============================================================================
-- STEP 1: Identify the problem - Show managers without restaurant_id
-- ============================================================================

SELECT '=== MANAGERS WITH MISSING RESTAURANT_ID (THE PROBLEM) ===' as info;

SELECT 
  id,
  email,
  role,
  restaurant_id,
  full_name,
  created_at,
  CASE 
    WHEN restaurant_id IS NULL THEN '❌ MISSING restaurant_id (causes login error)'
    ELSE '✅ Has restaurant_id'
  END as status
FROM public.users
WHERE role = 'manager'
ORDER BY created_at DESC;

-- ============================================================================
-- STEP 2: Show all restaurants to find the correct restaurant_id
-- ============================================================================

SELECT '=== ALL RESTAURANTS (Find the ID to assign) ===' as info;

SELECT 
  id as restaurant_id,
  name,
  slug,
  created_at,
  '👆 Copy this ID to assign to manager' as note
FROM restaurants
ORDER BY created_at DESC;

-- ============================================================================
-- STEP 3: FIX OPTION A - Auto-assign to the most recent restaurant
-- ============================================================================

SELECT '=== FIX OPTION A: Auto-assign manager to latest restaurant ===' as info;

-- This will assign ALL managers with NULL restaurant_id to the most recent restaurant
UPDATE public.users
SET 
  restaurant_id = (SELECT id FROM restaurants ORDER BY created_at DESC LIMIT 1),
  updated_at = NOW()
WHERE role = 'manager'
AND restaurant_id IS NULL
RETURNING 
  email,
  role,
  restaurant_id,
  '✅ Manager fixed - assigned to restaurant' as status;

-- ============================================================================
-- STEP 4: Verify the fix worked
-- ============================================================================

SELECT '=== VERIFICATION: All managers should now have restaurant_id ===' as info;

SELECT 
  u.email,
  u.role,
  u.restaurant_id,
  r.name as restaurant_name,
  CASE 
    WHEN u.restaurant_id IS NOT NULL THEN '✅ FIXED - Has restaurant_id'
    ELSE '❌ STILL BROKEN'
  END as status
FROM public.users u
LEFT JOIN restaurants r ON u.restaurant_id = r.id
WHERE u.role = 'manager'
ORDER BY u.created_at DESC;

-- ============================================================================
-- STEP 5: Show the manager's login credentials
-- ============================================================================

SELECT '=== MANAGER LOGIN CREDENTIALS (Use these to test) ===' as info;

SELECT 
  u.email as manager_email,
  r.name as restaurant_name,
  r.slug as restaurant_slug,
  '(Check SuperAdmin dashboard for password)' as password_note,
  'http://localhost:5173/login' as login_url
FROM public.users u
JOIN restaurants r ON u.restaurant_id = r.id
WHERE u.role = 'manager'
ORDER BY u.created_at DESC;

-- ============================================================================
-- ALTERNATIVE FIX OPTION B (Manual Assignment)
-- ============================================================================

/*

If you want to manually assign a specific manager to a specific restaurant:

-- Step 1: Find the manager's email and restaurant ID
SELECT email FROM public.users WHERE role = 'manager';
SELECT id, name FROM restaurants;

-- Step 2: Update the specific manager
UPDATE public.users
SET 
  restaurant_id = 'PASTE_RESTAURANT_ID_HERE',
  updated_at = NOW()
WHERE email = 'manager@email.com'
AND role = 'manager';

-- Example:
UPDATE public.users
SET 
  restaurant_id = 'a1b2c3d4-e5f6-7890-abcd-ef1234567890',
  updated_at = NOW()
WHERE email = 'rahul@spice.com'
AND role = 'manager';

*/

-- ============================================================================
-- ROOT CAUSE ANALYSIS
-- ============================================================================

/*

WHY THIS HAPPENS:

When SuperAdmin creates a manager via the UI, sometimes the restaurant_id
doesn't get saved properly in the public.users table.

Common causes:
1. RLS policy preventing INSERT with restaurant_id
2. Frontend not sending restaurant_id in the request
3. Database trigger not setting restaurant_id
4. Race condition between auth.users and public.users creation

PERMANENT FIX NEEDED:

Check these files:
1. src/pages/superadmin/CreateRestaurantManager.jsx
   → Ensure it sends restaurant_id in the request

2. src/utils/supabaseOwner.js
   → Verify createStaffMember includes restaurant_id

3. database/70_unified_login_rls_FIXED.sql
   → Check RLS policies allow owner to INSERT with restaurant_id

*/

-- ============================================================================
-- QUICK DIAGNOSTIC
-- ============================================================================

SELECT '=== DIAGNOSTIC: Check RLS Policy ===' as info;

-- This checks if RLS is enabled on users table
SELECT 
  schemaname,
  tablename,
  rowsecurity,
  CASE 
    WHEN rowsecurity = true THEN '✅ RLS is ON'
    ELSE '⚠️ RLS is OFF'
  END as rls_status
FROM pg_tables
WHERE schemaname = 'public'
AND tablename = 'users';

-- ============================================================================
-- ✅ SCRIPT COMPLETE
-- ============================================================================
-- After running this script:
-- 1. ✅ Manager should have restaurant_id
-- 2. ✅ Manager can login at /login
-- 3. ✅ Manager sees their restaurant dashboard
-- 4. ✅ No more "Restaurant context is missing" error
-- 
-- TEST IT:
-- 1. Go to: http://localhost:5173/login
-- 2. Login with manager email (e.g., rahul@spice.com)
-- 3. Enter the password you set when creating the manager
-- 4. Should redirect to /manager/dashboard
-- ============================================================================
