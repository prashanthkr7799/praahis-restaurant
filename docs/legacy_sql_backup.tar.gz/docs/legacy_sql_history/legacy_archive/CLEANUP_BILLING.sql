-- ============================================================================
-- CLEAN SLATE - Remove All Billing System Objects
-- ============================================================================
-- Run this if you need to start fresh
-- WARNING: This will delete all billing and payment data!
-- ============================================================================

-- Removing triggers (with error handling)...
DO $$ 
BEGIN
    DROP TRIGGER IF EXISTS update_billing_timestamp_trigger ON billing CASCADE;
EXCEPTION WHEN undefined_table THEN
    -- Table doesn't exist, skip
    NULL;
END $$;

DO $$ 
BEGIN
    DROP TRIGGER IF EXISTS update_payments_timestamp_trigger ON payments CASCADE;
EXCEPTION WHEN undefined_table THEN
    -- Table doesn't exist, skip
    NULL;
END $$;

-- Removing functions...
DROP FUNCTION IF EXISTS calculate_billing_amount(INTEGER, NUMERIC, INTEGER) CASCADE;
DROP FUNCTION IF EXISTS generate_monthly_bills() CASCADE;
DROP FUNCTION IF EXISTS mark_bill_as_paid(UUID, TEXT, TEXT, TEXT) CASCADE;
DROP FUNCTION IF EXISTS suspend_overdue_restaurants() CASCADE;
DROP FUNCTION IF EXISTS get_restaurant_billing_summary(UUID) CASCADE;
DROP FUNCTION IF EXISTS update_billing_timestamp() CASCADE;

-- Removing tables...
DROP TABLE IF EXISTS payments CASCADE;
DROP TABLE IF EXISTS billing CASCADE;

-- Show completion message
DO $$
BEGIN
    RAISE NOTICE '============================================================================';
    RAISE NOTICE '✅ Cleanup complete!';
    RAISE NOTICE '============================================================================';
    RAISE NOTICE 'You can now run the installation script: 40_billing_payments_system.sql';
END $$;
