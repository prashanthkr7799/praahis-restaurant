-- =========================================================================
-- ULTIMATE LOGIN FIX - Non-Recursive RLS Policies
-- =========================================================================
-- This fixes the 500 Internal Server Error caused by recursive RLS checks
-- =========================================================================

-- Step 1: Re-enable RLS on users table
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

-- Step 2: Drop ALL existing policies to start completely fresh
DO $$ 
DECLARE
    r RECORD;
BEGIN
    FOR r IN (SELECT policyname FROM pg_policies WHERE tablename = 'users' AND schemaname = 'public') LOOP
        EXECUTE 'DROP POLICY IF EXISTS ' || quote_ident(r.policyname) || ' ON public.users';
    END LOOP;
END $$;

-- Step 3: Create simple, non-recursive SELECT policies
-- Policy 1: Users can ALWAYS read their own profile (no recursion)
CREATE POLICY "users_select_own" 
ON public.users 
FOR SELECT 
USING (auth.uid() = id);

-- Policy 2: Owners can read ALL users
-- We check is_owner directly without subquery to avoid recursion
CREATE POLICY "users_select_owner" 
ON public.users 
FOR SELECT 
USING (
  (SELECT is_owner FROM public.users WHERE id = auth.uid() LIMIT 1) = true
  OR
  (SELECT role FROM public.users WHERE id = auth.uid() LIMIT 1) = 'owner'
);

-- Step 4: Create INSERT policy (owners only)
CREATE POLICY "users_insert" 
ON public.users 
FOR INSERT 
WITH CHECK (
  (SELECT is_owner FROM public.users WHERE id = auth.uid() LIMIT 1) = true
);

-- Step 5: Create UPDATE policies
-- Policy 1: Users can update their own profile
CREATE POLICY "users_update_own" 
ON public.users 
FOR UPDATE 
USING (auth.uid() = id);

-- Policy 2: Owners can update any user
CREATE POLICY "users_update_owner" 
ON public.users 
FOR UPDATE 
USING (
  (SELECT is_owner FROM public.users WHERE id = auth.uid() LIMIT 1) = true
);

-- Step 6: Create DELETE policy (owners only)
CREATE POLICY "users_delete" 
ON public.users 
FOR DELETE 
USING (
  (SELECT is_owner FROM public.users WHERE id = auth.uid() LIMIT 1) = true
);

-- Step 7: Ensure auto-confirm trigger exists
CREATE OR REPLACE FUNCTION public.auto_confirm_user()
RETURNS TRIGGER AS $$
BEGIN
  NEW.email_confirmed_at := NOW();
  NEW.confirmation_token := '';
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS auto_confirm_user_trigger ON auth.users;
CREATE TRIGGER auto_confirm_user_trigger
  BEFORE INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.auto_confirm_user();

-- Step 8: Confirm all existing unconfirmed users
UPDATE auth.users 
SET email_confirmed_at = COALESCE(email_confirmed_at, NOW()),
    confirmation_token = ''
WHERE email_confirmed_at IS NULL;

-- Step 9: Verify policies
SELECT 
    schemaname,
    tablename,
    policyname,
    cmd,
    qual,
    with_check
FROM pg_policies 
WHERE tablename = 'users'
ORDER BY policyname;

-- =========================================================================
-- DONE! This should work without recursion errors.
-- The key: We use direct SELECT with LIMIT 1 instead of EXISTS
-- =========================================================================
