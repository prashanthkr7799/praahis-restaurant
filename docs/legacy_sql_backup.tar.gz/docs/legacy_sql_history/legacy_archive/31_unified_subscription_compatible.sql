-- ============================================================================
-- UNIFIED SUBSCRIPTION SYSTEM - COMPATIBLE WITH EXISTING SCHEMA
-- ============================================================================
-- Works with existing subscriptions table (current_period_end column)
-- Single Plan: ₹35,000/month + ₹5,000 setup fee
-- 3-day trial → 3-day grace → Auto-suspension
-- ============================================================================

-- ============================================================================
-- 1. UPDATE PLATFORM SETTINGS (Unified Pricing)
-- ============================================================================
INSERT INTO platform_settings (key, value, category, description) VALUES
    ('subscription_monthly_price', '"35000"'::jsonb, 'pricing', 'Monthly subscription price in rupees'),
    ('subscription_setup_fee', '"5000"'::jsonb, 'pricing', 'One-time setup fee in rupees'),
    ('subscription_trial_days', '"3"'::jsonb, 'subscription', 'Free trial period in days'),
    ('subscription_grace_days', '"3"'::jsonb, 'subscription', 'Grace period after expiry in days'),
    ('subscription_auto_suspend', '"true"'::jsonb, 'subscription', 'Automatically suspend expired subscriptions'),
    ('subscription_currency', '"INR"'::jsonb, 'pricing', 'Currency for payments'),
    ('payment_gateway', '"razorpay"'::jsonb, 'payment', 'Default payment gateway')
ON CONFLICT (key) DO UPDATE SET
    value = EXCLUDED.value,
    description = EXCLUDED.description,
    updated_at = NOW();

-- ============================================================================
-- 2. ADD SETUP FEE COLUMN TO SUBSCRIPTIONS (if not exists)
-- ============================================================================
ALTER TABLE subscriptions 
ADD COLUMN IF NOT EXISTS setup_fee_paid BOOLEAN DEFAULT FALSE;

-- Add suspended columns if they don't exist (for tracking suspension)
ALTER TABLE subscriptions
ADD COLUMN IF NOT EXISTS suspended_at TIMESTAMPTZ;

ALTER TABLE subscriptions
ADD COLUMN IF NOT EXISTS suspended_reason TEXT;

-- ============================================================================
-- 3. ENSURE PAYMENTS TABLE EXISTS
-- ============================================================================
CREATE TABLE IF NOT EXISTS payments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
    
    -- Payment Details
    amount DECIMAL(10, 2) NOT NULL,
    payment_type TEXT NOT NULL CHECK (payment_type IN ('setup_fee', 'monthly_subscription', 'renewal')),
    
    -- Payment Gateway
    payment_method TEXT,
    payment_gateway_id TEXT,
    payment_gateway_order_id TEXT,
    
    -- Status
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed', 'refunded')),
    
    -- Dates
    payment_date TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    failed_at TIMESTAMPTZ,
    
    -- Metadata
    receipt_url TEXT,
    invoice_number TEXT,
    notes TEXT,
    metadata JSONB,
    
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Add subscription_id column if it doesn't exist
ALTER TABLE payments 
ADD COLUMN IF NOT EXISTS subscription_id UUID;

-- Add foreign key constraint separately
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'payments_subscription_id_fkey'
    ) THEN
        ALTER TABLE payments 
        ADD CONSTRAINT payments_subscription_id_fkey 
        FOREIGN KEY (subscription_id) 
        REFERENCES subscriptions(id) 
        ON DELETE SET NULL;
    END IF;
END $$;

-- Indexes (create only if column exists)
CREATE INDEX IF NOT EXISTS idx_payments_restaurant ON payments(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_payments_subscription ON payments(subscription_id);
CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);

-- Create index on payment_date only if column exists
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.columns 
               WHERE table_name = 'payments' AND column_name = 'payment_date') THEN
        CREATE INDEX IF NOT EXISTS idx_payments_date ON payments(payment_date);
    END IF;
END $$;

-- Create index on payment_gateway_id only if column exists
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.columns 
               WHERE table_name = 'payments' AND column_name = 'payment_gateway_id') THEN
        CREATE INDEX IF NOT EXISTS idx_payments_gateway_id ON payments(payment_gateway_id);
    END IF;
END $$;

-- ============================================================================
-- 4. FUNCTION: Check Subscription Status (UPDATED)
-- ============================================================================
-- Drop existing function to allow return type change
DROP FUNCTION IF EXISTS check_subscription_status(UUID);

CREATE OR REPLACE FUNCTION check_subscription_status(p_restaurant_id UUID)
RETURNS TABLE(
    status TEXT,
    is_active BOOLEAN,
    days_remaining INTEGER,
    in_grace_period BOOLEAN,
    message TEXT,
    end_date TIMESTAMPTZ
) 
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_subscription RECORD;
    v_now TIMESTAMPTZ := NOW();
    v_days_left INTEGER;
    v_grace_days INTEGER;
    v_end_date TIMESTAMPTZ;
BEGIN
    -- Get subscription
    SELECT * INTO v_subscription
    FROM subscriptions
    WHERE restaurant_id = p_restaurant_id;
    
    -- No subscription found
    IF v_subscription IS NULL THEN
        RETURN QUERY SELECT 
            'none'::TEXT,
            FALSE,
            0,
            FALSE,
            'No subscription found. Please contact support.'::TEXT,
            NULL::TIMESTAMPTZ;
        RETURN;
    END IF;
    
    -- Determine end date (use trial_ends_at or current_period_end)
    v_end_date := COALESCE(v_subscription.trial_ends_at, v_subscription.current_period_end);
    
    -- Calculate days remaining
    v_days_left := EXTRACT(DAY FROM (v_end_date - v_now))::INTEGER;
    v_grace_days := COALESCE(v_subscription.grace_period_days, 3);
    
    -- Status: Suspended
    IF v_subscription.status = 'suspended' THEN
        RETURN QUERY SELECT 
            'suspended'::TEXT,
            FALSE,
            0,
            FALSE,
            'Your subscription has been suspended. Please renew to continue.'::TEXT,
            v_end_date;
        RETURN;
    END IF;
    
    -- Status: Cancelled
    IF v_subscription.status = 'cancelled' THEN
        RETURN QUERY SELECT 
            'cancelled'::TEXT,
            FALSE,
            0,
            FALSE,
            'Subscription cancelled. Please contact support to reactivate.'::TEXT,
            v_end_date;
        RETURN;
    END IF;
    
    -- Status: Trial (Active)
    IF v_subscription.status = 'trial' AND v_subscription.trial_ends_at IS NOT NULL AND v_now < v_subscription.trial_ends_at THEN
        RETURN QUERY SELECT 
            'trial'::TEXT,
            TRUE,
            v_days_left,
            FALSE,
            format('Trial ends in %s days. Upgrade to continue.', v_days_left)::TEXT,
            v_end_date;
        RETURN;
    END IF;
    
    -- Status: Active (Paid)
    IF v_subscription.status = 'active' AND v_now < v_subscription.current_period_end THEN
        RETURN QUERY SELECT 
            'active'::TEXT,
            TRUE,
            v_days_left,
            FALSE,
            format('Subscription active. Renews in %s days.', v_days_left)::TEXT,
            v_end_date;
        RETURN;
    END IF;
    
    -- Status: Grace Period
    IF v_subscription.status = 'grace' OR 
       (v_now >= v_end_date AND v_now < (v_end_date + (v_grace_days || ' days')::INTERVAL)) THEN
        
        v_days_left := v_grace_days - EXTRACT(DAY FROM (v_now - v_end_date))::INTEGER;
        
        RETURN QUERY SELECT 
            'grace'::TEXT,
            TRUE,
            v_days_left,
            TRUE,
            format('Payment overdue! %s days left before suspension.', GREATEST(v_days_left, 0))::TEXT,
            v_end_date;
        RETURN;
    END IF;
    
    -- Status: Expired
    RETURN QUERY SELECT 
        'expired'::TEXT,
        FALSE,
        0,
        FALSE,
        'Subscription expired. Please renew to continue.'::TEXT,
        v_end_date;
END;
$$;

-- ============================================================================
-- 5. FUNCTION: Process Payment and Reactivate (UPDATED)
-- ============================================================================
-- Drop existing function to allow signature change
DROP FUNCTION IF EXISTS process_payment_and_reactivate(UUID, DECIMAL, TEXT, TEXT, TEXT, TEXT);
DROP FUNCTION IF EXISTS process_payment_and_reactivate(UUID, DECIMAL, TEXT);

CREATE OR REPLACE FUNCTION process_payment_and_reactivate(
    p_restaurant_id UUID,
    p_amount DECIMAL,
    p_payment_type TEXT,
    p_payment_method TEXT DEFAULT 'razorpay',
    p_gateway_id TEXT DEFAULT NULL,
    p_gateway_order_id TEXT DEFAULT NULL
)
RETURNS TABLE(
    success BOOLEAN,
    message TEXT,
    subscription_id UUID,
    payment_id UUID,
    new_end_date TIMESTAMPTZ
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_subscription RECORD;
    v_payment_id UUID;
    v_new_end_date TIMESTAMPTZ;
    v_monthly_price DECIMAL;
    v_setup_fee DECIMAL;
BEGIN
    -- Get pricing from JSONB
    SELECT (value->>0)::DECIMAL INTO v_monthly_price FROM platform_settings WHERE key = 'subscription_monthly_price';
    SELECT (value->>0)::DECIMAL INTO v_setup_fee FROM platform_settings WHERE key = 'subscription_setup_fee';
    
    v_monthly_price := COALESCE(v_monthly_price, 35000);
    v_setup_fee := COALESCE(v_setup_fee, 5000);
    
    -- Get subscription
    SELECT * INTO v_subscription FROM subscriptions WHERE restaurant_id = p_restaurant_id;
    
    IF v_subscription IS NULL THEN
        RETURN QUERY SELECT FALSE, 'Subscription not found'::TEXT, NULL::UUID, NULL::UUID, NULL::TIMESTAMPTZ;
        RETURN;
    END IF;
    
    -- Validate amount
    IF p_payment_type = 'setup_fee' AND p_amount != v_setup_fee THEN
        RETURN QUERY SELECT FALSE, format('Invalid setup fee. Expected ₹%s', v_setup_fee)::TEXT, NULL::UUID, NULL::UUID, NULL::TIMESTAMPTZ;
        RETURN;
    END IF;
    
    IF p_payment_type IN ('monthly_subscription', 'renewal') AND p_amount != v_monthly_price THEN
        RETURN QUERY SELECT FALSE, format('Invalid subscription amount. Expected ₹%s', v_monthly_price)::TEXT, NULL::UUID, NULL::UUID, NULL::TIMESTAMPTZ;
        RETURN;
    END IF;
    
    -- Create payment record
    INSERT INTO payments (
        restaurant_id,
        subscription_id,
        amount,
        payment_type,
        payment_method,
        payment_gateway_id,
        payment_gateway_order_id,
        status,
        payment_date,
        completed_at
    ) VALUES (
        p_restaurant_id,
        v_subscription.id,
        p_amount,
        p_payment_type,
        p_payment_method,
        p_gateway_id,
        p_gateway_order_id,
        'completed',
        NOW(),
        NOW()
    )
    RETURNING id INTO v_payment_id;
    
    -- Calculate new end date
    IF v_subscription.status IN ('suspended', 'grace', 'cancelled') OR 
       COALESCE(v_subscription.trial_ends_at, v_subscription.current_period_end) < NOW() THEN
        -- Expired/Suspended: Start fresh 30-day period
        v_new_end_date := NOW() + INTERVAL '30 days';
    ELSE
        -- Active: Extend from current end
        v_new_end_date := v_subscription.current_period_end + INTERVAL '30 days';
    END IF;
    
    -- Update subscription
    UPDATE subscriptions
    SET
        status = 'active',
        current_period_end = v_new_end_date,
        current_period_start = CASE 
            WHEN status IN ('suspended', 'grace', 'cancelled') THEN NOW()
            ELSE current_period_start
        END,
        setup_fee_paid = CASE WHEN p_payment_type = 'setup_fee' THEN TRUE ELSE setup_fee_paid END,
        trial_ends_at = NULL,
        suspended_at = NULL,
        suspended_reason = NULL,
        updated_at = NOW()
    WHERE id = v_subscription.id;
    
    -- Reactivate restaurant
    UPDATE restaurants
    SET is_active = TRUE, updated_at = NOW()
    WHERE id = p_restaurant_id;
    
    RETURN QUERY SELECT 
        TRUE,
        format('Payment successful! Subscription active until %s', v_new_end_date::DATE)::TEXT,
        v_subscription.id,
        v_payment_id,
        v_new_end_date;
END;
$$;

-- ============================================================================
-- 6. FUNCTION: Manual Suspend/Reactivate (UPDATED)
-- ============================================================================
-- Drop existing function to allow signature change
DROP FUNCTION IF EXISTS toggle_subscription_status(UUID, TEXT, TEXT);
DROP FUNCTION IF EXISTS toggle_subscription_status(UUID, TEXT);

CREATE OR REPLACE FUNCTION toggle_subscription_status(
    p_restaurant_id UUID,
    p_action TEXT,
    p_reason TEXT DEFAULT NULL
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    IF p_action = 'suspend' THEN
        UPDATE subscriptions
        SET 
            status = 'suspended',
            suspended_at = NOW(),
            suspended_reason = COALESCE(p_reason, 'Manually suspended by admin'),
            updated_at = NOW()
        WHERE restaurant_id = p_restaurant_id
        AND status NOT IN ('suspended', 'cancelled');
        
        UPDATE restaurants SET is_active = FALSE WHERE id = p_restaurant_id;
        
    ELSIF p_action = 'reactivate' THEN
        UPDATE subscriptions
        SET 
            status = 'active',
            suspended_at = NULL,
            suspended_reason = NULL,
            updated_at = NOW()
        WHERE restaurant_id = p_restaurant_id;
        
        UPDATE restaurants SET is_active = TRUE WHERE id = p_restaurant_id;
    ELSE
        RETURN FALSE;
    END IF;
    
    RETURN TRUE;
END;
$$;

-- ============================================================================
-- 7. VIEW: Subscription Overview (UPDATED)
-- ============================================================================
CREATE OR REPLACE VIEW subscription_overview AS
SELECT 
    r.id as restaurant_id,
    r.name as restaurant_name,
    r.email,
    r.phone,
    r.is_active,
    s.status as subscription_status,
    s.current_period_start as start_date,
    s.current_period_end,
    s.trial_ends_at,
    s.suspended_at,
    s.suspended_reason,
    s.setup_fee_paid,
    COALESCE(s.trial_ends_at, s.current_period_end) as end_date,
    EXTRACT(DAY FROM (COALESCE(s.trial_ends_at, s.current_period_end) - NOW()))::INTEGER as days_remaining,
    CASE 
        WHEN s.status = 'trial' AND NOW() < s.trial_ends_at THEN TRUE
        WHEN s.status = 'active' AND NOW() < s.current_period_end THEN TRUE
        WHEN s.status = 'grace' THEN TRUE
        ELSE FALSE
    END as has_access,
    (SELECT COUNT(*) FROM payments p WHERE p.restaurant_id = r.id AND p.status = 'completed') as total_payments,
    (SELECT SUM(amount) FROM payments p WHERE p.restaurant_id = r.id AND p.status = 'completed') as total_revenue
FROM restaurants r
LEFT JOIN subscriptions s ON s.restaurant_id = r.id
ORDER BY COALESCE(s.trial_ends_at, s.current_period_end) ASC;

-- ============================================================================
-- 8. RLS POLICIES FOR PAYMENTS
-- ============================================================================
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

-- Payments: Restaurants see only their own
DROP POLICY IF EXISTS payments_restaurant_select ON payments;
CREATE POLICY payments_restaurant_select ON payments
    FOR SELECT
    USING (
        restaurant_id IN (
            SELECT restaurant_id FROM users WHERE id = auth.uid()
        )
    );

-- Payments: Super Admin sees all
DROP POLICY IF EXISTS payments_superadmin_all ON payments;
CREATE POLICY payments_superadmin_all ON payments
    FOR ALL
    USING (
        EXISTS (
            SELECT 1 FROM users 
            WHERE id = auth.uid() 
            AND role = 'super_admin'
        )
    );

-- ============================================================================
-- 9. GRANT PERMISSIONS
-- ============================================================================
GRANT SELECT ON subscription_overview TO authenticated;
GRANT EXECUTE ON FUNCTION check_subscription_status TO authenticated;
GRANT EXECUTE ON FUNCTION process_payment_and_reactivate TO authenticated;
GRANT EXECUTE ON FUNCTION toggle_subscription_status TO authenticated;

-- ============================================================================
-- MIGRATION COMPLETE
-- ============================================================================
-- This migration updates your existing subscription system to support:
-- - Unified pricing (₹35,000/month + ₹5,000 setup)
-- - Payment tracking
-- - Manual suspend/reactivate
-- - Status checking with grace period support
-- 
-- Your existing auto_suspend_expired_subscriptions() function still works!
-- ============================================================================
