-- ============================================================================
-- UNIFIED LOGIN SYSTEM - ROW LEVEL SECURITY POLICIES (FIXED VERSION)
-- ============================================================================
-- Version: 1.1 (Fixed for Supabase permission restrictions)
-- Created: November 2025
-- Description: Strict restaurant isolation and role-based access control
-- ============================================================================

-- IMPORTANT: This version uses public schema instead of auth schema
-- because Supabase restricts direct access to the auth schema

-- ============================================================================
-- HELPER FUNCTIONS (in public schema)
-- ============================================================================
-- Note: Using auth_* prefix to avoid conflicts with existing functions

-- Get current user's restaurant_id
CREATE OR REPLACE FUNCTION public.auth_get_user_restaurant_id()
RETURNS UUID
LANGUAGE SQL
SECURITY DEFINER
STABLE
AS $$
  SELECT restaurant_id 
  FROM public.users 
  WHERE id = auth.uid()
  LIMIT 1;
$$;

COMMENT ON FUNCTION public.auth_get_user_restaurant_id IS 
'Returns the restaurant_id of the currently authenticated user (for unified login system)';

-- Check if current user is owner or platform superadmin
CREATE OR REPLACE FUNCTION public.auth_is_owner_or_superadmin()
RETURNS BOOLEAN
LANGUAGE SQL
SECURITY DEFINER
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 
    FROM public.users 
    WHERE id = auth.uid() 
    AND (
      is_owner = true 
      OR LOWER(role) IN ('owner', 'superadmin')
    )
  )
  OR is_superadmin(auth.uid()); -- Check platform_admins table too
$$;

COMMENT ON FUNCTION public.auth_is_owner_or_superadmin IS 
'Returns true if current user is a restaurant owner or platform superadmin';

-- Get current user's role
CREATE OR REPLACE FUNCTION public.auth_get_user_role()
RETURNS TEXT
LANGUAGE SQL
SECURITY DEFINER
STABLE
AS $$
  SELECT LOWER(role) 
  FROM public.users 
  WHERE id = auth.uid()
  LIMIT 1;
$$;

COMMENT ON FUNCTION public.auth_get_user_role IS 
'Returns the role of the currently authenticated user';

-- Validate restaurant access
CREATE OR REPLACE FUNCTION public.auth_validate_restaurant_access(target_restaurant_id UUID)
RETURNS BOOLEAN
LANGUAGE SQL
SECURITY DEFINER
STABLE
AS $$
  SELECT 
    public.auth_is_owner_or_superadmin() 
    OR 
    public.auth_get_user_restaurant_id() = target_restaurant_id;
$$;

COMMENT ON FUNCTION public.auth_validate_restaurant_access IS 
'Validates if user can access data for the specified restaurant';

-- ============================================================================
-- ORDERS TABLE - STRICT RESTAURANT ISOLATION
-- ============================================================================

-- Drop existing policies if any
DROP POLICY IF EXISTS "orders_staff_select" ON orders;
DROP POLICY IF EXISTS "orders_staff_insert" ON orders;
DROP POLICY IF EXISTS "orders_staff_update" ON orders;
DROP POLICY IF EXISTS "orders_staff_delete" ON orders;
DROP POLICY IF EXISTS "orders_chef_select" ON orders;
DROP POLICY IF EXISTS "orders_chef_update" ON orders;
DROP POLICY IF EXISTS "orders_waiter_select" ON orders;
DROP POLICY IF EXISTS "orders_waiter_update" ON orders;
DROP POLICY IF EXISTS "orders_manager_all" ON orders;
DROP POLICY IF EXISTS "orders_superadmin_all" ON orders;

-- Chef: Can view orders from their restaurant
CREATE POLICY "orders_chef_select"
ON orders FOR SELECT
TO authenticated
USING (
  public.auth_get_user_role() = 'chef'
  AND restaurant_id = public.auth_get_user_restaurant_id()
);

-- Chef: Can update order status for their restaurant
CREATE POLICY "orders_chef_update"
ON orders FOR UPDATE
TO authenticated
USING (
  public.auth_get_user_role() = 'chef'
  AND restaurant_id = public.auth_get_user_restaurant_id()
)
WITH CHECK (
  public.auth_get_user_role() = 'chef'
  AND restaurant_id = public.auth_get_user_restaurant_id()
);

-- Waiter: Can view and update orders from their restaurant
CREATE POLICY "orders_waiter_select"
ON orders FOR SELECT
TO authenticated
USING (
  public.auth_get_user_role() = 'waiter'
  AND restaurant_id = public.auth_get_user_restaurant_id()
);

CREATE POLICY "orders_waiter_update"
ON orders FOR UPDATE
TO authenticated
USING (
  public.auth_get_user_role() = 'waiter'
  AND restaurant_id = public.auth_get_user_restaurant_id()
)
WITH CHECK (
  public.auth_get_user_role() = 'waiter'
  AND restaurant_id = public.auth_get_user_restaurant_id()
);

-- Manager: Full access to orders from their restaurant
CREATE POLICY "orders_manager_all"
ON orders FOR ALL
TO authenticated
USING (
  public.auth_get_user_role() IN ('manager', 'admin')
  AND restaurant_id = public.auth_get_user_restaurant_id()
)
WITH CHECK (
  public.auth_get_user_role() IN ('manager', 'admin')
  AND restaurant_id = public.auth_get_user_restaurant_id()
);

-- SuperAdmin: Full access to all orders
CREATE POLICY "orders_superadmin_all"
ON orders FOR ALL
TO authenticated
USING (public.auth_is_owner_or_superadmin())
WITH CHECK (public.auth_is_owner_or_superadmin());

-- ============================================================================
-- TABLES TABLE - STRICT RESTAURANT ISOLATION
-- ============================================================================

DROP POLICY IF EXISTS "tables_staff_select" ON tables;
DROP POLICY IF EXISTS "tables_staff_update" ON tables;
DROP POLICY IF EXISTS "tables_waiter_select" ON tables;
DROP POLICY IF EXISTS "tables_waiter_update" ON tables;
DROP POLICY IF EXISTS "tables_manager_all" ON tables;
DROP POLICY IF EXISTS "tables_superadmin_all" ON tables;

-- Waiter: Can view and update tables from their restaurant
CREATE POLICY "tables_waiter_select"
ON tables FOR SELECT
TO authenticated
USING (
  public.auth_get_user_role() = 'waiter'
  AND restaurant_id = public.auth_get_user_restaurant_id()
);

CREATE POLICY "tables_waiter_update"
ON tables FOR UPDATE
TO authenticated
USING (
  public.auth_get_user_role() = 'waiter'
  AND restaurant_id = public.auth_get_user_restaurant_id()
)
WITH CHECK (
  public.auth_get_user_role() = 'waiter'
  AND restaurant_id = public.auth_get_user_restaurant_id()
);

-- Manager: Full access to tables from their restaurant
CREATE POLICY "tables_manager_all"
ON tables FOR ALL
TO authenticated
USING (
  public.auth_get_user_role() IN ('manager', 'admin')
  AND restaurant_id = public.auth_get_user_restaurant_id()
)
WITH CHECK (
  public.auth_get_user_role() IN ('manager', 'admin')
  AND restaurant_id = public.auth_get_user_restaurant_id()
);

-- SuperAdmin: Full access to all tables
CREATE POLICY "tables_superadmin_all"
ON tables FOR ALL
TO authenticated
USING (public.auth_is_owner_or_superadmin())
WITH CHECK (public.auth_is_owner_or_superadmin());

-- ============================================================================
-- MENU_ITEMS TABLE - STRICT RESTAURANT ISOLATION
-- ============================================================================

DROP POLICY IF EXISTS "menu_items_staff_select" ON menu_items;
DROP POLICY IF EXISTS "menu_items_chef_select" ON menu_items;
DROP POLICY IF EXISTS "menu_items_waiter_select" ON menu_items;
DROP POLICY IF EXISTS "menu_items_manager_all" ON menu_items;
DROP POLICY IF EXISTS "menu_items_superadmin_all" ON menu_items;

-- Chef: Can view menu items from their restaurant
CREATE POLICY "menu_items_chef_select"
ON menu_items FOR SELECT
TO authenticated
USING (
  public.auth_get_user_role() = 'chef'
  AND restaurant_id = public.auth_get_user_restaurant_id()
);

-- Waiter: Can view menu items from their restaurant
CREATE POLICY "menu_items_waiter_select"
ON menu_items FOR SELECT
TO authenticated
USING (
  public.auth_get_user_role() = 'waiter'
  AND restaurant_id = public.auth_get_user_restaurant_id()
);

-- Manager: Full access to menu items from their restaurant
CREATE POLICY "menu_items_manager_all"
ON menu_items FOR ALL
TO authenticated
USING (
  public.auth_get_user_role() IN ('manager', 'admin')
  AND restaurant_id = public.auth_get_user_restaurant_id()
)
WITH CHECK (
  public.auth_get_user_role() IN ('manager', 'admin')
  AND restaurant_id = public.auth_get_user_restaurant_id()
);

-- SuperAdmin: Full access to all menu items
CREATE POLICY "menu_items_superadmin_all"
ON menu_items FOR ALL
TO authenticated
USING (public.auth_is_owner_or_superadmin())
WITH CHECK (public.auth_is_owner_or_superadmin());

-- ============================================================================
-- USERS TABLE - STRICT SELF AND RESTAURANT ISOLATION
-- ============================================================================

DROP POLICY IF EXISTS "users_view_own_restaurant" ON users;
DROP POLICY IF EXISTS "users_view_self" ON users;
DROP POLICY IF EXISTS "users_self_select" ON users;
DROP POLICY IF EXISTS "users_self_update" ON users;
DROP POLICY IF EXISTS "users_manager_select" ON users;
DROP POLICY IF EXISTS "users_manager_insert" ON users;
DROP POLICY IF EXISTS "users_manager_update" ON users;
DROP POLICY IF EXISTS "users_manager_delete" ON users;
DROP POLICY IF EXISTS "users_superadmin_all" ON users;

-- Users can view their own profile
CREATE POLICY "users_self_select"
ON users FOR SELECT
TO authenticated
USING (id = auth.uid());

-- Users can update their own profile (limited fields)
CREATE POLICY "users_self_update"
ON users FOR UPDATE
TO authenticated
USING (id = auth.uid())
WITH CHECK (
  id = auth.uid()
  -- Prevent users from changing their own role or restaurant
  AND role = (SELECT role FROM users WHERE id = auth.uid())
  AND restaurant_id = (SELECT restaurant_id FROM users WHERE id = auth.uid())
);

-- Manager: Can view and manage users from their restaurant
CREATE POLICY "users_manager_select"
ON users FOR SELECT
TO authenticated
USING (
  public.auth_get_user_role() IN ('manager', 'admin')
  AND restaurant_id = public.auth_get_user_restaurant_id()
);

CREATE POLICY "users_manager_insert"
ON users FOR INSERT
TO authenticated
WITH CHECK (
  public.auth_get_user_role() IN ('manager', 'admin')
  AND restaurant_id = public.auth_get_user_restaurant_id()
);

CREATE POLICY "users_manager_update"
ON users FOR UPDATE
TO authenticated
USING (
  public.auth_get_user_role() IN ('manager', 'admin')
  AND restaurant_id = public.auth_get_user_restaurant_id()
)
WITH CHECK (
  public.auth_get_user_role() IN ('manager', 'admin')
  AND restaurant_id = public.auth_get_user_restaurant_id()
);

CREATE POLICY "users_manager_delete"
ON users FOR DELETE
TO authenticated
USING (
  public.auth_get_user_role() IN ('manager', 'admin')
  AND restaurant_id = public.auth_get_user_restaurant_id()
);

-- SuperAdmin: Full access to all users
CREATE POLICY "users_superadmin_all"
ON users FOR ALL
TO authenticated
USING (public.auth_is_owner_or_superadmin())
WITH CHECK (public.auth_is_owner_or_superadmin());

-- ============================================================================
-- PAYMENTS TABLE - STRICT RESTAURANT ISOLATION (Billing Payments)
-- ============================================================================
-- Note: This table is for restaurant billing/subscription payments

DROP POLICY IF EXISTS "payments_staff_select" ON payments;
DROP POLICY IF EXISTS "payments_manager_select" ON payments;
DROP POLICY IF EXISTS "payments_manager_all" ON payments;
DROP POLICY IF EXISTS "payments_superadmin_all" ON payments;

-- Manager: Can view billing payments for their restaurant
CREATE POLICY "payments_manager_select"
ON payments FOR SELECT
TO authenticated
USING (
  public.auth_get_user_role() IN ('manager', 'admin')
  AND restaurant_id = public.auth_get_user_restaurant_id()
);

-- Manager: No insert/update/delete - only superadmin can manage billing
-- SuperAdmin: Full access to all billing payments
CREATE POLICY "payments_superadmin_all"
ON payments FOR ALL
TO authenticated
USING (public.auth_is_owner_or_superadmin())
WITH CHECK (public.auth_is_owner_or_superadmin());

-- ============================================================================
-- ORDER_PAYMENTS TABLE - STRICT RESTAURANT ISOLATION (Customer Order Payments)
-- ============================================================================
-- Note: This table is for customer order payments via Razorpay

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'order_payments') THEN
    DROP POLICY IF EXISTS "order_payments_staff_select" ON order_payments;
    DROP POLICY IF EXISTS "order_payments_manager_all" ON order_payments;
    DROP POLICY IF EXISTS "order_payments_superadmin_all" ON order_payments;

    -- Staff can view order payments from their restaurant
    EXECUTE 'CREATE POLICY "order_payments_staff_select"
    ON order_payments FOR SELECT
    TO authenticated
    USING (restaurant_id = public.auth_get_user_restaurant_id())';

    -- Manager: Full access to order payments from their restaurant
    EXECUTE 'CREATE POLICY "order_payments_manager_all"
    ON order_payments FOR ALL
    TO authenticated
    USING (
      public.auth_get_user_role() IN (''manager'', ''admin'')
      AND restaurant_id = public.auth_get_user_restaurant_id()
    )
    WITH CHECK (
      public.auth_get_user_role() IN (''manager'', ''admin'')
      AND restaurant_id = public.auth_get_user_restaurant_id()
    )';

    -- SuperAdmin: Full access to all order payments
    EXECUTE 'CREATE POLICY "order_payments_superadmin_all"
    ON order_payments FOR ALL
    TO authenticated
    USING (public.auth_is_owner_or_superadmin())
    WITH CHECK (public.auth_is_owner_or_superadmin())';
  END IF;
END $$;

-- ============================================================================
-- FEEDBACKS TABLE - STRICT RESTAURANT ISOLATION
-- ============================================================================

DROP POLICY IF EXISTS "feedbacks_staff_select" ON feedbacks;
DROP POLICY IF EXISTS "feedbacks_manager_all" ON feedbacks;
DROP POLICY IF EXISTS "feedbacks_superadmin_all" ON feedbacks;

-- Staff can view feedbacks for orders from their restaurant
CREATE POLICY "feedbacks_staff_select"
ON feedbacks FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM orders 
    WHERE orders.id = feedbacks.order_id 
    AND orders.restaurant_id = public.auth_get_user_restaurant_id()
  )
);

-- Manager: Full access to feedbacks from their restaurant
CREATE POLICY "feedbacks_manager_all"
ON feedbacks FOR ALL
TO authenticated
USING (
  public.auth_get_user_role() IN ('manager', 'admin')
  AND EXISTS (
    SELECT 1 FROM orders 
    WHERE orders.id = feedbacks.order_id 
    AND orders.restaurant_id = public.auth_get_user_restaurant_id()
  )
);

-- SuperAdmin: Full access to all feedbacks
CREATE POLICY "feedbacks_superadmin_all"
ON feedbacks FOR ALL
TO authenticated
USING (public.auth_is_owner_or_superadmin())
WITH CHECK (public.auth_is_owner_or_superadmin());

-- ============================================================================
-- ACTIVITY_LOGS TABLE - RESTAURANT ISOLATION (if table exists)
-- ============================================================================

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'activity_logs') THEN
    DROP POLICY IF EXISTS "activity_logs_manager_select" ON activity_logs;
    DROP POLICY IF EXISTS "activity_logs_superadmin_all" ON activity_logs;

    -- Manager: Can view activity logs from their restaurant
    EXECUTE 'CREATE POLICY "activity_logs_manager_select"
    ON activity_logs FOR SELECT
    TO authenticated
    USING (
      public.auth_get_user_role() IN (''manager'', ''admin'')
      AND restaurant_id = public.auth_get_user_restaurant_id()
    )';

    -- SuperAdmin: Full access to all activity logs
    EXECUTE 'CREATE POLICY "activity_logs_superadmin_all"
    ON activity_logs FOR ALL
    TO authenticated
    USING (public.auth_is_owner_or_superadmin())
    WITH CHECK (public.auth_is_owner_or_superadmin())';
  END IF;
END $$;

-- ============================================================================
-- SUBSCRIPTIONS TABLE - MANAGER VIEW ONLY (if table exists)
-- ============================================================================

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'subscriptions') THEN
    DROP POLICY IF EXISTS "subscriptions_manager_select" ON subscriptions;
    DROP POLICY IF EXISTS "subscriptions_superadmin_all" ON subscriptions;

    -- Manager: Can view their restaurant's subscription
    EXECUTE 'CREATE POLICY "subscriptions_manager_select"
    ON subscriptions FOR SELECT
    TO authenticated
    USING (
      public.auth_get_user_role() IN (''manager'', ''admin'')
      AND restaurant_id = public.auth_get_user_restaurant_id()
    )';

    -- SuperAdmin: Full access to all subscriptions
    EXECUTE 'CREATE POLICY "subscriptions_superadmin_all"
    ON subscriptions FOR ALL
    TO authenticated
    USING (public.auth_is_owner_or_superadmin())
    WITH CHECK (public.auth_is_owner_or_superadmin())';
  END IF;
END $$;

-- ============================================================================
-- VALIDATION AND TESTING
-- ============================================================================

-- Test function to validate RLS setup
CREATE OR REPLACE FUNCTION test_rls_isolation()
RETURNS TABLE (
  test_name TEXT,
  passed BOOLEAN,
  message TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Test 1: Helper functions exist
  RETURN QUERY SELECT 
    'Helper Functions Exist'::TEXT,
    (
      SELECT COUNT(*) = 4 FROM pg_proc 
      WHERE proname IN (
        'auth_get_user_restaurant_id',
        'auth_is_owner_or_superadmin',
        'auth_get_user_role',
        'auth_validate_restaurant_access'
      )
      AND pronamespace = (SELECT oid FROM pg_namespace WHERE nspname = 'public')
    ),
    'All helper functions are created'::TEXT;
  
  -- Test 2: RLS enabled on critical tables
  RETURN QUERY SELECT 
    'RLS Enabled'::TEXT,
    (
      SELECT COUNT(*) >= 5 FROM pg_tables 
      WHERE schemaname = 'public' 
      AND tablename IN ('orders', 'tables', 'menu_items', 'users', 'payments')
      AND rowsecurity = true
    ),
    'RLS enabled on all critical tables'::TEXT;
  
  -- Test 3: Policies exist
  RETURN QUERY SELECT 
    'Policies Created'::TEXT,
    (SELECT COUNT(*) >= 20 FROM pg_policies WHERE schemaname = 'public'),
    'Sufficient policies created'::TEXT;
  
  RETURN;
END;
$$;

-- ============================================================================
-- INDEXES FOR PERFORMANCE
-- ============================================================================

-- Index for faster restaurant_id lookups
CREATE INDEX IF NOT EXISTS idx_users_restaurant_id ON users(restaurant_id) WHERE restaurant_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_users_is_owner ON users(is_owner) WHERE is_owner = true;

-- ============================================================================
-- COMPLETION
-- ============================================================================

-- Run validation test
SELECT * FROM test_rls_isolation();

-- Display success message
DO $$
BEGIN
  RAISE NOTICE '✅ Unified Login RLS System installed successfully!';
  RAISE NOTICE 'Helper functions: auth_get_user_restaurant_id(), auth_is_owner_or_superadmin(), auth_get_user_role(), auth_validate_restaurant_access()';
  RAISE NOTICE 'RLS policies applied to: orders, tables, menu_items, users, payments (billing), feedbacks';
  RAISE NOTICE 'Conditional policies for: order_payments, activity_logs, subscriptions';
  RAISE NOTICE 'Note: Compatible with existing is_superadmin(user_id) function';
END $$;
