-- Check existing restaurant slugs to avoid duplicates

-- Step 1: Show all existing restaurant slugs
SELECT 
  id,
  name,
  slug,
  is_active,
  created_at,
  '🏪 Existing restaurant' as type
FROM restaurants
ORDER BY created_at DESC;

-- Step 2: Check for duplicate slugs (shouldn't exist but let's verify)
SELECT 
  slug,
  COUNT(*) as count,
  STRING_AGG(name, ', ') as restaurant_names,
  CASE 
    WHEN COUNT(*) > 1 THEN '❌ DUPLICATE - needs fixing'
    ELSE '✅ Unique'
  END as status
FROM restaurants
GROUP BY slug
HAVING COUNT(*) > 1;

-- Step 3: Show all slugs in use (for reference when creating new ones)
SELECT 
  slug,
  name,
  '⚠️ This slug is taken' as note
FROM restaurants
ORDER BY slug;

-- Step 4: If you want to delete inactive/test restaurants, uncomment below:
-- Shows restaurants that might be safe to delete

SELECT 
  id,
  name,
  slug,
  is_active,
  created_at,
  (SELECT COUNT(*) FROM users WHERE restaurant_id = restaurants.id) as staff_count,
  (SELECT COUNT(*) FROM orders WHERE restaurant_id = restaurants.id) as order_count,
  CASE 
    WHEN is_active = false AND 
         (SELECT COUNT(*) FROM users WHERE restaurant_id = restaurants.id) = 0 AND
         (SELECT COUNT(*) FROM orders WHERE restaurant_id = restaurants.id) = 0 
    THEN '✅ Safe to delete (inactive, no staff, no orders)'
    ELSE 'Has data - review before deleting'
  END as can_delete
FROM restaurants
ORDER BY created_at DESC;

-- To delete a specific restaurant (uncomment and replace with actual ID):
-- DELETE FROM restaurants WHERE id = 'YOUR-RESTAURANT-ID-HERE';
