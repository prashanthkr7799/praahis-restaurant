-- ============================================================================
-- FIX: Enable anon access to restaurants table for customer QR code lookups
-- ============================================================================
-- This allows unauthenticated customers to look up restaurants by slug/name
-- when scanning QR codes at tables
-- ============================================================================

-- Drop existing policy if it exists
DROP POLICY IF EXISTS restaurants_read_public ON public.restaurants;

-- Create policy allowing anon to read active restaurants
CREATE POLICY restaurants_read_public ON public.restaurants
FOR SELECT TO anon, authenticated
USING (is_active = TRUE);

-- Verify RLS is enabled
ALTER TABLE public.restaurants ENABLE ROW LEVEL SECURITY;

-- Grant SELECT permission to anon role
GRANT SELECT ON public.restaurants TO anon;
GRANT SELECT ON public.restaurants TO authenticated;

-- Success message
DO $$
BEGIN
    RAISE NOTICE '
    ╔════════════════════════════════════════════════════════════════╗
    ║   ✅ RESTAURANTS ANON ACCESS ENABLED                           ║
    ╠════════════════════════════════════════════════════════════════╣
    ║                                                                ║
    ║   Anonymous users can now:                                     ║
    ║   - Read active restaurants                                    ║
    ║   - Look up by slug or name for QR code scanning               ║
    ║                                                                ║
    ║   Policy: restaurants_read_public                              ║
    ║   Applies to: anon, authenticated roles                        ║
    ║   Condition: is_active = TRUE                                  ║
    ║                                                                ║
    ╚════════════════════════════════════════════════════════════════╝
    ';
END $$;
