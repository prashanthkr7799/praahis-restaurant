-- ============================================================================
-- FIX MISSING SUBSCRIPTIONS
-- ============================================================================
-- This script creates subscriptions for restaurants that don't have one
-- Run this if you see restaurants in Restaurant Management but not in Subscriptions
-- ============================================================================

-- Step 1: Find restaurants without subscriptions
SELECT 
    r.id,
    r.name,
    r.slug,
    r.subscription_status,
    r.created_at
FROM restaurants r
LEFT JOIN subscriptions s ON s.restaurant_id = r.id
WHERE s.id IS NULL
ORDER BY r.created_at DESC;

-- Step 2: Create missing subscriptions
-- This will create trial subscriptions for any restaurant without one
INSERT INTO subscriptions (
    restaurant_id,
    plan_name,
    status,
    price,
    billing_cycle,
    current_period_start,
    current_period_end,
    trial_ends_at
)
SELECT 
    r.id as restaurant_id,
    COALESCE(r.subscription_status, 'trial') as plan_name,
    'active' as status,
    CASE 
        WHEN COALESCE(r.subscription_status, 'trial') = 'trial' THEN 0
        WHEN COALESCE(r.subscription_status, 'trial') = 'basic' THEN 999
        WHEN COALESCE(r.subscription_status, 'trial') = 'pro' THEN 2999
        WHEN COALESCE(r.subscription_status, 'trial') = 'enterprise' THEN 9999
        ELSE 0
    END as price,
    'monthly' as billing_cycle,
    NOW() as current_period_start,
    CASE 
        WHEN COALESCE(r.subscription_status, 'trial') = 'trial' THEN NOW() + INTERVAL '14 days'
        ELSE NOW() + INTERVAL '30 days'
    END as current_period_end,
    CASE 
        WHEN COALESCE(r.subscription_status, 'trial') = 'trial' THEN NOW() + INTERVAL '14 days'
        ELSE NULL
    END as trial_ends_at
FROM restaurants r
LEFT JOIN subscriptions s ON s.restaurant_id = r.id
WHERE s.id IS NULL;

-- Step 3: Verify all restaurants now have subscriptions
SELECT 
    r.name as restaurant_name,
    r.subscription_status,
    s.plan_name,
    s.status,
    s.price,
    s.trial_ends_at,
    s.current_period_end,
    EXTRACT(DAY FROM COALESCE(s.trial_ends_at, s.current_period_end) - NOW())::INTEGER as days_remaining
FROM restaurants r
LEFT JOIN subscriptions s ON s.restaurant_id = r.id
ORDER BY r.created_at DESC;

-- ============================================================================
-- RESULT
-- ============================================================================
-- After running this:
-- ✅ All restaurants will have subscriptions
-- ✅ They will appear in Subscriptions Management
-- ✅ Trial plans get 14 days, paid plans get 30 days
-- ============================================================================
