-- Configure JWT token expiry for longer sessions
-- This extends the session timeout from 1 hour to 4 hours

-- NOTE: JWT expiry is configured in Supabase Dashboard, not via SQL
-- You need to update it in the Supabase Dashboard:
-- Go to: Authentication → Settings → JWT Expiry

-- However, we can check current session timeouts:

-- Check auth config (read-only, for reference)
SELECT 
  name,
  setting,
  short_desc
FROM pg_settings
WHERE name LIKE '%jwt%' OR name LIKE '%session%' OR name LIKE '%timeout%'
ORDER BY name;

-- To extend JWT expiry to 4 hours (14400 seconds):
-- 1. Go to your Supabase Project Dashboard
-- 2. Click "Authentication" in the left sidebar
-- 3. Click "Settings" tab
-- 4. Scroll to "JWT Settings"
-- 5. Change "JWT expiry" from 3600 (1 hour) to 14400 (4 hours)
-- 6. Click "Save"

-- Alternative: Use Supabase CLI or API to update (requires project access token)
-- Example using Supabase Management API:
/*
PUT https://api.supabase.com/v1/projects/{ref}/config/auth

{
  "JWT_EXPIRY": 14400,
  "REFRESH_TOKEN_REUSE_INTERVAL": 10
}
*/

-- IMPORTANT: After changing JWT expiry:
-- 1. All users must log out and log back in
-- 2. Or wait for their current token to expire and auto-refresh
-- 3. New logins will have 4-hour sessions

SELECT 
  '⚠️ JWT expiry must be changed in Supabase Dashboard' as note,
  'Go to: Authentication → Settings → JWT Expiry' as instruction,
  'Change from 3600 (1 hour) to 14400 (4 hours)' as action;
