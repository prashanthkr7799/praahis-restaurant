-- IMPORTANT: Run this FIRST to prevent future orphaned users
-- This creates the missing RPC function that StaffForm.jsx needs

-- Check if the function exists
SELECT 
  proname as function_name,
  CASE 
    WHEN proname IS NOT NULL THEN '✅ Function exists'
    ELSE '❌ Function missing'
  END as status
FROM pg_proc
WHERE proname = 'admin_upsert_user_profile'
LIMIT 1;

-- If the above shows ❌ Function missing, the function doesn't exist yet
-- This is why staff creation creates orphaned users!
