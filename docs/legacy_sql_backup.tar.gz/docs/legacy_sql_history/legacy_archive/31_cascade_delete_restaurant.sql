-- ============================================================================
-- CASCADE DELETE: Auto-delete all restaurant data when restaurant is deleted
-- ============================================================================
-- This ensures that when a restaurant is deleted, ALL related data is removed:
-- - Staff/Users
-- - Menu Items
-- - Tables
-- - Orders & Order Items
-- - Payments
-- - Feedbacks
-- - Table Sessions
-- - Notifications
-- ============================================================================

-- ============================================================================
-- STEP 1: Drop existing foreign keys (they don't have CASCADE)
-- ============================================================================

-- Users table
ALTER TABLE users 
DROP CONSTRAINT IF EXISTS users_restaurant_id_fkey;

-- Menu Items table
ALTER TABLE menu_items 
DROP CONSTRAINT IF EXISTS menu_items_restaurant_id_fkey;

-- Tables table
ALTER TABLE tables 
DROP CONSTRAINT IF EXISTS tables_restaurant_id_fkey;

-- Orders table
ALTER TABLE orders 
DROP CONSTRAINT IF EXISTS orders_restaurant_id_fkey;

-- Payments table
ALTER TABLE payments 
DROP CONSTRAINT IF EXISTS payments_restaurant_id_fkey;

-- Feedbacks table
ALTER TABLE feedbacks 
DROP CONSTRAINT IF EXISTS feedbacks_restaurant_id_fkey;

-- Table Sessions table
ALTER TABLE table_sessions 
DROP CONSTRAINT IF EXISTS table_sessions_restaurant_id_fkey;

-- Notifications table
ALTER TABLE notifications 
DROP CONSTRAINT IF EXISTS notifications_restaurant_id_fkey;

-- Subscriptions table
ALTER TABLE subscriptions 
DROP CONSTRAINT IF EXISTS subscriptions_restaurant_id_fkey;


-- ============================================================================
-- STEP 2: Re-create foreign keys WITH CASCADE DELETE
-- ============================================================================

-- Users: Delete all staff when restaurant is deleted
ALTER TABLE users 
ADD CONSTRAINT users_restaurant_id_fkey 
FOREIGN KEY (restaurant_id) 
REFERENCES restaurants(id) 
ON DELETE CASCADE;

-- Menu Items: Delete all menu items when restaurant is deleted
ALTER TABLE menu_items 
ADD CONSTRAINT menu_items_restaurant_id_fkey 
FOREIGN KEY (restaurant_id) 
REFERENCES restaurants(id) 
ON DELETE CASCADE;

-- Tables: Delete all tables when restaurant is deleted
ALTER TABLE tables 
ADD CONSTRAINT tables_restaurant_id_fkey 
FOREIGN KEY (restaurant_id) 
REFERENCES restaurants(id) 
ON DELETE CASCADE;

-- Orders: Delete all orders when restaurant is deleted
ALTER TABLE orders 
ADD CONSTRAINT orders_restaurant_id_fkey 
FOREIGN KEY (restaurant_id) 
REFERENCES restaurants(id) 
ON DELETE CASCADE;

-- Payments: Delete all payments when restaurant is deleted
ALTER TABLE payments 
ADD CONSTRAINT payments_restaurant_id_fkey 
FOREIGN KEY (restaurant_id) 
REFERENCES restaurants(id) 
ON DELETE CASCADE;

-- Feedbacks: Delete all feedbacks when restaurant is deleted
ALTER TABLE feedbacks 
ADD CONSTRAINT feedbacks_restaurant_id_fkey 
FOREIGN KEY (restaurant_id) 
REFERENCES restaurants(id) 
ON DELETE CASCADE;

-- Table Sessions: Delete all sessions when restaurant is deleted
ALTER TABLE table_sessions 
ADD CONSTRAINT table_sessions_restaurant_id_fkey 
FOREIGN KEY (restaurant_id) 
REFERENCES restaurants(id) 
ON DELETE CASCADE;

-- Notifications: Delete all notifications when restaurant is deleted
ALTER TABLE notifications 
ADD CONSTRAINT notifications_restaurant_id_fkey 
FOREIGN KEY (restaurant_id) 
REFERENCES restaurants(id) 
ON DELETE CASCADE;

-- Subscriptions: Delete subscription when restaurant is deleted
ALTER TABLE subscriptions 
ADD CONSTRAINT subscriptions_restaurant_id_fkey 
FOREIGN KEY (restaurant_id) 
REFERENCES restaurants(id) 
ON DELETE CASCADE;


-- ============================================================================
-- STEP 3: Handle order_payments (CASCADE through orders and restaurants)
-- ============================================================================
-- Order payments should be deleted when their parent order or restaurant is deleted
-- NOTE: order_items are stored as JSONB in orders.items, not a separate table

-- Check if order_payments table exists before modifying
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'order_payments') THEN
    -- Cascade when order is deleted
    ALTER TABLE order_payments 
    DROP CONSTRAINT IF EXISTS order_payments_order_id_fkey;

    ALTER TABLE order_payments 
    ADD CONSTRAINT order_payments_order_id_fkey 
    FOREIGN KEY (order_id) 
    REFERENCES orders(id) 
    ON DELETE CASCADE;

    -- Cascade when restaurant is deleted
    ALTER TABLE order_payments 
    DROP CONSTRAINT IF EXISTS order_payments_restaurant_id_fkey;

    ALTER TABLE order_payments 
    ADD CONSTRAINT order_payments_restaurant_id_fkey 
    FOREIGN KEY (restaurant_id) 
    REFERENCES restaurants(id) 
    ON DELETE CASCADE;
  END IF;
END $$;


-- ============================================================================
-- STEP 4: Handle table relationships
-- ============================================================================
-- Orders should SET NULL when table is deleted (preserve order history)
-- We use SET NULL instead of CASCADE because we want to keep order records
-- even if the table is deleted

ALTER TABLE orders 
DROP CONSTRAINT IF EXISTS orders_table_id_fkey;

ALTER TABLE orders 
ADD CONSTRAINT orders_table_id_fkey 
FOREIGN KEY (table_id) 
REFERENCES tables(id) 
ON DELETE SET NULL;

-- Table sessions should cascade when table is deleted
ALTER TABLE table_sessions 
DROP CONSTRAINT IF EXISTS table_sessions_table_id_fkey;

ALTER TABLE table_sessions 
ADD CONSTRAINT table_sessions_table_id_fkey 
FOREIGN KEY (table_id) 
REFERENCES tables(id) 
ON DELETE CASCADE;


-- ============================================================================
-- STEP 5: Verify CASCADE is set up correctly
-- ============================================================================

SELECT 
  'Cascade Delete Setup' as check_name,
  tc.table_name,
  kcu.column_name,
  ccu.table_name AS foreign_table_name,
  rc.delete_rule
FROM information_schema.table_constraints AS tc 
JOIN information_schema.key_column_usage AS kcu
  ON tc.constraint_name = kcu.constraint_name
  AND tc.table_schema = kcu.table_schema
JOIN information_schema.constraint_column_usage AS ccu
  ON ccu.constraint_name = tc.constraint_name
  AND ccu.table_schema = tc.table_schema
JOIN information_schema.referential_constraints AS rc
  ON rc.constraint_name = tc.constraint_name
WHERE tc.constraint_type = 'FOREIGN KEY' 
  AND (ccu.table_name = 'restaurants' OR ccu.table_name = 'orders' OR ccu.table_name = 'tables' OR ccu.table_name = 'menu_items')
  AND tc.table_schema = 'public'
ORDER BY ccu.table_name, tc.table_name;


-- ============================================================================
-- EXPECTED RESULTS:
-- ============================================================================
-- All foreign keys pointing to 'restaurants' should show delete_rule = 'CASCADE'
-- All foreign keys pointing to 'orders', 'tables', 'menu_items' should show 'CASCADE'
--
-- When you delete a restaurant, this will automatically delete:
-- ✅ All staff/users
-- ✅ All menu items
-- ✅ All tables
-- ✅ All orders (and their order_items, order_payments)
-- ✅ All payments
-- ✅ All feedbacks
-- ✅ All table sessions
-- ✅ All notifications
-- ✅ The subscription
--
-- ============================================================================
-- USAGE:
-- ============================================================================
-- To delete a restaurant and ALL its data:
-- DELETE FROM restaurants WHERE id = 'restaurant-id-here';
--
-- This will automatically clean up everything!
-- ============================================================================
