-- ============================================================================
-- DIAGNOSTIC SCRIPT - Find and Fix Issues
-- ============================================================================
-- Run this if you encounter errors during deployment
-- ============================================================================

\echo '============================================================================'
\echo 'RUNNING DIAGNOSTICS'
\echo '============================================================================'

-- Check if tables exist
\echo 'Checking existing tables...'
SELECT 
    tablename,
    schemaname
FROM pg_tables 
WHERE schemaname = 'public' 
AND tablename IN ('billing', 'payments')
ORDER BY tablename;

-- Check if old tables have data
\echo 'Checking for existing data...'
DO $$
DECLARE
    v_billing_count INT;
    v_payments_count INT;
BEGIN
    SELECT COUNT(*) INTO v_billing_count FROM billing;
    SELECT COUNT(*) INTO v_payments_count FROM payments;
    
    RAISE NOTICE 'Existing billing records: %', v_billing_count;
    RAISE NOTICE 'Existing payment records: %', v_payments_count;
    
    IF v_billing_count > 0 OR v_payments_count > 0 THEN
        RAISE NOTICE '⚠️  WARNING: Existing data found. Consider backing up before proceeding.';
    END IF;
EXCEPTION
    WHEN undefined_table THEN
        RAISE NOTICE '✅ No existing tables found. Safe to proceed.';
END $$;

-- Check for existing functions
\echo 'Checking existing functions...'
SELECT 
    routine_name,
    routine_type
FROM information_schema.routines
WHERE routine_schema = 'public'
AND routine_name LIKE '%bill%' OR routine_name LIKE '%payment%'
ORDER BY routine_name;

-- Check for existing triggers
\echo 'Checking existing triggers...'
SELECT 
    trigger_name,
    event_object_table,
    action_statement
FROM information_schema.triggers
WHERE trigger_schema = 'public'
AND (event_object_table IN ('billing', 'payments') 
     OR trigger_name LIKE '%billing%' 
     OR trigger_name LIKE '%payment%')
ORDER BY event_object_table, trigger_name;

-- Check for RLS policies
\echo 'Checking RLS policies...'
SELECT 
    schemaname,
    tablename,
    policyname,
    permissive,
    roles,
    cmd
FROM pg_policies
WHERE schemaname = 'public'
AND tablename IN ('billing', 'payments')
ORDER BY tablename, policyname;

-- Check column existence in payments table
\echo 'Checking payments table structure...'
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'payments') THEN
        SELECT column_name, data_type 
        FROM information_schema.columns 
        WHERE table_name = 'payments' 
        AND table_schema = 'public'
        ORDER BY ordinal_position;
    ELSE
        RAISE NOTICE 'Payments table does not exist yet.';
    END IF;
END $$;

\echo '============================================================================'
\echo 'DIAGNOSTIC COMPLETE'
\echo '============================================================================'
\echo ''
\echo 'If you see errors above, run this cleanup script:'
\echo ''
\echo 'DROP TABLE IF EXISTS payments CASCADE;'
\echo 'DROP TABLE IF EXISTS billing CASCADE;'
\echo 'DROP FUNCTION IF EXISTS calculate_billing_amount CASCADE;'
\echo 'DROP FUNCTION IF EXISTS generate_monthly_bills CASCADE;'
\echo 'DROP FUNCTION IF EXISTS mark_bill_as_paid CASCADE;'
\echo 'DROP FUNCTION IF EXISTS suspend_overdue_restaurants CASCADE;'
\echo 'DROP FUNCTION IF EXISTS get_restaurant_billing_summary CASCADE;'
\echo ''
\echo 'Then run: \\i database/40_billing_payments_system.sql'
\echo ''
