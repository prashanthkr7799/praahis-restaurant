-- =============================================
-- Storage Buckets for File Uploads
-- =============================================
-- Purpose: Create storage buckets for menu images and other uploads
-- =============================================

-- Create menu-images bucket if it doesn't exist
insert into storage.buckets (id, name, public)
values ('menu-images', 'menu-images', true)
on conflict (id) do nothing;

-- Set up RLS policies for menu-images bucket

-- Drop existing policies if they exist
drop policy if exists "Public Access for Menu Images" on storage.objects;
drop policy if exists "Authenticated users can upload menu images" on storage.objects;
drop policy if exists "Authenticated users can update menu images" on storage.objects;
drop policy if exists "Authenticated users can delete menu images" on storage.objects;

-- Allow anyone to read menu images (public bucket)
create policy "Public Access for Menu Images"
on storage.objects for select
using ( bucket_id = 'menu-images' );

-- Allow authenticated users to upload menu images
create policy "Authenticated users can upload menu images"
on storage.objects for insert
with check (
  bucket_id = 'menu-images'
  and auth.role() = 'authenticated'
);

-- Allow authenticated users to update their menu images
create policy "Authenticated users can update menu images"
on storage.objects for update
using (
  bucket_id = 'menu-images'
  and auth.role() = 'authenticated'
);

-- Allow authenticated users to delete menu images
create policy "Authenticated users can delete menu images"
on storage.objects for delete
using (
  bucket_id = 'menu-images'
  and auth.role() = 'authenticated'
);

-- Success
do $$
begin
  raise notice 'Storage buckets and policies created successfully.';
end $$;
