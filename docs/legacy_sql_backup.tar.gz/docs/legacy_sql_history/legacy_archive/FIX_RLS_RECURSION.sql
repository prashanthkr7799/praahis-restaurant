-- ============================================================================
-- CORRECT RLS POLICIES FOR SUPERADMIN
-- ============================================================================
-- This fixes infinite recursion by using proper policy conditions
-- Safe to run multiple times
-- ============================================================================

-- ============================================================================
-- STEP 1: Clean up all existing problematic policies
-- ============================================================================
DROP POLICY IF EXISTS "owners_read_all_users" ON public.users;
DROP POLICY IF EXISTS "owners_read_all_subscriptions" ON public.subscriptions;
DROP POLICY IF EXISTS "owners_read_all_restaurants" ON public.restaurants;
DROP POLICY IF EXISTS "Platform owners can view all users" ON public.users;
DROP POLICY IF EXISTS "Platform owners can manage all users" ON public.users;
DROP POLICY IF EXISTS "Platform owners can view all subscriptions" ON public.subscriptions;
DROP POLICY IF EXISTS "Platform owners can manage all subscriptions" ON public.subscriptions;
DROP POLICY IF EXISTS "Platform owners can view all restaurants" ON public.restaurants;
DROP POLICY IF EXISTS "Platform owners can manage all restaurants" ON public.restaurants;
DROP POLICY IF EXISTS "authenticated_read_subscriptions" ON public.subscriptions;
DROP POLICY IF EXISTS "authenticated_read_restaurants" ON public.restaurants;
DROP POLICY IF EXISTS "users_read_own_profile" ON public.users;
DROP POLICY IF EXISTS "users_update_own_profile" ON public.users;

-- Also drop any manager/admin policies that might conflict
DROP POLICY IF EXISTS "Managers can view own restaurant subscriptions" ON public.subscriptions;
DROP POLICY IF EXISTS "Users can view their own profile" ON public.users;
DROP POLICY IF EXISTS "Users can update their own profile" ON public.users;

-- ============================================================================
-- STEP 2: Ensure RLS is enabled on tables
-- ============================================================================
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.restaurants ENABLE ROW LEVEL SECURITY;

-- ============================================================================
-- STEP 3: Create correct USERS table policies (NO RECURSION)
-- ============================================================================

-- Policy 1: Users can always read their own profile
CREATE POLICY "users_select_own"
ON public.users
FOR SELECT
TO authenticated
USING (id = auth.uid());

-- Policy 2: Users can update their own profile
CREATE POLICY "users_update_own"
ON public.users
FOR UPDATE
TO authenticated
USING (id = auth.uid())
WITH CHECK (id = auth.uid());

-- Policy 3: Owner users can read ALL users (using direct column check)
CREATE POLICY "owner_users_select_all"
ON public.users
FOR SELECT
TO authenticated
USING (
  -- Check if the REQUESTING user (auth.uid()) is an owner
  -- This reads ONLY the requesting user's row, not all users
  (SELECT is_owner FROM public.users WHERE id = auth.uid() LIMIT 1) = true
);

-- Policy 4: Owner users can manage ALL users
CREATE POLICY "owner_users_all_operations"
ON public.users
FOR ALL
TO authenticated
USING (
  (SELECT is_owner FROM public.users WHERE id = auth.uid() LIMIT 1) = true
)
WITH CHECK (
  (SELECT is_owner FROM public.users WHERE id = auth.uid() LIMIT 1) = true
);

-- ============================================================================
-- STEP 4: Create SUBSCRIPTIONS table policies
-- ============================================================================

-- Policy 1: Owner users can read all subscriptions
CREATE POLICY "owner_subscriptions_select_all"
ON public.subscriptions
FOR SELECT
TO authenticated
USING (
  (SELECT is_owner FROM public.users WHERE id = auth.uid() LIMIT 1) = true
);

-- Policy 2: Owner users can manage all subscriptions
CREATE POLICY "owner_subscriptions_all_operations"
ON public.subscriptions
FOR ALL
TO authenticated
USING (
  (SELECT is_owner FROM public.users WHERE id = auth.uid() LIMIT 1) = true
)
WITH CHECK (
  (SELECT is_owner FROM public.users WHERE id = auth.uid() LIMIT 1) = true
);

-- Policy 3: Managers can view their restaurant's subscription
CREATE POLICY "manager_subscriptions_select_own_restaurant"
ON public.subscriptions
FOR SELECT
TO authenticated
USING (
  restaurant_id IN (
    SELECT restaurant_id FROM public.users WHERE id = auth.uid()
  )
);

-- ============================================================================
-- STEP 5: Create RESTAURANTS table policies
-- ============================================================================

-- Policy 1: Owner users can read all restaurants
CREATE POLICY "owner_restaurants_select_all"
ON public.restaurants
FOR SELECT
TO authenticated
USING (
  (SELECT is_owner FROM public.users WHERE id = auth.uid() LIMIT 1) = true
);

-- Policy 2: Owner users can manage all restaurants
CREATE POLICY "owner_restaurants_all_operations"
ON public.restaurants
FOR ALL
TO authenticated
USING (
  (SELECT is_owner FROM public.users WHERE id = auth.uid() LIMIT 1) = true
)
WITH CHECK (
  (SELECT is_owner FROM public.users WHERE id = auth.uid() LIMIT 1) = true
);

-- Policy 3: Managers can view their own restaurant
CREATE POLICY "manager_restaurants_select_own"
ON public.restaurants
FOR SELECT
TO authenticated
USING (
  id IN (
    SELECT restaurant_id FROM public.users WHERE id = auth.uid()
  )
);

-- ============================================================================
-- STEP 6: Ensure superadmin user exists and is marked as owner
-- ============================================================================
DO $$
DECLARE
  v_user_id UUID;
BEGIN
  -- Find the superadmin user in auth.users
  SELECT id INTO v_user_id
  FROM auth.users
  WHERE email = 'prashanthkumarreddy879@gmail.com'
  LIMIT 1;

  IF v_user_id IS NOT NULL THEN
    -- Ensure they exist in public.users with is_owner = true
    INSERT INTO public.users (
      id,
      email,
      name,
      full_name,
      role,
      is_owner,
      is_active,
      restaurant_id
    )
    VALUES (
      v_user_id,
      'prashanthkumarreddy879@gmail.com',
      'Super Admin',
      'Super Admin',
      'owner',
      true,
      true,
      NULL  -- Owners don't belong to a restaurant
    )
    ON CONFLICT (id) DO UPDATE
    SET is_owner = true,
        role = 'owner',
        is_active = true,
        restaurant_id = NULL;

    RAISE NOTICE '✅ Updated user % as platform owner', v_user_id;
  ELSE
    RAISE WARNING '⚠️  Superadmin user not found in auth.users';
    RAISE WARNING '   Please create the user first or check the email';
  END IF;
END $$;

-- ============================================================================
-- STEP 7: Grant necessary permissions
-- ============================================================================
GRANT SELECT, INSERT, UPDATE, DELETE ON public.users TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.subscriptions TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.restaurants TO authenticated;

-- ============================================================================
-- STEP 8: Verify the setup
-- ============================================================================

-- Check if owner user exists
SELECT 
  'Owner user in public.users:' as check_type,
  id,
  email,
  name,
  role,
  is_owner,
  is_active,
  restaurant_id
FROM public.users
WHERE email = 'prashanthkumarreddy879@gmail.com';

-- Check policy count
SELECT 
  'Total policies on users table:' as info,
  COUNT(*) as count
FROM pg_policies
WHERE schemaname = 'public' AND tablename = 'users';

SELECT 
  'Total policies on subscriptions table:' as info,
  COUNT(*) as count
FROM pg_policies
WHERE schemaname = 'public' AND tablename = 'subscriptions';

SELECT 
  'Total policies on restaurants table:' as info,
  COUNT(*) as count
FROM pg_policies
WHERE schemaname = 'public' AND tablename = 'restaurants';

-- Show all policies for verification
SELECT 
  tablename,
  policyname,
  cmd as operation,
  CASE 
    WHEN qual IS NOT NULL THEN 'USING: ' || qual
    ELSE 'No USING clause'
  END as policy_condition
FROM pg_policies
WHERE schemaname = 'public'
  AND tablename IN ('users', 'subscriptions', 'restaurants')
ORDER BY tablename, policyname;

-- ============================================================================
-- DONE!
-- ============================================================================
DO $$
BEGIN
  RAISE NOTICE '';
  RAISE NOTICE '════════════════════════════════════════════════════════';
  RAISE NOTICE '✅ RLS POLICIES CONFIGURED SUCCESSFULLY!';
  RAISE NOTICE '════════════════════════════════════════════════════════';
  RAISE NOTICE '';
  RAISE NOTICE '✓ Removed all problematic recursive policies';
  RAISE NOTICE '✓ Created correct owner policies (no recursion)';
  RAISE NOTICE '✓ Created manager policies for restaurant access';
  RAISE NOTICE '✓ Verified superadmin user is marked as owner';
  RAISE NOTICE '';
  RAISE NOTICE '📝 NEXT STEPS:';
  RAISE NOTICE '   1. Logout from superadmin portal';
  RAISE NOTICE '   2. Clear browser cache (Cmd+Shift+R on Mac)';
  RAISE NOTICE '   3. Login again at /superadmin-login';
  RAISE NOTICE '   4. You should now see:';
  RAISE NOTICE '      • Managers list populated';
  RAISE NOTICE '      • Restaurants with subscription data';
  RAISE NOTICE '      • No 500 errors';
  RAISE NOTICE '';
  RAISE NOTICE '════════════════════════════════════════════════════════';
END $$;
