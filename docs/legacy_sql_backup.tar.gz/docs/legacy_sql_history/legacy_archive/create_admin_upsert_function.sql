-- Diagnostic: Check if admin_upsert_user_profile function exists
SELECT 
  proname as function_name,
  pg_get_functiondef(oid) as definition
FROM pg_proc
WHERE proname = 'admin_upsert_user_profile';

-- Drop the old function if it exists (with different return type)
DROP FUNCTION IF EXISTS admin_upsert_user_profile(UUID, TEXT, TEXT, TEXT, TEXT, UUID);

-- Create the function with correct return type:
CREATE OR REPLACE FUNCTION admin_upsert_user_profile(
  p_id UUID,
  p_email TEXT,
  p_full_name TEXT,
  p_role TEXT,
  p_phone TEXT DEFAULT NULL,
  p_restaurant_id UUID DEFAULT NULL
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Insert or update user profile
  INSERT INTO public.users (
    id,
    email,
    full_name,
    role,
    phone,
    restaurant_id,
    is_active,
    is_owner
  )
  VALUES (
    p_id,
    p_email,
    p_full_name,
    p_role,
    p_phone,
    p_restaurant_id,
    true,
    false
  )
  ON CONFLICT (id) DO UPDATE
  SET
    full_name = EXCLUDED.full_name,
    phone = EXCLUDED.phone,
    role = EXCLUDED.role,
    restaurant_id = COALESCE(EXCLUDED.restaurant_id, users.restaurant_id),
    updated_at = NOW();
END;
$$;

-- Grant execute permission
GRANT EXECUTE ON FUNCTION admin_upsert_user_profile TO authenticated;

-- Verify it was created
SELECT 
  proname as function_name,
  'Created successfully' as status
FROM pg_proc
WHERE proname = 'admin_upsert_user_profile';
