-- =========================================================================
-- COMPLETE LOGIN FIX - Re-enable RLS with Proper Policies
-- =========================================================================
-- This script will:
-- 1. Re-enable RLS on users table
-- 2. Create proper policies for owner and staff access
-- 3. Ensure auto-confirm trigger is active
-- =========================================================================

-- Step 1: Re-enable RLS on users table
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

-- Step 2: Drop existing policies to start fresh
DROP POLICY IF EXISTS "users_select_own" ON public.users;
DROP POLICY IF EXISTS "users_select_all_for_owner" ON public.users;
DROP POLICY IF EXISTS "users_insert_owner" ON public.users;
DROP POLICY IF EXISTS "users_update_owner" ON public.users;
DROP POLICY IF EXISTS "users_delete_owner" ON public.users;

-- Step 3: Create helper function to check if user is owner (BYPASSES RLS)
CREATE OR REPLACE FUNCTION public.is_owner()
RETURNS BOOLEAN AS $$
DECLARE
  owner_status BOOLEAN;
BEGIN
  -- SECURITY DEFINER allows this to bypass RLS and read directly
  SELECT (is_owner = true OR role = 'owner')
  INTO owner_status
  FROM public.users
  WHERE id = auth.uid()
  LIMIT 1;
  
  RETURN COALESCE(owner_status, false);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION public.is_owner() TO authenticated;

-- Step 4: Create SELECT policies
-- Policy 1: Users can read their own profile
CREATE POLICY "users_select_own" 
ON public.users 
FOR SELECT 
USING (auth.uid() = id);

-- Policy 2: Owners can read all users (using helper function)
CREATE POLICY "users_select_all_for_owner" 
ON public.users 
FOR SELECT 
USING (public.is_owner());

-- Step 5: Create INSERT policy for owners
CREATE POLICY "users_insert_owner" 
ON public.users 
FOR INSERT 
WITH CHECK (public.is_owner());

-- Step 6: Create UPDATE policy for owners
CREATE POLICY "users_update_owner" 
ON public.users 
FOR UPDATE 
USING (public.is_owner());

-- Step 7: Create DELETE policy for owners
CREATE POLICY "users_delete_owner" 
ON public.users 
FOR DELETE 
USING (public.is_owner());

-- Step 8: Verify the auto-confirm trigger exists
-- If it doesn't exist, create it
CREATE OR REPLACE FUNCTION public.auto_confirm_user()
RETURNS TRIGGER AS $$
BEGIN
  -- Auto-confirm email for new users
  NEW.email_confirmed_at := NOW();
  NEW.confirmation_token := '';
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS auto_confirm_user_trigger ON auth.users;
CREATE TRIGGER auto_confirm_user_trigger
  BEFORE INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.auto_confirm_user();

-- Step 9: Confirm all existing unconfirmed users
UPDATE auth.users 
SET email_confirmed_at = COALESCE(email_confirmed_at, NOW()),
    confirmation_token = ''
WHERE email_confirmed_at IS NULL;

-- Step 10: Verify policies were created
SELECT 
    schemaname,
    tablename,
    policyname,
    permissive,
    roles,
    cmd
FROM pg_policies 
WHERE tablename = 'users'
ORDER BY policyname;

-- =========================================================================
-- SUCCESS! 
-- 1. RLS is now enabled on users table
-- 2. Owners can manage all users
-- 3. Users can read their own profile
-- 4. New users are auto-confirmed
-- 
-- Now you can:
-- 1. Login as SuperAdmin via Admin panel (purple, left side)
-- 2. Login as staff via Staff panel (blue, right side)
-- 3. Create managers - they will be auto-confirmed
-- =========================================================================
