-- ============================================================================
-- QUICK CHECK: Do you have menu items?
-- ============================================================================

-- Check 1: Total menu items
SELECT 
  COUNT(*) as total_menu_items,
  COUNT(*) FILTER (WHERE is_available = true) as available_items,
  COUNT(*) FILTER (WHERE is_available = false) as unavailable_items
FROM menu_items;

-- Check 2: List all menu items
SELECT 
  m.id,
  m.name,
  m.category,
  m.price,
  m.is_available,
  r.name as restaurant_name,
  r.slug as restaurant_slug
FROM menu_items m
JOIN restaurants r ON r.id = m.restaurant_id
ORDER BY r.name, m.category, m.name;

-- Check 3: Test as customer (anonymous)
SET ROLE anon;
SELECT 
  COUNT(*) as items_customers_can_see
FROM menu_items
WHERE is_available = true;
RESET ROLE;
