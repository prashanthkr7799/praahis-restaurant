-- ============================================================================
-- AUTOMATED CRON JOBS FOR BILLING SYSTEM
-- ============================================================================
-- Version: 1.0
-- Created: November 17, 2025
-- Description: Automated scheduled tasks for billing, trials, and suspensions
-- Requires: pg_cron extension
-- ============================================================================

-- Enable pg_cron extension
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- ============================================================================
-- CRON JOB 1: Generate Monthly Bills (1st of every month at 00:00 UTC)
-- ============================================================================

SELECT cron.schedule(
    'generate-monthly-bills',
    '0 0 1 * *', -- At 00:00 on day 1 of every month
    $$
    SELECT generate_monthly_bills(
        EXTRACT(MONTH FROM CURRENT_DATE)::INTEGER,
        EXTRACT(YEAR FROM CURRENT_DATE)::INTEGER
    );
    $$
);

COMMENT ON EXTENSION pg_cron IS 'Cron job: Generate monthly bills on 1st of each month';

-- ============================================================================
-- CRON JOB 2: Expire Trial Subscriptions (Daily at 00:00 UTC)
-- ============================================================================

SELECT cron.schedule(
    'expire-trial-subscriptions',
    '0 0 * * *', -- Daily at midnight
    $$
    SELECT expire_trial_subscriptions();
    $$
);

-- ============================================================================
-- CRON JOB 3: Suspend Overdue Restaurants (Daily at 00:00 UTC)
-- ============================================================================

SELECT cron.schedule(
    'suspend-overdue-restaurants',
    '0 0 * * *', -- Daily at midnight
    $$
    SELECT suspend_overdue_subscriptions();
    $$
);

-- ============================================================================
-- CRON JOB 4: Send Payment Reminders (Daily at 09:00 UTC)
-- ============================================================================
-- This will be implemented once email system is set up

/*
SELECT cron.schedule(
    'send-payment-reminders',
    '0 9 * * *', -- Daily at 9 AM
    $$
    SELECT send_payment_reminder_emails();
    $$
);
*/

-- ============================================================================
-- CRON JOB 5: Generate and Send Invoices (1st of month at 06:00 UTC)
-- ============================================================================
-- This will be implemented once PDF generation is set up

/*
SELECT cron.schedule(
    'generate-monthly-invoices',
    '0 6 1 * *', -- At 06:00 on day 1 of every month
    $$
    SELECT generate_and_email_invoices();
    $$
);
*/

-- ============================================================================
-- UTILITY: View all scheduled cron jobs
-- ============================================================================

-- Query to see all active cron jobs
-- SELECT * FROM cron.job;

-- ============================================================================
-- UTILITY: Unschedule a cron job (for maintenance)
-- ============================================================================

-- To remove a cron job:
-- SELECT cron.unschedule('generate-monthly-bills');
-- SELECT cron.unschedule('expire-trial-subscriptions');
-- SELECT cron.unschedule('suspend-overdue-restaurants');

-- ============================================================================
-- TESTING: Manual execution commands
-- ============================================================================

-- Manually test bill generation:
-- SELECT * FROM generate_monthly_bills();

-- Manually test trial expiration:
-- SELECT * FROM expire_trial_subscriptions();

-- Manually test suspension:
-- SELECT * FROM suspend_overdue_subscriptions();

-- ============================================================================
-- SUCCESS MESSAGE
-- ============================================================================

DO $$
BEGIN
    RAISE NOTICE '
    ╔════════════════════════════════════════════════════════════════╗
    ║   ✅ CRON JOBS CONFIGURED SUCCESSFULLY                        ║
    ╠════════════════════════════════════════════════════════════════╣
    ║                                                                ║
    ║   Active Cron Jobs:                                            ║
    ║   1. Generate Monthly Bills      → 1st of month at 00:00 UTC  ║
    ║   2. Expire Trial Subscriptions  → Daily at 00:00 UTC         ║
    ║   3. Suspend Overdue Restaurants → Daily at 00:00 UTC         ║
    ║                                                                ║
    ║   To view jobs: SELECT * FROM cron.job;                        ║
    ║                                                                ║
    ╚════════════════════════════════════════════════════════════════╝
    ';
END $$;
