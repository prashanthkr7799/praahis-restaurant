-- ============================================================================
-- CLEAN DATABASE SETUP - SEED DATA
-- ============================================================================
-- Generated: 2025-11-18 13:10:11
-- Description: Sample data for development and testing
-- ============================================================================

-- ============================================================================
-- PLATFORM SETTINGS (Global Configuration)
-- ============================================================================

INSERT INTO platform_settings (key, value, category, description)
VALUES
    ('default_currency', '"INR"', 'platform', 'Default currency for the platform'),
    ('default_tax_rate', '18', 'platform', 'Default tax rate percentage (GST)'),
    ('trial_duration_days', '14', 'platform', 'Trial period duration in days'),
    ('max_file_upload_size_mb', '5', 'storage', 'Maximum file upload size in MB'),
    ('session_timeout_minutes', '60', 'platform', 'User session timeout in minutes'),
    ('billing_rate_per_table_per_day', '100', 'billing', 'Daily billing rate per table (INR)')
ON CONFLICT (key) DO NOTHING;

-- ============================================================================
-- SAMPLE RESTAURANT
-- ============================================================================

INSERT INTO restaurants (id, name, description, address, phone, email, slug, is_active, subscription_status)
VALUES (
    '550e8400-e29b-41d4-a716-446655440000',
    'Tabun Restaurant',
    'Authentic cuisine with modern dining experience',
    'Tirupati, Andhra Pradesh, India',
    '+91 98765 43210',
    'contact@tabunrestaurant.com',
    'tabun-restaurant',
    true,
    'trial'
) ON CONFLICT (id) DO NOTHING;

-- ============================================================================
-- SAMPLE TABLES
-- ============================================================================

INSERT INTO tables (restaurant_id, table_number, table_name, capacity, status, is_active) VALUES
('550e8400-e29b-41d4-a716-446655440000', '1', 'Table 1', 2, 'available', true),
('550e8400-e29b-41d4-a716-446655440000', '2', 'Table 2', 4, 'available', true),
('550e8400-e29b-41d4-a716-446655440000', '3', 'Table 3', 4, 'available', true),
('550e8400-e29b-41d4-a716-446655440000', '4', 'Table 4', 6, 'available', true),
('550e8400-e29b-41d4-a716-446655440000', '5', 'Table 5', 2, 'available', true),
('550e8400-e29b-41d4-a716-446655440000', '6', 'Table 6', 4, 'available', true),
('550e8400-e29b-41d4-a716-446655440000', '7', 'Table 7', 8, 'available', true),
('550e8400-e29b-41d4-a716-446655440000', '8', 'Table 8', 4, 'available', true),
('550e8400-e29b-41d4-a716-446655440000', '9', 'Table 9', 2, 'available', true),
('550e8400-e29b-41d4-a716-446655440000', '10', 'Table 10', 6, 'available', true)
ON CONFLICT DO NOTHING;

-- ============================================================================
-- SAMPLE MENU ITEMS
-- ============================================================================

-- Starters
INSERT INTO menu_items (restaurant_id, name, description, category, price, is_vegetarian, is_available, preparation_time, tags) VALUES
('550e8400-e29b-41d4-a716-446655440000', 'Paneer Tikka', 'Marinated cottage cheese grilled to perfection', 'Starters', 250.00, true, true, 15, ARRAY['popular', 'spicy']),
('550e8400-e29b-41d4-a716-446655440000', 'Chicken 65', 'Spicy deep-fried chicken appetizer', 'Starters', 280.00, false, true, 20, ARRAY['spicy', 'chef-special']),
('550e8400-e29b-41d4-a716-446655440000', 'Veg Spring Rolls', 'Crispy rolls filled with vegetables', 'Starters', 180.00, true, true, 12, ARRAY['popular']),
('550e8400-e29b-41d4-a716-446655440000', 'Fish Fingers', 'Crispy fish strips with tartar sauce', 'Starters', 320.00, false, true, 18, ARRAY['kids-favorite']),
('550e8400-e29b-41d4-a716-446655440000', 'Corn Cheese Balls', 'Deep-fried corn and cheese balls', 'Starters', 220.00, true, true, 15, ARRAY['popular'])
ON CONFLICT DO NOTHING;

-- Main Course
INSERT INTO menu_items (restaurant_id, name, description, category, price, is_vegetarian, is_available, preparation_time, tags) VALUES
('550e8400-e29b-41d4-a716-446655440000', 'Butter Chicken', 'Creamy tomato-based chicken curry', 'Main Course', 380.00, false, true, 25, ARRAY['popular', 'chef-special']),
('550e8400-e29b-41d4-a716-446655440000', 'Paneer Butter Masala', 'Rich cottage cheese curry', 'Main Course', 320.00, true, true, 20, ARRAY['popular']),
('550e8400-e29b-41d4-a716-446655440000', 'Biryani (Veg)', 'Aromatic basmati rice with vegetables', 'Main Course', 280.00, true, true, 30, ARRAY['popular', 'spicy']),
('550e8400-e29b-41d4-a716-446655440000', 'Biryani (Chicken)', 'Aromatic basmati rice with chicken', 'Main Course', 350.00, false, true, 35, ARRAY['popular', 'spicy', 'chef-special']),
('550e8400-e29b-41d4-a716-446655440000', 'Dal Tadka', 'Yellow lentils tempered with spices', 'Main Course', 180.00, true, true, 20, ARRAY['healthy']),
('550e8400-e29b-41d4-a716-446655440000', 'Fish Curry', 'Traditional fish curry with spices', 'Main Course', 420.00, false, true, 28, ARRAY['spicy']),
('550e8400-e29b-41d4-a716-446655440000', 'Naan (Plain)', 'Traditional Indian bread', 'Main Course', 40.00, true, true, 8, ARRAY['essential']),
('550e8400-e29b-41d4-a716-446655440000', 'Butter Naan', 'Naan brushed with butter', 'Main Course', 50.00, true, true, 8, ARRAY['essential']),
('550e8400-e29b-41d4-a716-446655440000', 'Garlic Naan', 'Naan topped with garlic', 'Main Course', 60.00, true, true, 10, ARRAY['popular'])
ON CONFLICT DO NOTHING;

-- Desserts
INSERT INTO menu_items (restaurant_id, name, description, category, price, is_vegetarian, is_available, preparation_time, tags) VALUES
('550e8400-e29b-41d4-a716-446655440000', 'Gulab Jamun', 'Sweet dumplings in sugar syrup', 'Desserts', 80.00, true, true, 5, ARRAY['popular', 'traditional']),
('550e8400-e29b-41d4-a716-446655440000', 'Ice Cream (Vanilla)', 'Classic vanilla ice cream', 'Desserts', 100.00, true, true, 3, ARRAY['kids-favorite']),
('550e8400-e29b-41d4-a716-446655440000', 'Ice Cream (Chocolate)', 'Rich chocolate ice cream', 'Desserts', 100.00, true, true, 3, ARRAY['kids-favorite']),
('550e8400-e29b-41d4-a716-446655440000', 'Rasmalai', 'Cottage cheese dumplings in sweet milk', 'Desserts', 120.00, true, true, 5, ARRAY['traditional', 'chef-special']),
('550e8400-e29b-41d4-a716-446655440000', 'Brownie with Ice Cream', 'Warm brownie topped with vanilla ice cream', 'Desserts', 180.00, true, true, 12, ARRAY['popular'])
ON CONFLICT DO NOTHING;

-- Beverages
INSERT INTO menu_items (restaurant_id, name, description, category, price, is_vegetarian, is_available, preparation_time, tags) VALUES
('550e8400-e29b-41d4-a716-446655440000', 'Masala Chai', 'Indian spiced tea', 'Beverages', 40.00, true, true, 5, ARRAY['traditional', 'hot']),
('550e8400-e29b-41d4-a716-446655440000', 'Coffee', 'Fresh brewed coffee', 'Beverages', 50.00, true, true, 5, ARRAY['hot']),
('550e8400-e29b-41d4-a716-446655440000', 'Fresh Lime Soda', 'Refreshing lime and soda drink', 'Beverages', 60.00, true, true, 5, ARRAY['refreshing', 'cold']),
('550e8400-e29b-41d4-a716-446655440000', 'Mango Lassi', 'Sweet mango yogurt drink', 'Beverages', 80.00, true, true, 5, ARRAY['popular', 'cold']),
('550e8400-e29b-41d4-a716-446655440000', 'Coca Cola', 'Chilled soft drink', 'Beverages', 50.00, true, true, 2, ARRAY['cold']),
('550e8400-e29b-41d4-a716-446655440000', 'Sprite', 'Lemon-lime soft drink', 'Beverages', 50.00, true, true, 2, ARRAY['cold']),
('550e8400-e29b-41d4-a716-446655440000', 'Mineral Water', 'Bottled water', 'Beverages', 20.00, true, true, 1, ARRAY['essential'])
ON CONFLICT DO NOTHING;

-- ============================================================================
-- SEED DATA COMPLETE
-- ============================================================================

SELECT 'Seed data inserted successfully!' AS status;
SELECT '1 Restaurant, 10 Tables, 27 Menu Items' AS summary;
