-- ============================================================================
-- FIX SUPERADMIN RLS POLICIES
-- ============================================================================
-- Problem: Owner account cannot read subscriptions or users tables
-- Solution: Add policies for is_owner = true users
-- ============================================================================

-- 1. Check if user is owner
CREATE OR REPLACE FUNCTION public.is_platform_owner()
RETURNS boolean AS $$
BEGIN
  -- Check if current user has is_owner = true in users table
  RETURN EXISTS (
    SELECT 1 FROM public.users
    WHERE id = auth.uid()
    AND is_owner = true
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 2. SUBSCRIPTIONS TABLE - Allow owners to read all subscriptions
DROP POLICY IF EXISTS "Platform owners can view all subscriptions" ON public.subscriptions;
CREATE POLICY "Platform owners can view all subscriptions"
ON public.subscriptions
FOR SELECT
TO authenticated
USING (
  is_platform_owner() = true
);

DROP POLICY IF EXISTS "Platform owners can manage all subscriptions" ON public.subscriptions;
CREATE POLICY "Platform owners can manage all subscriptions"
ON public.subscriptions
FOR ALL
TO authenticated
USING (
  is_platform_owner() = true
)
WITH CHECK (
  is_platform_owner() = true
);

-- 3. USERS TABLE - Allow owners to read all users
DROP POLICY IF EXISTS "Platform owners can view all users" ON public.users;
CREATE POLICY "Platform owners can view all users"
ON public.users
FOR SELECT
TO authenticated
USING (
  is_platform_owner() = true
  OR id = auth.uid()  -- Users can always see themselves
);

DROP POLICY IF EXISTS "Platform owners can manage all users" ON public.users;
CREATE POLICY "Platform owners can manage all users"
ON public.users
FOR ALL
TO authenticated
USING (
  is_platform_owner() = true
  OR id = auth.uid()  -- Users can manage themselves
)
WITH CHECK (
  is_platform_owner() = true
  OR id = auth.uid()
);

-- 4. RESTAURANTS TABLE - Owners should already have access, but let's ensure it
DROP POLICY IF EXISTS "Platform owners can view all restaurants" ON public.restaurants;
CREATE POLICY "Platform owners can view all restaurants"
ON public.restaurants
FOR SELECT
TO authenticated
USING (
  is_platform_owner() = true
);

DROP POLICY IF EXISTS "Platform owners can manage all restaurants" ON public.restaurants;
CREATE POLICY "Platform owners can manage all restaurants"
ON public.restaurants
FOR ALL
TO authenticated
USING (
  is_platform_owner() = true
)
WITH CHECK (
  is_platform_owner() = true
);

-- 5. Verify the owner user has is_owner flag set
DO $$
DECLARE
  v_owner_id UUID;
BEGIN
  -- Find the superadmin user
  SELECT id INTO v_owner_id
  FROM auth.users
  WHERE email = 'prashanthkumarreddy879@gmail.com'
  LIMIT 1;

  IF v_owner_id IS NOT NULL THEN
    -- Ensure they have is_owner = true in users table
    INSERT INTO public.users (
      id,
      email,
      name,
      full_name,
      role,
      is_owner,
      is_active
    )
    VALUES (
      v_owner_id,
      'prashanthkumarreddy879@gmail.com',
      'Super Admin',
      'Super Admin',
      'owner',
      true,
      true
    )
    ON CONFLICT (id) DO UPDATE
    SET is_owner = true,
        role = 'owner',
        is_active = true;

    RAISE NOTICE 'Updated user % to be platform owner', v_owner_id;
  ELSE
    RAISE NOTICE 'Owner user not found in auth.users';
  END IF;
END $$;

-- 6. Grant access to tables
GRANT SELECT, INSERT, UPDATE, DELETE ON public.subscriptions TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.users TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.restaurants TO authenticated;

-- 7. Verify policies are active
SELECT 
  schemaname,
  tablename,
  policyname,
  permissive,
  roles,
  cmd,
  qual
FROM pg_policies
WHERE schemaname = 'public'
  AND tablename IN ('subscriptions', 'users', 'restaurants')
ORDER BY tablename, policyname;

-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================

-- Check if owner exists
SELECT 
  id,
  email,
  name,
  role,
  is_owner,
  is_active
FROM public.users
WHERE email = 'prashanthkumarreddy879@gmail.com';

-- Check subscriptions count
SELECT COUNT(*) as subscription_count FROM public.subscriptions;

-- Check managers count
SELECT COUNT(*) as manager_count 
FROM public.users 
WHERE role IN ('manager', 'admin');

-- ============================================================================
-- SUCCESS MESSAGE
-- ============================================================================
DO $$
BEGIN
  RAISE NOTICE '✅ RLS policies updated successfully!';
  RAISE NOTICE '📝 Next steps:';
  RAISE NOTICE '   1. Logout from superadmin';
  RAISE NOTICE '   2. Login again';
  RAISE NOTICE '   3. Refresh the page';
  RAISE NOTICE '   4. Check Managers and Restaurants pages';
END $$;
