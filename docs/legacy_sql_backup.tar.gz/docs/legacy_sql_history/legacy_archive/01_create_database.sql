-- ============================================================================
-- CLEAN DATABASE SETUP - INITIALIZATION
-- ============================================================================
-- Generated: 2025-11-18 13:08:10
-- Description: Database initialization with extensions and core setup
-- ============================================================================

-- Enable required PostgreSQL extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Create custom types
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'admin_role') THEN
        CREATE TYPE admin_role AS ENUM ('superadmin', 'subadmin');
    END IF;
END $$;

-- ============================================================================
-- DATABASE INITIALIZATION COMPLETE
-- ============================================================================

SELECT 'Database initialization complete!' AS status;
