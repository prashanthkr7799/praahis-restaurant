-- Find all superadmin/owner accounts

-- Step 1: Check for users with is_superadmin flag
SELECT 
  id,
  email,
  full_name,
  role,
  is_superadmin,
  is_owner,
  is_active,
  created_at,
  '✅ SuperAdmin user' as type
FROM public.users
WHERE is_superadmin = true OR is_owner = true
ORDER BY created_at;

-- Step 2: Check auth.users for these accounts
SELECT 
  au.id,
  au.email,
  au.created_at as auth_created,
  pu.full_name,
  pu.is_superadmin,
  pu.is_owner,
  CASE 
    WHEN pu.id IS NOT NULL THEN '✅ Has profile'
    ELSE '❌ No profile'
  END as profile_status
FROM auth.users au
LEFT JOIN public.users pu ON au.id = pu.id
WHERE pu.is_superadmin = true OR pu.is_owner = true OR au.email LIKE '%superadmin%' OR au.email LIKE '%admin%'
ORDER BY au.created_at;

-- Step 3: Check all owner-type users (no restaurant_id)
SELECT 
  id,
  email,
  full_name,
  role,
  restaurant_id,
  is_superadmin,
  is_owner,
  is_active,
  '⚠️ Potential superadmin (no restaurant)' as type
FROM public.users
WHERE restaurant_id IS NULL
ORDER BY created_at;

-- Step 4: Show all users to help identify the right account
SELECT 
  id,
  email,
  full_name,
  role,
  restaurant_id,
  is_superadmin,
  is_owner,
  is_active
FROM public.users
ORDER BY created_at;
