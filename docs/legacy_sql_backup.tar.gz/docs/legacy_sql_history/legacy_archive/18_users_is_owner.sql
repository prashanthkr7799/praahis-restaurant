-- =========================================================================
-- users: add is_owner boolean to mark platform owner (idempotent)
-- Run after 17_users_add_phone.sql and before 11_rls_public_and_owner.sql re-run
-- =========================================================================

ALTER TABLE IF EXISTS public.users
  ADD COLUMN IF NOT EXISTS is_owner BOOLEAN DEFAULT FALSE;

-- Backfill: if role='owner', set is_owner=true
UPDATE public.users SET is_owner = TRUE WHERE lower(role) = 'owner' AND is_owner IS DISTINCT FROM TRUE;

-- Optional index for filters
CREATE INDEX IF NOT EXISTS idx_users_is_owner ON public.users(is_owner);

-- =========================================================================
