-- ============================================================================
-- FIX: DISABLE RLS ON BILLING & PAYMENTS TABLES
-- ============================================================================
-- Problem: RLS policies on billing/payments checking platform_admins table
--          may not be working correctly for superadmin access
-- Solution: Disable RLS on billing/payments tables (like we did for users table)
--           and rely on application-level security checks instead
-- Created: November 18, 2025
-- ============================================================================

-- Step 1: Disable RLS on billing table
ALTER TABLE billing DISABLE ROW LEVEL SECURITY;

-- Step 2: Disable RLS on payments table  
ALTER TABLE payments DISABLE ROW LEVEL SECURITY;

-- Step 3: Create helper functions for application-level security checks
-- These functions will be used by the frontend to verify access

-- Function: Check if user can view billing records (superadmin only for now)
CREATE OR REPLACE FUNCTION can_view_billing(p_user_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
    -- Check if user is a superadmin
    RETURN EXISTS (
        SELECT 1 FROM platform_admins
        WHERE user_id = p_user_id
        AND is_active = true
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

-- Function: Check if user can view billing for specific restaurant
CREATE OR REPLACE FUNCTION can_view_restaurant_billing(p_user_id UUID, p_restaurant_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
    -- Check if user is manager of that restaurant or superadmin
    RETURN EXISTS (
        SELECT 1 FROM users u
        WHERE u.id = p_user_id
        AND u.restaurant_id = p_restaurant_id
        AND u.role IN ('manager', 'admin')
    )
    OR EXISTS (
        SELECT 1 FROM platform_admins
        WHERE user_id = p_user_id
        AND is_active = true
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

-- Grant execute permissions
GRANT EXECUTE ON FUNCTION can_view_billing TO authenticated;
GRANT EXECUTE ON FUNCTION can_view_restaurant_billing TO authenticated;

-- ============================================================================
-- VERIFICATION
-- ============================================================================

DO $$
BEGIN
    RAISE NOTICE '
    ╔════════════════════════════════════════════════════════════════╗
    ║   ✅ RLS DISABLED ON BILLING & PAYMENTS TABLES                 ║
    ╠════════════════════════════════════════════════════════════════╣
    ║                                                                ║
    ║   Changes Applied:                                             ║
    ║   ✓ Disabled RLS on billing table                              ║
    ║   ✓ Disabled RLS on payments table                             ║
    ║   ✓ Created can_view_billing() helper function                 ║
    ║   ✓ Created can_view_restaurant_billing() helper function      ║
    ║                                                                ║
    ║   Note:                                                        ║
    ║   Security is now application-level (frontend/backend checks)  ║
    ║   Make sure frontend validates user roles before displaying    ║
    ║                                                                ║
    ╚════════════════════════════════════════════════════════════════╝
    ';
END $$;
