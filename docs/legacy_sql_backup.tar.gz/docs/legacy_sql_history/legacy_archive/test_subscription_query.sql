-- ============================================================================
-- TEST SUBSCRIPTION DATA QUERY
-- ============================================================================
-- This query simulates what the frontend is trying to fetch
-- Run this in Supabase SQL Editor to see the actual data structure
-- ============================================================================

-- Check what data exists in subscriptions table
SELECT 
    r.id as restaurant_id,
    r.name as restaurant_name,
    r.slug,
    s.id as subscription_id,
    s.status,
    s.plan_name,
    s.current_period_start,
    s.current_period_end,
    s.trial_ends_at,
    s.price,
    s.billing_cycle,
    EXTRACT(DAY FROM (s.current_period_end - NOW()))::INTEGER as days_until_expiry
FROM restaurants r
LEFT JOIN subscriptions s ON s.restaurant_id = r.id
ORDER BY r.name;

-- Check if subscriptions table has the required columns
SELECT column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_name = 'subscriptions'
ORDER BY ordinal_position;

-- Count restaurants with/without subscriptions
SELECT 
    'With Subscription' as category,
    COUNT(*) as count
FROM restaurants r
INNER JOIN subscriptions s ON s.restaurant_id = r.id

UNION ALL

SELECT 
    'Without Subscription' as category,
    COUNT(*) as count
FROM restaurants r
LEFT JOIN subscriptions s ON s.restaurant_id = r.id
WHERE s.id IS NULL;
