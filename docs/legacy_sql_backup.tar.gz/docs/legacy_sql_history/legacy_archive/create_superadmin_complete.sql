-- =========================================================================
-- CREATE SUPERADMIN USER - Complete Setup
-- =========================================================================
-- Run this AFTER creating the user in Supabase Auth Dashboard
-- =========================================================================

-- Step 1: Insert/Update user in public.users table
-- Replace the UUID and email with your actual values from Auth Dashboard
INSERT INTO public.users (
    id,                                      -- User ID from Auth Dashboard
    email,                                   -- Your email
    full_name,                               -- Your name
    name,                                    -- Same as full_name
    role,                                    -- 'owner'
    is_owner,                                -- TRUE
    is_active,                               -- TRUE
    restaurant_id,                           -- NULL for superadmin
    phone,                                   -- Optional
    created_at,
    updated_at
) VALUES (
    'PASTE-USER-UUID-FROM-AUTH-DASHBOARD',  -- ⚠️ CHANGE THIS!
    'your-email@example.com',                -- ⚠️ CHANGE THIS!
    'Super Admin',                           -- ⚠️ CHANGE THIS!
    'Super Admin',                           -- ⚠️ CHANGE THIS!
    'owner',
    TRUE,
    TRUE,
    NULL,
    NULL,                                    -- Optional phone
    NOW(),
    NOW()
)
ON CONFLICT (id) DO UPDATE SET
    is_owner = TRUE,
    role = 'owner',
    is_active = TRUE,
    email = EXCLUDED.email,
    full_name = EXCLUDED.full_name,
    name = EXCLUDED.name,
    updated_at = NOW();

-- Step 2: Verify the user was created/updated
SELECT 
    id, 
    email, 
    full_name,
    role, 
    is_owner, 
    is_active,
    created_at
FROM public.users 
WHERE is_owner = TRUE;

-- Step 3: Test if the user can be recognized as owner
-- (This will work once you login with this user)
SELECT public.is_owner() as is_owner_check;

-- =========================================================================
-- Instructions:
-- 1. Create user in Supabase Dashboard → Authentication → Users
-- 2. Copy the User ID (UUID) from the dashboard
-- 3. Replace 'PASTE-USER-UUID-FROM-AUTH-DASHBOARD' with that UUID
-- 4. Replace 'your-email@example.com' with your actual email
-- 5. Replace 'Super Admin' with your name
-- 6. Run this script
-- 7. Login using the email and password you set in the Auth Dashboard
-- =========================================================================
