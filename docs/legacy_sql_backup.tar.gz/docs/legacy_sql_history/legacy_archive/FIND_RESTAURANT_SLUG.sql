-- Find the restaurant slug for your menu item
SELECT 
  r.id,
  r.name,
  r.slug,
  r.is_active,
  COUNT(m.id) as menu_items_count
FROM restaurants r
LEFT JOIN menu_items m ON m.restaurant_id = r.id
WHERE r.id = '79679534-2019-4b19-ada0-e4c21e00c52b'
GROUP BY r.id, r.name, r.slug, r.is_active;

-- Also show all restaurants
SELECT 
  id,
  name,
  slug,
  is_active
FROM restaurants
ORDER BY name;
