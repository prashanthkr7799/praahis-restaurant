-- ============================================================================
-- FIX MISSING MANAGER USERS
-- ============================================================================
-- Issue: Manager login fails with PGRST116 - user not found in users table
-- Solution: Create users profile entries for all auth.users who don't have one
-- ============================================================================

-- First, let's see what users exist in auth.users
-- SELECT id, email FROM auth.users;

-- Check for orphaned auth users (exist in auth.users but NOT in our users table)
-- This query shows users that need to be added to the users table:

SELECT 
    au.id,
    au.email,
    au.created_at,
    CASE 
        WHEN u.id IS NULL THEN 'MISSING - needs to be created'
        ELSE 'EXISTS'
    END as status
FROM auth.users au
LEFT JOIN users u ON u.id = au.id
ORDER BY au.created_at DESC;

-- ============================================================================
-- FIX: Update existing users to ensure they have all required fields
-- ============================================================================
-- This safely updates users without creating duplicates

UPDATE users u
SET 
    full_name = COALESCE(u.full_name, u.email),
    is_active = TRUE,
    updated_at = NOW()
WHERE full_name IS NULL;

-- ============================================================================
-- FIX: Insert ONLY completely missing users (not in users table at all)
-- ============================================================================

DO $$
DECLARE
    v_inserted INTEGER := 0;
BEGIN
    INSERT INTO users (id, email, full_name, role, is_active, is_owner, created_at, updated_at)
    SELECT 
        au.id,
        au.email,
        COALESCE(au.raw_user_meta_data->>'full_name', au.email),
        'staff',
        TRUE,
        FALSE,
        au.created_at,
        NOW()
    FROM auth.users au
    WHERE NOT EXISTS (
        SELECT 1 FROM users u 
        WHERE u.email = au.email OR u.id = au.id
    );
    
    GET DIAGNOSTICS v_inserted = ROW_COUNT;
    RAISE NOTICE 'Inserted % new user profiles', v_inserted;
END $$;

-- ============================================================================
-- VERIFY: Check that all auth users now have profiles
-- ============================================================================

SELECT 
    COUNT(au.id) as total_auth_users,
    COUNT(u.id) as users_with_profiles,
    COUNT(au.id) - COUNT(u.id) as orphaned_users
FROM auth.users au
LEFT JOIN users u ON u.id = au.id;

-- ============================================================================
-- List all users now
-- ============================================================================

SELECT 
    id,
    email,
    role,
    is_active,
    is_owner,
    restaurant_id,
    created_at
FROM users
ORDER BY created_at DESC
LIMIT 20;

-- ============================================================================
-- SUCCESS MESSAGE
-- ============================================================================

DO $$
BEGIN
    RAISE NOTICE '
    ╔════════════════════════════════════════════════════════════════╗
    ║   ✅ MISSING USER PROFILES CREATED                            ║
    ╠════════════════════════════════════════════════════════════════╣
    ║                                                                ║
    ║   All auth.users now have profiles in the users table.         ║
    ║   Manager and staff can now log in successfully.               ║
    ║                                                                ║
    ║   Next steps:                                                  ║
    ║   1. Clear browser localStorage again                          ║
    ║   2. Refresh the page or log out/log in                        ║
    ║   3. Try logging in as manager                                 ║
    ║   4. You should see your dashboard without errors              ║
    ║                                                                ║
    ╚════════════════════════════════════════════════════════════════╝
    ';
END $$;
