-- ============================================================================
-- Idempotent seed for tenants (data only). Manager auth users are created by JS script.
-- Run after core schema and multitenancy migrations.
-- ============================================================================

-- Ensure base restaurants
INSERT INTO public.restaurants (slug, name, is_active)
VALUES 
  ('tabun', 'Tabun', TRUE),
  ('table9', 'Table 9', TRUE),
  ('redchillis', 'Red Chillis', TRUE),
  ('demo', 'Demo Restaurant', TRUE)
ON CONFLICT ((lower(slug))) DO UPDATE SET name = EXCLUDED.name, is_active = TRUE;

-- Helper: get ids
WITH r AS (
  SELECT id, lower(slug) AS slug FROM public.restaurants WHERE lower(slug) IN ('tabun','table9','redchillis','demo')
)
-- Tables (minimal)
INSERT INTO public.tables (restaurant_id, table_number, capacity, status, is_active)
SELECT r.id, t.num::text, 4, 'available', TRUE
FROM r
JOIN (VALUES ('tabun',1),('tabun',2),('tabun',3),('tabun',4),
             ('table9',1),('table9',2),('table9',3),('table9',4),('table9',5),
             ('redchillis',1),('redchillis',2),('redchillis',3),
             ('demo',1),('demo',2)) AS t(slug,num)
  ON r.slug = t.slug
ON CONFLICT DO NOTHING;

-- Menu items (minimal)
WITH r AS (
  SELECT id, lower(slug) AS slug FROM public.restaurants WHERE lower(slug) IN ('tabun','table9','redchillis','demo')
)
INSERT INTO public.menu_items (restaurant_id, name, category, price, is_available)
SELECT r.id, m.name, m.category, m.price, TRUE
FROM r
JOIN (
  VALUES
    ('tabun','Hummus','Starters',120),
    ('tabun','Falafel','Starters',150),
    ('tabun','Shawarma','Mains',280),
    ('table9','Tomato Soup','Starters',110),
    ('table9','Pasta Alfredo','Mains',320),
    ('table9','Brownie','Desserts',160),
    ('redchillis','Gobi Manchurian','Starters',180),
    ('redchillis','Paneer Butter Masala','Mains',260),
    ('redchillis','Gulab Jamun','Desserts',120),
    ('demo','Masala Dosa','South Indian',90),
    ('demo','Chai','Beverages',20),
    ('demo','Samosa','Snacks',30)
) AS m(slug,name,category,price)
  ON r.slug = lower(m.slug)
ON CONFLICT DO NOTHING;

-- Note: Manager auth users and profile rows are seeded by scripts/seed-tenants.js
-- ============================================================================
