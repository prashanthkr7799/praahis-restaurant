-- =========================================================================
-- ONE-TIME SETUP: Fix All RLS Policies for SuperAdmin
-- =========================================================================
-- Run this ONCE to fix all permission issues permanently
-- After this, you can add restaurants and managers via the UI
-- =========================================================================

-- ============================================================================
-- PART 1: FIX USERS TABLE RLS POLICIES
-- ============================================================================

-- Enable RLS on users table
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

-- Drop all existing policies on users table
DROP POLICY IF EXISTS "owners_can_read_own_profile" ON public.users;
DROP POLICY IF EXISTS "owners_can_read_all_users" ON public.users;
DROP POLICY IF EXISTS "owners_can_insert_users" ON public.users;
DROP POLICY IF EXISTS "owners_can_update_users" ON public.users;
DROP POLICY IF EXISTS "owners_can_delete_users" ON public.users;
DROP POLICY IF EXISTS "users_self_select" ON public.users;
DROP POLICY IF EXISTS "managers_can_read_own_restaurant_users" ON public.users;

-- Owners can read ALL users (for managing restaurants and staff)
CREATE POLICY "owners_can_read_all_users" ON public.users
    FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM public.users 
            WHERE id = auth.uid() 
            AND (is_owner = TRUE OR LOWER(role) = 'owner')
        )
    );

-- Owners can insert ANY user (for creating managers)
CREATE POLICY "owners_can_insert_users" ON public.users
    FOR INSERT
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM public.users 
            WHERE id = auth.uid() 
            AND (is_owner = TRUE OR LOWER(role) = 'owner')
        )
    );

-- Owners can update ANY user
CREATE POLICY "owners_can_update_users" ON public.users
    FOR UPDATE
    USING (
        EXISTS (
            SELECT 1 FROM public.users 
            WHERE id = auth.uid() 
            AND (is_owner = TRUE OR LOWER(role) = 'owner')
        )
    )
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM public.users 
            WHERE id = auth.uid() 
            AND (is_owner = TRUE OR LOWER(role) = 'owner')
        )
    );

-- Owners can delete ANY user
CREATE POLICY "owners_can_delete_users" ON public.users
    FOR DELETE
    USING (
        EXISTS (
            SELECT 1 FROM public.users 
            WHERE id = auth.uid() 
            AND (is_owner = TRUE OR LOWER(role) = 'owner')
        )
    );

-- Users can read their own profile (for login/auth)
CREATE POLICY "users_self_select" ON public.users
    FOR SELECT
    USING (id = auth.uid());

-- Managers can read users from their own restaurant
CREATE POLICY "managers_can_read_own_restaurant_users" ON public.users
    FOR SELECT
    USING (
        restaurant_id IN (
            SELECT restaurant_id 
            FROM public.users 
            WHERE id = auth.uid()
        )
    );

-- ============================================================================
-- PART 2: RESTAURANTS TABLE RLS POLICIES (Already done, but ensuring)
-- ============================================================================

-- These were already set in previous scripts, but let's ensure they exist
DROP POLICY IF EXISTS "owners_select_all_restaurants" ON restaurants;
DROP POLICY IF EXISTS "owners_insert_restaurants" ON restaurants;
DROP POLICY IF EXISTS "owners_update_restaurants" ON restaurants;
DROP POLICY IF EXISTS "owners_delete_restaurants" ON restaurants;
DROP POLICY IF EXISTS "managers_select_own_restaurant" ON restaurants;

CREATE POLICY "owners_select_all_restaurants" ON restaurants
    FOR SELECT
    USING (public.is_owner() = TRUE);

CREATE POLICY "owners_insert_restaurants" ON restaurants
    FOR INSERT
    WITH CHECK (public.is_owner() = TRUE);

CREATE POLICY "owners_update_restaurants" ON restaurants
    FOR UPDATE
    USING (public.is_owner() = TRUE)
    WITH CHECK (public.is_owner() = TRUE);

CREATE POLICY "owners_delete_restaurants" ON restaurants
    FOR DELETE
    USING (public.is_owner() = TRUE);

CREATE POLICY "managers_select_own_restaurant" ON restaurants
    FOR SELECT
    USING (
        id IN (
            SELECT restaurant_id 
            FROM public.users 
            WHERE id = auth.uid()
        )
    );

-- ============================================================================
-- PART 3: SETUP YOUR SUPERADMIN USER (Do this once)
-- ============================================================================

-- OPTION A: If you already created user in Supabase Dashboard
-- Just confirm the email and set permissions
UPDATE auth.users 
SET email_confirmed_at = COALESCE(email_confirmed_at, NOW()),
    confirmation_token = ''
WHERE email = 'your-email@example.com';  -- ⚠️ CHANGE THIS!

-- Insert/Update user in public.users
INSERT INTO public.users (
    id,
    email,
    full_name,
    name,
    role,
    is_owner,
    is_active,
    restaurant_id
)
SELECT 
    au.id,
    au.email,
    'Super Admin',
    'Super Admin',
    'owner',
    TRUE,
    TRUE,
    NULL
FROM auth.users au
WHERE au.email = 'your-email@example.com'  -- ⚠️ CHANGE THIS!
ON CONFLICT (id) DO UPDATE SET
    is_owner = TRUE,
    role = 'owner',
    is_active = TRUE,
    email = EXCLUDED.email;

-- ============================================================================
-- PART 4: VERIFY SETUP
-- ============================================================================

-- Check your superadmin user
SELECT 
    'SuperAdmin User' as check_type,
    u.id,
    u.email,
    u.role,
    u.is_owner,
    u.is_active,
    au.email_confirmed_at
FROM public.users u
JOIN auth.users au ON u.id = au.id
WHERE u.email = 'your-email@example.com';  -- ⚠️ CHANGE THIS!

-- Check RLS policies on users table
SELECT 
    'Users Table Policies' as check_type,
    schemaname, 
    tablename, 
    policyname, 
    cmd as operation,
    qual as using_expression
FROM pg_policies 
WHERE tablename = 'users' 
ORDER BY policyname;

-- Check RLS policies on restaurants table
SELECT 
    'Restaurants Table Policies' as check_type,
    schemaname, 
    tablename, 
    policyname, 
    cmd as operation
FROM pg_policies 
WHERE tablename = 'restaurants' 
ORDER BY policyname;

-- ============================================================================
-- SUCCESS! After running this script:
-- ✅ All RLS policies are set up correctly
-- ✅ Your superadmin user is confirmed and has owner permissions
-- ✅ You can now:
--    - Login via the SuperAdmin panel
--    - Create restaurants via UI
--    - Add managers via UI
--    - Everything works automatically!
-- 
-- You should NEVER need to run SQL scripts again for normal operations!
-- ============================================================================
