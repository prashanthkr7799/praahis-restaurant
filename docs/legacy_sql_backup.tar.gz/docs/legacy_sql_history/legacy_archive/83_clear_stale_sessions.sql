-- ============================================================================
-- CLEAR STALE SESSIONS AND FIX AUTH
-- ============================================================================
-- This clears all stale refresh tokens that are causing 400 errors

-- Clear all sessions (safe - users will need to log in again)
DELETE FROM auth.sessions;

-- Optional: Clear all refresh tokens
DELETE FROM auth.refresh_tokens;

-- Verify sessions are cleared
SELECT COUNT(*) as session_count FROM auth.sessions;
SELECT COUNT(*) as refresh_token_count FROM auth.refresh_tokens;

-- ============================================================================
-- SUCCESS MESSAGE
-- ============================================================================

DO $$
BEGIN
    RAISE NOTICE '
    ╔════════════════════════════════════════════════════════════════╗
    ║   ✅ SESSIONS AND TOKENS CLEARED                              ║
    ╠════════════════════════════════════════════════════════════════╣
    ║                                                                ║
    ║   All stale refresh tokens have been removed.                  ║
    ║   Users will need to log in fresh.                             ║
    ║                                                                ║
    ║   Next steps:                                                  ║
    ║   1. Clear browser localStorage and sessionStorage             ║
    ║   2. Close all browser tabs with your app                      ║
    ║   3. Restart: npm run dev                                      ║
    ║   4. Open fresh browser tab                                    ║
    ║   5. Try logging in again                                      ║
    ║                                                                ║
    ╚════════════════════════════════════════════════════════════════╝
    ';
END $$;
