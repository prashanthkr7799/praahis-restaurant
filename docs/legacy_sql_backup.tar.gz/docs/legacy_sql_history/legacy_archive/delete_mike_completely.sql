-- Complete cleanup and recreation plan for mike@gmail.com

-- Step 1: Delete mike from public.users (since there's no matching auth.users)
DELETE FROM public.users 
WHERE id = 'f30cd974-f656-4435-9f16-8bf1665f271f' 
  AND email = 'mike@gmail.com';

-- Step 2: Verify deletion
SELECT 
  COUNT(*) as mike_users_remaining,
  CASE 
    WHEN COUNT(*) = 0 THEN '✅ Mike deleted successfully - ready to recreate'
    ELSE '❌ Still exists'
  END as status
FROM public.users
WHERE email = 'mike@gmail.com';

-- Step 3: Verify no auth.users entry either
SELECT 
  COUNT(*) as auth_users_count,
  CASE 
    WHEN COUNT(*) = 0 THEN '✅ No auth.users entry - clean slate'
    ELSE '❌ Auth user still exists'
  END as status
FROM auth.users
WHERE email = 'mike@gmail.com';

-- Now mike@gmail.com is completely removed from the database
-- Next steps:
-- 1. Make sure you've run create_admin_upsert_function.sql
-- 2. Go to the app and create mike@gmail.com again through the Staff Management page
-- 3. This time it should work properly with both auth.users and public.users created
