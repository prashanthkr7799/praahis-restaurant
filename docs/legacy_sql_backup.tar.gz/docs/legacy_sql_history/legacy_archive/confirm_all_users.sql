-- =========================================================================
-- CONFIRM ALL UNCONFIRMED USERS
-- =========================================================================
-- This confirms all users who were created but not confirmed
-- =========================================================================

-- Confirm all unconfirmed users
UPDATE auth.users 
SET email_confirmed_at = NOW(),
    confirmation_token = ''
WHERE email_confirmed_at IS NULL;

-- Verify all users are now confirmed
SELECT 
    id,
    email,
    email_confirmed_at,
    created_at
FROM auth.users 
ORDER BY created_at DESC;

-- =========================================================================
-- All users are now confirmed and can login!
-- =========================================================================
