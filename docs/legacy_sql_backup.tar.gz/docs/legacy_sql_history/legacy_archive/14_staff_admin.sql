-- ============================================================================
-- Staff admin helper functions (SECURITY DEFINER, idempotent)
-- Purpose: allow managers to list and manage staff in their restaurant without
-- relying on recursive RLS on public.users.
-- Run after 10_multitenancy.sql and 13_users_rls_self.sql
-- ============================================================================

-- 1) list_staff_for_current_restaurant -------------------------------------------------
CREATE OR REPLACE FUNCTION public.list_staff_for_current_restaurant()
RETURNS SETOF public.users
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT u.*
  FROM public.users u
  WHERE u.restaurant_id = (
    SELECT restaurant_id FROM public.users WHERE id = auth.uid()
  )
  ORDER BY u.role, u.full_name NULLS LAST;
$$;

REVOKE ALL ON FUNCTION public.list_staff_for_current_restaurant() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.list_staff_for_current_restaurant() TO authenticated;

-- 2) admin_set_staff_active -------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.admin_set_staff_active(target_id uuid, p_is_active boolean)
RETURNS public.users
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  me public.users;
  target public.users;
BEGIN
  SELECT * INTO me FROM public.users WHERE id = auth.uid();
  IF me.id IS NULL THEN
    RAISE EXCEPTION 'Not a staff user';
  END IF;
  IF me.role NOT IN ('manager','admin') THEN
    RAISE EXCEPTION 'Insufficient role';
  END IF;

  SELECT * INTO target FROM public.users WHERE id = target_id;
  IF target.id IS NULL THEN
    RAISE EXCEPTION 'Target user not found';
  END IF;
  IF target.restaurant_id IS DISTINCT FROM me.restaurant_id THEN
    RAISE EXCEPTION 'Cross-restaurant update not allowed';
  END IF;

  UPDATE public.users
    SET is_active = COALESCE(p_is_active, target.is_active),
        updated_at = NOW()
    WHERE id = target.id
    RETURNING * INTO target;
  RETURN target;
END$$;

REVOKE ALL ON FUNCTION public.admin_set_staff_active(uuid, boolean) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.admin_set_staff_active(uuid, boolean) TO authenticated;

-- 3) admin_update_staff (name/phone/role) ----------------------------------------------
CREATE OR REPLACE FUNCTION public.admin_update_staff(
  target_id uuid,
  p_full_name text,
  p_phone text,
  p_role text,
  p_is_active boolean
) RETURNS public.users
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  me public.users;
  target public.users;
  new_role text := NULLIF(TRIM(LOWER(p_role)), '');
BEGIN
  SELECT * INTO me FROM public.users WHERE id = auth.uid();
  IF me.id IS NULL THEN RAISE EXCEPTION 'Not a staff user'; END IF;
  IF me.role NOT IN ('manager','admin') THEN RAISE EXCEPTION 'Insufficient role'; END IF;

  SELECT * INTO target FROM public.users WHERE id = target_id;
  IF target.id IS NULL THEN RAISE EXCEPTION 'Target user not found'; END IF;
  IF target.restaurant_id IS DISTINCT FROM me.restaurant_id THEN
    RAISE EXCEPTION 'Cross-restaurant update not allowed';
  END IF;

  IF new_role IS NOT NULL AND new_role NOT IN ('admin','manager','chef','waiter') THEN
    RAISE EXCEPTION 'Invalid role %', new_role;
  END IF;

  UPDATE public.users
    SET full_name = COALESCE(NULLIF(TRIM(p_full_name), ''), target.full_name),
        phone = COALESCE(NULLIF(TRIM(p_phone), ''), target.phone),
        role = COALESCE(new_role, target.role),
        is_active = COALESCE(p_is_active, target.is_active),
        updated_at = NOW()
    WHERE id = target.id
    RETURNING * INTO target;
  RETURN target;
END$$;

REVOKE ALL ON FUNCTION public.admin_update_staff(uuid, text, text, text, boolean) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.admin_update_staff(uuid, text, text, text, boolean) TO authenticated;

-- 4) admin_upsert_user_profile ----------------------------------------------------------
-- Use after creating an Auth user; inserts/updates row in public.users with given data.
CREATE OR REPLACE FUNCTION public.admin_upsert_user_profile(
  p_id uuid,
  p_email text,
  p_full_name text,
  p_role text,
  p_phone text,
  p_restaurant_id uuid
) RETURNS public.users
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  me public.users;
  outrow public.users;
  new_role text := NULLIF(TRIM(LOWER(p_role)), '');
BEGIN
  SELECT * INTO me FROM public.users WHERE id = auth.uid();
  IF me.id IS NULL THEN RAISE EXCEPTION 'Not a staff user'; END IF;
  IF me.role NOT IN ('manager','admin') THEN RAISE EXCEPTION 'Insufficient role'; END IF;
  IF p_restaurant_id IS DISTINCT FROM me.restaurant_id THEN
    RAISE EXCEPTION 'Cross-restaurant insert not allowed';
  END IF;
  IF new_role IS NOT NULL AND new_role NOT IN ('admin','manager','chef','waiter') THEN
    RAISE EXCEPTION 'Invalid role %', new_role;
  END IF;

  INSERT INTO public.users (id, email, full_name, role, phone, restaurant_id, is_active, created_at, updated_at)
  VALUES (p_id, p_email, COALESCE(NULLIF(TRIM(p_full_name), ''), p_email), new_role, NULLIF(TRIM(p_phone), ''), p_restaurant_id, TRUE, NOW(), NOW())
  ON CONFLICT (id) DO UPDATE
    SET email = EXCLUDED.email,
        full_name = EXCLUDED.full_name,
        role = CASE WHEN EXCLUDED.role IS NOT NULL THEN EXCLUDED.role ELSE public.users.role END,
        phone = EXCLUDED.phone,
        restaurant_id = EXCLUDED.restaurant_id,
        is_active = TRUE,
        updated_at = NOW()
  RETURNING * INTO outrow;
  RETURN outrow;
END$$;

REVOKE ALL ON FUNCTION public.admin_upsert_user_profile(uuid, text, text, text, text, uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.admin_upsert_user_profile(uuid, text, text, text, text, uuid) TO authenticated;

-- ============================================================================
