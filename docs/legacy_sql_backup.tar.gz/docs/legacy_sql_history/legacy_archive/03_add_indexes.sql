-- ============================================================================
-- CLEAN DATABASE SETUP - INDEXES
-- ============================================================================
-- Generated: 2025-11-18 13:10:11
-- Description: Performance indexes for all tables
-- ============================================================================

-- ============================================================================
-- RESTAURANTS INDEXES
-- ============================================================================
CREATE UNIQUE INDEX IF NOT EXISTS idx_restaurants_slug_unique ON restaurants(LOWER(slug));
CREATE INDEX IF NOT EXISTS idx_restaurants_is_active ON restaurants(is_active);
CREATE INDEX IF NOT EXISTS idx_restaurants_payment_enabled ON restaurants(payment_gateway_enabled);

-- ============================================================================
-- USERS INDEXES
-- ============================================================================
CREATE INDEX IF NOT EXISTS idx_users_email_lower ON users(LOWER(email));
CREATE INDEX IF NOT EXISTS idx_users_restaurant_id ON users(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_users_is_owner ON users(is_owner);
CREATE INDEX IF NOT EXISTS idx_users_is_active ON users(is_active);
CREATE INDEX IF NOT EXISTS idx_users_restaurant_active ON users(restaurant_id, is_active, role);
CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone);

-- ============================================================================
-- TABLES INDEXES
-- ============================================================================
CREATE INDEX IF NOT EXISTS idx_tables_restaurant ON tables(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_tables_status ON tables(status) WHERE is_active = true;

-- ============================================================================
-- MENU ITEMS INDEXES
-- ============================================================================
CREATE INDEX IF NOT EXISTS idx_menu_items_restaurant ON menu_items(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_menu_items_category ON menu_items(category);
CREATE INDEX IF NOT EXISTS idx_menu_items_available ON menu_items(is_available) WHERE is_available = true;

-- ============================================================================
-- TABLE SESSIONS INDEXES
-- ============================================================================
CREATE INDEX IF NOT EXISTS idx_table_sessions_table ON table_sessions(table_id, status, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_table_sessions_restaurant ON table_sessions(restaurant_id, status, started_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS idx_table_sessions_active_unique ON table_sessions(table_id) 
    WHERE status = 'active';

-- ============================================================================
-- ORDERS INDEXES (Most queried table)
-- ============================================================================
CREATE INDEX IF NOT EXISTS idx_orders_restaurant ON orders(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_orders_restaurant_created_at ON orders(restaurant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_table ON orders(table_id);
CREATE INDEX IF NOT EXISTS idx_orders_session ON orders(session_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(order_status);
CREATE INDEX IF NOT EXISTS idx_orders_payment_status ON orders(payment_status);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_order_number ON orders(order_number);
CREATE INDEX IF NOT EXISTS idx_orders_feedback ON orders(feedback_submitted);

-- ============================================================================
-- PAYMENTS INDEXES
-- ============================================================================
CREATE INDEX IF NOT EXISTS idx_payments_restaurant ON payments(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_payments_order ON payments(order_id);
CREATE INDEX IF NOT EXISTS idx_payments_billing ON payments(billing_id);
CREATE INDEX IF NOT EXISTS idx_payments_subscription ON payments(subscription_id);
CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);
CREATE INDEX IF NOT EXISTS idx_payments_date ON payments(payment_date);
CREATE INDEX IF NOT EXISTS idx_payments_gateway_id ON payments(payment_gateway_id);

-- ============================================================================
-- ORDER PAYMENTS INDEXES
-- ============================================================================
CREATE INDEX IF NOT EXISTS idx_order_payments_restaurant_id ON order_payments(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_order_payments_order_id ON order_payments(order_id);
CREATE INDEX IF NOT EXISTS idx_order_payments_razorpay_payment_id ON order_payments(razorpay_payment_id);

-- ============================================================================
-- SUBSCRIPTIONS INDEXES
-- ============================================================================
CREATE INDEX IF NOT EXISTS idx_subscriptions_restaurant ON subscriptions(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_status ON subscriptions(status);
CREATE INDEX IF NOT EXISTS idx_subscriptions_end_date ON subscriptions(end_date);
CREATE INDEX IF NOT EXISTS idx_subscriptions_next_billing ON subscriptions(next_billing_date);

-- ============================================================================
-- BILLING INDEXES
-- ============================================================================
CREATE INDEX IF NOT EXISTS idx_billing_restaurant ON billing(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_billing_status ON billing(status);
CREATE INDEX IF NOT EXISTS idx_billing_due_date ON billing(due_date);
CREATE INDEX IF NOT EXISTS idx_billing_period ON billing(billing_period);
CREATE INDEX IF NOT EXISTS idx_billing_grace_end ON billing(grace_end_date);

-- ============================================================================
-- FEEDBACKS INDEXES
-- ============================================================================
CREATE INDEX IF NOT EXISTS idx_feedbacks_restaurant ON feedbacks(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_feedbacks_restaurant_created_at ON feedbacks(restaurant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_feedbacks_order ON feedbacks(order_id);
CREATE INDEX IF NOT EXISTS idx_feedbacks_session ON feedbacks(session_id);
CREATE INDEX IF NOT EXISTS idx_feedbacks_created_at ON feedbacks(created_at DESC);

-- ============================================================================
-- MENU ITEM RATINGS INDEXES
-- ============================================================================
CREATE INDEX IF NOT EXISTS idx_item_ratings_restaurant ON menu_item_ratings(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_item_ratings_item ON menu_item_ratings(menu_item_id);
CREATE INDEX IF NOT EXISTS idx_item_ratings_order ON menu_item_ratings(order_id);
CREATE INDEX IF NOT EXISTS idx_item_ratings_session ON menu_item_ratings(session_id);
CREATE INDEX IF NOT EXISTS idx_item_ratings_created_at ON menu_item_ratings(created_at DESC);

-- ============================================================================
-- NOTIFICATIONS INDEXES
-- ============================================================================
CREATE INDEX IF NOT EXISTS idx_notifications_restaurant_created ON notifications(restaurant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_user_created ON notifications(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_unread ON notifications(restaurant_id, is_read, created_at DESC);

-- ============================================================================
-- OFFERS INDEXES
-- ============================================================================
CREATE INDEX IF NOT EXISTS idx_offers_restaurant ON offers(restaurant_id);

-- ============================================================================
-- ACTIVITY LOGS INDEXES
-- ============================================================================
CREATE INDEX IF NOT EXISTS idx_activity_logs_restaurant ON activity_logs(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_activity_logs_user ON activity_logs(user_id);

-- ============================================================================
-- PLATFORM ADMIN TABLES INDEXES
-- ============================================================================
CREATE INDEX IF NOT EXISTS idx_platform_settings_category ON platform_settings(category);
CREATE INDEX IF NOT EXISTS idx_platform_admins_role ON platform_admins(role);
CREATE INDEX IF NOT EXISTS idx_platform_admins_active ON platform_admins(is_active);
CREATE INDEX IF NOT EXISTS idx_platform_admins_email ON platform_admins(email);

CREATE INDEX IF NOT EXISTS idx_system_logs_level ON system_logs(level);
CREATE INDEX IF NOT EXISTS idx_system_logs_source ON system_logs(source);
CREATE INDEX IF NOT EXISTS idx_system_logs_created_at ON system_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_system_logs_restaurant ON system_logs(restaurant_id);

CREATE INDEX IF NOT EXISTS idx_audit_trail_actor ON audit_trail(actor_id);
CREATE INDEX IF NOT EXISTS idx_audit_trail_entity ON audit_trail(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_audit_trail_action ON audit_trail(action);
CREATE INDEX IF NOT EXISTS idx_audit_trail_created ON audit_trail(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_trail_severity ON audit_trail(severity);

CREATE INDEX IF NOT EXISTS idx_backups_restaurant ON backups(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_backups_status ON backups(status);
CREATE INDEX IF NOT EXISTS idx_backups_created ON backups(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_backups_expires ON backups(expires_at);

CREATE INDEX IF NOT EXISTS idx_backup_schedules_active ON backup_schedules(is_active);
CREATE INDEX IF NOT EXISTS idx_backup_schedules_next_run ON backup_schedules(next_run);

CREATE INDEX IF NOT EXISTS idx_maintenance_mode_active ON maintenance_mode(is_active);
CREATE INDEX IF NOT EXISTS idx_maintenance_mode_start_time ON maintenance_mode(start_time);

CREATE INDEX IF NOT EXISTS idx_payment_credential_audit_restaurant ON payment_credential_audit(restaurant_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_auth_activity_logs_user_id ON auth_activity_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_auth_activity_logs_action ON auth_activity_logs(action);
CREATE INDEX IF NOT EXISTS idx_auth_activity_logs_created_at ON auth_activity_logs(created_at DESC);

-- ============================================================================
-- INDEXES CREATED
-- ============================================================================

SELECT 'All indexes created successfully!' AS status;
