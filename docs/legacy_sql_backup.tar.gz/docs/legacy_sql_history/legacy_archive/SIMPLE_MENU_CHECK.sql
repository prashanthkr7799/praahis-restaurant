-- Simple check - just count menu items
SELECT COUNT(*) as total_menu_items FROM menu_items;
