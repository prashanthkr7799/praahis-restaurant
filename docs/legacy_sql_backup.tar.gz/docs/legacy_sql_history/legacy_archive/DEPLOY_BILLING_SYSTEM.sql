-- ============================================================================
-- SAFE DEPLOYMENT: BILLING & PAYMENTS SYSTEM
-- ============================================================================
-- This version can be run multiple times safely
-- It will clean up existing objects before creating new ones
-- ============================================================================

\echo '============================================================================'
\echo 'DEPLOYING BILLING & PAYMENTS SYSTEM'
\echo '============================================================================'

-- Enable UUID extension
DO $$ 
BEGIN
    CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
EXCEPTION
    WHEN duplicate_object THEN 
        RAISE NOTICE 'Extension uuid-ossp already exists, skipping';
END $$;

-- Clean up existing objects
\echo 'Cleaning up existing objects...'

DROP TRIGGER IF EXISTS update_billing_timestamp_trigger ON billing CASCADE;
DROP TRIGGER IF EXISTS update_payments_timestamp_trigger ON payments CASCADE;

DROP FUNCTION IF EXISTS calculate_billing_amount CASCADE;
DROP FUNCTION IF EXISTS generate_monthly_bills CASCADE;
DROP FUNCTION IF EXISTS mark_bill_as_paid CASCADE;
DROP FUNCTION IF EXISTS suspend_overdue_restaurants CASCADE;
DROP FUNCTION IF EXISTS get_restaurant_billing_summary CASCADE;
DROP FUNCTION IF EXISTS update_billing_timestamp CASCADE;

DROP TABLE IF EXISTS payments CASCADE;
DROP TABLE IF EXISTS billing CASCADE;

\echo 'Cleanup complete. Creating new objects...'

-- Now run the main SQL file
\ir 40_billing_payments_system.sql

\echo '============================================================================'
\echo 'VERIFYING INSTALLATION'
\echo '============================================================================'

-- Verify tables exist
SELECT 
    CASE 
        WHEN COUNT(*) = 2 THEN '✅ Tables created successfully'
        ELSE '❌ ERROR: Missing tables'
    END AS table_status
FROM information_schema.tables
WHERE table_schema = 'public'
AND table_name IN ('billing', 'payments');

-- Verify functions exist
SELECT 
    CASE 
        WHEN COUNT(*) >= 5 THEN '✅ Functions created successfully'
        ELSE '❌ ERROR: Missing functions'
    END AS function_status
FROM information_schema.routines
WHERE routine_schema = 'public'
AND routine_name IN (
    'calculate_billing_amount',
    'generate_monthly_bills',
    'mark_bill_as_paid',
    'suspend_overdue_restaurants',
    'get_restaurant_billing_summary'
);

-- Verify triggers exist
SELECT 
    CASE 
        WHEN COUNT(*) = 2 THEN '✅ Triggers created successfully'
        ELSE '❌ ERROR: Missing triggers'
    END AS trigger_status
FROM information_schema.triggers
WHERE trigger_schema = 'public'
AND trigger_name IN (
    'update_billing_timestamp_trigger',
    'update_payments_timestamp_trigger'
);

-- Test calculation function
\echo 'Testing calculation function...'
SELECT 
    calculate_billing_amount(10, 100, 30) AS calculated_amount,
    CASE 
        WHEN calculate_billing_amount(10, 100, 30) = 30000 THEN '✅ Calculation correct'
        ELSE '❌ Calculation error'
    END AS test_result;

\echo '============================================================================'
\echo 'DEPLOYMENT COMPLETE'
\echo '============================================================================'
\echo ''
\echo 'Next steps:'
\echo '1. Create your superadmin account'
\echo '2. Run: SELECT * FROM generate_monthly_bills();'
\echo '3. Setup Supabase Edge Functions for automation'
\echo ''
