-- ============================================================================
-- BILLING & PAYMENTS SYSTEM - AUTOMATED PER-TABLE BILLING
-- ============================================================================
-- Version: 1.0
-- Created: November 7, 2025
-- Description: Dynamic billing system - ₹100 per table per day
-- Pricing Model: Monthly billing = table_count × 100 × days_in_month
-- Grace Period: 3 days after due date before auto-suspension
-- ============================================================================

-- Enable UUID extension if not exists
DO $$ 
BEGIN
    CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
EXCEPTION
    WHEN duplicate_object THEN NULL;
END $$;

-- Drop existing objects if they exist (for clean reinstall)
DROP TABLE IF EXISTS payments CASCADE;
DROP TABLE IF EXISTS billing CASCADE;
DROP FUNCTION IF EXISTS calculate_billing_amount CASCADE;
DROP FUNCTION IF EXISTS generate_monthly_bills CASCADE;
DROP FUNCTION IF EXISTS mark_bill_as_paid CASCADE;
DROP FUNCTION IF EXISTS suspend_overdue_restaurants CASCADE;
DROP FUNCTION IF EXISTS get_restaurant_billing_summary CASCADE;
DROP FUNCTION IF EXISTS update_billing_timestamp CASCADE;

-- ============================================================================
-- TABLE 1: BILLING
-- ============================================================================
-- Tracks monthly bills for each restaurant based on table count

CREATE TABLE IF NOT EXISTS billing (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
    
    -- Billing Period
    billing_month INTEGER NOT NULL CHECK (billing_month BETWEEN 1 AND 12),
    billing_year INTEGER NOT NULL CHECK (billing_year >= 2024),
    billing_period DATE NOT NULL, -- First day of billing month
    
    -- Billing Calculation
    table_count INTEGER NOT NULL CHECK (table_count >= 0),
    rate_per_table_per_day DECIMAL(10, 2) NOT NULL DEFAULT 100.00,
    days_in_month INTEGER NOT NULL CHECK (days_in_month BETWEEN 28 AND 31),
    
    -- Amount Calculation: table_count × rate × days_in_month
    base_amount DECIMAL(10, 2) NOT NULL CHECK (base_amount >= 0),
    discount_amount DECIMAL(10, 2) DEFAULT 0 CHECK (discount_amount >= 0),
    tax_amount DECIMAL(10, 2) DEFAULT 0 CHECK (tax_amount >= 0),
    total_amount DECIMAL(10, 2) NOT NULL CHECK (total_amount >= 0),
    
    -- Payment Status
    status VARCHAR(50) DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'overdue', 'cancelled')),
    
    -- Important Dates
    due_date DATE NOT NULL,
    grace_period_days INTEGER DEFAULT 3,
    grace_end_date DATE NOT NULL,
    paid_at TIMESTAMP WITH TIME ZONE,
    
    -- Actions
    suspended_at TIMESTAMP WITH TIME ZONE,
    reactivated_at TIMESTAMP WITH TIME ZONE,
    
    -- Metadata
    notes TEXT,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Constraints
    UNIQUE(restaurant_id, billing_year, billing_month)
);

COMMENT ON TABLE billing IS 'Monthly billing records for restaurants - ₹100 per table per day';
COMMENT ON COLUMN billing.billing_period IS 'First day of the billing month (e.g., 2025-11-01)';
COMMENT ON COLUMN billing.table_count IS 'Number of tables at the time of bill generation';
COMMENT ON COLUMN billing.rate_per_table_per_day IS 'Daily rate per table (default ₹100)';
COMMENT ON COLUMN billing.base_amount IS 'table_count × rate × days_in_month';
COMMENT ON COLUMN billing.grace_period_days IS 'Days after due_date before suspension (default 3)';
COMMENT ON COLUMN billing.grace_end_date IS 'Last day of grace period before auto-suspension';
COMMENT ON COLUMN billing.status IS 'pending, paid, overdue, cancelled';

-- Indexes
CREATE INDEX idx_billing_restaurant ON billing(restaurant_id);
CREATE INDEX idx_billing_status ON billing(status);
CREATE INDEX idx_billing_due_date ON billing(due_date);
CREATE INDEX idx_billing_period ON billing(billing_period);
CREATE INDEX idx_billing_grace_end ON billing(grace_end_date);

-- ============================================================================
-- TABLE 2: PAYMENTS
-- ============================================================================
-- Payment records for bills (manual or automated)

CREATE TABLE IF NOT EXISTS payments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    billing_id UUID NOT NULL REFERENCES billing(id) ON DELETE CASCADE,
    restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
    
    -- Payment Details
    amount DECIMAL(10, 2) NOT NULL CHECK (amount > 0),
    payment_method VARCHAR(50) DEFAULT 'manual' CHECK (payment_method IN ('manual', 'razorpay', 'stripe', 'bank_transfer', 'cash', 'upi', 'other')),
    payment_status VARCHAR(50) DEFAULT 'completed' CHECK (payment_status IN ('pending', 'completed', 'failed', 'refunded')),
    
    -- Transaction Details
    transaction_id VARCHAR(255),
    transaction_reference VARCHAR(255),
    payment_gateway VARCHAR(50),
    
    -- Payment Proof
    receipt_url TEXT,
    invoice_url TEXT,
    
    -- Dates
    payment_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    verified_at TIMESTAMP WITH TIME ZONE,
    verified_by UUID REFERENCES auth.users(id),
    
    -- Metadata
    notes TEXT,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE payments IS 'Payment records for billing - manual or automated';
COMMENT ON COLUMN payments.payment_method IS 'manual, razorpay, stripe, bank_transfer, cash, upi, other';
COMMENT ON COLUMN payments.payment_status IS 'pending, completed, failed, refunded';
COMMENT ON COLUMN payments.verified_by IS 'Super admin who verified the payment';

-- Indexes
CREATE INDEX idx_payments_billing ON payments(billing_id);
CREATE INDEX idx_payments_restaurant ON payments(restaurant_id);
CREATE INDEX idx_payments_status ON payments(payment_status);
CREATE INDEX idx_payments_date ON payments(payment_date);

-- ============================================================================
-- FUNCTION: Calculate Monthly Bill Amount
-- ============================================================================

CREATE OR REPLACE FUNCTION calculate_billing_amount(
    p_table_count INTEGER,
    p_rate_per_table DECIMAL DEFAULT 100.00,
    p_days_in_month INTEGER DEFAULT 30
)
RETURNS DECIMAL AS $$
BEGIN
    RETURN p_table_count * p_rate_per_table * p_days_in_month;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

COMMENT ON FUNCTION calculate_billing_amount IS 'Calculate base billing amount: table_count × rate × days';

-- ============================================================================
-- FUNCTION: Generate Monthly Bills for All Restaurants
-- ============================================================================

CREATE OR REPLACE FUNCTION generate_monthly_bills(
    p_billing_month INTEGER DEFAULT EXTRACT(MONTH FROM CURRENT_DATE)::INTEGER,
    p_billing_year INTEGER DEFAULT EXTRACT(YEAR FROM CURRENT_DATE)::INTEGER
)
RETURNS TABLE(
    restaurant_id UUID,
    restaurant_name TEXT,
    table_count BIGINT,
    amount DECIMAL,
    status TEXT
) AS $$
DECLARE
    v_billing_period DATE;
    v_days_in_month INTEGER;
    v_due_date DATE;
    v_grace_end_date DATE;
    v_rate DECIMAL := 100.00;
    v_grace_days INTEGER := 3;
BEGIN
    -- Calculate dates
    v_billing_period := make_date(p_billing_year, p_billing_month, 1);
    v_days_in_month := EXTRACT(DAY FROM (v_billing_period + INTERVAL '1 month' - INTERVAL '1 day'))::INTEGER;
    v_due_date := v_billing_period + INTERVAL '1 month'; -- Due on 1st of next month
    v_grace_end_date := v_due_date + (v_grace_days || ' days')::INTERVAL;
    
    -- Generate bills for all active restaurants
    RETURN QUERY
    INSERT INTO billing (
        restaurant_id,
        billing_month,
        billing_year,
        billing_period,
        table_count,
        rate_per_table_per_day,
        days_in_month,
        base_amount,
        total_amount,
        status,
        due_date,
        grace_period_days,
        grace_end_date
    )
    SELECT 
        r.id,
        p_billing_month,
        p_billing_year,
        v_billing_period,
        COUNT(t.id)::INTEGER AS tables,
        v_rate,
        v_days_in_month,
        calculate_billing_amount(COUNT(t.id)::INTEGER, v_rate, v_days_in_month),
        calculate_billing_amount(COUNT(t.id)::INTEGER, v_rate, v_days_in_month),
        'pending',
        v_due_date,
        v_grace_days,
        v_grace_end_date
    FROM restaurants r
    LEFT JOIN tables t ON t.restaurant_id = r.id AND t.is_active = true
    WHERE r.is_active = true
    GROUP BY r.id
    ON CONFLICT (restaurant_id, billing_year, billing_month) DO NOTHING
    RETURNING 
        billing.restaurant_id,
        (SELECT name FROM restaurants WHERE id = billing.restaurant_id),
        billing.table_count,
        billing.total_amount,
        'Bill generated'::TEXT;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION generate_monthly_bills IS 'Generate bills for all restaurants on 1st of month';

-- ============================================================================
-- FUNCTION: Mark Bill as Paid & Reactivate Restaurant
-- ============================================================================

CREATE OR REPLACE FUNCTION mark_bill_as_paid(
    p_billing_id UUID,
    p_payment_method VARCHAR DEFAULT 'manual',
    p_transaction_id VARCHAR DEFAULT NULL,
    p_verified_by UUID DEFAULT NULL
)
RETURNS JSONB AS $$
DECLARE
    v_billing RECORD;
    v_payment_id UUID;
    v_result JSONB;
BEGIN
    -- Get billing record
    SELECT * INTO v_billing FROM billing WHERE id = p_billing_id;
    
    IF NOT FOUND THEN
        RETURN jsonb_build_object(
            'success', false,
            'error', 'Billing record not found'
        );
    END IF;
    
    -- Create payment record
    INSERT INTO payments (
        billing_id,
        restaurant_id,
        amount,
        payment_method,
        payment_status,
        transaction_id,
        payment_date,
        verified_by
    ) VALUES (
        p_billing_id,
        v_billing.restaurant_id,
        v_billing.total_amount,
        p_payment_method,
        'completed',
        p_transaction_id,
        NOW(),
        p_verified_by
    ) RETURNING id INTO v_payment_id;
    
    -- Update billing status
    UPDATE billing 
    SET 
        status = 'paid',
        paid_at = NOW(),
        reactivated_at = NOW(),
        updated_at = NOW()
    WHERE id = p_billing_id;
    
    -- Reactivate restaurant if suspended
    UPDATE restaurants 
    SET 
        is_active = true,
        updated_at = NOW()
    WHERE id = v_billing.restaurant_id AND is_active = false;
    
    v_result := jsonb_build_object(
        'success', true,
        'billing_id', p_billing_id,
        'payment_id', v_payment_id,
        'restaurant_id', v_billing.restaurant_id,
        'amount', v_billing.total_amount,
        'message', 'Payment recorded and restaurant reactivated'
    );
    
    RETURN v_result;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION mark_bill_as_paid IS 'Record payment and auto-reactivate restaurant';

-- ============================================================================
-- FUNCTION: Auto-Suspend Overdue Restaurants
-- ============================================================================

CREATE OR REPLACE FUNCTION suspend_overdue_restaurants()
RETURNS TABLE(
    restaurant_id UUID,
    restaurant_name TEXT,
    billing_id UUID,
    amount_due DECIMAL,
    days_overdue INTEGER,
    action TEXT
) AS $$
BEGIN
    RETURN QUERY
    WITH overdue_bills AS (
        SELECT 
            b.id AS billing_id,
            b.restaurant_id,
            r.name AS restaurant_name,
            b.total_amount,
            CURRENT_DATE - b.grace_end_date AS days_past_grace,
            r.is_active
        FROM billing b
        JOIN restaurants r ON r.id = b.restaurant_id
        WHERE b.status IN ('pending', 'overdue')
          AND CURRENT_DATE > b.grace_end_date
          AND r.is_active = true
    )
    UPDATE billing b
    SET 
        status = 'overdue',
        suspended_at = NOW(),
        updated_at = NOW()
    FROM overdue_bills ob
    WHERE b.id = ob.billing_id
    RETURNING 
        b.restaurant_id,
        ob.restaurant_name,
        b.id,
        b.total_amount,
        ob.days_past_grace,
        'Suspended'::TEXT;
    
    -- Also update restaurant status
    UPDATE restaurants r
    SET is_active = false, updated_at = NOW()
    FROM billing b
    WHERE r.id = b.restaurant_id
      AND b.status = 'overdue'
      AND CURRENT_DATE > b.grace_end_date
      AND r.is_active = true;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION suspend_overdue_restaurants IS 'Auto-suspend restaurants with bills past grace period';

-- ============================================================================
-- FUNCTION: Get Restaurant Billing Summary
-- ============================================================================

CREATE OR REPLACE FUNCTION get_restaurant_billing_summary(p_restaurant_id UUID)
RETURNS JSONB AS $$
DECLARE
    v_result JSONB;
    v_current_bill RECORD;
    v_total_paid DECIMAL;
    v_total_pending DECIMAL;
BEGIN
    -- Get current/latest bill
    SELECT * INTO v_current_bill
    FROM billing
    WHERE restaurant_id = p_restaurant_id
    ORDER BY billing_period DESC
    LIMIT 1;
    
    -- Calculate totals
    SELECT 
        COALESCE(SUM(CASE WHEN status = 'paid' THEN total_amount ELSE 0 END), 0),
        COALESCE(SUM(CASE WHEN status IN ('pending', 'overdue') THEN total_amount ELSE 0 END), 0)
    INTO v_total_paid, v_total_pending
    FROM billing
    WHERE restaurant_id = p_restaurant_id;
    
    v_result := jsonb_build_object(
        'restaurant_id', p_restaurant_id,
        'current_bill', row_to_json(v_current_bill),
        'total_paid', v_total_paid,
        'total_pending', v_total_pending,
        'has_overdue', EXISTS(
            SELECT 1 FROM billing 
            WHERE restaurant_id = p_restaurant_id 
            AND status = 'overdue'
        )
    );
    
    RETURN v_result;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION get_restaurant_billing_summary IS 'Get comprehensive billing summary for a restaurant';

-- ============================================================================
-- TRIGGERS: Auto-update timestamps
-- ============================================================================

CREATE OR REPLACE FUNCTION update_billing_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS update_billing_timestamp_trigger ON billing;
CREATE TRIGGER update_billing_timestamp_trigger
    BEFORE UPDATE ON billing
    FOR EACH ROW
    EXECUTE FUNCTION update_billing_timestamp();

DROP TRIGGER IF EXISTS update_payments_timestamp_trigger ON payments;
CREATE TRIGGER update_payments_timestamp_trigger
    BEFORE UPDATE ON payments
    FOR EACH ROW
    EXECUTE FUNCTION update_billing_timestamp();

-- ============================================================================
-- ROW LEVEL SECURITY (RLS)
-- ============================================================================

-- Enable RLS only if not already enabled
DO $$
BEGIN
    ALTER TABLE billing ENABLE ROW LEVEL SECURITY;
EXCEPTION
    WHEN undefined_table THEN NULL;
END $$;

DO $$
BEGIN
    ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
EXCEPTION
    WHEN undefined_table THEN NULL;
END $$;

-- Super Admin: Full access to billing
DROP POLICY IF EXISTS "Superadmin full access to billing" ON billing;
CREATE POLICY "Superadmin full access to billing" ON billing
    FOR ALL 
    USING (
        EXISTS (
            SELECT 1 FROM auth.users
            WHERE id = auth.uid()
            AND raw_user_meta_data->>'is_owner' = 'true'
        )
        OR
        (auth.jwt() ->> 'is_owner')::boolean = true
    );

-- Super Admin: Full access to payments
DROP POLICY IF EXISTS "Superadmin full access to payments" ON payments;
CREATE POLICY "Superadmin full access to payments" ON payments
    FOR ALL 
    USING (
        EXISTS (
            SELECT 1 FROM auth.users
            WHERE id = auth.uid()
            AND raw_user_meta_data->>'is_owner' = 'true'
        )
        OR
        (auth.jwt() ->> 'is_owner')::boolean = true
    );

-- Restaurant Managers: View their own billing
DROP POLICY IF EXISTS "Managers view own restaurant billing" ON billing;
CREATE POLICY "Managers view own restaurant billing" ON billing
    FOR SELECT 
    USING (
        EXISTS (
            SELECT 1 FROM users 
            WHERE users.id = auth.uid() 
            AND users.restaurant_id = billing.restaurant_id
            AND users.role IN ('manager', 'admin')
        )
    );

-- Restaurant Managers: View their own payments
DROP POLICY IF EXISTS "Managers view own restaurant payments" ON payments;
CREATE POLICY "Managers view own restaurant payments" ON payments
    FOR SELECT 
    USING (
        EXISTS (
            SELECT 1 FROM users 
            WHERE users.id = auth.uid() 
            AND users.restaurant_id = payments.restaurant_id
            AND users.role IN ('manager', 'admin')
        )
    );

-- ============================================================================
-- INITIAL DATA SETUP
-- ============================================================================

-- Generate bills for current month (if it's after the 1st)
-- SELECT * FROM generate_monthly_bills();

COMMENT ON SCHEMA public IS 'Billing system: ₹100 per table per day, 3-day grace period, auto-suspend';

-- ============================================================================
-- USAGE EXAMPLES
-- ============================================================================

/*
-- 1. Generate monthly bills (run on 1st of each month)
SELECT * FROM generate_monthly_bills();

-- 2. Check for overdue restaurants and suspend them (run daily)
SELECT * FROM suspend_overdue_restaurants();

-- 3. Mark a bill as paid and reactivate restaurant
SELECT mark_bill_as_paid(
    '<billing_id>'::UUID,
    'manual',
    'TXN12345',
    '<admin_user_id>'::UUID
);

-- 4. Get billing summary for a restaurant
SELECT get_restaurant_billing_summary('<restaurant_id>'::UUID);

-- 5. View all pending bills
SELECT 
    r.name,
    b.billing_period,
    b.table_count,
    b.total_amount,
    b.due_date,
    b.grace_end_date,
    b.status
FROM billing b
JOIN restaurants r ON r.id = b.restaurant_id
WHERE b.status = 'pending'
ORDER BY b.due_date;
*/
