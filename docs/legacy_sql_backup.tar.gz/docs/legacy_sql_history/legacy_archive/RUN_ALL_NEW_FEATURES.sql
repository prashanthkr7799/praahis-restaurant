-- ============================================================================
-- PRAAHIS COMPLETE SETUP - RUN ALL NEW FEATURES
-- ============================================================================
-- Quick setup script to deploy all new features at once
-- Run this after your existing database is set up
-- ============================================================================

-- Step 1: Run billing system
\i database/40_billing_payments_system.sql

-- Step 2: Run audit trail system
\i database/41_audit_trail_system.sql

-- Step 3: Run backups and roles
\i database/42_backups_and_roles.sql

-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================

-- Check all tables created
SELECT 
    tablename,
    schemaname
FROM pg_tables 
WHERE schemaname = 'public' 
AND tablename IN (
    'billing',
    'payments', 
    'audit_trail',
    'backups',
    'backup_schedules',
    'platform_admins'
)
ORDER BY tablename;

-- Check all functions created
SELECT 
    routine_name,
    routine_type
FROM information_schema.routines
WHERE routine_schema = 'public'
AND routine_name IN (
    'generate_monthly_bills',
    'suspend_overdue_restaurants',
    'mark_bill_as_paid',
    'get_restaurant_billing_summary',
    'log_audit_trail',
    'get_recent_audit_logs',
    'get_entity_audit_history',
    'create_backup_record',
    'complete_backup',
    'check_admin_permission'
)
ORDER BY routine_name;

-- Check triggers
SELECT 
    trigger_name,
    event_object_table,
    action_timing,
    event_manipulation
FROM information_schema.triggers
WHERE trigger_schema = 'public'
AND trigger_name LIKE '%audit%'
ORDER BY event_object_table, trigger_name;

-- ============================================================================
-- INITIAL DATA SETUP (Run these manually after setup)
-- ============================================================================

-- 1. Generate first monthly bill (example for current month)
-- Uncomment and run when ready:
-- SELECT * FROM generate_monthly_bills(
--     EXTRACT(MONTH FROM CURRENT_DATE)::INTEGER,
--     EXTRACT(YEAR FROM CURRENT_DATE)::INTEGER
-- );

-- 2. Create your first superadmin (replace with your actual user ID)
-- Get your user ID first:
-- SELECT id, email FROM auth.users WHERE email = 'your-email@example.com';

-- Then insert:
/*
INSERT INTO platform_admins (
    user_id,
    email,
    full_name,
    role,
    permissions
) VALUES (
    '<YOUR_USER_ID>'::UUID,
    'admin@praahis.com',
    'Super Administrator',
    'superadmin',
    '{
        "restaurants": {"create": true, "read": true, "update": true, "delete": true},
        "managers": {"create": true, "read": true, "update": true, "delete": true},
        "billing": {"create": true, "read": true, "update": true, "delete": true},
        "settings": {"create": true, "read": true, "update": true, "delete": true},
        "backups": {"create": true, "read": true, "update": true, "delete": true},
        "audit": {"create": true, "read": true, "update": true, "delete": true}
    }'::JSONB
)
ON CONFLICT (user_id) DO NOTHING;
*/

-- ============================================================================
-- TEST QUERIES
-- ============================================================================

-- Test billing calculation
SELECT calculate_billing_amount(
    10,   -- 10 tables
    100,  -- ₹100 per table
    30    -- 30 days in month
);
-- Expected: 30000.00

-- Test audit logging
SELECT log_audit_trail(
    'created',
    'system',
    NULL,
    'Test Entry',
    NULL,
    '{"test": true}'::JSONB,
    'Testing audit trail system',
    'info',
    '{}'::JSONB
);

-- View recent audit logs
SELECT 
    action,
    entity_type,
    entity_name,
    description,
    created_at
FROM get_recent_audit_logs(5);

-- Check permission system (will return false until platform_admins has data)
SELECT check_admin_permission(
    (SELECT id FROM auth.users LIMIT 1),
    'restaurants',
    'read'
) AS has_permission;

-- ============================================================================
-- CLEANUP (Use with caution!)
-- ============================================================================

-- Uncomment to remove everything (for testing/reset only)
/*
DROP TABLE IF EXISTS payments CASCADE;
DROP TABLE IF EXISTS billing CASCADE;
DROP TABLE IF EXISTS audit_trail CASCADE;
DROP TABLE IF EXISTS backup_schedules CASCADE;
DROP TABLE IF EXISTS backups CASCADE;
DROP TABLE IF EXISTS platform_admins CASCADE;
DROP TYPE IF EXISTS admin_role CASCADE;

DROP FUNCTION IF EXISTS generate_monthly_bills CASCADE;
DROP FUNCTION IF EXISTS suspend_overdue_restaurants CASCADE;
DROP FUNCTION IF EXISTS mark_bill_as_paid CASCADE;
DROP FUNCTION IF EXISTS get_restaurant_billing_summary CASCADE;
DROP FUNCTION IF EXISTS calculate_billing_amount CASCADE;
DROP FUNCTION IF EXISTS log_audit_trail CASCADE;
DROP FUNCTION IF EXISTS get_recent_audit_logs CASCADE;
DROP FUNCTION IF EXISTS get_entity_audit_history CASCADE;
DROP FUNCTION IF EXISTS create_backup_record CASCADE;
DROP FUNCTION IF EXISTS complete_backup CASCADE;
DROP FUNCTION IF EXISTS check_admin_permission CASCADE;
DROP FUNCTION IF EXISTS get_admin_dashboard_stats CASCADE;
*/

-- ============================================================================
-- SUCCESS MESSAGE
-- ============================================================================

DO $$
BEGIN
    RAISE NOTICE '
    ╔══════════════════════════════════════════════════════════════╗
    ║  PRAAHIS SUPER ADMIN - SETUP COMPLETE!                       ║
    ╠══════════════════════════════════════════════════════════════╣
    ║  ✅ Billing & Payments System                                ║
    ║  ✅ Audit Trail & Logging                                    ║
    ║  ✅ Backup & Restore System                                  ║
    ║  ✅ Role-Based Access Control                                ║
    ╠══════════════════════════════════════════════════════════════╣
    ║  Next Steps:                                                 ║
    ║  1. Create your superadmin account (see above)               ║
    ║  2. Generate first monthly bills                             ║
    ║  3. Setup Supabase Edge Functions for automation             ║
    ║  4. Build React UI components                                ║
    ║  5. Test billing flow end-to-end                             ║
    ╠══════════════════════════════════════════════════════════════╣
    ║  Documentation: IMPLEMENTATION_GUIDE.md                      ║
    ╚══════════════════════════════════════════════════════════════╝
    ';
END $$;
