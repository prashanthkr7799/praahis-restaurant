-- ============================================================================
-- OPTIONAL: Audit Logging for SuperAdmin Portal
-- ============================================================================
-- This creates the auth_activity_logs table for tracking login attempts
-- NOTE: SuperAdmin login will work WITHOUT this table - it just won't log attempts
-- Run this ONLY if you want audit logging enabled

-- 1. Create the auth_activity_logs table (if it doesn't exist)
CREATE TABLE IF NOT EXISTS public.auth_activity_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  action text NOT NULL,
  ip_address text,
  user_agent text,
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

-- 2. Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_auth_activity_logs_user_id 
  ON public.auth_activity_logs(user_id);
  
CREATE INDEX IF NOT EXISTS idx_auth_activity_logs_action 
  ON public.auth_activity_logs(action);
  
CREATE INDEX IF NOT EXISTS idx_auth_activity_logs_created_at 
  ON public.auth_activity_logs(created_at DESC);

-- 3. Enable Row Level Security
ALTER TABLE public.auth_activity_logs ENABLE ROW LEVEL SECURITY;

-- 4. Drop existing policies (in case they exist)
DROP POLICY IF EXISTS "Owners can view all activity logs" ON public.auth_activity_logs;
DROP POLICY IF EXISTS "Allow authenticated users to insert their own logs" ON public.auth_activity_logs;
DROP POLICY IF EXISTS "Service role can do anything" ON public.auth_activity_logs;

-- 5. Create RLS Policies

-- Policy 1: Owners can view all activity logs
CREATE POLICY "Owners can view all activity logs"
  ON public.auth_activity_logs
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.users
      WHERE users.id = auth.uid()
        AND (users.is_owner = true OR users.role = 'owner')
    )
  );

-- Policy 2: Authenticated users can insert logs (for their own actions)
CREATE POLICY "Allow authenticated users to insert their own logs"
  ON public.auth_activity_logs
  FOR INSERT
  TO authenticated
  WITH CHECK (true);  -- Allow inserts but RLS on SELECT restricts who sees them

-- Policy 3: Service role bypass (for server-side operations)
CREATE POLICY "Service role can do anything"
  ON public.auth_activity_logs
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- 6. Grant necessary permissions
GRANT SELECT, INSERT ON public.auth_activity_logs TO authenticated;
GRANT ALL ON public.auth_activity_logs TO service_role;

-- 7. Verify the setup
SELECT 
  schemaname,
  tablename,
  tableowner,
  rowsecurity
FROM pg_tables
WHERE tablename = 'auth_activity_logs';

-- 8. Check policies
SELECT 
  policyname,
  permissive,
  roles,
  cmd,
  qual,
  with_check
FROM pg_policies
WHERE tablename = 'auth_activity_logs';

-- ============================================================================
-- TESTING
-- ============================================================================

-- Test 1: Check if table exists
SELECT EXISTS (
  SELECT FROM information_schema.tables 
  WHERE table_schema = 'public' 
  AND table_name = 'auth_activity_logs'
) as table_exists;

-- Test 2: View existing logs (as owner)
SELECT 
  id,
  user_id,
  action,
  created_at,
  metadata->>'portal' as portal
FROM public.auth_activity_logs
ORDER BY created_at DESC
LIMIT 10;

-- Test 3: Count logs by action
SELECT 
  action,
  COUNT(*) as count,
  MAX(created_at) as last_occurrence
FROM public.auth_activity_logs
GROUP BY action
ORDER BY count DESC;

-- ============================================================================
-- CLEANUP (if you want to remove audit logging)
-- ============================================================================

-- Uncomment these lines to remove the table:
-- DROP TABLE IF EXISTS public.auth_activity_logs CASCADE;

-- ============================================================================
-- NOTES
-- ============================================================================

/*
What this fixes:
- 401 Unauthorized errors when logging into SuperAdmin portal
- 403 Forbidden errors when creating audit logs

After running this script:
1. Refresh your browser
2. Login to /superadmin-login
3. Check the logs:
   SELECT * FROM auth_activity_logs ORDER BY created_at DESC LIMIT 5;

If you still see errors:
- They will be silent warnings only (login still works)
- Check Supabase Dashboard > Authentication > Policies
- Verify your user has is_owner = true or role = 'owner'

The SuperAdmin login is designed to work WITHOUT this table.
This is purely for audit trail purposes.
*/
