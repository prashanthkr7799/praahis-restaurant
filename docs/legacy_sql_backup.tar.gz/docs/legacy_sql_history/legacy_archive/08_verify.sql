-- =============================================================================
-- TABUN RESTAURANT - POST-INSTALL VERIFICATION
-- =============================================================================
-- Run this after applying all migrations to validate the setup.
-- Order: 01_schema.sql -> 02_seed.sql -> 03_enable_realtime.sql -> 04_production_rls.sql -> 06_item_ratings.sql -> 07_item_rating_summary.sql -> 08_verify.sql
-- =============================================================================

-- 1) Tables present
SELECT tablename
FROM pg_tables
WHERE schemaname = 'public'
ORDER BY tablename;

-- 2) RLS status per table
SELECT 
  t.tablename,
  CASE WHEN t.rowsecurity THEN 'enabled' ELSE 'disabled' END AS rls_status,
  COUNT(p.policyname) AS policy_count
FROM pg_tables t
LEFT JOIN pg_policies p ON p.tablename = t.tablename AND p.schemaname = t.schemaname
WHERE t.schemaname = 'public'
GROUP BY t.tablename, t.rowsecurity
ORDER BY t.tablename;

-- 3) Policies per table (quick view)
SELECT schemaname, tablename, policyname, roles, cmd
FROM pg_policies
WHERE schemaname = 'public'
ORDER BY tablename, policyname;

-- 4) Realtime publication tables
SELECT schemaname, tablename
FROM pg_publication_tables
WHERE pubname = 'supabase_realtime'
ORDER BY tablename;

-- 5) Views exist
SELECT table_name AS view_name
FROM information_schema.views
WHERE table_schema = 'public'
  AND table_name IN ('menu_item_ratings_summary','menu_items_with_ratings')
ORDER BY view_name;

-- 6) Sample selects (should succeed without errors)
SELECT * FROM restaurants LIMIT 1;
SELECT * FROM tables LIMIT 1;
SELECT * FROM menu_items LIMIT 1;
SELECT id, order_number, order_status, total FROM orders ORDER BY created_at DESC LIMIT 1;
SELECT * FROM feedbacks ORDER BY created_at DESC LIMIT 1;

-- 7) Ratings summary (should return zero rows or data)
SELECT * FROM menu_item_ratings LIMIT 1;
SELECT * FROM menu_item_ratings_summary LIMIT 5;
SELECT id, name, avg_rating, total_ratings FROM menu_items_with_ratings ORDER BY name LIMIT 5;

-- 8) Index sanity checks (presence only)
SELECT 
  t.relname AS table_name,
  i.relname AS index_name
FROM pg_class t
JOIN pg_index ix ON t.oid = ix.indrelid
JOIN pg_class i ON i.oid = ix.indexrelid
JOIN pg_namespace n ON n.oid = t.relnamespace
WHERE n.nspname = 'public'
  AND t.relname IN ('tables','menu_items','orders','payments','feedbacks','menu_item_ratings')
ORDER BY t.relname, i.relname;

-- 9) Trigger presence (updated_at auto-update)
SELECT tgname AS trigger_name, relname AS table_name
FROM pg_trigger tg
JOIN pg_class c ON tg.tgrelid = c.oid
WHERE tg.tgenabled <> 'D'
  AND relname IN ('restaurants','tables','menu_items','orders','payments','users')
ORDER BY relname, tgname;

-- =============================================================================
-- VERIFICATION COMPLETE
-- =============================================================================
