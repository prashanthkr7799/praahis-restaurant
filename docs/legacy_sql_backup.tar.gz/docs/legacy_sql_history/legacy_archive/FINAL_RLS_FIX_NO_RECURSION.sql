-- ============================================================================
-- FINAL RLS FIX - NO RECURSION POSSIBLE
-- ============================================================================
-- Uses SECURITY DEFINER function to bypass RLS when checking is_owner
-- This completely eliminates recursion
-- ============================================================================

-- ============================================================================
-- STEP 1: Drop ALL existing policies
-- ============================================================================

-- Users table
DROP POLICY IF EXISTS "owner_users_all_operations" ON public.users;
DROP POLICY IF EXISTS "owner_users_select_all" ON public.users;
DROP POLICY IF EXISTS "owner_users_insert" ON public.users;
DROP POLICY IF EXISTS "owner_users_update_all" ON public.users;
DROP POLICY IF EXISTS "owner_users_delete" ON public.users;
DROP POLICY IF EXISTS "users_allow_insert" ON public.users;
DROP POLICY IF EXISTS "users_allow_update" ON public.users;
DROP POLICY IF EXISTS "users_delete" ON public.users;
DROP POLICY IF EXISTS "users_select" ON public.users;
DROP POLICY IF EXISTS "users_select_own" ON public.users;
DROP POLICY IF EXISTS "users_update_own" ON public.users;
DROP POLICY IF EXISTS "owners_read_all_users" ON public.users;
DROP POLICY IF EXISTS "Platform owners can view all users" ON public.users;
DROP POLICY IF EXISTS "Platform owners can manage all users" ON public.users;
DROP POLICY IF EXISTS "Users can view their own profile" ON public.users;
DROP POLICY IF EXISTS "Users can update their own profile" ON public.users;
DROP POLICY IF EXISTS "users_read_own_profile" ON public.users;
DROP POLICY IF EXISTS "users_update_own_profile" ON public.users;

-- Subscriptions table
DROP POLICY IF EXISTS "owner_subscriptions_all_operations" ON public.subscriptions;
DROP POLICY IF EXISTS "owner_subscriptions_select_all" ON public.subscriptions;
DROP POLICY IF EXISTS "owner_subscriptions_insert" ON public.subscriptions;
DROP POLICY IF EXISTS "owner_subscriptions_update" ON public.subscriptions;
DROP POLICY IF EXISTS "owner_subscriptions_delete" ON public.subscriptions;
DROP POLICY IF EXISTS "manager_subscriptions_select_own_restaurant" ON public.subscriptions;
DROP POLICY IF EXISTS "subscriptions_delete" ON public.subscriptions;
DROP POLICY IF EXISTS "subscriptions_insert" ON public.subscriptions;
DROP POLICY IF EXISTS "subscriptions_select" ON public.subscriptions;
DROP POLICY IF EXISTS "subscriptions_update" ON public.subscriptions;
DROP POLICY IF EXISTS "owners_read_all_subscriptions" ON public.subscriptions;
DROP POLICY IF EXISTS "Platform owners can view all subscriptions" ON public.subscriptions;
DROP POLICY IF EXISTS "Platform owners can manage all subscriptions" ON public.subscriptions;
DROP POLICY IF EXISTS "Managers can view own restaurant subscriptions" ON public.subscriptions;
DROP POLICY IF EXISTS "authenticated_read_subscriptions" ON public.subscriptions;

-- Restaurants table
DROP POLICY IF EXISTS "owner_restaurants_all_operations" ON public.restaurants;
DROP POLICY IF EXISTS "owner_restaurants_select_all" ON public.restaurants;
DROP POLICY IF EXISTS "owner_restaurants_insert" ON public.restaurants;
DROP POLICY IF EXISTS "owner_restaurants_update" ON public.restaurants;
DROP POLICY IF EXISTS "owner_restaurants_delete" ON public.restaurants;
DROP POLICY IF EXISTS "manager_restaurants_select_own" ON public.restaurants;
DROP POLICY IF EXISTS "restaurants_select" ON public.restaurants;
DROP POLICY IF EXISTS "owners_delete_restaurants" ON public.restaurants;
DROP POLICY IF EXISTS "owners_insert_restaurants" ON public.restaurants;
DROP POLICY IF EXISTS "owners_update_restaurants" ON public.restaurants;
DROP POLICY IF EXISTS "owners_read_all_restaurants" ON public.restaurants;
DROP POLICY IF EXISTS "Platform owners can view all restaurants" ON public.restaurants;
DROP POLICY IF EXISTS "Platform owners can manage all restaurants" ON public.restaurants;
DROP POLICY IF EXISTS "authenticated_read_restaurants" ON public.restaurants;

-- ============================================================================
-- STEP 2: Create SECURITY DEFINER function (bypasses RLS)
-- ============================================================================

CREATE OR REPLACE FUNCTION public.is_platform_owner()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER  -- This runs with elevated privileges, bypassing RLS
STABLE
AS $$
DECLARE
  v_is_owner boolean;
BEGIN
  -- Query users table without triggering RLS policies
  SELECT is_owner INTO v_is_owner
  FROM public.users
  WHERE id = auth.uid()
  LIMIT 1;
  
  RETURN COALESCE(v_is_owner, false);
EXCEPTION
  WHEN OTHERS THEN
    RETURN false;
END;
$$;

-- Grant execute permission
GRANT EXECUTE ON FUNCTION public.is_platform_owner() TO authenticated;

-- ============================================================================
-- STEP 3: Create USERS table policies (using the safe function)
-- ============================================================================

-- Everyone can read their own profile
CREATE POLICY "users_select_own"
ON public.users
FOR SELECT
TO authenticated
USING (id = auth.uid());

-- Everyone can update their own profile
CREATE POLICY "users_update_own"
ON public.users
FOR UPDATE
TO authenticated
USING (id = auth.uid())
WITH CHECK (id = auth.uid());

-- Platform owners can read ALL users
CREATE POLICY "owner_users_select_all"
ON public.users
FOR SELECT
TO authenticated
USING (public.is_platform_owner() = true);

-- Platform owners can insert users
CREATE POLICY "owner_users_insert"
ON public.users
FOR INSERT
TO authenticated
WITH CHECK (public.is_platform_owner() = true);

-- Platform owners can update all users
CREATE POLICY "owner_users_update_all"
ON public.users
FOR UPDATE
TO authenticated
USING (public.is_platform_owner() = true)
WITH CHECK (public.is_platform_owner() = true);

-- Platform owners can delete users
CREATE POLICY "owner_users_delete"
ON public.users
FOR DELETE
TO authenticated
USING (public.is_platform_owner() = true);

-- ============================================================================
-- STEP 4: Create SUBSCRIPTIONS table policies
-- ============================================================================

-- Platform owners can read all subscriptions
CREATE POLICY "owner_subscriptions_select_all"
ON public.subscriptions
FOR SELECT
TO authenticated
USING (public.is_platform_owner() = true);

-- Platform owners can insert subscriptions
CREATE POLICY "owner_subscriptions_insert"
ON public.subscriptions
FOR INSERT
TO authenticated
WITH CHECK (public.is_platform_owner() = true);

-- Platform owners can update subscriptions
CREATE POLICY "owner_subscriptions_update"
ON public.subscriptions
FOR UPDATE
TO authenticated
USING (public.is_platform_owner() = true)
WITH CHECK (public.is_platform_owner() = true);

-- Platform owners can delete subscriptions
CREATE POLICY "owner_subscriptions_delete"
ON public.subscriptions
FOR DELETE
TO authenticated
USING (public.is_platform_owner() = true);

-- Managers can view their restaurant's subscription
CREATE POLICY "manager_subscriptions_select_own_restaurant"
ON public.subscriptions
FOR SELECT
TO authenticated
USING (
  restaurant_id IN (
    SELECT restaurant_id 
    FROM public.users 
    WHERE id = auth.uid()
  )
);

-- ============================================================================
-- STEP 5: Create RESTAURANTS table policies
-- ============================================================================

-- Platform owners can read all restaurants
CREATE POLICY "owner_restaurants_select_all"
ON public.restaurants
FOR SELECT
TO authenticated
USING (public.is_platform_owner() = true);

-- Platform owners can insert restaurants
CREATE POLICY "owner_restaurants_insert"
ON public.restaurants
FOR INSERT
TO authenticated
WITH CHECK (public.is_platform_owner() = true);

-- Platform owners can update restaurants
CREATE POLICY "owner_restaurants_update"
ON public.restaurants
FOR UPDATE
TO authenticated
USING (public.is_platform_owner() = true)
WITH CHECK (public.is_platform_owner() = true);

-- Platform owners can delete restaurants
CREATE POLICY "owner_restaurants_delete"
ON public.restaurants
FOR DELETE
TO authenticated
USING (public.is_platform_owner() = true);

-- Managers can view their own restaurant
CREATE POLICY "manager_restaurants_select_own"
ON public.restaurants
FOR SELECT
TO authenticated
USING (
  id IN (
    SELECT restaurant_id 
    FROM public.users 
    WHERE id = auth.uid()
  )
);

-- ============================================================================
-- STEP 6: Ensure superadmin user is marked as owner
-- ============================================================================
DO $$
DECLARE
  v_user_id UUID;
BEGIN
  SELECT id INTO v_user_id
  FROM auth.users
  WHERE email = 'prashanthkumarreddy879@gmail.com'
  LIMIT 1;

  IF v_user_id IS NOT NULL THEN
    INSERT INTO public.users (
      id,
      email,
      name,
      full_name,
      role,
      is_owner,
      is_active,
      restaurant_id
    )
    VALUES (
      v_user_id,
      'prashanthkumarreddy879@gmail.com',
      'Super Admin',
      'Super Admin',
      'owner',
      true,
      true,
      NULL
    )
    ON CONFLICT (id) DO UPDATE
    SET is_owner = true,
        role = 'owner',
        is_active = true,
        restaurant_id = NULL;

    RAISE NOTICE '✅ Superadmin configured: %', v_user_id;
  END IF;
END $$;

-- ============================================================================
-- STEP 7: Test the function
-- ============================================================================

-- This should return true for the superadmin user
SELECT 
  '🧪 TEST is_platform_owner()' as test,
  email,
  is_owner as db_is_owner,
  public.is_platform_owner() as function_result
FROM public.users
WHERE email = 'prashanthkumarreddy879@gmail.com';

-- ============================================================================
-- STEP 8: Verify policies
-- ============================================================================

SELECT 
  '📊 POLICY COUNTS' as section,
  tablename,
  COUNT(*) as count
FROM pg_policies
WHERE schemaname = 'public'
  AND tablename IN ('users', 'subscriptions', 'restaurants')
GROUP BY tablename
ORDER BY tablename;

SELECT 
  '📋 ALL POLICIES' as section,
  tablename,
  policyname,
  cmd
FROM pg_policies
WHERE schemaname = 'public'
  AND tablename IN ('users', 'subscriptions', 'restaurants')
ORDER BY tablename, cmd, policyname;

-- ============================================================================
-- DONE!
-- ============================================================================
DO $$
BEGIN
  RAISE NOTICE '';
  RAISE NOTICE '════════════════════════════════════════════════════════';
  RAISE NOTICE '✅ RLS POLICIES FIXED - NO RECURSION!';
  RAISE NOTICE '════════════════════════════════════════════════════════';
  RAISE NOTICE '';
  RAISE NOTICE '🔑 Key Changes:';
  RAISE NOTICE '   • Created is_platform_owner() SECURITY DEFINER function';
  RAISE NOTICE '   • Function bypasses RLS when checking owner status';
  RAISE NOTICE '   • All policies use this safe function';
  RAISE NOTICE '   • NO MORE INFINITE RECURSION!';
  RAISE NOTICE '';
  RAISE NOTICE '📊 Policy Counts:';
  RAISE NOTICE '   • users: 6 policies';
  RAISE NOTICE '   • subscriptions: 5 policies';
  RAISE NOTICE '   • restaurants: 5 policies';
  RAISE NOTICE '';
  RAISE NOTICE '📝 NEXT STEPS:';
  RAISE NOTICE '   1. Logout from superadmin';
  RAISE NOTICE '   2. Clear cache (Cmd+Shift+R)';
  RAISE NOTICE '   3. Login again';
  RAISE NOTICE '   4. Should work perfectly now!';
  RAISE NOTICE '';
  RAISE NOTICE '════════════════════════════════════════════════════════';
END $$;
