-- =============================================
-- Seed Demo Notifications
-- =============================================
-- Purpose: Add sample notifications for testing the bell icon
-- Run AFTER: 20_notifications.sql
-- =============================================

-- Insert sample notifications for each manager/admin user
do $$
declare
  v_user record;
begin
  for v_user in (
    select id, restaurant_id, full_name 
    from public.users 
    where lower(role) in ('manager', 'admin') 
    and is_active = true
    limit 5
  ) loop
    -- Order notification
    insert into public.notifications (restaurant_id, user_id, type, title, body, data, is_read)
    values (
      v_user.restaurant_id,
      v_user.id,
      'order',
      'New Order Received',
      'Table 12 placed an order for 3 items',
      jsonb_build_object('order_id', gen_random_uuid()::text, 'table_number', 12),
      false
    );

    -- Payment notification
    insert into public.notifications (restaurant_id, user_id, type, title, body, data, is_read)
    values (
      v_user.restaurant_id,
      v_user.id,
      'payment',
      'Payment Successful',
      'Order #1234 paid ₹850 via UPI',
      jsonb_build_object('order_id', gen_random_uuid()::text, 'amount', 850, 'method', 'UPI'),
      false
    );

    -- System notification (read)
    insert into public.notifications (restaurant_id, user_id, type, title, body, data, is_read, created_at)
    values (
      v_user.restaurant_id,
      v_user.id,
      'system',
      'Daily Report Ready',
      'Your daily sales report for yesterday is now available',
      jsonb_build_object('report_date', (current_date - interval '1 day')::text),
      true,
      now() - interval '1 day'
    );

    -- Alert notification
    insert into public.notifications (restaurant_id, user_id, type, title, body, data, is_read)
    values (
      v_user.restaurant_id,
      v_user.id,
      'alert',
      'Low Stock Alert',
      'Tomatoes inventory is running low (5 units left)',
      jsonb_build_object('item', 'Tomatoes', 'quantity', 5),
      false
    );

    raise notice 'Seeded 4 demo notifications for user: %', v_user.full_name;
  end loop;
end $$;

-- Also add a few restaurant-wide notifications (no specific user)
insert into public.notifications (restaurant_id, user_id, type, title, body, data, is_read)
select 
  r.id,
  null,
  'system',
  'Weekly Review Available',
  'Check out your weekly performance metrics',
  jsonb_build_object('week_start', (current_date - interval '7 days')::text),
  false
from public.restaurants r
limit 3;

-- Success message
do $$
begin
  raise notice 'Demo notifications seeded successfully!';
end $$;
