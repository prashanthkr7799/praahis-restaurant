-- =========================================================================
-- CREATE SUPERADMIN - Simple Method (Works 100%)
-- =========================================================================
-- Step 1: First, manually create the user in Supabase Dashboard
-- Step 2: Then run this script to give them owner permissions
-- =========================================================================

-- INSTRUCTIONS:
-- 1. Go to Supabase Dashboard → Authentication → Users
-- 2. Click "Add user" → "Create new user"
-- 3. Enter:
--    - Email: admin@praahis.com (or your email)
--    - Password: YourSecurePassword123!
--    - Check "Auto Confirm User" ✅
-- 4. Click "Create user"
-- 5. Copy the User ID (UUID) from the created user
-- 6. Replace 'USER-ID-FROM-DASHBOARD' below with that UUID
-- 7. Run this script

-- =========================================================================

-- Set the user as owner in public.users table
INSERT INTO public.users (
    id,
    email,
    full_name,
    name,
    role,
    is_owner,
    is_active,
    restaurant_id,
    created_at,
    updated_at
) VALUES (
    'USER-ID-FROM-DASHBOARD',  -- ⚠️ PASTE USER ID HERE
    'admin@praahis.com',       -- ⚠️ CHANGE YOUR EMAIL
    'Super Admin',             -- ⚠️ CHANGE YOUR NAME
    'Super Admin',             -- ⚠️ CHANGE YOUR NAME
    'owner',
    TRUE,
    TRUE,
    NULL,
    NOW(),
    NOW()
)
ON CONFLICT (id) DO UPDATE SET
    is_owner = TRUE,
    role = 'owner',
    is_active = TRUE,
    email = EXCLUDED.email,
    full_name = EXCLUDED.full_name,
    name = EXCLUDED.name,
    updated_at = NOW();

-- Verify the user was created/updated
SELECT 
    u.id,
    u.email,
    u.full_name,
    u.role,
    u.is_owner,
    u.is_active,
    au.email_confirmed_at
FROM public.users u
LEFT JOIN auth.users au ON u.id = au.id
WHERE u.is_owner = TRUE;

-- =========================================================================
-- After running this:
-- 1. Go to http://localhost:5174/login
-- 2. Use SuperAdmin Login (purple panel)
-- 3. Login with the email and password you created
-- 4. You should be able to create restaurants!
-- =========================================================================
