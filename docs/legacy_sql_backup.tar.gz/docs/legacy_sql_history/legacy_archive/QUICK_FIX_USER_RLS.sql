-- =========================================================================
-- QUICK FIX: Allow owners to read users table
-- =========================================================================
-- This ensures owners can fetch their own profile during login
-- =========================================================================

-- Drop any conflicting policies
DROP POLICY IF EXISTS "owners_can_read_all_users" ON public.users;
DROP POLICY IF EXISTS "users_self_select" ON public.users;

-- Policy 1: Owners can read ALL users (using is_owner check)
CREATE POLICY "owners_can_read_all_users" ON public.users
    FOR SELECT
    USING (
        -- Allow if current user is an owner
        EXISTS (
            SELECT 1 FROM public.users 
            WHERE id = auth.uid() 
            AND (is_owner = TRUE OR LOWER(role) = 'owner')
        )
        OR
        -- OR allow users to read their own record
        id = auth.uid()
    );

-- Verify the policy was created
SELECT 
    tablename, 
    policyname, 
    cmd as operation,
    qual as using_expression
FROM pg_policies 
WHERE tablename = 'users' 
AND policyname = 'owners_can_read_all_users';

-- Test: Try to fetch your own user (this should work now)
SELECT id, email, role, is_owner, is_active 
FROM public.users 
WHERE id = auth.uid();

-- =========================================================================
-- After running this, try logging in again!
-- =========================================================================
