-- Migration: Add qr_code_url column to tables
-- Date: November 16, 2025
-- Description: Add column to store QR code URLs for each table

-- Add qr_code_url column if it doesn't exist
ALTER TABLE tables 
ADD COLUMN IF NOT EXISTS qr_code_url TEXT;

-- Add comment for documentation
COMMENT ON COLUMN tables.qr_code_url IS 'Public URL of the QR code image stored in Supabase Storage';
