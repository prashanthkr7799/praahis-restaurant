-- ============================================================================
-- SUPER ADMIN MODULE - DATABASE SCHEMA
-- ============================================================================
-- Version: 1.0
-- Created: November 6, 2025
-- Description: Additional tables and RLS policies for Super Admin module
-- Run after: All existing migrations (01-22)
-- ============================================================================

-- Enable UUID extension (if not already enabled)
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================================
-- TABLE 1: SUBSCRIPTIONS
-- ============================================================================
-- Restaurant subscription plans and billing information

CREATE TABLE IF NOT EXISTS subscriptions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    restaurant_id UUID NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
    plan_name VARCHAR(100) NOT NULL,                     -- 'trial', 'basic', 'pro', 'enterprise'
    status VARCHAR(50) DEFAULT 'active',                 -- 'active', 'inactive', 'trial', 'cancelled', 'expired'
    billing_cycle VARCHAR(20) DEFAULT 'monthly',         -- 'monthly', 'yearly'
    price DECIMAL(10, 2) NOT NULL CHECK (price >= 0),
    currency VARCHAR(10) DEFAULT 'INR',
    trial_ends_at TIMESTAMP WITH TIME ZONE,
    current_period_start TIMESTAMP WITH TIME ZONE NOT NULL,
    current_period_end TIMESTAMP WITH TIME ZONE NOT NULL,
    cancelled_at TIMESTAMP WITH TIME ZONE,
    metadata JSONB DEFAULT '{}',                         -- Additional subscription data
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE subscriptions IS 'Restaurant subscription plans and billing';
COMMENT ON COLUMN subscriptions.plan_name IS 'Subscription tier: trial, basic, pro, enterprise';
COMMENT ON COLUMN subscriptions.status IS 'Subscription status: active, inactive, trial, cancelled, expired';
COMMENT ON COLUMN subscriptions.billing_cycle IS 'Billing frequency: monthly or yearly';

-- Indexes for performance
CREATE INDEX idx_subscriptions_restaurant ON subscriptions(restaurant_id);
CREATE INDEX idx_subscriptions_status ON subscriptions(status);
CREATE INDEX idx_subscriptions_period_end ON subscriptions(current_period_end);

-- ============================================================================
-- TABLE 2: PLATFORM_SETTINGS
-- ============================================================================
-- Global platform configuration settings

CREATE TABLE IF NOT EXISTS platform_settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    key VARCHAR(255) UNIQUE NOT NULL,
    value JSONB,
    category VARCHAR(100),                               -- 'payment', 'email', 'storage', 'api', 'platform'
    is_encrypted BOOLEAN DEFAULT false,
    description TEXT,
    updated_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE platform_settings IS 'Platform-wide configuration settings';
COMMENT ON COLUMN platform_settings.key IS 'Unique setting identifier (e.g., razorpay_key_id)';
COMMENT ON COLUMN platform_settings.value IS 'Setting value stored as JSONB for flexibility';
COMMENT ON COLUMN platform_settings.category IS 'Setting category for grouping';
COMMENT ON COLUMN platform_settings.is_encrypted IS 'Whether this setting contains sensitive data';

-- Indexes
CREATE INDEX idx_platform_settings_category ON platform_settings(category);

-- ============================================================================
-- TABLE 3: SYSTEM_LOGS
-- ============================================================================
-- Platform-wide system events, errors, and monitoring

CREATE TABLE IF NOT EXISTS system_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    level VARCHAR(20) NOT NULL,                          -- 'info', 'warning', 'error', 'critical'
    source VARCHAR(100),                                 -- 'api', 'database', 'payment', 'auth', 'storage'
    message TEXT NOT NULL,
    details JSONB,
    restaurant_id UUID REFERENCES restaurants(id),       -- Optional: if log is restaurant-specific
    user_id UUID,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE system_logs IS 'System-wide logging and monitoring';
COMMENT ON COLUMN system_logs.level IS 'Log severity: info, warning, error, critical';
COMMENT ON COLUMN system_logs.source IS 'System component that generated the log';
COMMENT ON COLUMN system_logs.restaurant_id IS 'Related restaurant (if applicable)';

-- Indexes for efficient log queries
CREATE INDEX idx_system_logs_level ON system_logs(level);
CREATE INDEX idx_system_logs_created ON system_logs(created_at DESC);
CREATE INDEX idx_system_logs_restaurant ON system_logs(restaurant_id);
CREATE INDEX idx_system_logs_source ON system_logs(source);

-- ============================================================================
-- TABLE 4: AUDIT_TRAIL
-- ============================================================================
-- Enhanced audit logging for super admin actions

CREATE TABLE IF NOT EXISTS audit_trail (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    actor_id UUID REFERENCES auth.users(id),
    action VARCHAR(100) NOT NULL,                        -- 'restaurant_created', 'subscription_updated', etc.
    entity_type VARCHAR(50),                             -- 'restaurant', 'subscription', 'settings', 'user'
    entity_id UUID,
    old_values JSONB,
    new_values JSONB,
    ip_address INET,
    user_agent TEXT,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE audit_trail IS 'Audit trail for super admin actions';
COMMENT ON COLUMN audit_trail.actor_id IS 'User who performed the action';
COMMENT ON COLUMN audit_trail.action IS 'Action performed (e.g., created, updated, deleted)';
COMMENT ON COLUMN audit_trail.entity_type IS 'Type of entity affected';
COMMENT ON COLUMN audit_trail.old_values IS 'Previous values (for updates)';
COMMENT ON COLUMN audit_trail.new_values IS 'New values (for creates/updates)';

-- Indexes
CREATE INDEX idx_audit_trail_actor ON audit_trail(actor_id);
CREATE INDEX idx_audit_trail_created ON audit_trail(created_at DESC);
CREATE INDEX idx_audit_trail_entity ON audit_trail(entity_type, entity_id);
CREATE INDEX idx_audit_trail_action ON audit_trail(action);

-- ============================================================================
-- TABLE 5: BACKUPS
-- ============================================================================
-- Database backup operations tracking

CREATE TABLE IF NOT EXISTS backups (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    backup_type VARCHAR(50) NOT NULL,                    -- 'full', 'incremental', 'restaurant'
    restaurant_id UUID REFERENCES restaurants(id),       -- NULL for full platform backups
    file_path TEXT,
    file_size BIGINT,                                    -- Size in bytes
    status VARCHAR(50) DEFAULT 'in_progress',            -- 'in_progress', 'completed', 'failed'
    initiated_by UUID REFERENCES auth.users(id),
    completed_at TIMESTAMP WITH TIME ZONE,
    error_message TEXT,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE backups IS 'Database backup tracking';
COMMENT ON COLUMN backups.backup_type IS 'Type: full (all data), incremental (changes), restaurant (single tenant)';
COMMENT ON COLUMN backups.restaurant_id IS 'Specific restaurant (NULL for full backups)';
COMMENT ON COLUMN backups.file_size IS 'Backup file size in bytes';

-- Indexes
CREATE INDEX idx_backups_created ON backups(created_at DESC);
CREATE INDEX idx_backups_restaurant ON backups(restaurant_id);
CREATE INDEX idx_backups_status ON backups(status);

-- ============================================================================
-- EXTEND RESTAURANTS TABLE
-- ============================================================================
-- Add super admin specific fields to restaurants table

ALTER TABLE restaurants
    ADD COLUMN IF NOT EXISTS subscription_status VARCHAR(50) DEFAULT 'trial',
    ADD COLUMN IF NOT EXISTS max_users INTEGER DEFAULT 10,
    ADD COLUMN IF NOT EXISTS max_tables INTEGER DEFAULT 20,
    ADD COLUMN IF NOT EXISTS max_menu_items INTEGER DEFAULT 100,
    ADD COLUMN IF NOT EXISTS features JSONB DEFAULT '{}',
    ADD COLUMN IF NOT EXISTS metadata JSONB DEFAULT '{}';

COMMENT ON COLUMN restaurants.subscription_status IS 'Current subscription status';
COMMENT ON COLUMN restaurants.max_users IS 'Maximum allowed users for this restaurant';
COMMENT ON COLUMN restaurants.max_tables IS 'Maximum allowed tables';
COMMENT ON COLUMN restaurants.max_menu_items IS 'Maximum allowed menu items';
COMMENT ON COLUMN restaurants.features IS 'Feature flags for this restaurant';
COMMENT ON COLUMN restaurants.metadata IS 'Additional restaurant metadata';

-- ============================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ============================================================================

-- Enable RLS on new tables
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE platform_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE system_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_trail ENABLE ROW LEVEL SECURITY;
ALTER TABLE backups ENABLE ROW LEVEL SECURITY;

-- ============================================================================
-- SUBSCRIPTIONS POLICIES
-- ============================================================================

-- Managers can view their own restaurant's subscription
DROP POLICY IF EXISTS "Managers can view own subscription" ON subscriptions;
CREATE POLICY "Managers can view own subscription" ON subscriptions
    FOR SELECT
    USING (
        restaurant_id IN (
            SELECT restaurant_id FROM users WHERE id = auth.uid()
        )
    );

-- Owners have full access
DROP POLICY IF EXISTS "Owners have full access to subscriptions" ON subscriptions;
CREATE POLICY "Owners have full access to subscriptions" ON subscriptions
    USING (public.is_owner());

-- ============================================================================
-- PLATFORM_SETTINGS POLICIES
-- ============================================================================

-- Only owners can manage platform settings
DROP POLICY IF EXISTS "Only owners can manage platform settings" ON platform_settings;
CREATE POLICY "Only owners can manage platform settings" ON platform_settings
    USING (public.is_owner());

-- ============================================================================
-- SYSTEM_LOGS POLICIES
-- ============================================================================

-- Only owners can view system logs
DROP POLICY IF EXISTS "Only owners can view system logs" ON system_logs;
CREATE POLICY "Only owners can view system logs" ON system_logs
    FOR SELECT
    USING (public.is_owner());

-- Anyone can insert system logs (for error reporting)
DROP POLICY IF EXISTS "Anyone can insert system logs" ON system_logs;
CREATE POLICY "Anyone can insert system logs" ON system_logs
    FOR INSERT
    WITH CHECK (true);

-- ============================================================================
-- AUDIT_TRAIL POLICIES
-- ============================================================================

-- Only owners can view audit trail
DROP POLICY IF EXISTS "Only owners can view audit trail" ON audit_trail;
CREATE POLICY "Only owners can view audit trail" ON audit_trail
    FOR SELECT
    USING (public.is_owner());

-- Allow inserts for audit logging
DROP POLICY IF EXISTS "Allow audit trail inserts" ON audit_trail;
CREATE POLICY "Allow audit trail inserts" ON audit_trail
    FOR INSERT
    WITH CHECK (auth.uid() = actor_id);

-- ============================================================================
-- BACKUPS POLICIES
-- ============================================================================

-- Only owners can manage backups
DROP POLICY IF EXISTS "Only owners can manage backups" ON backups;
CREATE POLICY "Only owners can manage backups" ON backups
    USING (public.is_owner());

-- ============================================================================
-- HELPER FUNCTIONS
-- ============================================================================

-- Function to get platform statistics
CREATE OR REPLACE FUNCTION get_platform_stats()
RETURNS JSONB AS $$
DECLARE
    stats JSONB;
BEGIN
    SELECT jsonb_build_object(
        'total_restaurants', (SELECT COUNT(*) FROM restaurants),
        'active_restaurants', (SELECT COUNT(*) FROM restaurants WHERE is_active = true),
        'total_users', (SELECT COUNT(*) FROM users),
        'total_orders', (SELECT COUNT(*) FROM orders),
        'total_revenue', (SELECT COALESCE(SUM(total), 0) FROM orders WHERE payment_status = 'paid'),
        'active_subscriptions', (SELECT COUNT(*) FROM subscriptions WHERE status = 'active')
    ) INTO stats;
    
    RETURN stats;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION get_platform_stats() IS 'Get platform-wide statistics (owner only)';

-- Function to calculate subscription MRR (Monthly Recurring Revenue)
CREATE OR REPLACE FUNCTION calculate_mrr()
RETURNS DECIMAL AS $$
DECLARE
    mrr DECIMAL;
BEGIN
    SELECT COALESCE(SUM(
        CASE 
            WHEN billing_cycle = 'monthly' THEN price
            WHEN billing_cycle = 'yearly' THEN price / 12
            ELSE 0
        END
    ), 0)
    INTO mrr
    FROM subscriptions
    WHERE status = 'active';
    
    RETURN mrr;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION calculate_mrr() IS 'Calculate Monthly Recurring Revenue from active subscriptions';

-- Function to check restaurant resource limits
CREATE OR REPLACE FUNCTION check_resource_limit(
    p_restaurant_id UUID,
    p_resource_type VARCHAR,
    p_current_count INTEGER
)
RETURNS BOOLEAN AS $$
DECLARE
    max_allowed INTEGER;
BEGIN
    SELECT 
        CASE p_resource_type
            WHEN 'users' THEN max_users
            WHEN 'tables' THEN max_tables
            WHEN 'menu_items' THEN max_menu_items
            ELSE NULL
        END
    INTO max_allowed
    FROM restaurants
    WHERE id = p_restaurant_id;
    
    RETURN p_current_count < max_allowed;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION check_resource_limit IS 'Check if restaurant has reached resource limit';

-- ============================================================================
-- TRIGGERS
-- ============================================================================

-- Update updated_at timestamp on subscriptions
CREATE OR REPLACE FUNCTION update_subscriptions_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS update_subscriptions_timestamp ON subscriptions;
CREATE TRIGGER update_subscriptions_timestamp
    BEFORE UPDATE ON subscriptions
    FOR EACH ROW
    EXECUTE FUNCTION update_subscriptions_updated_at();

-- Update updated_at timestamp on platform_settings
CREATE OR REPLACE FUNCTION update_platform_settings_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS update_platform_settings_timestamp ON platform_settings;
CREATE TRIGGER update_platform_settings_timestamp
    BEFORE UPDATE ON platform_settings
    FOR EACH ROW
    EXECUTE FUNCTION update_platform_settings_updated_at();

-- ============================================================================
-- SEED DATA (Optional)
-- ============================================================================

-- Insert default platform settings
INSERT INTO platform_settings (key, value, category, description)
VALUES
    ('default_currency', '"INR"', 'platform', 'Default currency for the platform'),
    ('default_tax_rate', '18', 'platform', 'Default tax rate percentage'),
    ('trial_duration_days', '14', 'platform', 'Trial period duration in days'),
    ('max_file_upload_size_mb', '5', 'storage', 'Maximum file upload size in MB'),
    ('session_timeout_minutes', '60', 'platform', 'User session timeout in minutes')
ON CONFLICT (key) DO NOTHING;

-- Insert default subscription plans (as reference)
COMMENT ON TABLE subscriptions IS 'Default Plans: Trial (14 days, free), Basic (₹999/mo, 10 users), Pro (₹2999/mo, 50 users), Enterprise (₹9999/mo, unlimited)';

-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================

-- Verify tables created
DO $$
BEGIN
    RAISE NOTICE 'Verifying Super Admin tables...';
    
    IF EXISTS (SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'subscriptions') THEN
        RAISE NOTICE '✓ subscriptions table created';
    END IF;
    
    IF EXISTS (SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'platform_settings') THEN
        RAISE NOTICE '✓ platform_settings table created';
    END IF;
    
    IF EXISTS (SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'system_logs') THEN
        RAISE NOTICE '✓ system_logs table created';
    END IF;
    
    IF EXISTS (SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'audit_trail') THEN
        RAISE NOTICE '✓ audit_trail table created';
    END IF;
    
    IF EXISTS (SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'backups') THEN
        RAISE NOTICE '✓ backups table created';
    END IF;
    
    RAISE NOTICE 'Super Admin schema setup complete!';
END $$;

-- ============================================================================
-- END OF SUPER ADMIN SCHEMA
-- ============================================================================
