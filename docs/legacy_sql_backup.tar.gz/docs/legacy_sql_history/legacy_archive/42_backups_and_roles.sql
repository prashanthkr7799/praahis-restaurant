-- ============================================================================
-- BACKUP & RESTORE SYSTEM + ROLE-BASED ACCESS CONTROL
-- ============================================================================
-- Version: 1.0
-- Created: November 7, 2025
-- Description: Automated backup system and admin role management
-- ============================================================================

-- Enable UUID extension if not exists
DO $$ 
BEGIN
    CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
EXCEPTION
    WHEN duplicate_object THEN NULL;
END $$;

-- Drop existing objects if they exist (for clean reinstall)
-- Drop policies first
DO $$
BEGIN
    DROP POLICY IF EXISTS "Superadmin full access to platform_admins" ON platform_admins;
    DROP POLICY IF EXISTS "Admins can view their own profile" ON platform_admins;
    DROP POLICY IF EXISTS "Superadmin full access to backups" ON backups;
    DROP POLICY IF EXISTS "Subadmin read-only backups" ON backups;
    DROP POLICY IF EXISTS "Superadmin full access to backup_schedules" ON backup_schedules;
EXCEPTION
    WHEN undefined_table THEN NULL;
END $$;

-- Drop triggers
DO $$
BEGIN
    DROP TRIGGER IF EXISTS update_platform_admins_timestamp_trigger ON platform_admins CASCADE;
EXCEPTION
    WHEN undefined_table THEN NULL;
END $$;

-- Drop functions
DROP FUNCTION IF EXISTS update_platform_admins_timestamp() CASCADE;
DROP FUNCTION IF EXISTS check_admin_permission(UUID, TEXT, TEXT) CASCADE;
DROP FUNCTION IF EXISTS create_backup_record(VARCHAR, TEXT, UUID, UUID) CASCADE;
DROP FUNCTION IF EXISTS complete_backup(UUID, TEXT, BIGINT, TEXT[], BIGINT) CASCADE;
DROP FUNCTION IF EXISTS get_admin_dashboard_stats(UUID) CASCADE;

-- Drop tables
DROP TABLE IF EXISTS backup_schedules CASCADE;
DROP TABLE IF EXISTS backups CASCADE;
DROP TABLE IF EXISTS platform_admins CASCADE;

-- Drop type
DROP TYPE IF EXISTS admin_role CASCADE;

-- ============================================================================
-- ENUM TYPES FOR ROLES
-- ============================================================================

CREATE TYPE admin_role AS ENUM ('superadmin', 'subadmin', 'support');

COMMENT ON TYPE admin_role IS 'Platform admin roles: superadmin (full), subadmin (limited), support (readonly)';

-- ============================================================================
-- TABLE: PLATFORM_ADMINS
-- ============================================================================
-- Manages different levels of platform administrators

CREATE TABLE platform_admins (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
    
    -- Admin Details
    email TEXT NOT NULL UNIQUE,
    full_name TEXT NOT NULL,
    role admin_role NOT NULL DEFAULT 'subadmin',
    
    -- Permissions (JSONB for flexibility)
    permissions JSONB DEFAULT '{
        "restaurants": {"create": true, "read": true, "update": true, "delete": false},
        "managers": {"create": true, "read": true, "update": true, "delete": false},
        "billing": {"create": false, "read": true, "update": true, "delete": false},
        "settings": {"create": false, "read": false, "update": false, "delete": false},
        "backups": {"create": false, "read": false, "update": false, "delete": false},
        "audit": {"create": false, "read": true, "update": false, "delete": false}
    }',
    
    -- Status
    is_active BOOLEAN DEFAULT true,
    
    -- Two-Factor Authentication
    two_factor_enabled BOOLEAN DEFAULT false,
    two_factor_secret TEXT,
    
    -- Login Tracking
    last_login TIMESTAMP WITH TIME ZONE,
    login_count INTEGER DEFAULT 0,
    last_ip INET,
    
    -- Metadata
    notes TEXT,
    created_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE platform_admins IS 'Platform administrators with role-based access';
COMMENT ON COLUMN platform_admins.role IS 'superadmin, subadmin, or support';
COMMENT ON COLUMN platform_admins.permissions IS 'Granular permissions per module';

-- Indexes
CREATE INDEX idx_platform_admins_role ON platform_admins(role);
CREATE INDEX idx_platform_admins_active ON platform_admins(is_active);
CREATE INDEX idx_platform_admins_email ON platform_admins(email);

-- ============================================================================
-- TABLE: BACKUPS
-- ============================================================================
-- Tracks database backups for disaster recovery

CREATE TABLE backups (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Backup Details
    backup_type VARCHAR(50) NOT NULL CHECK (backup_type IN ('full', 'incremental', 'restaurant', 'manual')),
    backup_name TEXT NOT NULL,
    
    -- Scope
    restaurant_id UUID REFERENCES restaurants(id) ON DELETE SET NULL,
    restaurant_name TEXT,
    
    -- Storage
    file_path TEXT,
    storage_location VARCHAR(100) DEFAULT 'supabase_storage', -- 'supabase_storage', 's3', 'local'
    file_size BIGINT, -- Size in bytes
    compressed BOOLEAN DEFAULT true,
    encryption_enabled BOOLEAN DEFAULT false,
    
    -- Status
    status VARCHAR(50) DEFAULT 'in_progress' CHECK (status IN ('in_progress', 'completed', 'failed', 'deleted')),
    
    -- Execution Details
    started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE,
    duration_seconds INTEGER,
    
    -- Tables Included
    tables_backed_up TEXT[],
    row_count BIGINT,
    
    -- User & Error Tracking
    initiated_by UUID REFERENCES auth.users(id),
    initiated_by_email TEXT,
    error_message TEXT,
    error_details JSONB,
    
    -- Restoration
    can_restore BOOLEAN DEFAULT true,
    restored_at TIMESTAMP WITH TIME ZONE,
    restored_by UUID REFERENCES auth.users(id),
    
    -- Metadata
    metadata JSONB DEFAULT '{}',
    retention_days INTEGER DEFAULT 30,
    expires_at TIMESTAMP WITH TIME ZONE,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE backups IS 'Database backup tracking and metadata';
COMMENT ON COLUMN backups.backup_type IS 'full, incremental, restaurant, manual';
COMMENT ON COLUMN backups.storage_location IS 'Where backup file is stored';
COMMENT ON COLUMN backups.retention_days IS 'Days to keep backup before auto-deletion';

-- Indexes
CREATE INDEX idx_backups_restaurant ON backups(restaurant_id);
CREATE INDEX idx_backups_status ON backups(status);
CREATE INDEX idx_backups_type ON backups(backup_type);
CREATE INDEX idx_backups_created ON backups(created_at DESC);
CREATE INDEX idx_backups_expires ON backups(expires_at);

-- ============================================================================
-- TABLE: BACKUP_SCHEDULES
-- ============================================================================
-- Automated backup scheduling

CREATE TABLE backup_schedules (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Schedule Details
    name TEXT NOT NULL,
    backup_type VARCHAR(50) NOT NULL CHECK (backup_type IN ('full', 'incremental', 'restaurant')),
    
    -- Frequency
    frequency VARCHAR(50) NOT NULL CHECK (frequency IN ('hourly', 'daily', 'weekly', 'monthly')),
    schedule_time TIME, -- e.g., '02:00:00' for 2 AM
    schedule_day INTEGER, -- 1-7 for weekly, 1-31 for monthly
    
    -- Scope
    restaurant_id UUID REFERENCES restaurants(id) ON DELETE CASCADE,
    include_all_restaurants BOOLEAN DEFAULT false,
    
    -- Settings
    retention_days INTEGER DEFAULT 30,
    compression_enabled BOOLEAN DEFAULT true,
    encryption_enabled BOOLEAN DEFAULT false,
    
    -- Status
    is_active BOOLEAN DEFAULT true,
    last_run TIMESTAMP WITH TIME ZONE,
    next_run TIMESTAMP WITH TIME ZONE,
    last_backup_id UUID REFERENCES backups(id),
    
    -- Metadata
    created_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE backup_schedules IS 'Automated backup scheduling configuration';
COMMENT ON COLUMN backup_schedules.frequency IS 'hourly, daily, weekly, monthly';

-- Indexes
CREATE INDEX idx_backup_schedules_active ON backup_schedules(is_active);
CREATE INDEX idx_backup_schedules_next_run ON backup_schedules(next_run);

-- ============================================================================
-- FUNCTION: Check Admin Permissions
-- ============================================================================

CREATE OR REPLACE FUNCTION check_admin_permission(
    p_user_id UUID,
    p_module TEXT,
    p_action TEXT
)
RETURNS BOOLEAN AS $$
DECLARE
    v_role admin_role;
    v_permissions JSONB;
    v_has_permission BOOLEAN;
BEGIN
    -- Superadmin has all permissions
    SELECT role, permissions 
    INTO v_role, v_permissions
    FROM platform_admins
    WHERE user_id = p_user_id AND is_active = true;
    
    IF NOT FOUND THEN
        RETURN false;
    END IF;
    
    IF v_role = 'superadmin' THEN
        RETURN true;
    END IF;
    
    -- Check specific permission
    v_has_permission := COALESCE(
        (v_permissions->p_module->>p_action)::BOOLEAN,
        false
    );
    
    RETURN v_has_permission;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION check_admin_permission IS 'Check if admin has specific permission for a module';

-- ============================================================================
-- FUNCTION: Create Backup Record
-- ============================================================================

CREATE OR REPLACE FUNCTION create_backup_record(
    p_backup_type VARCHAR,
    p_backup_name TEXT,
    p_restaurant_id UUID DEFAULT NULL,
    p_initiated_by UUID DEFAULT NULL
)
RETURNS UUID AS $$
DECLARE
    v_backup_id UUID;
    v_restaurant_name TEXT;
    v_actor_email TEXT;
    v_expires_at TIMESTAMP WITH TIME ZONE;
BEGIN
    -- Get restaurant name if applicable
    IF p_restaurant_id IS NOT NULL THEN
        SELECT name INTO v_restaurant_name
        FROM restaurants
        WHERE id = p_restaurant_id;
    END IF;
    
    -- Get initiator email
    SELECT email INTO v_actor_email
    FROM auth.users
    WHERE id = p_initiated_by;
    
    -- Calculate expiration (30 days from now)
    v_expires_at := NOW() + INTERVAL '30 days';
    
    -- Create backup record
    INSERT INTO backups (
        backup_type,
        backup_name,
        restaurant_id,
        restaurant_name,
        initiated_by,
        initiated_by_email,
        status,
        started_at,
        expires_at,
        retention_days
    ) VALUES (
        p_backup_type,
        p_backup_name,
        p_restaurant_id,
        v_restaurant_name,
        p_initiated_by,
        v_actor_email,
        'in_progress',
        NOW(),
        v_expires_at,
        30
    ) RETURNING id INTO v_backup_id;
    
    -- Log audit trail
    PERFORM log_audit_trail(
        'backup_created',
        'backup',
        v_backup_id,
        p_backup_name,
        NULL,
        jsonb_build_object('backup_type', p_backup_type, 'restaurant_id', p_restaurant_id),
        'Backup initiated: ' || p_backup_name,
        'info'
    );
    
    RETURN v_backup_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION create_backup_record IS 'Create a new backup tracking record';

-- ============================================================================
-- FUNCTION: Mark Backup Complete
-- ============================================================================

CREATE OR REPLACE FUNCTION complete_backup(
    p_backup_id UUID,
    p_file_path TEXT,
    p_file_size BIGINT,
    p_tables_backed_up TEXT[],
    p_row_count BIGINT DEFAULT 0
)
RETURNS BOOLEAN AS $$
DECLARE
    v_duration INTEGER;
BEGIN
    UPDATE backups
    SET 
        status = 'completed',
        completed_at = NOW(),
        duration_seconds = EXTRACT(EPOCH FROM (NOW() - started_at))::INTEGER,
        file_path = p_file_path,
        file_size = p_file_size,
        tables_backed_up = p_tables_backed_up,
        row_count = p_row_count
    WHERE id = p_backup_id
    RETURNING duration_seconds INTO v_duration;
    
    -- Log completion
    PERFORM log_audit_trail(
        'backup_completed',
        'backup',
        p_backup_id,
        'Backup #' || p_backup_id::TEXT,
        NULL,
        jsonb_build_object(
            'file_size', p_file_size,
            'duration', v_duration,
            'row_count', p_row_count
        ),
        'Backup completed successfully',
        'info'
    );
    
    RETURN true;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION complete_backup IS 'Mark backup as completed with metadata';

-- ============================================================================
-- FUNCTION: Get Admin Dashboard Stats
-- ============================================================================

CREATE OR REPLACE FUNCTION get_admin_dashboard_stats(p_admin_id UUID)
RETURNS JSONB AS $$
DECLARE
    v_role admin_role;
    v_permissions JSONB;
    v_stats JSONB;
BEGIN
    -- Get admin role
    SELECT role, permissions INTO v_role, v_permissions
    FROM platform_admins
    WHERE user_id = p_admin_id;
    
    -- Build stats based on permissions
    v_stats := jsonb_build_object(
        'role', v_role,
        'can_access_settings', (v_role = 'superadmin'),
        'can_access_backups', (v_role = 'superadmin'),
        'restaurants_count', (
            SELECT COUNT(*) FROM restaurants WHERE v_role IN ('superadmin', 'subadmin')
        ),
        'active_restaurants', (
            SELECT COUNT(*) FROM restaurants WHERE is_active = true AND v_role IN ('superadmin', 'subadmin')
        ),
        'pending_bills', (
            SELECT COUNT(*) FROM billing WHERE status = 'pending' AND v_role IN ('superadmin', 'subadmin')
        ),
        'overdue_bills', (
            SELECT COUNT(*) FROM billing WHERE status = 'overdue' AND v_role IN ('superadmin', 'subadmin')
        )
    );
    
    RETURN v_stats;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION get_admin_dashboard_stats IS 'Get dashboard stats based on admin role';

-- ============================================================================
-- ROW LEVEL SECURITY
-- ============================================================================

ALTER TABLE platform_admins ENABLE ROW LEVEL SECURITY;
ALTER TABLE backups ENABLE ROW LEVEL SECURITY;
ALTER TABLE backup_schedules ENABLE ROW LEVEL SECURITY;

-- Platform Admins Policies
DROP POLICY IF EXISTS "Superadmin full access to platform_admins" ON platform_admins;
CREATE POLICY "Superadmin full access to platform_admins" ON platform_admins
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM platform_admins
            WHERE user_id = auth.uid()
            AND role = 'superadmin'
            AND is_active = true
        )
    );

DROP POLICY IF EXISTS "Admins can view their own profile" ON platform_admins;
CREATE POLICY "Admins can view their own profile" ON platform_admins
    FOR SELECT USING (user_id = auth.uid());

-- Backups Policies
DROP POLICY IF EXISTS "Superadmin full access to backups" ON backups;
CREATE POLICY "Superadmin full access to backups" ON backups
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM platform_admins
            WHERE user_id = auth.uid()
            AND role = 'superadmin'
            AND is_active = true
        )
    );

DROP POLICY IF EXISTS "Subadmin read-only backups" ON backups;
CREATE POLICY "Subadmin read-only backups" ON backups
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM platform_admins
            WHERE user_id = auth.uid()
            AND role = 'subadmin'
            AND is_active = true
        )
    );

-- Backup Schedules Policies
DROP POLICY IF EXISTS "Superadmin full access to backup_schedules" ON backup_schedules;
CREATE POLICY "Superadmin full access to backup_schedules" ON backup_schedules
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM platform_admins
            WHERE user_id = auth.uid()
            AND role = 'superadmin'
            AND is_active = true
        )
    );

-- ============================================================================
-- TRIGGERS
-- ============================================================================

-- Update timestamp for platform_admins
CREATE OR REPLACE FUNCTION update_platform_admins_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS update_platform_admins_timestamp_trigger ON platform_admins;
CREATE TRIGGER update_platform_admins_timestamp_trigger
    BEFORE UPDATE ON platform_admins
    FOR EACH ROW
    EXECUTE FUNCTION update_platform_admins_timestamp();

-- ============================================================================
-- DEFAULT SUPERADMIN SETUP
-- ============================================================================

-- This should be run manually after creating the first superadmin account
/*
INSERT INTO platform_admins (user_id, email, full_name, role, permissions)
VALUES (
    '<superadmin_user_id>'::UUID,
    'admin@praahis.com',
    'Super Administrator',
    'superadmin',
    '{
        "restaurants": {"create": true, "read": true, "update": true, "delete": true},
        "managers": {"create": true, "read": true, "update": true, "delete": true},
        "billing": {"create": true, "read": true, "update": true, "delete": true},
        "settings": {"create": true, "read": true, "update": true, "delete": true},
        "backups": {"create": true, "read": true, "update": true, "delete": true},
        "audit": {"create": true, "read": true, "update": true, "delete": true}
    }'
)
ON CONFLICT (user_id) DO NOTHING;
*/

-- ============================================================================
-- USAGE EXAMPLES
-- ============================================================================

/*
-- 1. Check if user has permission
SELECT check_admin_permission(
    '<user_id>'::UUID,
    'restaurants',
    'delete'
);

-- 2. Create a backup record
SELECT create_backup_record(
    'full',
    'daily_backup_2025_11_07',
    NULL,
    '<admin_user_id>'::UUID
);

-- 3. Mark backup as complete
SELECT complete_backup(
    '<backup_id>'::UUID,
    '/backups/2025/11/daily_backup_2025_11_07.sql.gz',
    1048576, -- file size in bytes
    ARRAY['restaurants', 'users', 'billing', 'payments'],
    10000 -- total rows
);

-- 4. Get admin dashboard stats
SELECT get_admin_dashboard_stats('<admin_user_id>'::UUID);

-- 5. Clean up old backups
DELETE FROM backups
WHERE status = 'completed'
  AND expires_at < NOW()
  AND can_restore = true;
*/
