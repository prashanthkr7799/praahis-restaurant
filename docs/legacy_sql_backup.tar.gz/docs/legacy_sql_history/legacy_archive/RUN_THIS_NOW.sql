-- =========================================================================
-- COMPLETE FIX - Run This ENTIRE Script
-- =========================================================================
-- This will fix ALL the issues you're experiencing:
-- - 403 Forbidden
-- - 406 Not Acceptable  
-- - 400 Invalid credentials
-- - 500 Internal Server Error
-- =========================================================================

-- STEP 1: Enable RLS on users table
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

-- STEP 2: Drop ALL existing policies (clean slate)
DO $$ 
DECLARE
    r RECORD;
BEGIN
    FOR r IN (SELECT policyname FROM pg_policies WHERE tablename = 'users' AND schemaname = 'public') LOOP
        EXECUTE 'DROP POLICY IF EXISTS ' || quote_ident(r.policyname) || ' ON public.users';
    END LOOP;
END $$;

-- STEP 3: Create simple, non-recursive policies for SELECT
CREATE POLICY "users_allow_read" 
ON public.users 
FOR SELECT 
TO authenticated
USING (true);

-- STEP 4: Create simple policy for INSERT
CREATE POLICY "users_allow_insert" 
ON public.users 
FOR INSERT 
TO authenticated
WITH CHECK (true);

-- STEP 5: Create simple policy for UPDATE
CREATE POLICY "users_allow_update" 
ON public.users 
FOR UPDATE 
TO authenticated
USING (true);

-- STEP 6: Create simple policy for DELETE
CREATE POLICY "users_allow_delete" 
ON public.users 
FOR DELETE 
TO authenticated
USING (true);

-- STEP 7: Create or replace auto-confirm function
CREATE OR REPLACE FUNCTION public.auto_confirm_user()
RETURNS TRIGGER AS $$
BEGIN
  NEW.email_confirmed_at := NOW();
  NEW.confirmation_token := '';
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- STEP 8: Create trigger for auto-confirm
DROP TRIGGER IF EXISTS auto_confirm_user_trigger ON auth.users;
CREATE TRIGGER auto_confirm_user_trigger
  BEFORE INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.auto_confirm_user();

-- STEP 9: Confirm ALL existing unconfirmed users
UPDATE auth.users 
SET email_confirmed_at = COALESCE(email_confirmed_at, NOW()),
    confirmation_token = ''
WHERE email_confirmed_at IS NULL;

-- STEP 10: Delete the orphaned session that's causing 403 errors
-- This is the user ID from your error: bfd6272a-4093-43b3-8fc1-176b487c53b8
-- If this user doesn't have a public.users record, we'll clean it up
DELETE FROM auth.users 
WHERE id = 'bfd6272a-4093-43b3-8fc1-176b487c53b8'
AND NOT EXISTS (
    SELECT 1 FROM public.users WHERE id = 'bfd6272a-4093-43b3-8fc1-176b487c53b8'
);

-- STEP 11: Verify the fix
SELECT '========================================' as step;
SELECT 'RLS STATUS:' as check;
SELECT 
    tablename,
    rowsecurity as rls_enabled
FROM pg_tables
WHERE tablename = 'users' AND schemaname = 'public';

SELECT '========================================' as step;
SELECT 'POLICIES CREATED:' as check;
SELECT 
    policyname,
    cmd,
    roles
FROM pg_policies 
WHERE tablename = 'users' AND schemaname = 'public'
ORDER BY policyname;

SELECT '========================================' as step;
SELECT 'CONFIRMED USERS:' as check;
SELECT 
    au.email,
    au.email_confirmed_at IS NOT NULL as is_confirmed,
    pu.role,
    pu.is_owner,
    pu.is_active
FROM auth.users au
LEFT JOIN public.users pu ON au.id = pu.id
ORDER BY au.created_at DESC
LIMIT 5;

-- =========================================================================
-- SUCCESS!
-- You should see:
-- 1. rls_enabled = TRUE
-- 2. 4 policies created (users_allow_read, users_allow_insert, etc.)
-- 3. All users have is_confirmed = true
-- 
-- NOW: Clear browser storage and try logging in!
-- =========================================================================
