-- ============================================================================
-- FIX MISSING SUBSCRIPTIONS
-- ============================================================================
-- This script creates subscriptions for restaurants that don't have one
-- Run this in Supabase SQL Editor
-- ============================================================================

-- 1. Check which restaurants are missing subscriptions
SELECT 
    r.id,
    r.name,
    r.slug,
    r.max_tables,
    CASE 
        WHEN s.id IS NULL THEN '❌ NO SUBSCRIPTION'
        ELSE '✅ HAS SUBSCRIPTION'
    END as status
FROM restaurants r
LEFT JOIN subscriptions s ON s.restaurant_id = r.id
ORDER BY r.name;

-- 2. Create subscriptions for restaurants that don't have one
-- You can choose between Trial (free) or Paid (₹35,000) subscription

-- OPTION A: Create FREE TRIAL subscriptions (3-day trial)
-- Uncomment this if you want FREE trial:
/*
INSERT INTO subscriptions (
    restaurant_id,
    plan_name,
    status,
    billing_cycle,
    price,
    price_per_table,
    current_period_start,
    current_period_end,
    trial_ends_at,
    created_at,
    updated_at
)
SELECT 
    r.id as restaurant_id,
    'Trial' as plan_name,
    'trial' as status,  -- Trial status
    'monthly' as billing_cycle,
    0 as price,  -- Free during trial
    NULL as price_per_table,  -- No per-table pricing during trial
    NOW() as current_period_start,
    NOW() + INTERVAL '3 days' as current_period_end,
    NOW() + INTERVAL '3 days' as trial_ends_at,
    NOW() as created_at,
    NOW() as updated_at
FROM restaurants r
LEFT JOIN subscriptions s ON s.restaurant_id = r.id
WHERE s.id IS NULL;
*/

-- OPTION B: Create PAID subscriptions (₹35,000/month fixed price)
-- This is active by default:
INSERT INTO subscriptions (
    restaurant_id,
    plan_name,
    status,
    billing_cycle,
    price,
    price_per_table,
    current_period_start,
    current_period_end,
    created_at,
    updated_at
)
SELECT 
    r.id as restaurant_id,
    'Standard Plan' as plan_name,  -- Fixed plan name
    'active' as status,  -- Paid and active
    'monthly' as billing_cycle,
    35000 as price,  -- ₹35,000 per month
    NULL as price_per_table,  -- NULL means custom/fixed pricing, not per-table
    NOW() as current_period_start,
    NOW() + INTERVAL '30 days' as current_period_end,
    NOW() as created_at,
    NOW() as updated_at
FROM restaurants r
LEFT JOIN subscriptions s ON s.restaurant_id = r.id
WHERE s.id IS NULL;  -- Only create for restaurants without subscriptions

-- OPTION C: Create PER-TABLE subscriptions (₹100/table/day)
-- Uncomment this if you want per-table pricing:
/*
INSERT INTO subscriptions (
    restaurant_id,
    plan_name,
    status,
    billing_cycle,
    price,
    price_per_table,
    current_period_start,
    current_period_end,
    created_at,
    updated_at
)
SELECT 
    r.id as restaurant_id,
    r.max_tables || ' Tables' as plan_name,  -- "10 Tables", "20 Tables"
    'active' as status,
    'monthly' as billing_cycle,
    (r.max_tables * 100 * 30) as price,  -- Tables × ₹100/day × 30 days
    100 as price_per_table,  -- ₹100 per table per day
    NOW() as current_period_start,
    NOW() + INTERVAL '30 days' as current_period_end,
    NOW() as created_at,
    NOW() as updated_at
FROM restaurants r
LEFT JOIN subscriptions s ON s.restaurant_id = r.id
WHERE s.id IS NULL;
*/

-- 3. Verify all restaurants now have subscriptions
SELECT 
    'Total Restaurants' as metric,
    COUNT(*) as count
FROM restaurants

UNION ALL

SELECT 
    'Restaurants with Subscriptions',
    COUNT(*)
FROM restaurants r
INNER JOIN subscriptions s ON s.restaurant_id = r.id

UNION ALL

SELECT 
    'Restaurants WITHOUT Subscriptions',
    COUNT(*)
FROM restaurants r
LEFT JOIN subscriptions s ON s.restaurant_id = r.id
WHERE s.id IS NULL;

-- 4. Show all restaurants with their subscription details
SELECT 
    r.name,
    r.max_tables,
    s.plan_name,
    s.status,
    s.price,
    s.price_per_table,
    s.current_period_end,
    EXTRACT(DAY FROM (s.current_period_end - NOW()))::INTEGER as days_remaining
FROM restaurants r
LEFT JOIN subscriptions s ON s.restaurant_id = r.id
ORDER BY r.name;
