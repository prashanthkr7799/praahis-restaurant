-- ============================================================================
-- USERS TABLE - ADD SUPER ADMIN FIELDS
-- ============================================================================
-- Version: 1.0
-- Created: November 6, 2025
-- Description: Add fields needed for Super Admin manager management
-- Run after: 18_users_is_owner.sql
-- ============================================================================

-- Add name column (alias for full_name for consistency)
ALTER TABLE users
    ADD COLUMN IF NOT EXISTS name VARCHAR(255);

-- Add phone column
ALTER TABLE users
    ADD COLUMN IF NOT EXISTS phone VARCHAR(50);

-- Add restaurant_id for multi-tenancy
ALTER TABLE users
    ADD COLUMN IF NOT EXISTS restaurant_id UUID REFERENCES restaurants(id) ON DELETE CASCADE;

-- Backfill name from full_name if exists
UPDATE users 
SET name = full_name 
WHERE name IS NULL AND full_name IS NOT NULL;

-- Backfill full_name from name if exists
UPDATE users 
SET full_name = name 
WHERE full_name IS NULL AND name IS NOT NULL;

-- Create index for restaurant_id
CREATE INDEX IF NOT EXISTS idx_users_restaurant ON users(restaurant_id);

-- Create index for phone
CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone);

-- Add comments
COMMENT ON COLUMN users.name IS 'User display name (synced with full_name)';
COMMENT ON COLUMN users.phone IS 'User phone number';
COMMENT ON COLUMN users.restaurant_id IS 'Associated restaurant (for managers/staff)';

-- ============================================================================
-- TRIGGER TO KEEP name AND full_name IN SYNC
-- ============================================================================

-- Function to sync name and full_name
CREATE OR REPLACE FUNCTION sync_user_names()
RETURNS TRIGGER AS $$
BEGIN
    -- If name is updated, sync to full_name
    IF NEW.name IS DISTINCT FROM OLD.name THEN
        NEW.full_name = NEW.name;
    END IF;
    
    -- If full_name is updated, sync to name
    IF NEW.full_name IS DISTINCT FROM OLD.full_name THEN
        NEW.name = NEW.full_name;
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger
DROP TRIGGER IF EXISTS sync_user_names_trigger ON users;
CREATE TRIGGER sync_user_names_trigger
    BEFORE UPDATE ON users
    FOR EACH ROW
    EXECUTE FUNCTION sync_user_names();

-- ============================================================================
-- RLS POLICIES FOR USERS TABLE
-- ============================================================================

-- Enable RLS on users table (if not already enabled)
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- Owners can view all users
DROP POLICY IF EXISTS "Owners can view all users" ON users;
CREATE POLICY "Owners can view all users" ON users
    FOR SELECT
    USING (public.is_owner());

-- Owners can insert users
DROP POLICY IF EXISTS "Owners can insert users" ON users;
CREATE POLICY "Owners can insert users" ON users
    FOR INSERT
    WITH CHECK (public.is_owner());

-- Owners can update any user
DROP POLICY IF EXISTS "Owners can update users" ON users;
CREATE POLICY "Owners can update users" ON users
    FOR UPDATE
    USING (public.is_owner())
    WITH CHECK (public.is_owner());

-- Owners can delete any user
DROP POLICY IF EXISTS "Owners can delete users" ON users;
CREATE POLICY "Owners can delete users" ON users
    FOR DELETE
    USING (public.is_owner());

-- Users can view their own record
DROP POLICY IF EXISTS "Users can view own record" ON users;
CREATE POLICY "Users can view own record" ON users
    FOR SELECT
    USING (id = auth.uid());

-- Users can update their own record (limited fields)
DROP POLICY IF EXISTS "Users can update own record" ON users;
CREATE POLICY "Users can update own record" ON users
    FOR UPDATE
    USING (id = auth.uid())
    WITH CHECK (id = auth.uid());

-- ============================================================================
-- VERIFICATION
-- ============================================================================

DO $$
BEGIN
    RAISE NOTICE 'Verifying users table columns...';
    
    IF EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'users' AND column_name = 'name'
    ) THEN
        RAISE NOTICE '✓ name column exists';
    END IF;
    
    IF EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'users' AND column_name = 'phone'
    ) THEN
        RAISE NOTICE '✓ phone column exists';
    END IF;
    
    IF EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'users' AND column_name = 'restaurant_id'
    ) THEN
        RAISE NOTICE '✓ restaurant_id column exists';
    END IF;
    
    RAISE NOTICE 'Users table enhanced for Super Admin successfully!';
END $$;

-- ============================================================================
-- END OF USERS TABLE ENHANCEMENT
-- ============================================================================
