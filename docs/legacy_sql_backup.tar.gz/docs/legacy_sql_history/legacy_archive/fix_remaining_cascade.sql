-- Fix remaining tables without CASCADE DELETE

-- Fix 1: Update backups table to CASCADE (if you want backups deleted with restaurant)
DO $$
DECLARE
  constraint_name_var TEXT;
BEGIN
  -- Find the constraint name for backups.restaurant_id
  SELECT tc.constraint_name INTO constraint_name_var
  FROM information_schema.table_constraints AS tc 
  JOIN information_schema.key_column_usage AS kcu
    ON tc.constraint_name = kcu.constraint_name
  WHERE tc.constraint_type = 'FOREIGN KEY'
    AND tc.table_name = 'backups'
    AND kcu.column_name = 'restaurant_id';
  
  -- Drop it if found
  IF constraint_name_var IS NOT NULL THEN
    EXECUTE format('ALTER TABLE public.backups DROP CONSTRAINT IF EXISTS %I', constraint_name_var);
    RAISE NOTICE 'Dropped backups constraint: %', constraint_name_var;
  END IF;
END $$;

-- Add CASCADE to backups
ALTER TABLE public.backups
ADD CONSTRAINT backups_restaurant_id_fkey 
FOREIGN KEY (restaurant_id) 
REFERENCES restaurants(id) 
ON DELETE CASCADE;

-- Fix 2: Update system_logs table to CASCADE
DO $$
DECLARE
  constraint_name_var TEXT;
BEGIN
  -- Find the constraint name for system_logs.restaurant_id
  SELECT tc.constraint_name INTO constraint_name_var
  FROM information_schema.table_constraints AS tc 
  JOIN information_schema.key_column_usage AS kcu
    ON tc.constraint_name = kcu.constraint_name
  WHERE tc.constraint_type = 'FOREIGN KEY'
    AND tc.table_name = 'system_logs'
    AND kcu.column_name = 'restaurant_id';
  
  -- Drop it if found
  IF constraint_name_var IS NOT NULL THEN
    EXECUTE format('ALTER TABLE public.system_logs DROP CONSTRAINT IF EXISTS %I', constraint_name_var);
    RAISE NOTICE 'Dropped system_logs constraint: %', constraint_name_var;
  END IF;
END $$;

-- Add CASCADE to system_logs
ALTER TABLE public.system_logs
ADD CONSTRAINT system_logs_restaurant_id_fkey 
FOREIGN KEY (restaurant_id) 
REFERENCES restaurants(id) 
ON DELETE CASCADE;

-- Verify all tables now have CASCADE
SELECT 
  tc.table_name,
  kcu.column_name,
  rc.delete_rule,
  CASE 
    WHEN rc.delete_rule = 'CASCADE' THEN '✅ Has CASCADE'
    ELSE '❌ No CASCADE: ' || rc.delete_rule
  END as status
FROM information_schema.table_constraints AS tc 
JOIN information_schema.key_column_usage AS kcu
  ON tc.constraint_name = kcu.constraint_name
JOIN information_schema.constraint_column_usage AS ccu
  ON ccu.constraint_name = tc.constraint_name
JOIN information_schema.referential_constraints AS rc
  ON rc.constraint_name = tc.constraint_name
WHERE tc.constraint_type = 'FOREIGN KEY'
  AND ccu.table_name = 'restaurants'
ORDER BY tc.table_name;
