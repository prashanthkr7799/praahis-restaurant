-- ============================================================================
-- CHECK WHICH ACCOUNTS ARE SUPERADMIN (is_owner = true)
-- ============================================================================
-- Run this in Supabase SQL Editor to see which of your admin accounts
-- are real SuperAdmins (platform owners)
-- ============================================================================

-- ============================================================================
-- QUERY 1: Check your two admin accounts specifically
-- ============================================================================

SELECT 
  email,
  role,
  is_owner,
  restaurant_id,
  created_at,
  updated_at,
  CASE 
    WHEN is_owner = true THEN '✅ REAL SUPERADMIN (Platform Owner)'
    WHEN role = 'admin' AND is_owner = false THEN '⚠️ ADMIN (but not owner)'
    WHEN role = 'admin' AND is_owner IS NULL THEN '⚠️ ADMIN (is_owner not set)'
    ELSE 'Other'
  END as account_type
FROM public.users
WHERE email IN ('admin@praahis.com', 'prashanthkumareddy879@gmail.com')
ORDER BY is_owner DESC NULLS LAST, created_at;

-- ============================================================================
-- QUERY 2: Show ALL admin/owner accounts in the system
-- ============================================================================

SELECT 
  email,
  role,
  is_owner,
  restaurant_id,
  full_name,
  created_at,
  CASE 
    WHEN is_owner = true THEN '🔑 SUPERADMIN'
    WHEN role = 'admin' THEN '👤 ADMIN (not owner)'
    WHEN role = 'manager' THEN '👨‍💼 MANAGER'
    ELSE role
  END as account_type
FROM public.users
WHERE role IN ('admin', 'manager') OR is_owner = true
ORDER BY is_owner DESC NULLS LAST, role, created_at;

-- ============================================================================
-- QUERY 3: Check if accounts exist in auth.users
-- ============================================================================

SELECT 
  au.email as auth_email,
  au.created_at as auth_created_at,
  au.confirmed_at,
  u.email as profile_email,
  u.role,
  u.is_owner,
  CASE 
    WHEN u.id IS NULL THEN '❌ No profile in public.users'
    WHEN u.is_owner = true THEN '✅ SuperAdmin with profile'
    WHEN u.role = 'admin' THEN '⚠️ Admin with profile (not owner)'
    ELSE '✅ Has profile'
  END as status
FROM auth.users au
LEFT JOIN public.users u ON au.id = u.id
WHERE au.email IN ('admin@praahis.com', 'prashanthkumareddy879@gmail.com')
ORDER BY au.created_at;

-- ============================================================================
-- INTERPRETATION GUIDE
-- ============================================================================

/*

WHAT TO LOOK FOR:

1. If is_owner = true:
   ✅ This is a REAL SuperAdmin (Platform Owner)
   ✅ Can access /superadmin-login
   ✅ Can create restaurants and managers
   ✅ Has global access to all data

2. If is_owner = false (or NULL) and role = 'admin':
   ⚠️ This is just an admin, NOT a platform owner
   ⚠️ Should NOT use /superadmin-login
   ⚠️ May have limited access

3. If is_owner = NULL:
   ⚠️ The is_owner field was never set
   ⚠️ Need to update this account

EXPECTED RESULTS:

SCENARIO A: Both are SuperAdmin
┌─────────────────────────────┬────────┬──────────┬───────────────┬──────────────────┐
│ email                       │ role   │ is_owner │ restaurant_id │ account_type     │
├─────────────────────────────┼────────┼──────────┼───────────────┼──────────────────┤
│ admin@praahis.com           │ admin  │ true     │ NULL          │ ✅ SUPERADMIN   │
│ prashant...@gmail.com       │ admin  │ true     │ NULL          │ ✅ SUPERADMIN   │
└─────────────────────────────┴────────┴──────────┴───────────────┴──────────────────┘
RESULT: Both can be used as SuperAdmin. Pick one!

SCENARIO B: Only one is SuperAdmin
┌─────────────────────────────┬────────┬──────────┬───────────────┬──────────────────┐
│ email                       │ role   │ is_owner │ restaurant_id │ account_type     │
├─────────────────────────────┼────────┼──────────┼───────────────┼──────────────────┤
│ admin@praahis.com           │ admin  │ true     │ NULL          │ ✅ SUPERADMIN   │
│ prashant...@gmail.com       │ admin  │ false    │ NULL          │ ⚠️ ADMIN        │
└─────────────────────────────┴────────┴──────────┴───────────────┴──────────────────┘
RESULT: Use admin@praahis.com as SuperAdmin

SCENARIO C: Neither is SuperAdmin (is_owner not set)
┌─────────────────────────────┬────────┬──────────┬───────────────┬──────────────────┐
│ email                       │ role   │ is_owner │ restaurant_id │ account_type     │
├─────────────────────────────┼────────┼──────────┼───────────────┼──────────────────┤
│ admin@praahis.com           │ admin  │ NULL     │ NULL          │ ⚠️ ADMIN        │
│ prashant...@gmail.com       │ admin  │ NULL     │ NULL          │ ⚠️ ADMIN        │
└─────────────────────────────┴────────┴──────────┴───────────────┴──────────────────┘
RESULT: Need to set is_owner = true for one of them!

*/

-- ============================================================================
-- NEXT STEPS BASED ON RESULTS
-- ============================================================================

/*

IF YOU NEED TO SET is_owner = true:

-- Option A: Make admin@praahis.com the SuperAdmin
UPDATE public.users 
SET is_owner = true 
WHERE email = 'admin@praahis.com';

-- Option B: Make prashanthkumareddy879@gmail.com the SuperAdmin
UPDATE public.users 
SET is_owner = true 
WHERE email = 'prashanthkumareddy879@gmail.com';


IF YOU WANT TO DELETE ONE SUPERADMIN (OPTIONAL):

After you've decided which one to keep, delete the other:

-- Delete admin@praahis.com (if you want to keep your personal email)
BEGIN;
DELETE FROM public.users WHERE email = 'admin@praahis.com';
DELETE FROM auth.users WHERE email = 'admin@praahis.com';
COMMIT;

-- OR delete prashanthkumareddy879@gmail.com (if you want to keep admin@praahis.com)
BEGIN;
DELETE FROM public.users WHERE email = 'prashanthkumareddy879@gmail.com';
DELETE FROM auth.users WHERE email = 'prashanthkumareddy879@gmail.com';
COMMIT;

*/
