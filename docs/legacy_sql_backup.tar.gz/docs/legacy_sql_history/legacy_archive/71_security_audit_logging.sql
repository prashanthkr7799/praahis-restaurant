-- ============================================================================
-- SECURITY AUDIT LOGGING TABLES
-- ============================================================================
-- Version: 1.0
-- Created: November 2025
-- Description: Comprehensive logging for authentication and security events
-- ============================================================================

-- ============================================================================
-- TABLE: auth_activity_logs
-- Purpose: Track all authentication-related activities
-- ============================================================================

CREATE TABLE IF NOT EXISTS auth_activity_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    action VARCHAR(100) NOT NULL,
    ip_address INET,
    user_agent TEXT,
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE auth_activity_logs IS 'Authentication and security event logs';
COMMENT ON COLUMN auth_activity_logs.action IS 'login_success, login_failed, logout, cross_restaurant_access_attempt, etc.';
COMMENT ON COLUMN auth_activity_logs.metadata IS 'Additional context: role, restaurant_id, error messages, etc.';

-- Create indexes for fast querying
CREATE INDEX IF NOT EXISTS idx_auth_logs_user_id ON auth_activity_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_auth_logs_action ON auth_activity_logs(action);
CREATE INDEX IF NOT EXISTS idx_auth_logs_created_at ON auth_activity_logs(created_at DESC);

-- ============================================================================
-- TABLE: system_logs
-- Purpose: General system events and errors
-- ============================================================================

CREATE TABLE IF NOT EXISTS system_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    level VARCHAR(20) NOT NULL CHECK (level IN ('DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL')),
    source VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE system_logs IS 'System-wide event and error logs';
COMMENT ON COLUMN system_logs.source IS 'Component or module that generated the log (e.g., RLS_VIOLATION, API_ERROR)';

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_system_logs_level ON system_logs(level);
CREATE INDEX IF NOT EXISTS idx_system_logs_source ON system_logs(source);
CREATE INDEX IF NOT EXISTS idx_system_logs_created_at ON system_logs(created_at DESC);

-- ============================================================================
-- HELPER FUNCTIONS FOR LOGGING
-- ============================================================================

-- Log authentication event
CREATE OR REPLACE FUNCTION log_auth_event(
    p_user_id UUID,
    p_action VARCHAR(100),
    p_metadata JSONB DEFAULT '{}'::jsonb
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_log_id UUID;
BEGIN
    INSERT INTO auth_activity_logs (
        user_id,
        action,
        metadata
    ) VALUES (
        p_user_id,
        p_action,
        p_metadata
    )
    RETURNING id INTO v_log_id;
    
    RETURN v_log_id;
END;
$$;

COMMENT ON FUNCTION log_auth_event IS 'Helper function to log authentication events';

-- Log system event
CREATE OR REPLACE FUNCTION log_system_event(
    p_level VARCHAR(20),
    p_source VARCHAR(100),
    p_message TEXT,
    p_metadata JSONB DEFAULT '{}'::jsonb
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_log_id UUID;
BEGIN
    INSERT INTO system_logs (
        level,
        source,
        message,
        metadata
    ) VALUES (
        p_level,
        p_source,
        p_message,
        p_metadata
    )
    RETURNING id INTO v_log_id;
    
    RETURN v_log_id;
END;
$$;

COMMENT ON FUNCTION log_system_event IS 'Helper function to log system events';

-- ============================================================================
-- SECURITY MONITORING VIEWS
-- ============================================================================

-- View: Recent failed login attempts
CREATE OR REPLACE VIEW recent_failed_logins AS
SELECT 
    al.user_id,
    u.email,
    u.role,
    al.action,
    al.metadata->>'error' as error_message,
    al.created_at
FROM auth_activity_logs al
LEFT JOIN users u ON u.id = al.user_id
WHERE al.action IN ('login_failed', 'superadmin_login_failed')
AND al.created_at > NOW() - INTERVAL '24 hours'
ORDER BY al.created_at DESC;

COMMENT ON VIEW recent_failed_logins IS 'Failed login attempts in the last 24 hours';

-- View: Cross-restaurant access attempts
CREATE OR REPLACE VIEW cross_restaurant_violations AS
SELECT 
    al.user_id,
    u.email,
    u.role,
    u.restaurant_id as user_restaurant_id,
    al.metadata->>'attempted_restaurant_id' as attempted_restaurant_id,
    al.metadata->>'reason' as reason,
    al.created_at
FROM auth_activity_logs al
LEFT JOIN users u ON u.id = al.user_id
WHERE al.action = 'cross_restaurant_access_attempt'
ORDER BY al.created_at DESC;

COMMENT ON VIEW cross_restaurant_violations IS 'Attempted cross-restaurant data access violations';

-- View: Authentication activity summary
CREATE OR REPLACE VIEW auth_activity_summary AS
SELECT 
    DATE_TRUNC('day', created_at) as date,
    action,
    COUNT(*) as count
FROM auth_activity_logs
WHERE created_at > NOW() - INTERVAL '30 days'
GROUP BY DATE_TRUNC('day', created_at), action
ORDER BY date DESC, count DESC;

COMMENT ON VIEW auth_activity_summary IS 'Daily authentication activity summary for the last 30 days';

-- ============================================================================
-- AUTOMATIC CLEANUP (Optional)
-- ============================================================================

-- Function to clean old logs (run periodically via cron job)
CREATE OR REPLACE FUNCTION cleanup_old_logs(retention_days INTEGER DEFAULT 90)
RETURNS TABLE (
    deleted_auth_logs BIGINT,
    deleted_system_logs BIGINT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_deleted_auth BIGINT;
    v_deleted_system BIGINT;
BEGIN
    -- Delete old auth activity logs
    WITH deleted AS (
        DELETE FROM auth_activity_logs
        WHERE created_at < NOW() - (retention_days || ' days')::INTERVAL
        RETURNING *
    )
    SELECT COUNT(*) INTO v_deleted_auth FROM deleted;
    
    -- Delete old system logs (keep errors longer)
    WITH deleted AS (
        DELETE FROM system_logs
        WHERE created_at < NOW() - (retention_days || ' days')::INTERVAL
        AND level NOT IN ('ERROR', 'CRITICAL')
        RETURNING *
    )
    SELECT COUNT(*) INTO v_deleted_system FROM deleted;
    
    -- Log the cleanup action
    PERFORM log_system_event(
        'INFO',
        'LOG_CLEANUP',
        'Automatic log cleanup completed',
        jsonb_build_object(
            'retention_days', retention_days,
            'auth_logs_deleted', v_deleted_auth,
            'system_logs_deleted', v_deleted_system
        )
    );
    
    RETURN QUERY SELECT v_deleted_auth, v_deleted_system;
END;
$$;

COMMENT ON FUNCTION cleanup_old_logs IS 'Delete logs older than specified retention period (default 90 days)';

-- ============================================================================
-- RLS POLICIES FOR LOG TABLES
-- ============================================================================

-- Enable RLS on log tables
ALTER TABLE auth_activity_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE system_logs ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if any
DROP POLICY IF EXISTS "auth_logs_manager_select" ON auth_activity_logs;
DROP POLICY IF EXISTS "auth_logs_superadmin_all" ON auth_activity_logs;
DROP POLICY IF EXISTS "auth_logs_service_insert" ON auth_activity_logs;
DROP POLICY IF EXISTS "system_logs_superadmin_all" ON system_logs;
DROP POLICY IF EXISTS "system_logs_service_insert" ON system_logs;

-- Managers can view their own restaurant's auth logs
CREATE POLICY "auth_logs_manager_select"
ON auth_activity_logs FOR SELECT
TO authenticated
USING (
    public.auth_get_user_role() IN ('manager', 'admin')
    AND user_id IN (
        SELECT id FROM users 
        WHERE restaurant_id = public.auth_get_user_restaurant_id()
    )
);

-- SuperAdmin can view all auth logs
CREATE POLICY "auth_logs_superadmin_all"
ON auth_activity_logs FOR ALL
TO authenticated
USING (public.auth_is_owner_or_superadmin())
WITH CHECK (public.auth_is_owner_or_superadmin());

-- System logs: only superadmin can view
CREATE POLICY "system_logs_superadmin_all"
ON system_logs FOR ALL
TO authenticated
USING (public.auth_is_owner_or_superadmin())
WITH CHECK (public.auth_is_owner_or_superadmin());

-- Allow insert from service role (for logging from backend)
CREATE POLICY "auth_logs_service_insert"
ON auth_activity_logs FOR INSERT
TO service_role
WITH CHECK (true);

CREATE POLICY "system_logs_service_insert"
ON system_logs FOR INSERT
TO service_role
WITH CHECK (true);

-- ============================================================================
-- GRANT PERMISSIONS
-- ============================================================================

-- Grant necessary permissions to authenticated users
GRANT SELECT ON recent_failed_logins TO authenticated;
GRANT SELECT ON cross_restaurant_violations TO authenticated;
GRANT SELECT ON auth_activity_summary TO authenticated;

-- Grant execute on logging functions
GRANT EXECUTE ON FUNCTION log_auth_event TO authenticated;
GRANT EXECUTE ON FUNCTION log_system_event TO authenticated;

-- ============================================================================
-- COMPLETION MESSAGE
-- ============================================================================

DO $$
BEGIN
    RAISE NOTICE 'Security audit logging system installed successfully';
    RAISE NOTICE 'Tables created: auth_activity_logs, system_logs';
    RAISE NOTICE 'Views created: recent_failed_logins, cross_restaurant_violations, auth_activity_summary';
    RAISE NOTICE 'Functions created: log_auth_event, log_system_event, cleanup_old_logs';
END $$;
