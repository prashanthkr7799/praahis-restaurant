-- ============================================================================
-- ADD PRICE_PER_TABLE COLUMN TO SUBSCRIPTIONS
-- ============================================================================
-- Version: 1.0
-- Created: November 9, 2025
-- Description: Add price_per_table field to support table-based pricing model
-- ============================================================================

-- Add price_per_table column to subscriptions table
ALTER TABLE subscriptions 
ADD COLUMN IF NOT EXISTS price_per_table DECIMAL(10, 2) DEFAULT NULL;

COMMENT ON COLUMN subscriptions.price_per_table IS 'Price per table per day (NULL for custom pricing)';

-- Create index for queries filtering by pricing type
CREATE INDEX IF NOT EXISTS idx_subscriptions_price_per_table 
ON subscriptions(price_per_table) WHERE price_per_table IS NOT NULL;

-- Update existing subscriptions to have default per-table pricing
-- (Optional: uncomment if you want to update existing records)
-- UPDATE subscriptions 
-- SET price_per_table = 100
-- WHERE price_per_table IS NULL 
--   AND plan_name NOT IN ('trial', 'custom');
