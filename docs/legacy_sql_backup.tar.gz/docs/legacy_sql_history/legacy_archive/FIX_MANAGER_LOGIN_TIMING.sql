-- ============================================================================
-- FIX: Manager Login "Restaurant context is missing" - TIMING ISSUE
-- ============================================================================
-- This issue is DIFFERENT from missing restaurant_id in database
-- 
-- SYMPTOMS:
-- - Login shows "Access Denied - Restaurant context is missing"
-- - Page reload → Dashboard works fine!
-- - 401 error on auth_activity_logs
-- 
-- ROOT CAUSE:
-- Race condition: ProtectedRoute checks restaurantId before RestaurantContext
-- finishes loading after login redirect
-- ============================================================================

-- ============================================================================
-- STEP 1: Verify manager HAS restaurant_id in database
-- ============================================================================

SELECT '=== VERIFY: Manager has restaurant_id ===' as info;

SELECT 
  email,
  role,
  restaurant_id,
  full_name,
  CASE 
    WHEN restaurant_id IS NOT NULL THEN '✅ HAS restaurant_id (database is OK)'
    ELSE '❌ MISSING restaurant_id (run FIX_MANAGER_RESTAURANT_ID.sql first!)'
  END as status
FROM public.users
WHERE role = 'manager'
ORDER BY created_at DESC;

-- If restaurant_id is NULL above, STOP HERE and run FIX_MANAGER_RESTAURANT_ID.sql instead!
-- The fix below is ONLY for timing/race condition issues.

-- ============================================================================
-- STEP 2: Check if auth_activity_logs table exists (optional logging table)
-- ============================================================================

SELECT '=== CHECK: auth_activity_logs table ===' as info;

SELECT 
  table_name,
  CASE 
    WHEN table_name = 'auth_activity_logs' THEN '✅ Table exists'
    ELSE 'Table not found'
  END as status
FROM information_schema.tables
WHERE table_schema = 'public'
AND table_name = 'auth_activity_logs';

-- ============================================================================
-- STEP 3: Create auth_activity_logs table if missing (prevents 401 errors)
-- ============================================================================

CREATE TABLE IF NOT EXISTS public.auth_activity_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  action VARCHAR(100) NOT NULL,
  ip_address VARCHAR(45),
  user_agent TEXT,
  metadata JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_auth_activity_logs_user_id 
ON public.auth_activity_logs(user_id);

CREATE INDEX IF NOT EXISTS idx_auth_activity_logs_created_at 
ON public.auth_activity_logs(created_at DESC);

-- Enable RLS
ALTER TABLE public.auth_activity_logs ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist (idempotent)
DROP POLICY IF EXISTS "users_select_own_logs" ON public.auth_activity_logs;
DROP POLICY IF EXISTS "system_insert_logs" ON public.auth_activity_logs;
DROP POLICY IF EXISTS "owners_select_all_logs" ON public.auth_activity_logs;

-- Policy: Users can only see their own logs
CREATE POLICY "users_select_own_logs" ON public.auth_activity_logs
  FOR SELECT TO authenticated
  USING (user_id = auth.uid());

-- Policy: System can insert logs (for ProtectedRoute.jsx)
CREATE POLICY "system_insert_logs" ON public.auth_activity_logs
  FOR INSERT TO authenticated
  WITH CHECK (true);

-- Policy: Owners can see all logs
CREATE POLICY "owners_select_all_logs" ON public.auth_activity_logs
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.users
      WHERE id = auth.uid()
      AND is_owner = true
    )
  );

SELECT '✅ auth_activity_logs table created/verified (policies recreated)' as status;

-- ============================================================================
-- ROOT CAUSE EXPLANATION
-- ============================================================================

/*

THE PROBLEM:

When manager logs in:
1. ✅ StaffLogin.jsx calls hydrateRestaurantContext(userId)
2. ✅ Saves to localStorage: praahis_restaurant_ctx
3. ✅ Navigates to /manager/dashboard
4. ❌ ProtectedRoute runs BEFORE RestaurantContext finishes loading
5. ❌ restaurantId is still null (loading state)
6. ❌ Shows "Restaurant context is missing"
7. ✅ On page reload, context loads from localStorage BEFORE navigation

SEQUENCE DIAGRAM:

LOGIN:
Login → hydrateContext → navigate(/manager/dashboard) → ProtectedRoute checks
                                                          ↓
                                                   restaurantId = null (loading!)
                                                          ↓
                                                   ERROR: "context missing"

RELOAD:
Page load → RestaurantContext loads from localStorage → ProtectedRoute checks
                                                          ↓
                                                   restaurantId = [UUID] ✅
                                                          ↓
                                                   SUCCESS: Dashboard renders

THE FIX:

We need to modify ProtectedRoute.jsx to wait for restaurantLoading = false
before showing the error. Currently it shows error immediately if restaurantId is null.

*/

-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================

-- Check if manager has valid restaurant assignment
SELECT '=== FINAL VERIFICATION ===' as info;

SELECT 
  u.email,
  u.role,
  u.restaurant_id,
  r.name as restaurant_name,
  r.is_active as restaurant_active,
  u.is_active as user_active,
  CASE 
    WHEN u.restaurant_id IS NULL THEN '❌ FAIL: No restaurant_id'
    WHEN r.id IS NULL THEN '❌ FAIL: Restaurant not found'
    WHEN NOT r.is_active THEN '⚠️ WARNING: Restaurant inactive'
    WHEN NOT u.is_active THEN '⚠️ WARNING: User inactive'
    ELSE '✅ PASS: All checks OK'
  END as final_status
FROM public.users u
LEFT JOIN restaurants r ON u.restaurant_id = r.id
WHERE u.role = 'manager'
ORDER BY u.created_at DESC;

-- ============================================================================
-- NEXT STEPS (CODE FIX REQUIRED)
-- ============================================================================

/*

This is a CODE issue, not a DATABASE issue!

You need to modify: src/shared/guards/ProtectedRoute.jsx

CURRENT CODE (BUGGY):
```javascript
// Restaurant context must be set
if (!restaurantId) {
  setValidationError('no_restaurant_context');
  // Shows error immediately even if still loading!
  return;
}
```

FIXED CODE:
```javascript
// Wait for restaurant context to finish loading
if (restaurantLoading) {
  return; // Still loading, don't validate yet
}

// Restaurant context must be set (after loading complete)
if (!restaurantId) {
  setValidationError('no_restaurant_context');
  return;
}
```

OR BETTER: Add a small delay after login before redirect:

In StaffLogin.jsx, change:
```javascript
await hydrateRestaurantContext(userId);
toast.success('Login successful!');
navigate('/manager/dashboard', { replace: true });
```

To:
```javascript
await hydrateRestaurantContext(userId);
toast.success('Login successful!');

// Wait for context to propagate
await new Promise(resolve => setTimeout(resolve, 300));

navigate('/manager/dashboard', { replace: true });
```

*/

-- ============================================================================
-- SUMMARY
-- ============================================================================
-- ✅ Created/verified auth_activity_logs table (prevents 401 errors)
-- ✅ Verified manager has restaurant_id in database
-- ⚠️ CODE FIX NEEDED: Modify ProtectedRoute.jsx or StaffLogin.jsx
-- 
-- The SQL fix is complete. Now you need to apply the code fix above.
-- ============================================================================
