-- ============================================================================
-- ITEM RATING SUMMARY VIEWS
-- ============================================================================
-- Creates helper views to expose avg_rating and total_ratings for menu items
-- Run after 06_item_ratings.sql
-- ==========================================================================

-- Simple aggregate view per menu item
CREATE OR REPLACE VIEW menu_item_ratings_summary AS
SELECT
	mir.menu_item_id,
	COUNT(*)::INT AS total_ratings,
	ROUND(AVG(mir.rating)::numeric, 2) AS avg_rating
FROM menu_item_ratings mir
GROUP BY mir.menu_item_id;

COMMENT ON VIEW menu_item_ratings_summary IS 'Aggregated ratings per menu item (avg + count)';

-- Convenience view: menu items with ratings (adds avg_rating, total_ratings)
CREATE OR REPLACE VIEW menu_items_with_ratings AS
SELECT
	mi.*,
	COALESCE(s.avg_rating, 0) AS avg_rating,
	COALESCE(s.total_ratings, 0) AS total_ratings
FROM menu_items mi
LEFT JOIN menu_item_ratings_summary s ON s.menu_item_id = mi.id;

COMMENT ON VIEW menu_items_with_ratings IS 'Menu items enriched with avg_rating and total_ratings';

-- Permissions for views (RLS on base tables still enforced)
GRANT SELECT ON menu_item_ratings_summary TO anon, authenticated;
GRANT SELECT ON menu_items_with_ratings TO anon, authenticated;

-- Verify
SELECT table_name, view_definition IS NOT NULL AS is_view
FROM information_schema.views
WHERE table_schema = 'public' AND table_name IN ('menu_item_ratings_summary','menu_items_with_ratings');

