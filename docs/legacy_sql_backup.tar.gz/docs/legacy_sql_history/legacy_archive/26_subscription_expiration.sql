-- ============================================================================
-- SUBSCRIPTION EXPIRATION & AUTO-DEACTIVATION
-- ============================================================================
-- Version: 1.0
-- Created: November 6, 2025
-- Description: Automatic trial expiration and restaurant deactivation
-- Run after: 23_superadmin_schema.sql
-- ============================================================================

-- ============================================================================
-- HELPER FUNCTIONS
-- ============================================================================

-- Function to check if a subscription has expired
CREATE OR REPLACE FUNCTION is_subscription_expired(subscription_id UUID)
RETURNS BOOLEAN AS $$
DECLARE
    sub_record RECORD;
BEGIN
    SELECT 
        status,
        current_period_end,
        trial_ends_at,
        plan_name
    INTO sub_record
    FROM subscriptions
    WHERE id = subscription_id;
    
    -- If subscription doesn't exist, consider it expired
    IF NOT FOUND THEN
        RETURN TRUE;
    END IF;
    
    -- Active paid subscriptions are never expired
    IF sub_record.status = 'active' AND sub_record.plan_name != 'trial' THEN
        RETURN FALSE;
    END IF;
    
    -- Check trial expiration
    IF sub_record.plan_name = 'trial' AND sub_record.trial_ends_at IS NOT NULL THEN
        RETURN sub_record.trial_ends_at < NOW();
    END IF;
    
    -- Check current period end
    IF sub_record.current_period_end < NOW() THEN
        RETURN TRUE;
    END IF;
    
    RETURN FALSE;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER;

COMMENT ON FUNCTION is_subscription_expired IS 'Check if a subscription has expired';

-- ============================================================================
-- Function to deactivate expired trial restaurants
CREATE OR REPLACE FUNCTION deactivate_expired_trials()
RETURNS TABLE(
    restaurant_id UUID,
    restaurant_name VARCHAR,
    subscription_id UUID,
    expired_at TIMESTAMP WITH TIME ZONE,
    action VARCHAR
) AS $$
BEGIN
    RETURN QUERY
    WITH expired_subs AS (
        SELECT 
            s.id as sub_id,
            s.restaurant_id as rest_id,
            r.name as rest_name,
            COALESCE(s.trial_ends_at, s.current_period_end) as expiry_date
        FROM subscriptions s
        JOIN restaurants r ON r.id = s.restaurant_id
        WHERE 
            s.plan_name = 'trial'
            AND s.status = 'active'
            AND (
                (s.trial_ends_at IS NOT NULL AND s.trial_ends_at < NOW())
                OR 
                (s.trial_ends_at IS NULL AND s.current_period_end < NOW())
            )
            AND r.is_active = true
    ),
    updated_restaurants AS (
        UPDATE restaurants r
        SET is_active = false
        FROM expired_subs es
        WHERE r.id = es.rest_id
        RETURNING r.id
    ),
    updated_subscriptions AS (
        UPDATE subscriptions s
        SET 
            status = 'expired',
            cancelled_at = NOW()
        FROM expired_subs es
        WHERE s.id = es.sub_id
        RETURNING s.id
    )
    SELECT 
        es.rest_id,
        es.rest_name,
        es.sub_id,
        es.expiry_date,
        'deactivated'::VARCHAR
    FROM expired_subs es;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION deactivate_expired_trials IS 'Deactivate restaurants with expired trial subscriptions';

-- ============================================================================
-- Function to get restaurants expiring soon
CREATE OR REPLACE FUNCTION get_expiring_soon_restaurants(days_ahead INTEGER DEFAULT 3)
RETURNS TABLE(
    restaurant_id UUID,
    restaurant_name VARCHAR,
    restaurant_email VARCHAR,
    subscription_plan VARCHAR,
    expires_at TIMESTAMP WITH TIME ZONE,
    days_remaining INTEGER
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        r.id,
        r.name,
        (SELECT email FROM users WHERE restaurant_id = r.id AND role = 'admin' LIMIT 1) as email,
        s.plan_name,
        COALESCE(s.trial_ends_at, s.current_period_end) as expiry,
        EXTRACT(DAY FROM COALESCE(s.trial_ends_at, s.current_period_end) - NOW())::INTEGER as days_left
    FROM subscriptions s
    JOIN restaurants r ON r.id = s.restaurant_id
    WHERE 
        s.status = 'active'
        AND r.is_active = true
        AND COALESCE(s.trial_ends_at, s.current_period_end) BETWEEN NOW() AND NOW() + (days_ahead || ' days')::INTERVAL
    ORDER BY COALESCE(s.trial_ends_at, s.current_period_end) ASC;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER;

COMMENT ON FUNCTION get_expiring_soon_restaurants IS 'Get list of restaurants whose subscriptions are expiring soon';

-- ============================================================================
-- Function to extend trial period (manual override)
CREATE OR REPLACE FUNCTION extend_trial_period(
    p_restaurant_id UUID,
    p_days INTEGER DEFAULT 14
)
RETURNS JSONB AS $$
DECLARE
    v_subscription_id UUID;
    v_new_expiry TIMESTAMP WITH TIME ZONE;
    v_result JSONB;
BEGIN
    -- Get active subscription
    SELECT id INTO v_subscription_id
    FROM subscriptions
    WHERE restaurant_id = p_restaurant_id
    AND status = 'active'
    LIMIT 1;
    
    IF v_subscription_id IS NULL THEN
        RETURN jsonb_build_object(
            'success', false,
            'message', 'No active subscription found for this restaurant'
        );
    END IF;
    
    -- Calculate new expiry date
    v_new_expiry := NOW() + (p_days || ' days')::INTERVAL;
    
    -- Update subscription
    UPDATE subscriptions
    SET 
        trial_ends_at = v_new_expiry,
        current_period_end = v_new_expiry,
        status = 'trial',
        metadata = COALESCE(metadata, '{}'::JSONB) || jsonb_build_object(
            'trial_extended', true,
            'extended_at', NOW(),
            'extended_days', p_days
        )
    WHERE id = v_subscription_id;
    
    -- Reactivate restaurant if needed
    UPDATE restaurants
    SET is_active = true
    WHERE id = p_restaurant_id;
    
    RETURN jsonb_build_object(
        'success', true,
        'message', 'Trial period extended successfully',
        'new_expiry', v_new_expiry,
        'days_added', p_days
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION extend_trial_period IS 'Extend trial period for a restaurant (owner only)';

-- ============================================================================
-- Function to check and update subscription status (can be called on login)
CREATE OR REPLACE FUNCTION check_subscription_status(p_restaurant_id UUID)
RETURNS JSONB AS $$
DECLARE
    v_subscription RECORD;
    v_is_expired BOOLEAN;
    v_result JSONB;
BEGIN
    -- Get subscription details
    SELECT 
        s.*,
        COALESCE(s.trial_ends_at, s.current_period_end) as expiry_date
    INTO v_subscription
    FROM subscriptions s
    WHERE s.restaurant_id = p_restaurant_id
    AND s.status IN ('active', 'trial')
    ORDER BY s.created_at DESC
    LIMIT 1;
    
    -- No subscription found
    IF NOT FOUND THEN
        -- Deactivate restaurant
        UPDATE restaurants SET is_active = false WHERE id = p_restaurant_id;
        
        RETURN jsonb_build_object(
            'is_active', false,
            'status', 'no_subscription',
            'message', 'No active subscription found. Please contact support.',
            'can_login', false
        );
    END IF;
    
    -- Check if expired
    v_is_expired := v_subscription.expiry_date < NOW();
    
    IF v_is_expired THEN
        -- Update subscription status
        UPDATE subscriptions
        SET 
            status = 'expired',
            cancelled_at = NOW()
        WHERE id = v_subscription.id;
        
        -- Deactivate restaurant
        UPDATE restaurants
        SET is_active = false
        WHERE id = p_restaurant_id;
        
        RETURN jsonb_build_object(
            'is_active', false,
            'status', 'expired',
            'expired_at', v_subscription.expiry_date,
            'plan', v_subscription.plan_name,
            'message', 'Your subscription has expired. Please upgrade to continue.',
            'can_login', false
        );
    ELSE
        -- Subscription is active
        RETURN jsonb_build_object(
            'is_active', true,
            'status', v_subscription.status,
            'plan', v_subscription.plan_name,
            'expires_at', v_subscription.expiry_date,
            'days_remaining', EXTRACT(DAY FROM v_subscription.expiry_date - NOW()),
            'can_login', true
        );
    END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION check_subscription_status IS 'Check and update subscription status for a restaurant';

-- ============================================================================
-- SCHEDULED JOBS (PostgreSQL cron extension required)
-- ============================================================================

-- Note: Requires pg_cron extension
-- Install: CREATE EXTENSION IF NOT EXISTS pg_cron;

-- Schedule daily check at 2 AM UTC
-- Run this in Supabase SQL Editor after enabling pg_cron:
/*
SELECT cron.schedule(
    'deactivate-expired-trials',           -- Job name
    '0 2 * * *',                           -- Daily at 2 AM UTC (cron format)
    $$ SELECT deactivate_expired_trials(); $$
);
*/

-- Schedule notification check at 10 AM UTC (3 days before expiry)
/*
SELECT cron.schedule(
    'notify-expiring-subscriptions',
    '0 10 * * *',
    $$ 
    INSERT INTO system_logs (level, source, message, details)
    SELECT 
        'info',
        'subscription',
        'Restaurant trial expiring soon',
        jsonb_build_object(
            'restaurant_id', restaurant_id,
            'restaurant_name', restaurant_name,
            'expires_at', expires_at,
            'days_remaining', days_remaining
        )
    FROM get_expiring_soon_restaurants(3);
    $$
);
*/

-- ============================================================================
-- GRACE PERIOD CONFIGURATION
-- ============================================================================

-- Add grace period setting (days after expiry before deactivation)
INSERT INTO platform_settings (key, value, category, description)
VALUES
    ('trial_grace_period_days', '0', 'subscription', 'Days of grace period after trial expiry before deactivation'),
    ('send_expiry_warnings', 'true', 'subscription', 'Send email warnings before subscription expiry'),
    ('warning_days_before_expiry', '[7, 3, 1]', 'subscription', 'Days before expiry to send warnings'),
    ('auto_deactivate_expired', 'true', 'subscription', 'Automatically deactivate expired subscriptions')
ON CONFLICT (key) DO NOTHING;

-- ============================================================================
-- UPDATE SUBSCRIPTIONS TABLE
-- ============================================================================

-- Add grace_period_end column
ALTER TABLE subscriptions
    ADD COLUMN IF NOT EXISTS grace_period_end TIMESTAMP WITH TIME ZONE;

COMMENT ON COLUMN subscriptions.grace_period_end IS 'End of grace period after subscription expiry';

-- ============================================================================
-- TRIGGER: Auto-calculate grace period
-- ============================================================================

CREATE OR REPLACE FUNCTION calculate_grace_period()
RETURNS TRIGGER AS $$
DECLARE
    grace_days INTEGER;
BEGIN
    -- Get grace period from settings (default 0)
    SELECT COALESCE((value::INTEGER), 0) INTO grace_days
    FROM platform_settings
    WHERE key = 'trial_grace_period_days';
    
    -- Calculate grace period end
    IF NEW.plan_name = 'trial' THEN
        NEW.grace_period_end := COALESCE(NEW.trial_ends_at, NEW.current_period_end) + (grace_days || ' days')::INTERVAL;
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS set_grace_period ON subscriptions;
CREATE TRIGGER set_grace_period
    BEFORE INSERT OR UPDATE ON subscriptions
    FOR EACH ROW
    EXECUTE FUNCTION calculate_grace_period();

-- ============================================================================
-- VIEWS FOR MONITORING
-- ============================================================================

-- View: Active trials with expiry info
CREATE OR REPLACE VIEW active_trials AS
SELECT 
    r.id as restaurant_id,
    r.name as restaurant_name,
    r.slug,
    r.is_active,
    s.id as subscription_id,
    s.status as subscription_status,
    s.created_at as trial_started,
    COALESCE(s.trial_ends_at, s.current_period_end) as expires_at,
    s.grace_period_end,
    EXTRACT(DAY FROM COALESCE(s.trial_ends_at, s.current_period_end) - NOW())::INTEGER as days_remaining,
    CASE 
        WHEN COALESCE(s.trial_ends_at, s.current_period_end) < NOW() THEN 'expired'
        WHEN COALESCE(s.trial_ends_at, s.current_period_end) < NOW() + INTERVAL '3 days' THEN 'expiring_soon'
        ELSE 'active'
    END as trial_status
FROM restaurants r
JOIN subscriptions s ON s.restaurant_id = r.id
WHERE s.plan_name = 'trial'
AND s.status IN ('active', 'trial')
ORDER BY expires_at ASC;

COMMENT ON VIEW active_trials IS 'View of all active trial subscriptions with expiry information';

-- ============================================================================
-- VERIFICATION & TESTING
-- ============================================================================

DO $$
BEGIN
    RAISE NOTICE '===========================================';
    RAISE NOTICE 'Subscription Expiration System Installed';
    RAISE NOTICE '===========================================';
    RAISE NOTICE '';
    RAISE NOTICE 'Functions created:';
    RAISE NOTICE '  ✓ is_subscription_expired()';
    RAISE NOTICE '  ✓ deactivate_expired_trials()';
    RAISE NOTICE '  ✓ get_expiring_soon_restaurants()';
    RAISE NOTICE '  ✓ extend_trial_period()';
    RAISE NOTICE '  ✓ check_subscription_status()';
    RAISE NOTICE '';
    RAISE NOTICE 'Views created:';
    RAISE NOTICE '  ✓ active_trials';
    RAISE NOTICE '';
    RAISE NOTICE 'Settings added:';
    RAISE NOTICE '  ✓ trial_grace_period_days';
    RAISE NOTICE '  ✓ send_expiry_warnings';
    RAISE NOTICE '  ✓ warning_days_before_expiry';
    RAISE NOTICE '  ✓ auto_deactivate_expired';
    RAISE NOTICE '';
    RAISE NOTICE 'Next steps:';
    RAISE NOTICE '  1. Enable pg_cron extension (if not enabled)';
    RAISE NOTICE '  2. Schedule cron jobs (see comments in SQL)';
    RAISE NOTICE '  3. Integrate check_subscription_status() in login flow';
    RAISE NOTICE '  4. Set up email notifications';
    RAISE NOTICE '';
END $$;

-- ============================================================================
-- TESTING QUERIES
-- ============================================================================

-- Test: View all active trials
-- SELECT * FROM active_trials;

-- Test: Check expiring soon (next 7 days)
-- SELECT * FROM get_expiring_soon_restaurants(7);

-- Test: Manually deactivate expired trials
-- SELECT * FROM deactivate_expired_trials();

-- Test: Check subscription status for a restaurant
-- SELECT check_subscription_status('<restaurant-id>');

-- Test: Extend trial period
-- SELECT extend_trial_period('<restaurant-id>', 14);

-- ============================================================================
-- END OF SUBSCRIPTION EXPIRATION SYSTEM
-- ============================================================================
