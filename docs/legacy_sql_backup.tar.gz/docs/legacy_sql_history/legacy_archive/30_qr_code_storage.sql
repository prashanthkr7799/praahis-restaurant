-- Migration: Setup QR Code Storage Bucket with RLS Policies
-- Date: November 16, 2025
-- Description: Create storage bucket for QR codes and configure RLS policies

-- Create QR codes storage bucket (public read access)
INSERT INTO storage.buckets (id, name, public)
VALUES ('qr-codes', 'qr-codes', true)
ON CONFLICT (id) DO NOTHING;

-- Drop existing policies if they exist (to avoid conflicts)
DROP POLICY IF EXISTS "Managers can upload QR codes for their restaurant" ON storage.objects;
DROP POLICY IF EXISTS "Public can view QR codes" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can view QR codes" ON storage.objects;
DROP POLICY IF EXISTS "Managers can delete their restaurant QR codes" ON storage.objects;
DROP POLICY IF EXISTS "Managers can update their restaurant QR codes" ON storage.objects;

-- Policy: Allow managers to upload QR codes for their restaurant
CREATE POLICY "Managers can upload QR codes for their restaurant"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'qr-codes' AND
  (storage.foldername(name))[1] = (
    SELECT restaurant_id::text 
    FROM users 
    WHERE id = auth.uid()
    AND role = 'manager'
  )
);

-- Policy: Public can view QR codes (required for customers scanning)
CREATE POLICY "Public can view QR codes"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'qr-codes');

-- Policy: Authenticated users can view QR codes too
CREATE POLICY "Authenticated users can view QR codes"
ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'qr-codes');

-- Policy: Managers can delete their restaurant's QR codes
CREATE POLICY "Managers can delete their restaurant QR codes"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'qr-codes' AND
  (storage.foldername(name))[1] = (
    SELECT restaurant_id::text 
    FROM users 
    WHERE id = auth.uid()
    AND role = 'manager'
  )
);

-- Policy: Managers can update/replace their restaurant's QR codes
CREATE POLICY "Managers can update their restaurant QR codes"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'qr-codes' AND
  (storage.foldername(name))[1] = (
    SELECT restaurant_id::text 
    FROM users 
    WHERE id = auth.uid()
    AND role = 'manager'
  )
);
