-- ============================================================================
-- MULTI-TENANT RAZORPAY INTEGRATION
-- ============================================================================
-- This migration adds Razorpay payment gateway credentials per restaurant
-- allowing each restaurant to receive payments to their own Razorpay account
-- ============================================================================

-- Add Razorpay credentials columns to restaurants table
ALTER TABLE restaurants 
ADD COLUMN IF NOT EXISTS razorpay_key_id VARCHAR(255),
ADD COLUMN IF NOT EXISTS razorpay_key_secret VARCHAR(255),
ADD COLUMN IF NOT EXISTS razorpay_webhook_secret VARCHAR(255),
ADD COLUMN IF NOT EXISTS payment_gateway_enabled BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS payment_settings JSONB DEFAULT '{}'::jsonb;

COMMENT ON COLUMN restaurants.razorpay_key_id IS 'Razorpay API Key ID for this restaurant';
COMMENT ON COLUMN restaurants.razorpay_key_secret IS 'Razorpay API Key Secret (encrypted) for this restaurant';
COMMENT ON COLUMN restaurants.razorpay_webhook_secret IS 'Razorpay Webhook Secret for payment verification';
COMMENT ON COLUMN restaurants.payment_gateway_enabled IS 'Whether payment gateway is configured and active';
COMMENT ON COLUMN restaurants.payment_settings IS 'Additional payment configuration like currency, accepted methods, etc.';

-- ============================================================================
-- RLS POLICIES FOR PAYMENT CREDENTIALS
-- ============================================================================
-- Only restaurant owners and managers can view their payment credentials
-- Superadmins can view all credentials for support purposes

-- Drop existing policies if they exist (for re-running)
DROP POLICY IF EXISTS "Restaurant owners can view their payment credentials" ON restaurants;
DROP POLICY IF EXISTS "Restaurant owners can update their payment credentials" ON restaurants;
DROP POLICY IF EXISTS "Superadmins can manage all payment credentials" ON restaurants;

-- Restaurant owners/managers can view their own payment credentials
CREATE POLICY "Restaurant owners can view their payment credentials"
ON restaurants
FOR SELECT
USING (
  id IN (
    SELECT restaurant_id 
    FROM users 
    WHERE users.id = auth.uid() 
    AND role IN ('owner', 'manager', 'admin')
  )
);

-- Restaurant owners/managers can update their own payment credentials
CREATE POLICY "Restaurant owners can update their payment credentials"
ON restaurants
FOR UPDATE
USING (
  id IN (
    SELECT restaurant_id 
    FROM users 
    WHERE users.id = auth.uid() 
    AND role IN ('owner', 'manager', 'admin')
  )
)
WITH CHECK (
  id IN (
    SELECT restaurant_id 
    FROM users 
    WHERE users.id = auth.uid() 
    AND role IN ('owner', 'manager', 'admin')
  )
);

-- Superadmins can view and manage all payment credentials
CREATE POLICY "Superadmins can manage all payment credentials"
ON restaurants
FOR ALL
USING (
  is_superadmin(auth.uid())
);

-- ============================================================================
-- HELPER FUNCTION: GET RESTAURANT PAYMENT CONFIG
-- ============================================================================
-- Function to safely retrieve payment configuration for a restaurant
-- This can be called by backend/edge functions

CREATE OR REPLACE FUNCTION get_restaurant_payment_config(restaurant_uuid UUID)
RETURNS TABLE (
  razorpay_key_id VARCHAR(255),
  payment_gateway_enabled BOOLEAN,
  payment_settings JSONB
) 
SECURITY DEFINER
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    r.razorpay_key_id,
    r.payment_gateway_enabled,
    r.payment_settings
  FROM restaurants r
  WHERE r.id = restaurant_uuid
  AND r.is_active = true
  AND r.payment_gateway_enabled = true;
END;
$$;

COMMENT ON FUNCTION get_restaurant_payment_config IS 'Safely retrieve payment configuration without exposing secrets';

-- ============================================================================
-- VALIDATION FUNCTION: CHECK RAZORPAY CREDENTIALS FORMAT
-- ============================================================================
-- Validates that Razorpay credentials are in correct format

CREATE OR REPLACE FUNCTION validate_razorpay_credentials()
RETURNS TRIGGER AS $$
BEGIN
  -- Validate Key ID format (starts with rzp_test_ or rzp_live_)
  IF NEW.razorpay_key_id IS NOT NULL THEN
    IF NOT (NEW.razorpay_key_id ~ '^rzp_(test|live)_[A-Za-z0-9]+$') THEN
      RAISE EXCEPTION 'Invalid Razorpay Key ID format. Must start with rzp_test_ or rzp_live_';
    END IF;
  END IF;

  -- Validate Key Secret format (starts with same as key_id)
  IF NEW.razorpay_key_secret IS NOT NULL THEN
    IF NOT (NEW.razorpay_key_secret ~ '^[A-Za-z0-9]+$') THEN
      RAISE EXCEPTION 'Invalid Razorpay Key Secret format';
    END IF;
  END IF;

  -- If credentials are provided, enable payment gateway
  IF NEW.razorpay_key_id IS NOT NULL AND NEW.razorpay_key_secret IS NOT NULL THEN
    NEW.payment_gateway_enabled := true;
  ELSE
    NEW.payment_gateway_enabled := false;
  END IF;

  -- Set default payment settings if not provided
  IF NEW.payment_settings IS NULL OR NEW.payment_settings = '{}'::jsonb THEN
    NEW.payment_settings := jsonb_build_object(
      'currency', 'INR',
      'accepted_methods', jsonb_build_array('card', 'netbanking', 'wallet', 'upi'),
      'auto_capture', true,
      'retry_enabled', false
    );
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for validation
DROP TRIGGER IF EXISTS validate_razorpay_credentials_trigger ON restaurants;
CREATE TRIGGER validate_razorpay_credentials_trigger
BEFORE INSERT OR UPDATE OF razorpay_key_id, razorpay_key_secret ON restaurants
FOR EACH ROW
EXECUTE FUNCTION validate_razorpay_credentials();

-- ============================================================================
-- AUDIT LOG FOR PAYMENT CREDENTIAL CHANGES
-- ============================================================================
-- Track when payment credentials are added/updated

CREATE TABLE IF NOT EXISTS payment_credential_audit (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  restaurant_id UUID REFERENCES restaurants(id) ON DELETE CASCADE,
  changed_by UUID REFERENCES auth.users(id),
  action VARCHAR(50) NOT NULL, -- 'added', 'updated', 'removed', 'verified'
  old_key_id VARCHAR(255),
  new_key_id VARCHAR(255),
  ip_address INET,
  user_agent TEXT,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

COMMENT ON TABLE payment_credential_audit IS 'Audit trail for payment credential changes';

-- Function to log credential changes
CREATE OR REPLACE FUNCTION log_payment_credential_change()
RETURNS TRIGGER AS $$
DECLARE
  change_action VARCHAR(50);
BEGIN
  IF TG_OP = 'INSERT' AND NEW.razorpay_key_id IS NOT NULL THEN
    change_action := 'added';
  ELSIF TG_OP = 'UPDATE' AND OLD.razorpay_key_id IS DISTINCT FROM NEW.razorpay_key_id THEN
    change_action := 'updated';
  ELSIF TG_OP = 'UPDATE' AND NEW.razorpay_key_id IS NULL AND OLD.razorpay_key_id IS NOT NULL THEN
    change_action := 'removed';
  ELSE
    RETURN NEW;
  END IF;

  INSERT INTO payment_credential_audit (
    restaurant_id,
    changed_by,
    action,
    old_key_id,
    new_key_id
  ) VALUES (
    NEW.id,
    auth.uid(),
    change_action,
    OLD.razorpay_key_id,
    NEW.razorpay_key_id
  );

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for audit logging
DROP TRIGGER IF EXISTS log_payment_credential_change_trigger ON restaurants;
CREATE TRIGGER log_payment_credential_change_trigger
AFTER INSERT OR UPDATE OF razorpay_key_id ON restaurants
FOR EACH ROW
EXECUTE FUNCTION log_payment_credential_change();

-- ============================================================================
-- INDEXES FOR PERFORMANCE
-- ============================================================================
CREATE INDEX IF NOT EXISTS idx_restaurants_payment_enabled 
ON restaurants(payment_gateway_enabled) 
WHERE payment_gateway_enabled = true;

CREATE INDEX IF NOT EXISTS idx_payment_credential_audit_restaurant 
ON payment_credential_audit(restaurant_id, created_at DESC);

-- ============================================================================
-- GRANT PERMISSIONS
-- ============================================================================
-- Allow authenticated users to read payment configs (with RLS)
GRANT SELECT ON restaurants TO authenticated;
GRANT UPDATE ON restaurants TO authenticated;

-- Allow service role full access for edge functions
GRANT ALL ON payment_credential_audit TO service_role;

-- ============================================================================
-- VERIFICATION
-- ============================================================================
-- Verify the migration
DO $$ 
BEGIN
  -- Check if columns were added
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'restaurants' 
    AND column_name = 'razorpay_key_id'
  ) THEN
    RAISE NOTICE '✓ Razorpay columns added to restaurants table';
  ELSE
    RAISE EXCEPTION '✗ Failed to add Razorpay columns';
  END IF;

  -- Check if audit table exists
  IF EXISTS (
    SELECT 1 FROM information_schema.tables 
    WHERE table_name = 'payment_credential_audit'
  ) THEN
    RAISE NOTICE '✓ Payment credential audit table created';
  ELSE
    RAISE EXCEPTION '✗ Failed to create audit table';
  END IF;

  RAISE NOTICE '✓ Multi-tenant Razorpay integration migration completed successfully';
END $$;
