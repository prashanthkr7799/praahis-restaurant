-- ============================================================================
-- Multi-Tenancy Migration (Safe, idempotent)
-- Ensures per-restaurant isolation with FK, indexes, and RLS policies.
-- Run order: after 01_schema.sql and 02_seed.sql
-- ============================================================================

-- 0) Helper: ensure uuid extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1) restaurants: ensure required columns and indexes
ALTER TABLE IF EXISTS public.restaurants
  ADD COLUMN IF NOT EXISTS slug TEXT,
  ADD COLUMN IF NOT EXISTS logo_url TEXT,
  ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT true,
  ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ DEFAULT NOW();

-- slug should be unique for routing
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE schemaname = 'public' AND indexname = 'idx_restaurants_slug_unique'
  ) THEN
    CREATE UNIQUE INDEX idx_restaurants_slug_unique ON public.restaurants((lower(slug)));
  END IF;
END$$;

-- 2) Ensure restaurant_id columns and FKs

-- 2.a) tables (already present in base schema): ensure FK and index
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'fk_tables_restaurant' 
      AND conrelid = 'public.tables'::regclass
  ) THEN
    ALTER TABLE public.tables
      ADD CONSTRAINT fk_tables_restaurant
        FOREIGN KEY (restaurant_id) REFERENCES public.restaurants(id) ON DELETE CASCADE;
  END IF;
END$$;
CREATE INDEX IF NOT EXISTS idx_tables_restaurant ON public.tables(restaurant_id);

-- 2.b) menu_items (already present): ensure FK and index
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'fk_menu_items_restaurant' 
      AND conrelid = 'public.menu_items'::regclass
  ) THEN
    ALTER TABLE public.menu_items
      ADD CONSTRAINT fk_menu_items_restaurant
        FOREIGN KEY (restaurant_id) REFERENCES public.restaurants(id) ON DELETE CASCADE;
  END IF;
END$$;
CREATE INDEX IF NOT EXISTS idx_menu_items_restaurant ON public.menu_items(restaurant_id);

-- 2.c) orders (already present): ensure FK and indexes
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'fk_orders_restaurant' 
      AND conrelid = 'public.orders'::regclass
  ) THEN
    ALTER TABLE public.orders
      ADD CONSTRAINT fk_orders_restaurant
        FOREIGN KEY (restaurant_id) REFERENCES public.restaurants(id) ON DELETE CASCADE;
  END IF;
END$$;
CREATE INDEX IF NOT EXISTS idx_orders_restaurant ON public.orders(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_orders_restaurant_created_at ON public.orders(restaurant_id, created_at DESC);

-- 2.d) payments: add restaurant_id, backfill from orders, add FK/index
ALTER TABLE IF EXISTS public.payments
  ADD COLUMN IF NOT EXISTS restaurant_id UUID;

-- Backfill payments.restaurant_id from parent order
UPDATE public.payments p
SET restaurant_id = o.restaurant_id
FROM public.orders o
WHERE p.order_id = o.id
  AND (p.restaurant_id IS NULL AND o.restaurant_id IS NOT NULL);

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'fk_payments_restaurant' 
      AND conrelid = 'public.payments'::regclass
  ) THEN
    ALTER TABLE public.payments
      ADD CONSTRAINT fk_payments_restaurant
        FOREIGN KEY (restaurant_id) REFERENCES public.restaurants(id) ON DELETE CASCADE;
  END IF;
END$$;
CREATE INDEX IF NOT EXISTS idx_payments_restaurant ON public.payments(restaurant_id);

-- 2.e) feedbacks: add restaurant_id, backfill from orders, add FK/indexes
ALTER TABLE IF EXISTS public.feedbacks
  ADD COLUMN IF NOT EXISTS restaurant_id UUID;

UPDATE public.feedbacks f
SET restaurant_id = o.restaurant_id
FROM public.orders o
WHERE f.order_id = o.id
  AND (f.restaurant_id IS NULL AND o.restaurant_id IS NOT NULL);

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'fk_feedbacks_restaurant' 
      AND conrelid = 'public.feedbacks'::regclass
  ) THEN
    ALTER TABLE public.feedbacks
      ADD CONSTRAINT fk_feedbacks_restaurant
        FOREIGN KEY (restaurant_id) REFERENCES public.restaurants(id) ON DELETE CASCADE;
  END IF;
END$$;
CREATE INDEX IF NOT EXISTS idx_feedbacks_restaurant ON public.feedbacks(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_feedbacks_restaurant_created_at ON public.feedbacks(restaurant_id, created_at DESC);

-- 2.f) users (staff): add restaurant_id if missing, add FK and index
ALTER TABLE IF EXISTS public.users
  ADD COLUMN IF NOT EXISTS restaurant_id UUID;

-- Also track last_login used by app code
ALTER TABLE IF EXISTS public.users
  ADD COLUMN IF NOT EXISTS last_login TIMESTAMPTZ;

-- Optional: if exactly one restaurant exists, auto-backfill users.restaurant_id
DO $$
DECLARE rcount INT;
DECLARE rid UUID;
BEGIN
  -- Count restaurants; if exactly one, backfill users.restaurant_id with that id
  SELECT COUNT(*) INTO rcount FROM public.restaurants;
  IF rcount = 1 THEN
    SELECT id INTO rid FROM public.restaurants LIMIT 1;
    UPDATE public.users SET restaurant_id = rid WHERE restaurant_id IS NULL;
  END IF;
END$$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'fk_users_restaurant' 
      AND conrelid = 'public.users'::regclass
  ) THEN
    ALTER TABLE public.users
      ADD CONSTRAINT fk_users_restaurant
        FOREIGN KEY (restaurant_id) REFERENCES public.restaurants(id) ON DELETE SET NULL;
  END IF;
END$$;
CREATE INDEX IF NOT EXISTS idx_users_restaurant ON public.users(restaurant_id);

-- 2.g) offers: create if missing, or just ensure restaurant_id
CREATE TABLE IF NOT EXISTS public.offers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  restaurant_id UUID REFERENCES public.restaurants(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  discount_percent NUMERIC(5,2) CHECK (discount_percent >= 0 AND discount_percent <= 100),
  is_active BOOLEAN DEFAULT true,
  starts_at TIMESTAMPTZ,
  ends_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_offers_restaurant ON public.offers(restaurant_id);

-- 2.h) activity_logs: create if missing, include restaurant_id
CREATE TABLE IF NOT EXISTS public.activity_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES public.users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  entity_type TEXT,
  entity_id UUID,
  details JSONB,
  ip_address INET,
  user_agent TEXT,
  restaurant_id UUID REFERENCES public.restaurants(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_activity_logs_restaurant ON public.activity_logs(restaurant_id);
CREATE INDEX IF NOT EXISTS idx_activity_logs_user ON public.activity_logs(user_id);

-- 3) RLS Policies (Supabase)

-- Helper policy predicate: staff has same restaurant
-- We will inline EXISTS checks in each policy for portability.

-- Deprecated helper (auth_user_restaurant_id) removed to avoid recursion and
-- syntax issues when declaring CREATE FUNCTION inside DO/IF blocks. We will
-- use self-only users policies instead, set up further below.

-- Enable RLS
ALTER TABLE public.restaurants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tables ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.menu_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.offers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.feedbacks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.activity_logs ENABLE ROW LEVEL SECURITY;

-- Drop existing policies with same names to be idempotent
DO $$
BEGIN
  -- restaurants
  IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='restaurants' AND policyname='restaurant_read_own') THEN
    DROP POLICY restaurant_read_own ON public.restaurants;
  END IF;
  -- tables
  IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='tables' AND policyname='tables_rw_own') THEN
    DROP POLICY tables_rw_own ON public.tables;
  END IF;
  IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='tables' AND policyname='tables_read_own') THEN
    DROP POLICY tables_read_own ON public.tables;
  END IF;
  -- menu_items
  IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='menu_items' AND policyname='menu_items_rw_own') THEN
    DROP POLICY menu_items_rw_own ON public.menu_items;
  END IF;
  IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='menu_items' AND policyname='menu_items_read_own') THEN
    DROP POLICY menu_items_read_own ON public.menu_items;
  END IF;
  -- orders
  IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='orders' AND policyname='orders_read_own') THEN
    DROP POLICY orders_read_own ON public.orders;
  END IF;
  IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='orders' AND policyname='orders_rw_own') THEN
    DROP POLICY orders_rw_own ON public.orders;
  END IF;
  -- payments
  IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='payments' AND policyname='payments_rw_own') THEN
    DROP POLICY payments_rw_own ON public.payments;
  END IF;
  IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='payments' AND policyname='payments_read_own') THEN
    DROP POLICY payments_read_own ON public.payments;
  END IF;
  -- offers
  IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='offers' AND policyname='offers_rw_own') THEN
    DROP POLICY offers_rw_own ON public.offers;
  END IF;
  IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='offers' AND policyname='offers_read_own') THEN
    DROP POLICY offers_read_own ON public.offers;
  END IF;
  -- feedbacks
  IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='feedbacks' AND policyname='feedbacks_rw_own') THEN
    DROP POLICY feedbacks_rw_own ON public.feedbacks;
  END IF;
  IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='feedbacks' AND policyname='feedbacks_read_own') THEN
    DROP POLICY feedbacks_read_own ON public.feedbacks;
  END IF;
  -- users
  IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='users' AND policyname='users_read_own_restaurant') THEN
    DROP POLICY users_read_own_restaurant ON public.users;
  END IF;
  IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='users' AND policyname='users_rw_own_restaurant') THEN
    DROP POLICY users_rw_own_restaurant ON public.users;
  END IF;
  IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='users' AND policyname='users_self_select') THEN
    DROP POLICY users_self_select ON public.users;
  END IF;
  IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='users' AND policyname='users_self_update') THEN
    DROP POLICY users_self_update ON public.users;
  END IF;
  -- activity_logs
  IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='activity_logs' AND policyname='activity_logs_rw_own') THEN
    DROP POLICY activity_logs_rw_own ON public.activity_logs;
  END IF;
  IF EXISTS (SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='activity_logs' AND policyname='activity_logs_read_own') THEN
    DROP POLICY activity_logs_read_own ON public.activity_logs;
  END IF;
END$$;

-- restaurants: staff can read their own restaurant
CREATE POLICY restaurant_read_own ON public.restaurants
FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users u
    WHERE u.id = auth.uid() AND u.restaurant_id = restaurants.id
  )
);

-- tables policies
CREATE POLICY tables_read_own ON public.tables
FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users u
    WHERE u.id = auth.uid() AND u.restaurant_id = tables.restaurant_id
  )
);

CREATE POLICY tables_rw_own ON public.tables
FOR ALL TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users u
    WHERE u.id = auth.uid() AND u.restaurant_id = tables.restaurant_id
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.users u
    WHERE u.id = auth.uid() AND u.restaurant_id = tables.restaurant_id
  )
);

-- menu_items policies
CREATE POLICY menu_items_read_own ON public.menu_items
FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users u
    WHERE u.id = auth.uid() AND u.restaurant_id = menu_items.restaurant_id
  )
);

CREATE POLICY menu_items_rw_own ON public.menu_items
FOR ALL TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users u
    WHERE u.id = auth.uid() AND u.restaurant_id = menu_items.restaurant_id
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.users u
    WHERE u.id = auth.uid() AND u.restaurant_id = menu_items.restaurant_id
  )
);

-- orders policies (read/update by staff of same restaurant)
CREATE POLICY orders_read_own ON public.orders
FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users u
    WHERE u.id = auth.uid() AND u.restaurant_id = orders.restaurant_id
  )
);

CREATE POLICY orders_rw_own ON public.orders
FOR ALL TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users u
    WHERE u.id = auth.uid() AND u.restaurant_id = orders.restaurant_id
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.users u
    WHERE u.id = auth.uid() AND u.restaurant_id = orders.restaurant_id
  )
);

-- payments
CREATE POLICY payments_read_own ON public.payments
FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users u
    WHERE u.id = auth.uid() AND u.restaurant_id = payments.restaurant_id
  )
);

CREATE POLICY payments_rw_own ON public.payments
FOR ALL TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users u
    WHERE u.id = auth.uid() AND u.restaurant_id = payments.restaurant_id
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.users u
    WHERE u.id = auth.uid() AND u.restaurant_id = payments.restaurant_id
  )
);

-- offers
CREATE POLICY offers_read_own ON public.offers
FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users u
    WHERE u.id = auth.uid() AND u.restaurant_id = offers.restaurant_id
  )
);

CREATE POLICY offers_rw_own ON public.offers
FOR ALL TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users u
    WHERE u.id = auth.uid() AND u.restaurant_id = offers.restaurant_id
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.users u
    WHERE u.id = auth.uid() AND u.restaurant_id = offers.restaurant_id
  )
);

-- feedbacks
CREATE POLICY feedbacks_read_own ON public.feedbacks
FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users u
    WHERE u.id = auth.uid() AND u.restaurant_id = feedbacks.restaurant_id
  )
);

CREATE POLICY feedbacks_rw_own ON public.feedbacks
FOR ALL TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users u
    WHERE u.id = auth.uid() AND u.restaurant_id = feedbacks.restaurant_id
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.users u
    WHERE u.id = auth.uid() AND u.restaurant_id = feedbacks.restaurant_id
  )
);

-- users (staff) - minimal, non-recursive self-only policies (safe for login)
CREATE POLICY users_self_select ON public.users
FOR SELECT TO authenticated
USING (
  id = auth.uid()
);

CREATE POLICY users_self_update ON public.users
FOR UPDATE TO authenticated
USING (
  id = auth.uid()
)
WITH CHECK (
  id = auth.uid()
);

-- activity_logs
CREATE POLICY activity_logs_read_own ON public.activity_logs
FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users u
    WHERE u.id = auth.uid() AND u.restaurant_id = activity_logs.restaurant_id
  )
);

CREATE POLICY activity_logs_rw_own ON public.activity_logs
FOR ALL TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users u
    WHERE u.id = auth.uid() AND u.restaurant_id = activity_logs.restaurant_id
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.users u
    WHERE u.id = auth.uid() AND u.restaurant_id = activity_logs.restaurant_id
  )
);

-- ============================================================================
-- Usage examples (copy/paste into SQL editor)
-- ============================================================================
-- SELECT
--   select * from public.menu_items where restaurant_id = '550e8400-e29b-41d4-a716-446655440000' order by category, name;
-- INSERT
--   insert into public.orders (restaurant_id, table_id, table_number, items, subtotal, tax, total)
--   values ('550e8400-e29b-41d4-a716-446655440000', 'TABLE_UUID', '1', '[]', 0, 0, 0);
-- FEEDBACKS
--   insert into public.feedbacks (restaurant_id, order_id, rating, comment)
--   values ('550e8400-e29b-41d4-a716-446655440000', 'ORDER_UUID', 5, 'Great!');
-- ============================================================================
