-- =========================================================================
-- COMPLETE FIX: Restaurant RLS Policies + Set Owner
-- =========================================================================
-- This script fixes all RLS issues preventing restaurant creation
-- Run this in Supabase SQL Editor
-- =========================================================================

-- Step 1: Drop ALL existing policies on restaurants table
DROP POLICY IF EXISTS "restaurants_select" ON restaurants;
DROP POLICY IF EXISTS "restaurant_read_own" ON restaurants;
DROP POLICY IF EXISTS "restaurants_owner_all" ON restaurants;
DROP POLICY IF EXISTS "restaurants_read_public" ON restaurants;
DROP POLICY IF EXISTS "Owners can view all restaurants" ON restaurants;
DROP POLICY IF EXISTS "Owners can insert restaurants" ON restaurants;
DROP POLICY IF EXISTS "Owners can update restaurants" ON restaurants;
DROP POLICY IF EXISTS "Owners can delete restaurants" ON restaurants;
DROP POLICY IF EXISTS "Restaurant owners can view their payment credentials" ON restaurants;
DROP POLICY IF EXISTS "Restaurant owners can update their payment credentials" ON restaurants;
DROP POLICY IF EXISTS "Superadmins can manage all payment credentials" ON restaurants;

-- Step 2: Ensure RLS is enabled
ALTER TABLE restaurants ENABLE ROW LEVEL SECURITY;

-- Step 3: Drop our new policies too (in case they already exist)
DROP POLICY IF EXISTS "owners_select_all_restaurants" ON restaurants;
DROP POLICY IF EXISTS "owners_insert_restaurants" ON restaurants;
DROP POLICY IF EXISTS "owners_update_restaurants" ON restaurants;
DROP POLICY IF EXISTS "owners_delete_restaurants" ON restaurants;
DROP POLICY IF EXISTS "managers_select_own_restaurant" ON restaurants;

-- Step 3b: Create clean, simple policies for owners
CREATE POLICY "owners_select_all_restaurants" ON restaurants
    FOR SELECT
    USING (public.is_owner() = TRUE);

CREATE POLICY "owners_insert_restaurants" ON restaurants
    FOR INSERT
    WITH CHECK (public.is_owner() = TRUE);

CREATE POLICY "owners_update_restaurants" ON restaurants
    FOR UPDATE
    USING (public.is_owner() = TRUE)
    WITH CHECK (public.is_owner() = TRUE);

CREATE POLICY "owners_delete_restaurants" ON restaurants
    FOR DELETE
    USING (public.is_owner() = TRUE);

-- Step 4: Allow managers to view their own restaurant
CREATE POLICY "managers_select_own_restaurant" ON restaurants
    FOR SELECT
    USING (
        id IN (
            SELECT restaurant_id 
            FROM public.users 
            WHERE id = auth.uid()
        )
    );

-- Step 5: Set your user as owner (REPLACE WITH YOUR EMAIL)
UPDATE public.users 
SET is_owner = TRUE, 
    role = 'owner',
    is_active = TRUE
WHERE email = 'YOUR-EMAIL-HERE@example.com';  -- ⚠️ CHANGE THIS!

-- Step 6: Verify your user is now owner
SELECT 
    id, 
    email, 
    role, 
    is_owner, 
    is_active,
    created_at
FROM public.users 
WHERE is_owner = TRUE OR role = 'owner';

-- Step 7: Test the is_owner() function
SELECT 
    auth.uid() as current_user_id,
    public.is_owner() as is_owner_result,
    (SELECT email FROM public.users WHERE id = auth.uid()) as current_email;

-- =========================================================================
-- Expected Results:
-- 1. All old policies dropped
-- 2. New clean policies created
-- 3. Your user should show: is_owner = TRUE, role = 'owner'
-- 4. is_owner() function should return TRUE
-- =========================================================================
