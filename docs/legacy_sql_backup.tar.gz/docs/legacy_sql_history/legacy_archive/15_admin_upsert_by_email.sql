-- ============================================================================
-- Add helper RPC to upsert user profile by email
-- Purpose: Allow a manager/admin to link an existing Auth user to their restaurant
-- without needing the user's UUID. Resolves common case where account exists
-- but `public.users` row is missing.
-- Run after 10_multitenancy.sql, 13_users_rls_self.sql, and 14_staff_admin.sql
-- ============================================================================

CREATE OR REPLACE FUNCTION public.admin_upsert_user_profile_by_email(
  p_email text,
  p_full_name text,
  p_role text,
  p_phone text
) RETURNS public.users
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  me public.users;
  target_id uuid;
  rid uuid;
BEGIN
  -- Ensure caller is a staff member with manager/admin role
  SELECT * INTO me FROM public.users WHERE id = auth.uid();
  IF me.id IS NULL THEN RAISE EXCEPTION 'Not a staff user'; END IF;
  IF me.role NOT IN ('manager','admin') THEN RAISE EXCEPTION 'Insufficient role'; END IF;
  rid := me.restaurant_id;

  -- Find Auth user by email
  SELECT u.id INTO target_id
  FROM auth.users u
  WHERE lower(u.email) = lower(p_email)
  LIMIT 1;

  IF target_id IS NULL THEN
    RAISE EXCEPTION 'Auth user with email % not found', p_email;
  END IF;

  -- Delegate to existing upsert (enforces role validation and same-restaurant constraint)
  RETURN public.admin_upsert_user_profile(
    target_id,
    p_email,
    p_full_name,
    p_role,
    p_phone,
    rid
  );
END$$;

REVOKE ALL ON FUNCTION public.admin_upsert_user_profile_by_email(text, text, text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.admin_upsert_user_profile_by_email(text, text, text, text) TO authenticated;

-- ============================================================================