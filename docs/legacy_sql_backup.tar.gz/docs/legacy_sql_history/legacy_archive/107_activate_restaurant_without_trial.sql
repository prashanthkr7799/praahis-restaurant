-- ============================================================================
-- ACTIVATE RESTAURANT WITHOUT TRIAL FUNCTION
-- ============================================================================
-- Purpose: Allow restaurants to skip the 3-day trial period and activate
--          directly for billing. Useful when restaurant doesn't need a trial.
-- Usage: SELECT activate_restaurant_without_trial(restaurant_id)
-- Created: November 18, 2025
-- ============================================================================

DROP FUNCTION IF EXISTS activate_restaurant_without_trial(UUID);

CREATE OR REPLACE FUNCTION activate_restaurant_without_trial(
    p_restaurant_id UUID,
    p_subscription_days INTEGER DEFAULT 30
)
RETURNS JSONB AS $$
DECLARE
    v_subscription_id UUID;
    v_end_date TIMESTAMP WITH TIME ZONE;
    v_result JSONB;
BEGIN
    -- Calculate subscription end date
    v_end_date := NOW() + (p_subscription_days || ' days')::INTERVAL;

    -- Check if restaurant has an existing subscription
    IF EXISTS (SELECT 1 FROM subscriptions WHERE restaurant_id = p_restaurant_id) THEN
        -- Update existing subscription to active
        UPDATE subscriptions
        SET 
            status = 'active',
            start_date = NOW(),
            end_date = v_end_date,
            current_period_start = NOW(),
            current_period_end = v_end_date,
            trial_ends_at = NULL,
            grace_period_days = 3,
            plan_name = 'Per-Table Plan',
            price_per_table = 100.00,
            updated_at = NOW()
        WHERE restaurant_id = p_restaurant_id
        RETURNING id INTO v_subscription_id;
    ELSE
        -- Create new active subscription (skip trial)
        INSERT INTO subscriptions (
            restaurant_id,
            status,
            start_date,
            end_date,
            current_period_start,
            current_period_end,
            grace_period_days,
            plan_name,
            price_per_table
        ) VALUES (
            p_restaurant_id,
            'active',
            NOW(),
            v_end_date,
            NOW(),
            v_end_date,
            3,
            'Per-Table Plan',
            100.00
        )
        RETURNING id INTO v_subscription_id;
    END IF;

    -- Activate restaurant
    UPDATE restaurants
    SET 
        is_active = TRUE,
        updated_at = NOW()
    WHERE id = p_restaurant_id;

    -- Build success response
    v_result := jsonb_build_object(
        'success', true,
        'subscription_id', v_subscription_id,
        'restaurant_id', p_restaurant_id,
        'status', 'active',
        'subscription_starts', NOW(),
        'subscription_ends', v_end_date,
        'message', 'Restaurant activated without trial period'
    );

    RETURN v_result;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION activate_restaurant_without_trial IS 'Activate a restaurant directly without 3-day trial period. Useful for existing restaurants or special cases.';

-- Grant permissions
GRANT EXECUTE ON FUNCTION activate_restaurant_without_trial TO authenticated;

-- ============================================================================
-- SUCCESS MESSAGE
-- ============================================================================

DO $$
BEGIN
    RAISE NOTICE '
    ╔════════════════════════════════════════════════════════════════╗
    ║   ✅ ACTIVATE_RESTAURANT_WITHOUT_TRIAL FUNCTION CREATED        ║
    ╠════════════════════════════════════════════════════════════════╣
    ║                                                                ║
    ║   Function: activate_restaurant_without_trial()                ║
    ║   Purpose: Skip trial period and activate directly             ║
    ║   Default Subscription: 30 days from activation date            ║
    ║                                                                ║
    ║   Usage Example:                                               ║
    ║   SELECT activate_restaurant_without_trial(                    ║
    ║       restaurant_id::UUID,                                     ║
    ║       30  -- optional: days to activate for (default 30)       ║
    ║   );                                                            ║
    ║                                                                ║
    ╚════════════════════════════════════════════════════════════════╝
    ';
END $$;
