-- Fix mike@gmail.com ID mismatch
-- Delete the orphaned auth.users entry and keep the public.users entry

-- Step 1: Verify what we're about to delete
SELECT 
  id,
  email,
  created_at,
  'Will be deleted - orphaned auth user' as action
FROM auth.users
WHERE id = 'bf61d54a-59f4-4dcc-9817-ef8c543a42a9' 
  AND email = 'mike@gmail.com';

-- Step 2: Delete the orphaned auth.users entry
DELETE FROM auth.users 
WHERE id = 'bf61d54a-59f4-4dcc-9817-ef8c543a42a9' 
  AND email = 'mike@gmail.com';

-- Step 3: Verify the deletion
SELECT 
  'Orphaned user deleted' as message,
  COUNT(*) as remaining_auth_users
FROM auth.users
WHERE email = 'mike@gmail.com';

-- Step 4: Final verification - should show no entries or just the correct one
SELECT 
  au.id as auth_id,
  au.email as auth_email,
  pu.id as public_id,
  pu.email as public_email,
  CASE 
    WHEN au.id IS NULL THEN '⚠️ No auth.users entry (mike needs to be re-created properly)'
    WHEN au.id = pu.id THEN '✅ IDs match perfectly'
    ELSE '❌ Still mismatched'
  END as status
FROM public.users pu
LEFT JOIN auth.users au ON au.id = pu.id
WHERE pu.email = 'mike@gmail.com';
