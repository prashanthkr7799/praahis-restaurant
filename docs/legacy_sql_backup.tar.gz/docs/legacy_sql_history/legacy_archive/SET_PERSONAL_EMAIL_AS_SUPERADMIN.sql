-- ============================================================================
-- SET PERSONAL EMAIL AS MAIN SUPERADMIN AND DELETE OLD ADMIN ACCOUNT
-- ============================================================================
-- This script will:
-- 1. Ensure prashanthkumareddy879@gmail.com is set as SuperAdmin (is_owner = true)
-- 2. Delete admin@praahis.com from both auth.users and public.users
-- ============================================================================

BEGIN;

-- ============================================================================
-- STEP 1: Show current state (BEFORE changes)
-- ============================================================================

SELECT '=== CURRENT STATE BEFORE CHANGES ===' as info;

SELECT 
  email,
  role,
  is_owner,
  restaurant_id,
  created_at,
  CASE 
    WHEN is_owner = true THEN '✅ SUPERADMIN'
    WHEN role = 'admin' THEN '⚠️ ADMIN (not owner)'
    ELSE role
  END as account_type
FROM public.users
WHERE email IN ('admin@praahis.com', 'prashanthkumareddy879@gmail.com')
ORDER BY created_at;

-- ============================================================================
-- STEP 2: Make personal email the SuperAdmin (if not already)
-- ============================================================================

SELECT '=== SETTING prashanthkumareddy879@gmail.com AS SUPERADMIN ===' as info;

UPDATE public.users 
SET 
  is_owner = true,
  role = 'admin',
  restaurant_id = NULL,
  updated_at = NOW()
WHERE email = 'prashanthkumareddy879@gmail.com';

-- Verify the update
SELECT 
  email,
  role,
  is_owner,
  'Personal email is now SuperAdmin ✅' as status
FROM public.users
WHERE email = 'prashanthkumareddy879@gmail.com';

-- ============================================================================
-- STEP 3: Delete admin@praahis.com account
-- ============================================================================

SELECT '=== DELETING admin@praahis.com ACCOUNT ===' as info;

-- First, get the ID to show what we're deleting
SELECT 
  id,
  email,
  role,
  is_owner,
  'This account will be deleted' as status
FROM public.users
WHERE email = 'admin@praahis.com';

-- Delete from public.users (profile)
DELETE FROM public.users 
WHERE email = 'admin@praahis.com';

-- Delete from auth.users (authentication)
DELETE FROM auth.users 
WHERE email = 'admin@praahis.com';

-- ============================================================================
-- STEP 4: Verify final state
-- ============================================================================

SELECT '=== FINAL STATE AFTER CHANGES ===' as info;

SELECT 
  email,
  role,
  is_owner,
  restaurant_id,
  full_name,
  created_at,
  '✅ Your main SuperAdmin account' as status
FROM public.users
WHERE email = 'prashanthkumareddy879@gmail.com';

-- Check that admin@praahis.com is gone
SELECT '=== VERIFY admin@praahis.com IS DELETED ===' as info;

SELECT 
  CASE 
    WHEN COUNT(*) = 0 THEN '✅ admin@praahis.com successfully deleted'
    ELSE '⚠️ admin@praahis.com still exists!'
  END as deletion_status
FROM public.users
WHERE email = 'admin@praahis.com';

-- ============================================================================
-- STEP 5: Show all remaining admin accounts
-- ============================================================================

SELECT '=== ALL SUPERADMIN/ADMIN ACCOUNTS IN SYSTEM ===' as info;

SELECT 
  email,
  role,
  is_owner,
  restaurant_id,
  full_name,
  created_at,
  CASE 
    WHEN is_owner = true THEN '🔑 SUPERADMIN (Platform Owner)'
    WHEN role = 'admin' THEN '👤 ADMIN'
    WHEN role = 'manager' THEN '👨‍💼 MANAGER'
    ELSE role
  END as account_type
FROM public.users
WHERE role IN ('admin', 'manager') OR is_owner = true
ORDER BY is_owner DESC NULLS LAST, created_at;

COMMIT;

-- ============================================================================
-- ✅ SCRIPT COMPLETE!
-- ============================================================================
-- Your SuperAdmin account is now:
-- 
-- Email: prashanthkumareddy879@gmail.com
-- Password: 123456 (⚠️ CHANGE THIS IMMEDIATELY AFTER LOGIN!)
-- Login URL: http://localhost:5173/superadmin-login
-- 
-- IMPORTANT NEXT STEPS:
-- 1. Clear your browser cache and localStorage
-- 2. Login at /superadmin-login with your personal email
-- 3. IMMEDIATELY change your password from 123456 to something secure!
-- 4. Test that you can access SuperAdmin Dashboard
-- 5. Proceed with testing workflow (create restaurant, add manager, etc.)
-- 
-- Security Warning: 
-- The password "123456" is weak! Change it immediately:
-- 1. Go to http://localhost:5173/superadmin-forgot-password
-- 2. Enter: prashanthkumareddy879@gmail.com
-- 3. Check your email for reset link
-- 4. Set a strong password (min 8 chars, mix of letters/numbers/symbols)
-- ============================================================================
