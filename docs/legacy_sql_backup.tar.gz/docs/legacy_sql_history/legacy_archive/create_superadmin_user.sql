-- =========================================================================
-- CREATE SUPERADMIN USER
-- =========================================================================
-- Creates a new superadmin user with owner privileges
-- =========================================================================

-- Insert a new superadmin user (you'll need to set password via Supabase Auth UI)
-- First, create the user in Supabase Auth Dashboard, then run this:

INSERT INTO public.users (
    id,
    email,
    full_name,
    role,
    is_owner,
    is_active,
    restaurant_id
) VALUES (
    'YOUR-AUTH-USER-UUID-HERE',  -- Get this from Supabase Auth > Users
    'superadmin@example.com',      -- Your email
    'Super Admin',                  -- Your name
    'owner',                        -- Role
    TRUE,                           -- is_owner flag
    TRUE,                           -- Active
    NULL                            -- No restaurant_id for superadmin
)
ON CONFLICT (id) DO UPDATE SET
    is_owner = TRUE,
    role = 'owner',
    is_active = TRUE;

-- Verify
SELECT id, email, role, is_owner, is_active 
FROM public.users 
WHERE email = 'superadmin@example.com';

-- =========================================================================
