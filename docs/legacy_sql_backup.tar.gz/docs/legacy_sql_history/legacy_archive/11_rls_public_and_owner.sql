-- ============================================================================
-- RLS hardening for multitenancy: public (customer) access + owner bypass
-- Safe/idempotent where possible. Run after 10_multitenancy.sql
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 0) Helper: detect owner users (Praahis owner bypass)
-- Assumes application-level 'users.role' contains 'owner' for the platform owner
CREATE OR REPLACE FUNCTION public.is_owner()
RETURNS BOOLEAN AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.users u
    WHERE u.id = auth.uid() AND lower(u.role) = 'owner'
  );
$$ LANGUAGE sql STABLE SECURITY DEFINER;

COMMENT ON FUNCTION public.is_owner() IS 'True when current auth.uid() is platform owner (role=owner)';

-- 1) Owner bypass: grant broad access via additional policies without changing existing ones
-- For every multitenant table, add an owner policy allowing all operations
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='restaurants' AND policyname='restaurants_owner_all'
  ) THEN
    CREATE POLICY restaurants_owner_all ON public.restaurants
    FOR ALL TO authenticated
    USING (public.is_owner())
    WITH CHECK (public.is_owner());
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='tables' AND policyname='tables_owner_all'
  ) THEN
    CREATE POLICY tables_owner_all ON public.tables
    FOR ALL TO authenticated
    USING (public.is_owner())
    WITH CHECK (public.is_owner());
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='menu_items' AND policyname='menu_items_owner_all'
  ) THEN
    CREATE POLICY menu_items_owner_all ON public.menu_items
    FOR ALL TO authenticated
    USING (public.is_owner())
    WITH CHECK (public.is_owner());
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='orders' AND policyname='orders_owner_all'
  ) THEN
    CREATE POLICY orders_owner_all ON public.orders
    FOR ALL TO authenticated
    USING (public.is_owner())
    WITH CHECK (public.is_owner());
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='payments' AND policyname='payments_owner_all'
  ) THEN
    CREATE POLICY payments_owner_all ON public.payments
    FOR ALL TO authenticated
    USING (public.is_owner())
    WITH CHECK (public.is_owner());
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='offers' AND policyname='offers_owner_all'
  ) THEN
    CREATE POLICY offers_owner_all ON public.offers
    FOR ALL TO authenticated
    USING (public.is_owner())
    WITH CHECK (public.is_owner());
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='feedbacks' AND policyname='feedbacks_owner_all'
  ) THEN
    CREATE POLICY feedbacks_owner_all ON public.feedbacks
    FOR ALL TO authenticated
    USING (public.is_owner())
    WITH CHECK (public.is_owner());
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='users' AND policyname='users_owner_all'
  ) THEN
    CREATE POLICY users_owner_all ON public.users
    FOR ALL TO authenticated
    USING (public.is_owner())
    WITH CHECK (public.is_owner());
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='activity_logs' AND policyname='activity_logs_owner_all'
  ) THEN
    CREATE POLICY activity_logs_owner_all ON public.activity_logs
    FOR ALL TO authenticated
    USING (public.is_owner())
    WITH CHECK (public.is_owner());
  END IF;
END$$;

-- 2) Public (anon) read policies for customer endpoints
-- Allow read-only access for active restaurants and content, but enforce row guards

-- Restaurants: anon can read active restaurants (to resolve slug -> id)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='restaurants' AND policyname='restaurants_read_public'
  ) THEN
    CREATE POLICY restaurants_read_public ON public.restaurants
    FOR SELECT TO anon
    USING (is_active = TRUE);
  END IF;
END$$;

-- Menu Items: anon can read available items of active restaurants
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='menu_items' AND policyname='menu_items_read_public'
  ) THEN
    CREATE POLICY menu_items_read_public ON public.menu_items
    FOR SELECT TO anon
    USING (
      is_available = TRUE
      AND EXISTS (
        SELECT 1 FROM public.restaurants r
        WHERE r.id = menu_items.restaurant_id AND r.is_active = TRUE
      )
    );
  END IF;
END$$;

-- Tables: anon can read active tables (to show table name/capacity if needed)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='tables' AND policyname='tables_read_public'
  ) THEN
    CREATE POLICY tables_read_public ON public.tables
    FOR SELECT TO anon
    USING (
      is_active = TRUE
      AND EXISTS (
        SELECT 1 FROM public.restaurants r
        WHERE r.id = tables.restaurant_id AND r.is_active = TRUE
      )
    );
  END IF;
END$$;

-- Orders: anon can insert orders only for active restaurants and must provide restaurant_id/table relations
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='orders' AND policyname='orders_insert_public'
  ) THEN
    CREATE POLICY orders_insert_public ON public.orders
    FOR INSERT TO anon
    WITH CHECK (
      -- Ensure restaurant is active
      EXISTS (
        SELECT 1 FROM public.restaurants r
        WHERE r.id = orders.restaurant_id AND r.is_active = TRUE
      )
      AND (
        -- Ensure table belongs to same restaurant if provided
        orders.table_id IS NULL OR EXISTS (
          SELECT 1 FROM public.tables t
          WHERE t.id = orders.table_id AND t.restaurant_id = orders.restaurant_id AND t.is_active = TRUE
        )
      )
    );
  END IF;
END$$;

-- Orders: anon can read their order by id only to check status (optional, narrow)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='orders' AND policyname='orders_read_public_limited'
  ) THEN
    CREATE POLICY orders_read_public_limited ON public.orders
    FOR SELECT TO anon
    USING (
      -- Restrict to orders with NULL user_id or created via public flow; fallback: allow read only by id with active restaurant
      EXISTS (
        SELECT 1 FROM public.restaurants r
        WHERE r.id = orders.restaurant_id AND r.is_active = TRUE
      )
    );
  END IF;
END$$;

-- Feedbacks: anon can insert feedback for active restaurants
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='feedbacks' AND policyname='feedbacks_insert_public'
  ) THEN
    CREATE POLICY feedbacks_insert_public ON public.feedbacks
    FOR INSERT TO anon
    WITH CHECK (
      EXISTS (
        SELECT 1 FROM public.restaurants r
        WHERE r.id = feedbacks.restaurant_id AND r.is_active = TRUE
      )
      AND EXISTS (
        SELECT 1 FROM public.orders o
        WHERE o.id = feedbacks.order_id AND o.restaurant_id = feedbacks.restaurant_id
      )
    );
  END IF;
END$$;

-- 3) Public RPC wrappers (SECURITY DEFINER) to enforce QR context server-side
-- These functions encapsulate tenant checks so the client can call as anon safely.

-- 3.a) Resolve menu items by restaurant slug
CREATE OR REPLACE FUNCTION public.public_api_get_menu_items(p_slug text)
RETURNS SETOF public.menu_items AS $$
BEGIN
  RETURN QUERY
  SELECT mi.*
  FROM public.menu_items mi
  JOIN public.restaurants r ON r.id = mi.restaurant_id
  WHERE lower(r.slug) = lower(p_slug)
    AND r.is_active = TRUE
    AND mi.is_available = TRUE
  ORDER BY mi.category, mi.name;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION public.public_api_get_menu_items(text) TO anon, authenticated;

-- 3.b) Get table by slug and table_number
CREATE OR REPLACE FUNCTION public.public_api_get_table(p_slug text, p_table_number text)
RETURNS public.tables AS $$
DECLARE v_table public.tables;
BEGIN
  SELECT t.* INTO v_table
  FROM public.tables t
  JOIN public.restaurants r ON r.id = t.restaurant_id
  WHERE lower(r.slug) = lower(p_slug)
    AND r.is_active = TRUE
    AND t.table_number = p_table_number
    AND t.is_active = TRUE
  LIMIT 1;
  RETURN v_table;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION public.public_api_get_table(text, text) TO anon, authenticated;

-- 3.c) Create order by slug + table_number
CREATE OR REPLACE FUNCTION public.public_api_create_order(
  p_slug text,
  p_table_number text,
  p_items jsonb,
  p_subtotal numeric,
  p_tax numeric,
  p_total numeric
)
RETURNS public.orders AS $$
DECLARE v_restaurant_id uuid; v_table_id uuid; v_session uuid; v_order public.orders;
BEGIN
  SELECT id INTO v_restaurant_id FROM public.restaurants WHERE lower(slug)=lower(p_slug) AND is_active=TRUE LIMIT 1;
  IF v_restaurant_id IS NULL THEN RAISE EXCEPTION 'Restaurant not found or inactive'; END IF;

  SELECT id, active_session_id INTO v_table_id, v_session
  FROM public.tables
  WHERE restaurant_id=v_restaurant_id AND table_number=p_table_number AND is_active=TRUE
  LIMIT 1;
  IF v_table_id IS NULL THEN RAISE EXCEPTION 'Table not found'; END IF;

  IF v_session IS NULL THEN v_session := uuid_generate_v4(); END IF;

  INSERT INTO public.orders (restaurant_id, table_id, table_number, items, subtotal, tax, total, order_status, session_id, created_at, updated_at)
  VALUES (v_restaurant_id, v_table_id, p_table_number, p_items, p_subtotal, p_tax, p_total, 'pending', v_session, NOW(), NOW())
  RETURNING * INTO v_order;

  -- ensure table has active_session_id set
  UPDATE public.tables SET status='occupied', active_session_id=v_session, booked_at=COALESCE(booked_at, NOW()), updated_at=NOW()
  WHERE id=v_table_id;

  RETURN v_order;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION public.public_api_create_order(text, text, jsonb, numeric, numeric, numeric) TO anon, authenticated;

-- 3.d) Submit feedback by order id + slug (guards tenant)
CREATE OR REPLACE FUNCTION public.public_api_submit_feedback(
  p_slug text,
  p_order_id uuid,
  p_rating int,
  p_comment text,
  p_item_ratings jsonb DEFAULT '[]'::jsonb
)
RETURNS VOID AS $$
DECLARE v_restaurant_id uuid; v_table_id uuid;
BEGIN
  SELECT id INTO v_restaurant_id FROM public.restaurants WHERE lower(slug)=lower(p_slug) AND is_active=TRUE LIMIT 1;
  IF v_restaurant_id IS NULL THEN RAISE EXCEPTION 'Restaurant not found or inactive'; END IF;

  PERFORM 1 FROM public.orders o WHERE o.id=p_order_id AND o.restaurant_id=v_restaurant_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'Order does not belong to restaurant'; END IF;

  INSERT INTO public.feedbacks (order_id, rating, comment, restaurant_id, created_at)
  VALUES (p_order_id, p_rating, NULLIF(p_comment,''), v_restaurant_id, NOW());

  -- Per-item ratings array of objects: [{menu_item_id, rating}]
  INSERT INTO public.menu_item_ratings (order_id, menu_item_id, rating, restaurant_id, created_at)
  SELECT p_order_id, (elem->>'menu_item_id')::uuid, (elem->>'rating')::int, v_restaurant_id, NOW()
  FROM jsonb_array_elements(p_item_ratings) elem
  WHERE (elem->>'rating') IS NOT NULL;

  -- Mark feedback submitted
  UPDATE public.orders SET feedback_submitted=TRUE, feedback_submitted_at=NOW(), updated_at=NOW()
  WHERE id=p_order_id AND restaurant_id=v_restaurant_id;

  -- Free table
  UPDATE public.tables t SET status='available', active_session_id=NULL, updated_at=NOW()
  FROM public.orders o
  WHERE o.id=p_order_id AND o.restaurant_id=v_restaurant_id AND t.id=o.table_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION public.public_api_submit_feedback(text, uuid, int, text, jsonb) TO anon, authenticated;

-- ============================================================================
-- End of file
-- ============================================================================
